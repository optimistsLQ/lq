package com.foxconn.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.foxconn.entity.ParamDTO;
import com.foxconn.entity.ReportEntity;
import com.foxconn.entity.Result;
import com.foxconn.entity.ResultCode;
import com.foxconn.service.BaseService;
import com.github.pagehelper.PageInfo;

@RestController
@RequestMapping("report")
@CrossOrigin
public class ReportController {

	@Autowired
	private BaseService baseService;
	
	@RequestMapping("/addReport.do")
	public Result addReport(ReportEntity report) {
		Result r = null;
		ArrayList<ReportEntity> arrayList = new ArrayList<ReportEntity>();
		arrayList.add(report);
		Integer i = baseService.addData(arrayList, ReportEntity.class);
		if (i > 0) {
			r = new Result(ResultCode.SUCCESS);
		}else {
			
			r = new Result(ResultCode.FAIL);
		}
		return r;
	}
	
	@RequestMapping("/delReport.do")
	public Map<String, String> delReport(@RequestBody List<String> ids) {
		Map<String, String> msg = new HashMap<String, String>();
		Integer i = baseService.delData(ids, ReportEntity.class);
		if (i > 0) {
			msg.put("msg", "OK");
		}else {
			msg.put("msg", "NG");
		}
		return msg;
	}
	
	@RequestMapping("/updateReport.do")
	public Map<String, String> updateReport(ReportEntity report) {
		Map<String, String> msg = new HashMap<String, String>();
		Integer i = baseService.updateData(report);
		if (i > 0) {
			msg.put("msg", "OK");
		}else {
			msg.put("msg", "NG");
		}
		return msg;
	}
	
	@RequestMapping("/findReport.do")
	public Map<String,Object> findReport(ParamDTO param){
		System.out.println(param);
		Map<String, Object> queryMap = new HashMap<String, Object>();
		if (!ObjectUtils.isEmpty(param.getSearch1())) {
			queryMap.put("REPORT_TITLE",param.getSearch1());
		}
		PageInfo<ReportEntity> info = baseService.findByItem(ReportEntity.class, queryMap, param);
		Map<String,Object> result = new HashMap<String,Object>();
		result.put("iTotalDisplayRecords", info.getTotal());
		result.put("iTotalRecords", info.getTotal());
		result.put("data", info.getList());
		return result;
	}
	
	/**vue页面请求公告接口
	 * @param param
	 * @return
	 */
	@RequestMapping("/findReportToVue.do")
	public List<ReportEntity> findReportToVue(){
//	    ParamDTO param = new ParamDTO();
//		System.out.println("132>>"+param);
		Map<String, Object> queryMap = new HashMap<String, Object>();
//		if (!ObjectUtils.isEmpty(param.getSearch1())) {
//			queryMap.put("REPORT_TITLE",param.getSearch1());
//		}
		PageInfo<ReportEntity> info = baseService.findByItem(ReportEntity.class, queryMap, null);
//		System.out.println(">123>>"+info.getList());
		return info.getList();
	}
	
	@RequestMapping("/findReportById.do")
	public ReportEntity findReprotById(String reportId){
	    return baseService.findOneById(reportId, ReportEntity.class);
	}
	
}
