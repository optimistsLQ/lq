package com.foxconn.controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSON;
import com.foxconn.entity.AuditPeople;
import com.foxconn.entity.ParamDTO;
import com.foxconn.service.BaseService;
import com.foxconn.utils.Utils;
import com.github.pagehelper.PageInfo;

@CrossOrigin
@Controller
@RequestMapping("auditPeople")
public class AuditPeopleController {

	@Autowired
	private BaseService service;
	
	/**excel上传批量插入数据
	 * @param file
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "addAuditPeople.do",method = RequestMethod.POST)
	@ResponseBody
	public HashMap<String, String> addAuditPeople(@RequestParam(value="") MultipartFile file) throws IOException  {
		HashMap<String, String> msgMap = new HashMap<String, String>();
		String fileName = file.getOriginalFilename();
		if (!fileName.endsWith(".xls") && !fileName.endsWith(".xlsx")) {
			msgMap.put("NG", "文件错误，请上传Excel文档");
		}else {
			List<AuditPeople> excelList = Utils.readExcel(file, AuditPeople.class);
			Integer i = service.addData(excelList, AuditPeople.class);
			msgMap.put("OK", "上传成功");
		}
		return msgMap;
	}
	
	@RequestMapping("delData.do")
	@ResponseBody
	public Map<String, String> delData(@RequestBody List<String> ids) {
		Map<String, String> msg = new HashMap<String, String>();
		Integer i = service.delData(ids, AuditPeople.class);
		if (i > 0) {
			msg.put("msg", "OK");
		}else {
			msg.put("msg", "NG");
		}
		return msg;
	}
	
	@RequestMapping("updateData.do")
	@ResponseBody
	public Map<String, String> updateData(AuditPeople obj){
		Map<String, String> msg = new HashMap<String, String>();
		Integer i = service.updateData(obj);
		if (i > 0) {
			msg.put("msg", "OK");
		}else {
			msg.put("msg", "NG");
		}
		return msg;
	}
	@RequestMapping("findOneData.do")
	@ResponseBody
	public AuditPeople getAuditPeople(@RequestParam String id) {
		AuditPeople auditPeople = service.findOneById(id, AuditPeople.class);
		return auditPeople;
	}
	
	@RequestMapping("findByItem.do")
	@ResponseBody
	public Map<String,Object> findByItem(ParamDTO param){
		Map<String, Object> queryMap = new HashMap<String, Object>();
		if (!ObjectUtils.isEmpty(param.getSearch1())) {
			queryMap.put("JOB_CARD",param.getSearch1());
		}
		
		if (!ObjectUtils.isEmpty(param.getSearch2())) {
			queryMap.put("station_Nature",param.getSearch2());
		}
		
		
		PageInfo<AuditPeople> info = service.findByItem(AuditPeople.class, queryMap, param);
		Map<String,Object> result = new HashMap<String,Object>();
		result.put("iTotalDisplayRecords", info.getTotal());
		result.put("iTotalRecords", info.getTotal());
		result.put("data", info.getList());
		return result;
	}
	
	@RequestMapping(value = "/findAllAuditPeople.do", produces = "application/json;charset=utf-8")
	@ResponseBody
	public String findAllAuditPeople() {
		PageInfo<AuditPeople> info = service.findByItem(AuditPeople.class, null, null);
		return JSON.toJSONString(info.getList());
	}
}
