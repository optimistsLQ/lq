package com.foxconn.controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSONObject;
import com.foxconn.entity.AuditPeople;
import com.foxconn.entity.DiningRoom;
import com.foxconn.entity.ManagementStandard;
import com.foxconn.entity.ParamDTO;
import com.foxconn.entity.SelfCheck;
import com.foxconn.service.BaseService;
import com.foxconn.utils.Utils;
import com.github.pagehelper.PageInfo;

@CrossOrigin
@Controller
@RequestMapping("selfCheck")
public class SelfCheckController {

	@Autowired
	private BaseService service;
	
	/**excel上传批量插入数据
	 * @param file
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "addSelfCheck.do",method = RequestMethod.POST)
	@ResponseBody
	public HashMap<String, String> addSelfCheck(@RequestParam(value="") MultipartFile file) throws IOException  {
		HashMap<String, String> msgMap = new HashMap<String, String>();
		String fileName = file.getOriginalFilename();
		if (!fileName.endsWith(".xls") && !fileName.endsWith(".xlsx")) {
			msgMap.put("NG", "文件错误，请上传Excel文档");
		}else {
			
			List<SelfCheck> excelList = Utils.readExcel(file, SelfCheck.class);
			Integer i = service.addData(excelList, SelfCheck.class);
			msgMap.put("OK", "上传成功");
		}
		
		return msgMap;
	}
	
	@RequestMapping("delData.do")
	@ResponseBody
	public Map<String, String> delData(@RequestBody List<String> ids) {
		Map<String, String> msg = new HashMap<String, String>();
		Integer i = service.delData(ids, SelfCheck.class);
		if (i > 0) {
			msg.put("msg", "OK");
		}else {
			msg.put("msg", "NG");
		}
		return msg;
	}
	
	@RequestMapping("updateData.do")
	@ResponseBody
	public Map<String, String> updateData(SelfCheck param){
		Map<String, String> msg = new HashMap<String, String>();
		Integer i = service.updateData(param);
		if (i > 0) {
			msg.put("msg", "OK");
		}else {
			msg.put("msg", "NG");
		}
		return msg;
	}
	@RequestMapping("findOneData.do")
	@ResponseBody
	public String getDingroom(@RequestParam String id) {
		SelfCheck dingroom = service.findOneById(id, SelfCheck.class);
		return "123";
	}
	
	@RequestMapping("findByItem.do")
	@ResponseBody
	public Map<String,Object> findByItem(ParamDTO param){
		Map<String, Object> queryMap = new HashMap<String, Object>();
		if (!ObjectUtils.isEmpty(param.getSearch1())) {
			queryMap.put("TYPE_BIG_NAME",param.getSearch1());
		}
		
		if (!ObjectUtils.isEmpty(param.getSearch2())) {
			queryMap.put("TYPE_SMALL_NAME",param.getSearch2());
		}
		
		PageInfo<SelfCheck> info = service.findByItem(SelfCheck.class, queryMap, param);
		Map<String,Object> result = new HashMap<String,Object>();
		result.put("iTotalDisplayRecords", info.getTotal());
		result.put("iTotalRecords", info.getTotal());
		result.put("data", info.getList());
		return result;
	}
	
//	@RequestMapping("/getCondition.do")
//	@ResponseBody
//	public Map<String, Set<String>> getCondition() {
//		Map<String, Set<String>> map = new HashMap<String, Set<String>>();
//		ParamDTO param = new ParamDTO();
//		param.setStart(0);param.setLength(Integer.MAX_VALUE);
//		PageInfo<SelfCheck> info = service.findByItem(SelfCheck.class, null, param);
//		if (ObjectUtils.isEmpty(info.getList())) {
//			return null;
//		}else {
//			
//			for (SelfCheck din : info.getList()) {
//				String bigName = din.getTypeBigName();
//				Set<String> smallSet = map.get(bigName);
//				if (ObjectUtils.isEmpty(smallSet)) {
//					HashSet<String> hashSet = new HashSet<String>();
//					map.put(bigName, hashSet);
//				}
//				smallSet = map.get(bigName);
//				smallSet.add(din.getTypeSmallName());
//			}
//			
//			return map;
//		}
//	}
}
