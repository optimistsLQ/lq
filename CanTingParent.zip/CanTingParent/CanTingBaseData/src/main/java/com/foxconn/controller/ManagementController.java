package com.foxconn.controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.foxconn.entity.AuditPeople;
import com.foxconn.entity.DiningRoom;
import com.foxconn.entity.ManagementStandard;
import com.foxconn.entity.ParamDTO;
import com.foxconn.service.BaseService;
import com.foxconn.utils.Utils;
import com.github.pagehelper.PageInfo;

@CrossOrigin
@Controller
@RequestMapping("management")
public class ManagementController {

	@Autowired
	private BaseService service;
	
	/**excel上传批量插入数据
	 * @param file
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "addmanagement.do",method = RequestMethod.POST)
	@ResponseBody
	public HashMap<String, String> addmanagement(@RequestParam(value="") MultipartFile file) throws IOException  {
		HashMap<String, String> msgMap = new HashMap<String, String>();
		String fileName = file.getOriginalFilename();
		if (!fileName.endsWith(".xls") && !fileName.endsWith(".xlsx")) {
			msgMap.put("NG", "文件错误，请上传Excel文档");
		}else {
			
			List<ManagementStandard> excelList = Utils.readExcel(file, ManagementStandard.class);
			Integer i = service.addData(excelList, ManagementStandard.class);
			msgMap.put("OK", "上传成功");
		}
		
		return msgMap;
	}
	
	@RequestMapping("delData.do")
	@ResponseBody
	public Map<String, String> delData(@RequestBody List<String> ids) {
		Map<String, String> msg = new HashMap<String, String>();
		Integer i = service.delData(ids, ManagementStandard.class);
		if (i > 0) {
			msg.put("msg", "OK");
		}else {
			msg.put("msg", "NG");
		}
		return msg;
	}
	
	@RequestMapping("updateData.do")
	@ResponseBody
	public Map<String, String> updateData(ManagementStandard param){
		Map<String, String> msg = new HashMap<String, String>();
		Integer i = service.updateData(param);
		if (i > 0) {
			msg.put("msg", "OK");
		}else {
			msg.put("msg", "NG");
		}
		return msg;
	}
	@RequestMapping("findOneData.do")
	@ResponseBody
	public String getDingroom(@RequestParam String id) {
		ManagementStandard dingroom = service.findOneById(id, ManagementStandard.class);
		return "123";
	}
	
	@RequestMapping("findByItem.do")
	@ResponseBody
	public Map<String,Object> findByItem(ParamDTO param){
		Map<String, Object> queryMap = new HashMap<String, Object>();
		if (!ObjectUtils.isEmpty(param.getSearch1())) {
			queryMap.put("TYPE_BIG_NAME",param.getSearch1());
		}
		
		if (!ObjectUtils.isEmpty(param.getSearch2())) {
			queryMap.put("TYPE_SMALL_NAME",param.getSearch2());
		}
		
		PageInfo<ManagementStandard> info = service.findByItem(ManagementStandard.class, queryMap, param);
		Map<String,Object> result = new HashMap<String,Object>();
		result.put("iTotalDisplayRecords", info.getTotal());
		result.put("iTotalRecords", info.getTotal());
		result.put("data", info.getList());
		return result;
	}
	
	/**稽核標準獲取人機料法環及對應的查詢條件
	 * @return
	 * {環=[前處理區, 清洗區, 防四害, 烹飪區, 內環境整體要求, 週邊衛生, 供餐專間, 庫房], 
	 * 法=[消防安全, 備餐供餐, 客戶服務, 其它, 食材貯存, 食品品質, 剩菜管控, 化學物品, 文件管制, 前處理, 采購驗收, 清洗, 烹飪], 
	 * 物=[化學物品, 食品加工, 食品留樣, 餐器具, 食材及食材相關, 輔助器具], 人=[人員衛生管理, 人員健康管理, 其它], 其他=[檢測與測量, 防四害],
	 * 機=[監控設備, 運輸工具, 保潔設備, 輔助設施設備, 生產設備], /=[前置條件]}
	 */
	@RequestMapping("/getCondition.do")
	@ResponseBody
	public Map<String, Set<String>> getCondition() {
		Map<String, Set<String>> map = new HashMap<String, Set<String>>();
		ParamDTO param = new ParamDTO();
		param.setStart(0);param.setLength(Integer.MAX_VALUE);
		PageInfo<ManagementStandard> info = service.findByItem(ManagementStandard.class, null, param);
		if (ObjectUtils.isEmpty(info.getList())) {
			return null;
		}else {
			
			for (ManagementStandard din : info.getList()) {
				String bigName = din.getTypeBigName();
				Set<String> smallSet = map.get(bigName);
				if (ObjectUtils.isEmpty(smallSet)) {
					HashSet<String> hashSet = new HashSet<String>();
					map.put(bigName, hashSet);
				}
				smallSet = map.get(bigName);
				smallSet.add(din.getTypeSmallName());
			}
			
			return map;
		}
	}
	
	/**獲取所有的稽核標準條件，并按人機料法環分類
	 * @return
	 */
	@RequestMapping(value = "getManagementByType.do",produces = "application/json;charset=utf-8")
	@ResponseBody
	public String getManagementByType() {
		ParamDTO param = new ParamDTO();
		param.setStart(0);param.setLength(Integer.MAX_VALUE);
		PageInfo<ManagementStandard> info = service.findByItem(ManagementStandard.class, null, param);
		Map<String, HashMap<String, List<ManagementStandard>>> map = new HashMap<String, HashMap<String,List<ManagementStandard>>>();
		if (ObjectUtils.isEmpty(info.getList())) {
			return null;
		}else {
			for (ManagementStandard din : info.getList()) {
				String bigName = "\""+din.getTypeBigName()+"\"";//人機料發還
				HashMap<String, List<ManagementStandard>> smallMap = map.get(bigName);
				if (ObjectUtils.isEmpty(smallMap)) {
					smallMap = new HashMap<String, List<ManagementStandard>>();
					map.put(bigName, smallMap);
				}
				smallMap = map.get(bigName);
				String smallName = "\""+din.getTypeSmallName()+"\"";
				List<ManagementStandard> standardList = smallMap.get(smallName);
				if (ObjectUtils.isEmpty(standardList)) {
					smallMap.put(smallName, new ArrayList<ManagementStandard>());
				}
				standardList = smallMap.get(smallName);
				standardList.add(din);
			}
		}
		return JSON.toJSONString(map);
	}
	public static void main(String[] args) {
		int number = 100;
	}
}
