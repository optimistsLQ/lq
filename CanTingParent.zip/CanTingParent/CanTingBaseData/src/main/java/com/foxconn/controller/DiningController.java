package com.foxconn.controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.foxconn.entity.DiningRoom;
import com.foxconn.entity.ImgFile;
import com.foxconn.entity.ParamDTO;
import com.foxconn.service.BaseService;
import com.foxconn.service.ImgFileService;
import com.foxconn.utils.Utils;
import com.github.pagehelper.PageInfo;

@CrossOrigin
@Controller
@RequestMapping("ding")
public class DiningController {

	@Autowired
	private BaseService service;
	@Autowired
	private ImgFileService imgService;
	
	/**excel上传批量插入数据
	 * @param file
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "addDining.do",method = RequestMethod.POST)
	@ResponseBody
	public HashMap<String, String> addDining(@RequestParam(value="") MultipartFile file) throws IOException  {
		HashMap<String, String> msgMap = new HashMap<String, String>();
		String fileName = file.getOriginalFilename();
		if (!fileName.endsWith(".xls") && !fileName.endsWith(".xlsx")) {
			msgMap.put("NG", "文件错误，请上传Excel文档");
		}else {
			List<DiningRoom> excelList = Utils.readExcel(file, DiningRoom.class);
//			if (org.apache.commons.lang3.ObjectUtils.isEmpty(excelList)) {
//				msgMap.put("NG", "解析0条数据");
//				return msgMap;
//			}
			Integer i = service.addData(excelList, DiningRoom.class);
			msgMap.put("OK", "上传成功");
		}
		
		return msgMap;
	}
	
	@RequestMapping("delData.do")
	@ResponseBody
	public Map<String, String> delData(@RequestBody List<String> ids) {
		Map<String, String> msg = new HashMap<String, String>();
		Integer i = service.delData(ids, DiningRoom.class);
		if (i > 0) {
			imgService.delImgByForeign(ids);
			msg.put("msg", "OK");
		}else {
			msg.put("msg", "NG");
		}
		return msg;
	}
	
	@RequestMapping("updateData.do")
	@ResponseBody
	public Map<String, String> updateData(DiningRoom param){
		Map<String, String> msg = new HashMap<String, String>();
		Integer i = service.updateData(param);
		if (i > 0) {
			msg.put("msg", "OK");
		}else {
			msg.put("msg", "NG");
		}
		return msg;
	}
	@RequestMapping("findOneData.do")
	@ResponseBody
	public String getDingroom(@RequestParam String id) {
		DiningRoom dingroom = service.findOneById(id, DiningRoom.class);
		return "123";
	}
	
	@RequestMapping("findByItem.do")
	@ResponseBody
	public Map<String,Object> findByItem(ParamDTO param){
		Map<String, Object> queryMap = new HashMap<String, Object>();
		if (!ObjectUtils.isEmpty(param.getSearch1())) {
			queryMap.put("dr_Name",param.getSearch1());
		}
		
		if (!ObjectUtils.isEmpty(param.getSearch2())) {
			queryMap.put("dr_Status",param.getSearch2());
		}
		
		PageInfo<DiningRoom> info = service.findByItem(DiningRoom.class, queryMap, param);
		Map<String,Object> result = new HashMap<String,Object>();
		result.put("iTotalDisplayRecords", info.getTotal());
		result.put("iTotalRecords", info.getTotal());
		result.put("data", info.getList());
		return result;
	}
	
	@RequestMapping(value = "/getAllDining.do",produces = "application/json;charset=utf-8")
	@ResponseBody
	public String getAllDining() {
		Set<String> set = null;
		ParamDTO param = new ParamDTO();
		param.setStart(0);
		param.setLength(Integer.MAX_VALUE );
		PageInfo<DiningRoom> info = service.findByItem(DiningRoom.class, null, param);
		return JSONObject.toJSONString(info.getList());
	}
	
	
	@RequestMapping("/getDiningdrStatus.do")
	@ResponseBody
	public Set<String> getDiningdrStatus() {
		Set<String> set = null;
		ParamDTO param = new ParamDTO();
		param.setStart(0);
		param.setLength(Integer.MAX_VALUE );
		PageInfo<DiningRoom> info = service.findByItem(DiningRoom.class, null, param);
		if (ObjectUtils.isEmpty(info.getList())) {
			return null;
		}else {
			set = new HashSet<String>();
			for (DiningRoom din : info.getList()) {
				set.add(din.getDrStatus());
			}
			return set;
		}
	}
	
	/**
	 * 查詢餐廳對應圖片
	 */
	@RequestMapping("getImgId.do")
	@ResponseBody
	public List<ImgFile> getImgId(String foreign) {
		List<ImgFile> imgList = imgService.getImgId(foreign);
		return imgList;
	}
	
	@RequestMapping("getImg.do")
	@ResponseBody
	public byte[] getImg(String imgId) {
		ImgFile imgFile = imgService.getImg(imgId);
		byte[] imgEntity = imgFile.getImgEntity();
		return imgEntity;
	}
	/**
	 * 添加圖片
	 * @throws Exception 
	 */
	@RequestMapping("/addImg.do")
	@ResponseBody
	public JSONObject addImg(ImgFile imgFile, @RequestParam MultipartFile file) {
		int i = 0;
		String uuid = UUID.randomUUID().toString().toUpperCase().replaceAll("-", "");
		try {
			imgFile.setImgId(uuid);
			imgFile.setImgEntity(file.getBytes());
			i = imgService.addImg(imgFile);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		JSONObject result = new JSONObject();
		if (i > 0) {
			result.put("statusText", "上傳成功");
			result.put("status", "success");
		}else {
			result.put("statusText", "文件不合格");
			result.put("status", "invalid");
			
		}
//		InputStream in = file.getInputStream();
//		OutputStream os = new FileOutputStream("D:\\1.jpg");
//		int len = 0;
//		byte[] b = new byte[1024];
//		while((len = in.read(b)) != -1) {
//			os.write(b, 0, len);
//		}
//		os.close();
//		in.close();
		return result;
	}
	
	@RequestMapping("/delImg.do")
	@ResponseBody
	public String delImg(String imgDelId) {
		List<String> idList = JSON.parseArray(imgDelId, String.class);
		
		int i = imgService.delImgs(idList);
		if (i > 0) {
			return "OK";
		}else {
			return "NG";
		}
	}
}
