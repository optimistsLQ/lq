package com.foxconn.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.foxconn.entity.CheckPeople;
import com.foxconn.entity.CheckProblem;
import com.foxconn.entity.ParamDTO;
import com.foxconn.service.CheckPeopleService;

/**稽核人controller
 * @author C3410596
 *
 */
@Controller
@RequestMapping("checkPeople")
@CrossOrigin
public class PeopleController {

	@Autowired
	private CheckPeopleService peopleService;
	 
	/**添加稽核人员
	 * @param people 稽核人对象
	 * @return 返回受影响 的行数
	 */
	@RequestMapping("/addPeople.do")
	@ResponseBody
	public String addPeople(@RequestBody CheckPeople people) {
		Integer i = peopleService.addCheckPeople(people);
		return String.valueOf(i);
	}
	
	/**根据id删除稽核人
	 * @param peopleId 稽核人id
	 * @return 返回受影响 的行数
	 */
	@RequestMapping("/delPeople.do")
	@ResponseBody
	public String delPeople(String peopleId) {
		Integer i = peopleService.delCheckPeople(peopleId);
		return i.toString();
	}
	
	/**修改稽核人
	 * @param people 稽核人对象
	 * @return 返回受影响 的行数
	 */
	@RequestMapping("/updatePeople.do")
	@ResponseBody
	public String updatePeople(CheckPeople people) {
		int i = peopleService.updateCheckPeople(people);
		return String.valueOf(i);
	}
	
}
