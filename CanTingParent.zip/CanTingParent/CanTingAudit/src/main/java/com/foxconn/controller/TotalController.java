package com.foxconn.controller;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.foxconn.entity.CheckPeople;
import com.foxconn.entity.CheckProblem;
import com.foxconn.entity.CheckTotal;
import com.foxconn.entity.Result;
import com.foxconn.entity.ResultCode;
import com.foxconn.entity.UserEntity;
import com.foxconn.service.CheckPeopleService;
import com.foxconn.service.CheckProblemService;
import com.foxconn.service.CheckTotalService;
import com.foxconn.utils.Utils;
import com.github.pagehelper.PageInfo;

@Controller
@RequestMapping("checkTotal")
@CrossOrigin
public class TotalController {

//	 稽核单接口核
	@Autowired
	private CheckTotalService totalService;
//	稽核单对应的稽核人员接口
	@Autowired
	private CheckPeopleService peopleService;
//	稽核单对应的集合问题接口
	@Autowired
	private CheckProblemService problemService;

	/**新增稽核单
	 * @param map <checkList:稽核单list，status：状态，代表稽核单单号以（p/c）开头>
	 * @param session
	 * @return
	 */
	@RequestMapping("/addTotal.do")
	@ResponseBody
	public Result addTotal(@RequestBody Map<String, Object> map,HttpSession session) {
		Result r =null;
		List<CheckTotal> checkTotalList = Utils.objToList(map.get("checkList"), CheckTotal.class);
		Integer i = 0;
		ArrayList<CheckTotal> totalList = new ArrayList<CheckTotal>();
		ArrayList<CheckPeople> peopleList = new ArrayList<CheckPeople>();
		/**
		 * 1.给稽核单设置UUID和创建人工号
		 * 2.给对应的稽核人员设置外键
		 */
		for (CheckTotal checkTotal : checkTotalList) {
			String totalId = map.get("status") + UUID.randomUUID().toString().replaceAll("-", "");
			checkTotal.setChecktotalId(totalId);
			// TODO 此处获取当前用户并设置进去
			UserEntity userEntity = (UserEntity) session.getAttribute("user");
			checkTotal.setCreateUser(userEntity.getCardNum());
			totalList.add(checkTotal);
			for (CheckPeople checkPeople : checkTotal.getPeopleList()) {
				checkPeople.setCheckTotalId(totalId);
				peopleList.add(checkPeople);
			}
		}
		/**
		 * 给稽核单和稽核人员分别保存
		 */
		i += totalService.addCheckTotalList(totalList);
		if (i > 0) {
			peopleService.addCheckPeopleList(peopleList);
			r = new Result(ResultCode.SUCCESS);
			r.setMessage("添加成功");
			r.setData(totalList);
		}else {
			r = new Result(ResultCode.FAIL);
			r.setMessage("添加失败");
		}
		return r;
	}
	
	/**根据id删除稽核单
	 * @param totalId 稽核单id
	 * @return
	 */
	@RequestMapping("/delTotal.do")
	@ResponseBody
	public String delTotal(String totalId) {
		Integer i = totalService.delCheckTotal(totalId);
		return i.toString();
	}
	
	/**修改集合单
	 * @param total 稽核单对象
	 * @return
	 */
	@RequestMapping("/updateTotal.do")
	@ResponseBody
	public String updateTotal(@RequestBody CheckTotal total) {
		Integer i = totalService.updateCheckTotal(total);
		return i.toString();
	}
	
	/**根据条件查询稽核单list
	 * @param session
	 * @param start 起始页码
	 * @param length 每页条数
	 * @param startDate 稽核开始时间
	 * @param endDate 稽核结束时间
	 * @param checkPeople 稽核人
	 * @param overend 表达状态
	 * @return 稽核单list
	 */
	@RequestMapping("/getTotalDataByCondition.do")
	@ResponseBody
	public PageInfo<CheckTotal> getTotalDataByCondition(HttpSession session,Integer start, Integer length, String startDate, String endDate, String checkPeople, String overend) {
		UserEntity userEntity = (UserEntity) session.getAttribute("user");
		PageInfo<CheckTotal> info = null;
		if (userEntity.getRoles() == null || userEntity.getRoles().getrName() == null) {
			return new PageInfo<CheckTotal>(new ArrayList<>()); 
		}
		if (userEntity.getRoles().getrName().contains("管理員")) {
			info = totalService.getTotalDataByCondition(start, length,startDate,endDate, checkPeople, overend, null);
		}else {
			info = totalService.getTotalDataByCondition(start, length,startDate,endDate, checkPeople, overend, userEntity.getCardNum());
		}
		return info;
	}
	/**根据稽核单id查询信息及其关联的问题和集合人
	 * @param checkTotalId 稽核单id
	 * @return 稽核单对象
	 */
	@RequestMapping("/getCheckTotalById.do")
	@ResponseBody
	public HashMap<String, Object> getCheckTotalById(String checkTotalId) {
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("msg", "OK");
		CheckTotal checkTotal = totalService.getCheckTotalById(checkTotalId);
//		System.out.println("checkTotalId>>"+checkTotalId+" - "+checkTotal);
		if (ObjectUtils.isEmpty(checkTotal)) {
			resultMap.put("data", null);
			resultMap.put("totalMoney", 0);
			resultMap.put("totalScore", 0);
			return resultMap;
		}
		/**
		 * 统计问题频率，罚扣总分和罚扣总金额
		 */
		double totalMoney = 0d;
		double totalScore = 0d;
		if (ObjectUtils.isNotEmpty(checkTotal.getProblemList())) {
			for (CheckProblem checkProblem : checkTotal.getProblemList()) {
				totalMoney += (checkProblem.getAfterMoney() == -1.0?checkProblem.getBeforeMoney():checkProblem.getAfterMoney());
				totalScore += (checkProblem.getAfterScore() == null?checkProblem.getBeforeScore():checkProblem.getAfterScore());
		}
	}
		resultMap.put("data", checkTotal);
		resultMap.put("totalMoney", totalMoney);
		resultMap.put("totalScore", totalScore);
//		System.out.println("resultMap>>"+resultMap);
		return resultMap;
	
	}
	
}
