package com.foxconn.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import com.alibaba.fastjson.JSON;
import com.foxconn.entity.CheckProblem;
import com.foxconn.entity.ImgFile;
import com.foxconn.entity.ManagementStandard;
import com.foxconn.service.CheckProblemService;
import com.foxconn.service.ImgFileService;
import com.foxconn.utils.Utils;

/**
 * @author C3410596
 *
 */
@Controller
@RequestMapping("checkProblem")
@CrossOrigin
public class ProblemController {

//	稽核问题接口
	@Autowired
	private CheckProblemService problemService;
//	图片业务接口
	@Autowired
	private ImgFileService imgService;
	
	private Logger logger = Logger.getLogger(this.getClass());
	
	/**
	 * 添加问题
	 * @param map("checkProblem":checkProblem)("ManagementStandardObj":ManagementStandard)
	 * @return Map<String, String>
	 */
	@RequestMapping("/addProblem.do")
	@ResponseBody
	public Map<String, String> addProblem(@RequestBody Map<String, Object> map) {
		HashMap<String, String> resultMap = new HashMap<String, String>();
		CheckProblem problem = JSON.parseObject(JSON.toJSONString(map.get("checkProblem")), CheckProblem.class);
		String uuid = UUID.randomUUID().toString().replaceAll("-", "");
		problem.setCheckProblemId(uuid);
		resultMap.put("checkProblemId", uuid);
		ManagementStandard managementStandard = JSON.parseObject(JSON.toJSONString(map.get("ManagementStandardObj")), ManagementStandard.class);
		// 统计之前犯的次数
		int pinlv = problemService.countWrong(problem.getCantingId(), problem.getThirdCode(), ((problem.getGrade() == null || problem.getGrade().length() <= 4) ? 3d:6d));//蝏恣餈�像���
		// 设置这次犯的次数=之前犯的次数+1；
		problem.setPinlv(pinlv+1);
		String handle = null;
		switch (pinlv) {
		case 0:// 频率为0，加上这次，说明是第一次犯，执行一级处罚
			handle = managementStandard.getFirstHandle();
			
			break;
		case 1:// 频率为1，加上这次，说明是第二次犯，执行二级处罚
			handle = managementStandard.getSecondHandle();
			break;

		case -1:// 频率为1，加上这次，说明是第二次犯，执行二级处罚
	        resultMap.put("msg", "没有找到该餐厅基础资料");
	        return resultMap;
	      case -2:
	        resultMap.put("msg", "合同未生效");
	        return resultMap;
	      case -3:
	        resultMap.put("msg", "合同已过期");
	        return resultMap;
	      default:
	        handle = managementStandard.getThirdHandle();
	        break;
		}
		
		boolean b = Utils.isNumeric(handle);//判断处罚措施里是否只有罚扣金额，是不是纯数字
		if (b) {
			problem.setBeforeMoney(Double.parseDouble(handle));
			problem.setAfterMoney(-1d);
		}else {//(限期整改&500)
			if (handle.contains("&") || handle.contains("或")) {
				String[] split = handle.split("&");
				if (split.length < 2) {
					split = handle.split("或");
				}
				problem.setBeforeMoney(Double.parseDouble(split[0].replace(",", "")));
				problem.setAfterMoney(-1d);
				problem.setStandRemark(split[1]);
			}else {
				problem.setBeforeMoney(0d);
				problem.setAfterMoney(-1d);
				problem.setStandRemark(handle);
			}
		}		
		Integer i = problemService.addCheckProblem(problem);
		if (i > 0) {
			resultMap.put("msg", "OK");
			resultMap.put("money", String.valueOf(problem.getBeforeMoney()));
			resultMap.put("pinlv", String.valueOf(pinlv));
		}else {
			resultMap.put("msg", "NG");
		}
		return resultMap;
	}
	
	/**根据问题id删除问题
	 * @param problemId 问题id
	 * @return 返回受影响 的行数
	 */
	@RequestMapping("/delProblem.do")
	@ResponseBody
	public String delProblem(String problemId) {
//		System.out.println("problemId"+problemId);
		Integer i = problemService.delCheckProblem(problemId);
		return i.toString();
	}
	
	
	/**根据发单id查询对应的问题
	 * @param checkTotalId 罚单id
	 * @return 返回对应的问题
	 */
	@RequestMapping("/getProblemByCheckTotalId.do")
	@ResponseBody
	public List<CheckProblem> getProblemData(String checkTotalId) {
		List<CheckProblem> info = problemService.findByItem(checkTotalId);

		for (CheckProblem checkProblem : info) {
			int pinlv = problemService.countWrong(checkProblem.getCantingId(), checkProblem.getThirdCode(),((checkProblem.getGrade() == null || checkProblem.getGrade().length() <= 4) ? 3d:6d));//蝏恣餈�像���
			checkProblem.setPinlv(pinlv);
		}

		return info;
	}
	
	
	/**修改问题
	 * @param problem 问题对象
	 * @return 返回受影响 的行数
	 */
	@RequestMapping("/updateProblem.do")
	@ResponseBody
	public String updateProblem(CheckProblem problem) {
		int i = problemService.updateCheckProblem(problem);
		return String.valueOf(i);
	}
	
	/**修改罚扣金额
	 * @param problem 问题对象
	 * @return 返回受影响 的行数
	 */
	@RequestMapping("/updateProblemMoney.do")
	@ResponseBody
	public String updateProblemMoney(CheckProblem problem) {
		int i = problemService.updateCheckProblem(problem);
		return String.valueOf(i);
	}
	
	
	/**
	 * 给问题上传对应的图片
	 * @param checkProblemId 问题id 
	 */
	@RequestMapping("/addImg.do")
	@ResponseBody
	public Map<String, String> addImg(String checkProblemId, @RequestParam(name = "file")MultipartFile file) {
		HashMap<String, String> resultMap = new HashMap<String, String>();
		ImgFile imgFile = new ImgFile();
		
		int i = 0;
		String uuid = UUID.randomUUID().toString().toUpperCase().replaceAll("-", "");
		try {
			imgFile.setImgId(uuid);
			imgFile.setImgForeign(checkProblemId);
			imgFile.setImgEntity(file.getBytes());
			i = imgService.addImg(imgFile);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (i > 0) {
			resultMap.put("msg", "OK");
			resultMap.put("imgId", uuid);
		}else {
			resultMap.put("msg", "NG");
		}
		return resultMap;
	}
	
	/**根据问题id查询对应的图片id集合
	 * @param checkProblemId 问题id
	 * @return 图片id集合
	 */
	@RequestMapping("getImgId.do")
	@ResponseBody
	public List<String> getImgList(String checkProblemId){
		List<String> idList = new ArrayList<String>();
		List<ImgFile> imgList = imgService.getImgId(checkProblemId);
		for (ImgFile img : imgList) {
			idList.add(img.getImgId());
		}
		return idList;
	}
	
	/**根据id获取图片
	 * @param imgId 图片id
	 * @return 返回图片
	 */
	@RequestMapping("getImg.do")
	@ResponseBody
	public byte[] getImg(String imgId) {
		//System.out.println(imgId);
		ImgFile imgFile = imgService.getImg(imgId);
		byte[] imgEntity = imgFile.getImgEntity();
		return imgEntity;
	}
	
	/**根据图片id删除图片
	 * @param imgDelId 图片id
	 * @return 返回OK或NG
	 */
	@RequestMapping("/delImg.do")
	@ResponseBody
	public String delImg(String imgDelId) {
		ArrayList<String> idList = new ArrayList<String>();
		idList.add(imgDelId);
		int i = imgService.delImgs(idList);
		if (i > 0) {
			return "OK";
		}else {
			return "NG";
		}
	}
}
