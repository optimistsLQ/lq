package com.foxconn.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.foxconn.entity.Proxy;
import com.foxconn.entity.Result;
import com.foxconn.entity.ResultCode;
import com.foxconn.entity.UserEntity;
import com.foxconn.service.ProxyService;
@CrossOrigin
@RestController
@RequestMapping("/proxy")
public class ProxyController {
  
    @Autowired
    private ProxyService proxyService;
    
    @PostMapping("getProxyInfo.do")
    public Result getProxyInfo(String proxyCardNum,HttpSession session){
        UserEntity userEntity = (UserEntity)session.getAttribute("user");
        if (userEntity.getUserName().equals(proxyCardNum)) {
   
            return new Result(ResultCode.FAIL, "請設置有效人員！");
        }
        UserEntity user = proxyService.getProxy(proxyCardNum);
        if (user == null) {
            return new Result(ResultCode.FAIL, "請設置有效人員！");
        }
        return new Result(ResultCode.SUCCESS, user);
    }
    /**
     * 添加代理人
     * @param session
     * @param proxyId
     * @param startTime
     * @param endTime
     * @return
     */
    @PostMapping(value = "addProxy.do",produces = {"application/text;charset=utf-8"})
    public String addProxy(HttpSession session, String proxyId,String startTime,String endTime){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        Date _startTime = null,_endTime = null;
        try {
            _startTime = sdf.parse(startTime);
            _endTime = sdf.parse(endTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        UserEntity userEntity = (UserEntity)session.getAttribute("user");
        //說明代理人已經存在
        String uuid = userEntity.getUuid();
        if(proxyService.checkProxyExists(uuid,new Date())) {
            return "代理人已存在,無需重複設置！";
        }
        //刪除之前已過期的代理人
        proxyService.deleteByUserId(uuid);
        //通過該工號獲得id號
        Proxy param = new Proxy();
        param.setUuid(uuid);
        param.setProxyId(proxyId);
        param.setStartTime(_startTime);
        param.setEndTime(_endTime);
        proxyService.insertSelective(param);
        return "添加成功！";
    }
    
    @PostMapping("getProxy.do")
    public Result getProxy(HttpSession session){
        UserEntity userEntity = (UserEntity)session.getAttribute("user");
        List<Map<String,Object>> user = proxyService.getProxyByUuid(userEntity.getUuid());
        if (user.size() == 0) {
            return new Result(ResultCode.FAIL, "請設置有效人員！");
        }
        return new Result(ResultCode.SUCCESS, user);
   }  
    /**
     * 刪除代理人
     * @param pid
     * @return
     */
    @PostMapping("toDelProxy.do")
    public Result toDelProxy(String  pid){
        proxyService.toDelProxy(pid);
        return new Result(ResultCode.SUCCESS, "刪除成功");
   }  
    /**
     * 判断是否被代理
     */
    @GetMapping("getProxyInfo.do")
    public void getProxyInfo(HttpSession session){
        UserEntity userEntity = (UserEntity)session.getAttribute("user");
        String uuid = userEntity.getUuid();
        proxyService.getProxyInfo(uuid);
    }
}
