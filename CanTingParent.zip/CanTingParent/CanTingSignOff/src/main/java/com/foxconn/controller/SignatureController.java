package com.foxconn.controller;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.foxconn.entity.Result;
import com.foxconn.entity.ResultCode;
import com.foxconn.entity.Signature;
import com.foxconn.entity.Totalsignature;
import com.foxconn.entity.UserEntity;
import com.foxconn.service.SignatureService;
import com.foxconn.service.TotalSignatureService;
import com.foxconn.service.UserService;
import com.github.pagehelper.PageInfo;

@CrossOrigin
@RestController
@RequestMapping("/signature")
public class SignatureController {

    @Autowired
    private TotalSignatureService tolSigService;
    @Autowired
    private SignatureService sigService;
    @Autowired
    private UserService userService;

    /**
     * 添加流程
     * @param tolSig
     * @return
     */
    @PostMapping("/addTolSig.do")
    public Result addTolSig(Totalsignature tolSig,HttpSession session) {
        UserEntity user = (UserEntity) session.getAttribute("user");
        tolSig.setUuid(user.getUserName());
        int i = tolSigService.insertTolSig(tolSig);
        if (i > 0) {
        	return new Result(ResultCode.SUCCESS);
        }
        return new Result(ResultCode.FAIL);
    }
    /**
     * 查找所有流程
     * @param search
     * @param start
     * @param length
     * @return
     */
    @PostMapping("/findAllTolSig.do")
    public Map<String,Object> findAllTolSig(String search, Integer start, Integer length) {
        if ("".equals(search)) {
            search = null;
        }
        String signatureName = search;
        PageInfo<Totalsignature> info = tolSigService.findAll(signatureName, start, length);
        Map<String,Object> result = new HashMap<String,Object>();
        result.put("iTotalDisplayRecords", info.getTotal());
        result.put("iTotalRecords", info.getTotal());
        result.put("data", info.getList());
        return result;        
    }
    /**
     * 修改流程狀態
     * @param tolsigId
     * @param lockStatus
     * @return
     */
    @PostMapping("/updateSignatureLock.do")
    public Result updateSignatureLock(String tolsigId,Integer lockStatus) {
        return tolSigService.updateSignatureLock(tolsigId,lockStatus);
    }
    /**
     * 刪除流程
     * @param deleteIds
     * @return
     */
    @PostMapping("/deleteTolsig.do")
    public Result deleteTolsig(@RequestParam(name="deleteIds[]")List<String> deleteIds) {
        return tolSigService.deleteTolsig(deleteIds);
    }
    /**
     * 添加節點
     * @param deleteIds
     * @return
     */
    @PostMapping("/insertSignature.do")
    public Result insertSignature(String sigarr ,String tolsigId) {
        List<Signature> sigList = JSONObject.parseArray(sigarr, Signature.class);
        sigService.delByTolSigId(tolsigId);
        Integer i = 0;
        for (Signature signature : sigList) {
            signature.setTolsigId(tolsigId);
            sigService.insertSig(signature);
            i++;
        }
        return new Result(ResultCode.SUCCESS,i);
    }
    /**
     * 查詢人員信息
     */
    @PostMapping("/getUserByName.do")
    public Result getUserByName(String name){
        
        UserEntity user = userService.getUserByNickname(name);
        if (user == null) {
            return new Result(ResultCode.FAIL, "用戶不存在！");
        }
        return new Result(ResultCode.SUCCESS, user);
    }
    /**
     * 獲取節點信息
     */
    @PostMapping("/getSigData.do")
    public List<Map<String,Object>> getSigData(String tolsigId){
        
       return sigService.findSig(tolsigId);
    }
    
    @PostMapping("/getUserByItem.do")
    public List<Map<String,String>> listUserByItem(String item) {
        List<UserEntity> userList = userService.listAllUser(item);
        List<Map<String,String>> list = new ArrayList<Map<String,String>>();
        for (UserEntity user : userList) {
            Map<String,String> newMap = new HashMap<String,String>();
            newMap.put("userName", user.getUserName());
            newMap.put("uuid", user.getUuid());
            newMap.put("cardNum", user.getCardNum());
            list.add(newMap);
        }
        return list;
    }
    
    @PostMapping("/listUserByItem.do")
    public List<String> getUserByItem(String item) {
        List<UserEntity> userList = userService.listAllUser(item);
        List<String> list = new ArrayList<>();
        for (UserEntity user : userList) {
            list.add( user.getUserName());
        }
        return list;
    }
}
