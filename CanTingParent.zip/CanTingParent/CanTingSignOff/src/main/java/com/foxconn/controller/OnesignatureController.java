package com.foxconn.controller;

import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Base64Utils;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.foxconn.entity.Archive;
import com.foxconn.entity.CheckTotal;
import com.foxconn.entity.EndSignInfo;
import com.foxconn.entity.Files;
import com.foxconn.entity.Result;
import com.foxconn.entity.ResultCode;
import com.foxconn.entity.RoleEntity;
import com.foxconn.entity.UserEntity;
import com.foxconn.service.CheckTotalService;
import com.foxconn.service.FilesService;
import com.foxconn.service.OnesignatureService;
import com.foxconn.service.SignatureService;
import com.foxconn.service.TotalSignatureService;
import com.foxconn.util.ExcelUtil;
import com.foxconn.utils.Utils;


@SuppressWarnings("unchecked")
@CrossOrigin
@RestController
@RequestMapping("/onesignature")
public class OnesignatureController {

    @Autowired
    private OnesignatureService onesignatureService;
    @Autowired
    private TotalSignatureService totalSignatureService;
    @Autowired
    private SignatureService signatureService;
    @Autowired
    private CheckTotalService checkTotalService;
    @Autowired
    private FilesService filesService;
    
   
    /**
     * 获取签核流程
     * @return
     */
    @GetMapping("/getTotalsignature.do")
    public Result getTotalsignature(){
        List<Map<String,String>> list =totalSignatureService.getTotalsignature();
        if (list.size() == 0) {
            return new Result(ResultCode.FAIL,"没有流程，请添加流程");
        }
        return new Result(ResultCode.SUCCESS,list);
    }
    /**
     * 根据签核流程id获取签核流程所有节点
     */
    @GetMapping("/getSignature.do")
    public Result getSignature(String tolsigId){
        List<Map<String,Object>> list = signatureService.findByTolsigId(tolsigId);
        if (list.size() == 0) {
            return new Result(ResultCode.FAIL,"流程无节点，请添加节点！");
        }
        return new Result(ResultCode.SUCCESS,list);
    }
    /**
     * 创建签核
     * @param list
     */
    @PostMapping("/insertOnesignature.do")
    public Result insertOnesignature(@RequestBody Map<String,Object> map) {
        Map<String,String> totalMap = (Map<String, String>) map.get("total");
        if (!ObjectUtils.isEmpty(totalMap)) {
            CheckTotal checkTotal = new CheckTotal();
            checkTotal.setChecktotalId(totalMap.get("checktotalId"));
            checkTotal.setCheckNaturn(totalMap.get("checkNaturn"));
            checkTotal.setHastrouble(totalMap.get("hastrouble"));
            checkTotal.setOverend(totalMap.get("overend"));
            checkTotalService.updateCheckTotal(checkTotal);
        }
        
        String type = (String) map.get("type");
        List<Map<String,Object>> list = (List<Map<String, Object>>) map.get("list");
        for (int i = 0; i < list.size(); i++) {
            Map<String,Object> newMap = list.get(i);
            if (i == 1) {
                newMap.put("myselfSign", "N");
            } else {
                newMap.put("myselfSign", "N");
            }
            if (i == 0) {
                newMap.put("sigstatus", "Y");
            } else {
                newMap.put("sigstatus", "N");
            }
        }
        Integer i = onesignatureService.insertOnesignature(list,type);
        if (i != 0) {
            return new Result(ResultCode.SUCCESS,"创建成功！");
        }
        return new Result(ResultCode.FAIL);
    }
    /**
     * 确认签核
     */
    @PostMapping("/updateOnesignature.do")
    public Result updateOnesignature(@RequestParam Map<String,String> map,HttpSession session){
        UserEntity userEntity = (UserEntity)session.getAttribute("user");
        String uuid = map.get("uuid");
        String formCode = map.get("formCode");
        String sigidea = map.get("sigidea");
        String type = map.get("type");
        String orderNumber = map.get("orderNumber");
        return onesignatureService.updateOnesignature(uuid,formCode,sigidea,userEntity.getUserName(),type,orderNumber);
    }
  
    /**
     * 加签
     */
    @PostMapping("/endorsement.do")
    public Result getEndorsement(@RequestParam Map<String,String> map) {
        String uuid = map.get("uuid");
        String formCode = map.get("formCode");
        String orderNumber = map.get("orderNumber");
        String nodeName = map.get("nodeName");
        final String status = "H";
        String type = map.get("type");
        return onesignatureService.insertEndorsement(uuid,formCode,nodeName,orderNumber,status,type);
    }
    /**
     * 会签
     */
    @PostMapping("/countersign.do")
    public Result getCountersign(@RequestParam Map<String,String> map) {
        String uuid = map.get("uuid");
        String formCode = map.get("formCode");
        String orderNumber = map.get("orderNumber");
        String nodeName = map.get("nodeName");
        String status = "J";
        String type = map.get("type");
        return onesignatureService.insertEndorsement(uuid,formCode,nodeName,orderNumber,status,type);
    }
    /**
     * 驳回
     */
    @PostMapping("/turnDown.do")
    public Result getTurnDown(@RequestParam Map<String,String> map) {
        String uuid = map.get("uuid");
        String formCode = map.get("formCode");
        String orderNumber = map.get("orderNumber");
        String nodeName = map.get("sigidea");
        String status = "B";
        String type = map.get("type");
        return onesignatureService.insertEndorsement(uuid,formCode,nodeName,orderNumber,status,type);
    }
    /**
     * 作廢
     */
    @PostMapping("/doWaste.do")
    public Result getDoWaste(@RequestParam Map<String,String> map) {
        String uuid = map.get("uuid");
        String formCode = map.get("formCode");
        String orderNumber = "";
        String nodeName = map.get("sigidea");
        String status = "Z";
        String type = map.get("type");
        return onesignatureService.insertEndorsement(uuid,formCode,nodeName,orderNumber,status,type);
    }
    /**
     * 上传文件--附件
     * @param formCode
     * @param file
     * @return
     */
    @PostMapping("/updatingFiles.do")
    public Result UpdatingFiles(String formCode,String identifier,@RequestParam("file") MultipartFile file) {
        byte [] annex = null;
        try {
             Long size = file.getSize()/1024/1024/1024;
             if (size > 50) {
                 return new Result(ResultCode.FAIL,"请上传50M以内的文件！");
             }
             Files files = new Files();
             annex = file.getBytes();
             files.setEntity(annex);
             files.setForeignKey(formCode);
             String fileName = null;
             if (ObjectUtils.isEmpty(identifier)) {
                 fileName = file.getOriginalFilename();
             } else {
                 fileName = identifier + "$000$" + file.getOriginalFilename();
             }
             files.setFileName(fileName + "$000$" + UUID.randomUUID().toString().toUpperCase());
             return filesService.insertFile(files);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return new Result(ResultCode.FAIL,"上传失败！");
    }

    
    /**
     * 根据表单id查询所属文件ID
     */
    @GetMapping("/findFiles.do")
    public Result FindFiles(String formCode) {
        List<Map<String,String>> list = filesService.findFiles(formCode);
        if (list.size() == 0) {
            return new Result(ResultCode.FAIL,"没有上传附件！");
        } else {
            return new Result(ResultCode.SUCCESS,list);
        }
    }
    /**
     * 根据文件id下载此文件
     */
    @GetMapping("/findFile.do")
    public Result FindFile(String fid) {
        Files list = filesService.findFile(fid);
        if (list == null) {
            return new Result(ResultCode.FAIL,"没有上传附件！");
        } else {
            return new Result(ResultCode.SUCCESS,list);
        }
    }

    /**
     * 根据文件id回显此文件
     * @throws IOException 
     */
    @GetMapping("/findImage.do")
    public void findImage(String fid,HttpServletResponse resp) throws IOException {
        Files file = filesService.findFile(fid);
        String fileName = file.getFileName();
        //获取文件后缀名
        String strNames [] = fileName.split("\\$000\\$")[0].split("\\.");
        String name = null;
        for (String string : strNames) {
			if (string.contains(".")) {
				name = string;
				break;
			}
		}
        resp.setContentType("image/" + name);
        byte [] annex = file.getEntity();
        //写入输出流
        OutputStream out = resp.getOutputStream();
        out.write(annex);
        out.flush();
        out.close();
    }
    
    /**
     * PDF合併並添加水印 下載
     */
    @GetMapping("/mergePdf.do")
    public void mergePdf(HttpServletRequest req,HttpServletResponse response,String formCode,String formType){
    	
    	String formStatus = onesignatureService.getFormStatus(formCode,formType);
    	
    	if (!formStatus.equals("已结案")) {
    		return;
    	}
    	try {
	    	List<byte[]> filesList = filesService.ListFiles(formCode);
	    	if (filesList.size() == 0) {
	    		return;
	    	}
	    	String name = System.currentTimeMillis() +".pdf";
			//設置中文響應頭
			String encode = URLEncoder.encode(name, "UTF-8");
			encode = encode.replace("+", " ");
			String ua = req.getHeader("user-agent");
			if(ua.toLowerCase().indexOf("firefox") > -1)
			{
				encode = "=?UTF-8?B?" + (new String(Base64Utils.encodeToString((name).getBytes("UTF-8")))) + "?=";
			}
			response.setContentType("application/octet-stream;charset=utf-8");
			response.setHeader("Content-Disposition", "attachment;filename="+encode);
	    	Utils.mergePdfPutStream(filesList, response.getOutputStream());
    	} catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    
    /**
     * 根据文件id下载此文件
     * @param respones
     * @param fid
     */
    @GetMapping("/download.do")
    public void download(HttpServletRequest req,HttpServletResponse response,String fid){
        try {
            Files files = filesService.findFile(fid);
            String str[] = files.getFileName().split("\\$000\\$");
            String name = null;
            for (String string : str) {
				if (string.contains(".")) {
					name = string;
					break;
				}
			}
            
            if (ObjectUtils.isEmpty(files)) {
            	response.getOutputStream().write(("不存在文件ID：" + fid).getBytes("UTF-8"));
            	return;
            } 
			//設置中文響應頭
			String encode = URLEncoder.encode(name, "UTF-8");
			encode = encode.replace("+", " ");
			String ua = req.getHeader("user-agent");
			if(ua.toLowerCase().indexOf("firefox") > -1)
			{
				encode = "=?UTF-8?B?" + (new String(Base64Utils.encodeToString((name).getBytes("UTF-8")))) + "?=";
			}
			response.setContentType("application/octet-stream;charset=utf-8");
			response.setHeader("Content-Disposition", "attachment;filename="+encode);
            response.getOutputStream().write(files.getEntity());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
 
    /**
     * 根据文件id删除此文件件
     */
    @GetMapping("/deleteFiles.do")
    public Result deleteFiles(String fid) { 
        return filesService.deleteFiles(fid);
    }
    /**
     * 分页显示稽核表单待签核表单
     */
    @GetMapping("/findSignOffStatus.do")
    public Result findSignOffStatus(String uuid,Integer start, Integer length ){
        Map<String,Object> map = onesignatureService.findSignOffByUuid(uuid,start,length);
        return new Result(ResultCode.SUCCESS,map);
    }
    
    /**
     * 查找待签核表单数量
     */
    @GetMapping("/findSignOffAll.do")
    public Result findSignOffAll(HttpSession session){
        UserEntity user = (UserEntity) session.getAttribute("user");
        Map<String,Object> map = onesignatureService.findSignOffAll(user.getUuid());
        return new Result(ResultCode.SUCCESS,map);
    }
    /**
     * 根据表单id获取当前表单的所有签核节点
     */
    @GetMapping("/finSignOff.do")
    public Result finSignOff(String formCode){
        return new Result(ResultCode.SUCCESS,onesignatureService.findSignOffByFormCode(formCode));
    }
    /**
     * 稽核表单的归档查询
     */
    @GetMapping("/allSignOff.do")
    public Result findSignOff(Integer start, Integer length,EndSignInfo endSignInfo,HttpSession session){
    	UserEntity user = (UserEntity) session.getAttribute("user");
        String roles = user.getRoles().getrName();
        Boolean b = roles.contains("管理員");
        String contractor = user.getContractor();
        if (b) {
        	endSignInfo.setUuid("administrator");
        } else if (!StringUtils.isEmpty(contractor)) {
        	endSignInfo.setUuid(contractor);
        }
        Map<String, Object> info = onesignatureService.newEndAllSignOff(endSignInfo,start,length);
        return new Result(ResultCode.SUCCESS,info);
    }
    /**
     * 稽核表单excel下載
     */
    @GetMapping("/getExcel.do")
    public void getExcel(HttpServletResponse response,HttpServletRequest request,EndSignInfo endSignInfo,HttpSession session){
    	UserEntity user = (UserEntity) session.getAttribute("user");
        String roles = user.getRoles().getrName();
        Boolean b = roles.contains("管理員");
        String contractor = user.getContractor();
        if (b) {
        	endSignInfo.setUuid("administrator");
        } else if (!StringUtils.isEmpty(contractor)) {
        	// 餐包商可以看到自己所有餐廳下的表單
        	endSignInfo.setUuid(contractor);
        }
        List<Archive> info = onesignatureService.getNewAllSignOff(endSignInfo);
        String [] title = {"编号","排配编号","餐厅","包商","稽核要点","大类","问题描述","问题星级","稽核员","处理措施","扣分"
                ,"稽核类别","状态","待签人员","问题位置"};
        HSSFWorkbook wb = ExcelUtil.getHSSFWorkbook("SheetName",title,info,null);
        // 4 响应到客户端,弹出下载提示框
        try {
            this.setResponseHeader(response,Utils.dateFormatStr(new Date(), "yyyyMMdd")+".xls");
            OutputStream os = response.getOutputStream();
            wb.write(os);
            os.flush();
            os.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 功能描述: 发送响应流方法
     *
     */
    private void setResponseHeader(HttpServletResponse response, String fileName) {
        try {
            try {
                fileName = new String(fileName.getBytes(),"UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            response.setContentType("application/octet-stream;charset=UTF-8");
            response.setHeader("Content-Disposition", "attachment;filename="+ fileName);
            response.addHeader("Pargam", "no-cache");
            response.addHeader("Cache-Control", "no-cache");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    
    /**
     * 餐厅变动归档查询
     */
    @PostMapping("stallChangeFile.do")
    public Result StallChangeFile(HttpSession session,@RequestParam Map<String,String> map) {
    	UserEntity user = (UserEntity) session.getAttribute("user");
    	RoleEntity userRole = user.getRoles();
        String roles = userRole.getrName();
        // 判斷權限名是否為管理員 或者 其權限路徑中包含允許全部查詢的路徑
        Boolean c = userRole.getOperationList().stream().filter(w->String.valueOf(w.getoAddress()).equals("/onesignature/booleanSign.do")).findAny().isPresent();
        Boolean b = (roles.contains("管理員") || c);
        
        String contractor = user.getContractor();
        String uuid = user.getUuid();
        if (b) {
        	uuid = "administrator";
        } else if (!StringUtils.isEmpty(contractor)) {
        	uuid = contractor;
        }
        String startDate = map.get("startDate");// 开始时间
        String endDate = map.get("endDate");// 结束时间
        String catererName = map.get("catererName");// 餐包商名称
        String restaurantLocation = map.get("restaurantLocation");// 餐厅位置
        String applicationType = map.get("applicationType");// 申请类型
        String status = map.get("status"); // 签核状态
        String start = map.get("start"); // 
        String length = map.get("length"); // 
        Map<String,Object> info = onesignatureService.selectStallChangeFile(uuid,startDate,endDate,catererName,restaurantLocation,applicationType,status,length,start);
        return new Result(ResultCode.SUCCESS,info);
    }
    /**
     * 食材经销商申请归档查询
     */
    @PostMapping("foodQualifictionFile.do")
    public Result FoodQualifictionFile(HttpSession session,@RequestParam Map<String,String> map) {
    	UserEntity user = (UserEntity) session.getAttribute("user");
    	RoleEntity userRole = user.getRoles();
        String roles = userRole.getrName();
        // 判斷權限名是否為管理員 或者 其權限路徑中包含允許全部查詢的路徑
        Boolean c = userRole.getOperationList().stream().filter(w->String.valueOf(w.getoAddress()).equals("/onesignature/booleanSign.do")).findAny().isPresent();
        Boolean b = (roles.contains("管理員") || c);
        
        String contractor = user.getContractor();
        String uuid = user.getUuid();
        if (b) {
        	uuid = "administrator";
        } else if (!StringUtils.isEmpty(contractor)) {
        	// 餐包商可以看到自己所有餐廳下的表單
        	uuid = contractor;
        }
        String startDate = map.get("startDate");// 开始时间
        String endDate = map.get("endDate");// 结束时间
        String catererName = map.get("catererName");// 餐包商名称
        String brand = map.get("brand");// 品牌
        String productName = map.get("productName");// 品名
        String status = map.get("status"); //签核状态
        String start = map.get("start"); // 
        String length = map.get("length"); // 
        Map<String,Object> info = onesignatureService.selectFoodQualifictionFile(uuid,startDate,endDate,catererName,brand,productName,status,length,start);
        return new Result(ResultCode.SUCCESS,info);
    }
    
    /**
     * 食材经销商申请归档查询
     */
    @PostMapping("dealerFile.do")
    public Result DealerFile(HttpSession session,@RequestParam Map<String,String> map) {
    	UserEntity user = (UserEntity) session.getAttribute("user");
    	RoleEntity userRole = user.getRoles();
        String roles = userRole.getrName();
        // 判斷權限名是否為管理員 或者 其權限路徑中包含允許全部查詢的路徑
        Boolean c = userRole.getOperationList().stream().filter(w->String.valueOf(w.getoAddress()).equals("/onesignature/booleanSign.do")).findAny().isPresent();
        Boolean b = (roles.contains("管理員") || c);
        
        String contractor = user.getContractor();
        String uuid = user.getUuid();
        if (b) {
        	uuid = "administrator";
        } else if (!StringUtils.isEmpty(contractor)) {
        	// 餐包商可以看到自己所有餐廳下的表單
        	uuid = contractor;
        }
        
        String startDate = map.get("startDate");// 开始时间
        String endDate = map.get("endDate");// 结束时间
        String catererName = map.get("catererName");// 餐包商名称
        String dealer = map.get("dealer");// 经销商
        String status = map.get("status"); //签核状态
        String start = map.get("start"); // 
        String length = map.get("length"); // 
        Map<String,Object> info = onesignatureService.selectDealerFile(uuid,startDate,endDate,catererName,dealer,status,length,start);
        return new Result(ResultCode.SUCCESS,info);
    }
    
    @GetMapping("/dealerFileExcel.do")
    public void DealerFileExcel(HttpServletResponse response,HttpServletRequest request,@RequestParam Map<String, String> map,HttpSession session){
    	UserEntity user = (UserEntity) session.getAttribute("user");
    	RoleEntity userRole = user.getRoles();
        String roles = userRole.getrName();
        // 判斷權限名是否為管理員 或者 其權限路徑中包含允許全部查詢的路徑
        Boolean c = userRole.getOperationList().stream().filter(w->String.valueOf(w.getoAddress()).equals("/onesignature/booleanSign.do")).findAny().isPresent();
        Boolean b = (roles.contains("管理員") || c);
        
        String contractor = user.getContractor();
        String uuid = user.getUuid();
        if (b) {
        	uuid = "administrator";
        } else if (!StringUtils.isEmpty(contractor)) {
        	// 餐包商可以看到自己所有餐廳下的表單
        	uuid = contractor;
        }
        
        String startDate = map.get("startDate");// 开始时间
        String endDate = map.get("endDate");// 结束时间
        String catererName = map.get("catererName");// 餐包商名称
        String dealer = map.get("dealer");// 经销商
        String status = map.get("status"); //签核状态
        String start = map.get("start"); // 
        String length = map.get("length"); // 
        Map<String,Object> info = onesignatureService.selectDealerFile(uuid,startDate,endDate,catererName,dealer,status,length,start);
        String [] title = {"餐饮厂商","经销商","食品許可證到證日期","食品許可證編號","申請日期","申請人","簽核狀態"};
        HSSFWorkbook wb = ExcelUtil.getDealerHSSFWorkbook("SheetName",title,(List<Object>)info.get("value"),null);
        // 4 响应到客户端,弹出下载提示框
        
        try {
            this.setResponseHeader(response,"经销商"+Utils.dateFormatStr(new Date(), "yyyyMMdd")+".xls");
            OutputStream os = response.getOutputStream();
            wb.write(os);
            os.flush();
            os.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ;
    }
    
    @GetMapping("/stallChangeFileExcel.do")
    public void FoodQualifictionFileExcel(HttpServletResponse response,HttpServletRequest request,@RequestParam Map<String, String> map,HttpSession session){
    	UserEntity user = (UserEntity) session.getAttribute("user");
    	RoleEntity userRole = user.getRoles();
        String roles = userRole.getrName();
        // 判斷權限名是否為管理員 或者 其權限路徑中包含允許全部查詢的路徑
        Boolean c = userRole.getOperationList().stream().filter(w->String.valueOf(w.getoAddress()).equals("/onesignature/booleanSign.do")).findAny().isPresent();
        Boolean b = (roles.contains("管理員") || c);
        
        String contractor = user.getContractor();
        String uuid = user.getUuid();
        if (b) {
        	uuid = "administrator";
        } else if (!StringUtils.isEmpty(contractor)) {
        	// 餐包商可以看到自己所有餐廳下的表單
        	uuid = contractor;
        }
        String startDate = map.get("startDate");// 开始时间
        String endDate = map.get("endDate");// 结束时间
        String catererName = map.get("catererName");// 餐包商名称
        String restaurantLocation = map.get("restaurantLocation");// 餐厅位置
        String applicationType = map.get("applicationType");// 申请类型
        String status = map.get("status"); // 签核状态
        String start = map.get("start"); // 
        String length = map.get("length"); // 
        Map<String,Object> info = onesignatureService.selectStallChangeFile(uuid,startDate,endDate,catererName,restaurantLocation,applicationType,status,length,start);
        String [] title = {"餐包商","餐廳位置","包商負責人","檔口號","檔口名稱","檔口負責人","申請變更時間","變更類型","檔口性質","申請人","簽核狀態"};
        HSSFWorkbook wb = ExcelUtil.getStallChangeHSSFWorkbook("SheetName",title,(List<Object>)info.get("value"),null);
        // 4 响应到客户端,弹出下载提示框
        try {
            this.setResponseHeader(response,"餐厅变动申请单"+Utils.dateFormatStr(new Date(), "yyyyMMdd")+".xls");
            OutputStream os = response.getOutputStream();
            wb.write(os);
            os.flush();
            os.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ;
    }
    /**
     * 流式下载excel
     * @param response
     * @throws IOException
     */
//    @GetMapping("/test.do")
//    public void getTest(HttpServletResponse response) throws IOException  {
//        response.setCharacterEncoding("utf8");
//        response.setContentType("application/vnd.ms-excel;charset=utf-8");
//        String fileName = URLEncoder.encode("test.xlsx", "UTF-8");
//        //文件名
//        response.setHeader("Content-Disposition", "attachment; filename=" + fileName   );
//        response.setHeader("Cache-Control", "no-store");
//        response.addHeader("Cache-Control", "max-age=0");
//        ExcelWriter excelWriter = EasyExcel.write(response.getOutputStream(),Onesignature.class).build();
//        WriteSheet writeSheet = EasyExcel.writerSheet("sheet").build();
//        onesignatureService.ioReader(excelWriter,writeSheet);
//        excelWriter.finish();
//    }
    /**
     * 餐厅变动申请单归档下载
     * @param response
     * @param request
     * @param map
     * @param session
     */
    @GetMapping("/foodQualifictionFileExcel.do")
    public void StallChangeFileExcel(HttpServletResponse response,HttpServletRequest request,@RequestParam Map<String, String> map,HttpSession session){
        
    	UserEntity user = (UserEntity) session.getAttribute("user");
    	RoleEntity userRole = user.getRoles();
        String roles = userRole.getrName();
        /**
         *  判斷權限名是否為管理員 或者 其權限路徑中包含允許全部查詢的路徑
         */
        Boolean c = userRole.getOperationList().stream().filter(w->String.valueOf(w.getoAddress()).equals("/onesignature/booleanSign.do")).findAny().isPresent();
        Boolean b = (roles.contains("管理員") || c);
        
        String contractor = user.getContractor();
        String uuid = user.getUuid();
        if (b) {
        	uuid = "administrator";
        } else if (!StringUtils.isEmpty(contractor)) {
        	// 餐包商可以看到自己所有餐廳下的表單
        	uuid = contractor;
        }
        String startDate = map.get("startDate");// 开始时间
        String endDate = map.get("endDate");// 结束时间
        String catererName = map.get("catererName");// 餐包商名称
        String brand = map.get("brand");// 品牌
        String productName = map.get("productName");// 品名
        String status = map.get("status"); // 签核状态
        String start = map.get("start"); // 
        String length = map.get("length"); // 
        Map<String,Object> info = onesignatureService.selectFoodQualifictionFile(uuid,startDate,endDate,catererName,brand,productName,status,length,start);     
        String [] title = {"餐飲廠商","生產商","经销商","大類","小類","品牌","品名","規格","等級","食材經營許可證到證日期","食品經營許可證編號"
        	,"食品生產許可證到期日","食品生產許可證編號","產品檢驗報告到期日","申請日期","申請人","單據狀態"};
        
        HSSFWorkbook wb = ExcelUtil.getFoodQualifictionHSSFWorkbook("SheetName",title,(List<Object>)info.get("value"),null);
        // 4 响应到客户端,弹出下载提示框
        try {
            this.setResponseHeader(response,"食材资质申请商" + Utils.dateFormatStr(new Date(), "yyyyMMdd")+".xls");
            OutputStream os = response.getOutputStream();
            wb.write(os);
            os.flush();
            os.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ;
    } 
    
    /**
     * 判斷能否查詢簽核單（只適用於角色權限判斷，不做其他操作）
     */
    @GetMapping("/booleanSign.do")
    public void BooleanSign(){
    	
    }
    /**
     * 查詢歷史-駁回簽核流程
     */
    @GetMapping("/historyOnesignature.do")
    public Result historyOnesignature(String formCode){
        return onesignatureService.historyOnesignature(formCode);
    }
}
