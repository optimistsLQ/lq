package com.foxconn.service;

import java.util.ArrayList;
import java.util.List;

import com.foxconn.entity.CheckTotal;
import com.foxconn.entity.Result;
import com.github.pagehelper.PageInfo;

public interface CheckTotalService {

	public int addCheckTotal(CheckTotal total);
	public int delCheckTotal(String id);
	public int updateCheckTotal(CheckTotal total);
	CheckTotal findOne(String id);
	PageInfo<CheckTotal> findByItem(Integer start, Integer length);
	public PageInfo<CheckTotal> getTotalDataByCondition(Integer start, Integer length, String startDate, String endDate,
			String checkPeople, String overend, String createUser);
	public CheckTotal getCheckTotalById(String checkTotalId);
	public int addCheckTotalList(ArrayList<CheckTotal> totalList);
	public List<String> listcheckTotalIdListByCanTingId(String restaurantId);
	
}
