package com.foxconn.mapper;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.CheckPeople;

import tk.mybatis.mapper.common.Mapper;

public interface CheckPeopleMapper extends Mapper<CheckPeople>{

	int addCheckPeopleList(@Param("peopleList") ArrayList<CheckPeople> peopleList);
    
}