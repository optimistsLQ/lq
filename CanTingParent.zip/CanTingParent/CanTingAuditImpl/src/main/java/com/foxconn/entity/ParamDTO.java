package com.foxconn.entity;

import java.io.Serializable;

public class ParamDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8817797004151297619L;
	private int start;
	private int length;
	private String order;
	private String orderField;
	private String search1;
	private String search2;
	private String search3;
	private String search4;
	private String myEndover;
	private String startTime;
	private String endTime;
	
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getMyEndover() {
		return myEndover;
	}
	public void setMyEndover(String myEndover) {
		this.myEndover = myEndover;
	}
	public int getStart() {
		return start;
	}
	public void setStart(int start) {
		this.start = start;
	}
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	public String getOrder() {
		return order;
	}
	public void setOrder(String order) {
		this.order = order;
	}
	public String getOrderField() {
		return orderField;
	}
	public void setOrderField(String orderField) {
		this.orderField = orderField;
	}
	public String getSearch1() {
		return search1;
	}
	public void setSearch1(String search1) {
		this.search1 = search1;
	}
	public String getSearch2() {
		return search2;
	}
	public void setSearch2(String search2) {
		this.search2 = search2;
	}
	public String getSearch3() {
		return search3;
	}
	public void setSearch3(String search3) {
		this.search3 = search3;
	}
	public String getSearch4() {
		return search4;
	}
	public void setSearch4(String search4) {
		this.search4 = search4;
	}
	@Override
	public String toString() {
		return "ParamDTO [start=" + start + ", length=" + length + ", order=" + order + ", orderField=" + orderField
				+ ", search1=" + search1 + ", search2=" + search2 + ", search3=" + search3 + ", search4=" + search4
				+ ", myEndover=" + myEndover + ", startTime=" + startTime + ", endTime=" + endTime + "]";
	}
	
}
