package com.foxconn.service;

import java.util.List;
import com.foxconn.entity.CheckProblem;

public interface CheckProblemService {

	public int addCheckProblem(CheckProblem total);
	public int delCheckProblem(String id);
	public int updateCheckProblem(CheckProblem total);
	CheckProblem findOne(String id);
	List<CheckProblem> findByItem(String checkTotalId);
	/**
	 * @param restaurantId 餐厅ID
	 * @param thirdCode 问题对应的三级编码
	 * @param cycle 问题的统计周期（季度或半年）根据问题等级，1-4星统计周期为三个月，5星统计周期为半年
	 * @return 返回统计的次数
	 */
	public int countWrong(String restaurantId, String thirdCode, double cycle);
	public List<String> findProblemIdByTotalId(String id);
	public int updatePinLv(int pinlv, String problemId);
}
