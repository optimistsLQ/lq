package com.foxconn.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.CheckProblem;

import tk.mybatis.mapper.common.Mapper;

public interface CheckProblemMapper extends Mapper<CheckProblem>{

	int countPinLv(@Param("cantingId")String cantingId, 
				   @Param("thirdCode")String thirdCode, 
				   @Param("startDate")String startDate, 
				   @Param("endDate")String endDate);

	List<String> findProblemIdByTotalId(@Param("totalId")String totalId);
	int updatePinLv(@Param("pinlv")int pinlv, @Param("problemId")String problemId);
}