package com.foxconn.service.impl;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.foxconn.entity.CheckTotal;
import com.foxconn.entity.Result;
import com.foxconn.mapper.CheckTotalMapper;
import com.foxconn.service.CheckPeopleService;
import com.foxconn.service.CheckProblemService;
import com.foxconn.service.CheckTotalService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
@Service
public class CheckTotalServiceImpl implements CheckTotalService{

	@Autowired
	private CheckTotalMapper mapper;
	@Autowired
	private CheckProblemService problemService;
	@Autowired
	private CheckPeopleService peopleService;
	
	@Override
	public int addCheckTotal(CheckTotal total) {
		// TODO Auto-generated method stub
		return mapper.insertSelective(total);
	}

	@Override
	public int delCheckTotal(String id) {
		// TODO Auto-generated method stub
		int i = mapper.deleteByPrimaryKey(id);
		if (i > 0) {
			List<String> problemIdList = problemService.findProblemIdByTotalId(id);
			if (ObjectUtils.isNotEmpty(problemIdList)) {
				
				for (String problemId : problemIdList) {
					problemService.delCheckProblem(problemId);
				}
			}
			peopleService.delCheckPeopleByTotalId(id);
		}
		return i;
	}

	@Override
	public int updateCheckTotal(CheckTotal total) {
		// TODO Auto-generated method stub
		return mapper.updateByPrimaryKeySelective(total);
	}

	@Override
	public CheckTotal findOne(String id) {
		// TODO Auto-generated method stub
		return mapper.selectByPrimaryKey(id);
	}

	@Override
	public PageInfo<CheckTotal> findByItem(Integer start, Integer length) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PageInfo<CheckTotal> getTotalDataByCondition(Integer start, Integer length, String startDate, String endDate,
			String checkPeople, String overend, String createUser) {
		if (null != start && null != length) {
			PageHelper.startPage(start, length);
		}
		List<CheckTotal> list = mapper.getTotalDataByPage(startDate, endDate,checkPeople, overend, createUser);
		PageInfo<CheckTotal> pageInfo1 = new PageInfo<CheckTotal>(list);
		List<CheckTotal> listData = new ArrayList<>();
		if (!list.isEmpty()) {
			listData.addAll(mapper.getTotalData(list));
		}
		PageInfo<CheckTotal> pageInfo = new PageInfo<CheckTotal>(listData);
		pageInfo.setTotal(pageInfo1.getTotal());
		list.clear();
		list.addAll(listData);
		return pageInfo;
	}

	@Override
	public CheckTotal getCheckTotalById(String checkTotalId) {
		// TODO Auto-generated method stub
		return mapper.getCheckTotalById(checkTotalId);
	}

	@Override
	public int addCheckTotalList(ArrayList<CheckTotal> totalList) {
		// TODO Auto-generated method stub
		return mapper.addCheckTotalList(totalList);
	}

	@Override
	public List<String> listcheckTotalIdListByCanTingId(String restaurantId) {
		// TODO Auto-generated method stub
		return mapper.listcheckTotalIdListByCanTingId(restaurantId);
	}

   
}
