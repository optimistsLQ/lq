package com.foxconn.entity;

import java.io.Serializable;

import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

/**稽核人員
 * @author C3410596
 *
 */
@Table(name = "T_CHECKPEOPLE")
public class CheckPeople implements Serializable{
	@Transient
	private static final long serialVersionUID = -3723739981383642209L;

	@Id
	private String checkpeopleId;
//罚单id
    private String checkTotalId;
//稽核人名字
    private String checkManname;
//稽核人工號
    private String checkManCard;
//稽核人類型
    private String manType;

    private String remark1;

    public String getCheckpeopleId() {
        return checkpeopleId;
    }

    public void setCheckpeopleId(String checkpeopleId) {
        this.checkpeopleId = checkpeopleId == null ? null : checkpeopleId.trim();
    }

    public String getCheckTotalId() {
        return checkTotalId;
    }

    public void setCheckTotalId(String checkTotalId) {
        this.checkTotalId = checkTotalId == null ? null : checkTotalId.trim();
    }

    public String getCheckManname() {
        return checkManname;
    }

    public void setCheckManname(String checkManname) {
        this.checkManname = checkManname == null ? null : checkManname.trim();
    }

    public String getCheckManCard() {
        return checkManCard;
    }

    public void setCheckManCard(String checkManCard) {
        this.checkManCard = checkManCard == null ? null : checkManCard.trim();
    }

    public String getManType() {
        return manType;
    }

    public void setManType(String manType) {
        this.manType = manType == null ? null : manType.trim();
    }

    public String getRemark1() {
        return remark1;
    }

    public void setRemark1(String remark1) {
        this.remark1 = remark1 == null ? null : remark1.trim();
    }

	@Override
	public String toString() {
		return "CheckPeople [checkpeopleId=" + checkpeopleId + ", checkTotalId=" + checkTotalId + ", checkManname="
				+ checkManname + ", checkManCard=" + checkManCard + ", manType=" + manType + ", remark1=" + remark1
				+ "]";
	}
}