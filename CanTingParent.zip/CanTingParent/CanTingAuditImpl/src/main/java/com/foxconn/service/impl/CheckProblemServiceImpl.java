package com.foxconn.service.impl;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.entity.CheckProblem;
import com.foxconn.entity.DiningRoom;
import com.foxconn.mapper.CheckProblemMapper;
import com.foxconn.service.BaseService;
import com.foxconn.service.CheckProblemService;
import com.foxconn.service.CheckTotalService;
import com.foxconn.service.ImgFileService;

import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;

@Service
public class CheckProblemServiceImpl implements CheckProblemService{

	@Autowired
	private CheckProblemMapper mapper;
	@Autowired
	private BaseService baseService;
	@Autowired
	private ImgFileService imgService;
	@Autowired
	private CheckTotalService checkTotalService;
	
	private Logger logger = Logger.getLogger(this.getClass());
	
	@Override
	public int addCheckProblem(CheckProblem problem) {
		// TODO Auto-generated method stub
		return mapper.insertSelective(problem);
	}

	@Override
	public int delCheckProblem(String id) {
		// TODO Auto-generated method stub
		int i = mapper.deleteByPrimaryKey(id);
		if (i > 0) {
			List<String> list = Arrays.asList(id);
			if (ObjectUtils.isNotEmpty(list)) {
				imgService.delImgByForeign(list);
			}
		}
		return i;
	}

	@Override
	public int updateCheckProblem(CheckProblem problem) {
		
		return mapper.updateByPrimaryKeySelective(problem);
		
	}

	@Override
	public CheckProblem findOne(String id) {
		CheckProblem problem = mapper.selectByPrimaryKey(id);
		
		return problem;
	}

	@Override
	public List<CheckProblem> findByItem(String checkTotalId) {
		// TODO Auto-generated method stub
		Example example = new Example(CheckProblem.class);
		Criteria criteria = example.createCriteria();
		criteria.andEqualTo("checkMtotalId", checkTotalId);
		List<CheckProblem> list = mapper.selectByExample(example);
		return list;
	}
	
	/**
	 * @param restaurantId 餐厅ID
	 * @param thirdCode 对应问题的三级编码
	 * @param cycle 频率周期 ，根据问题等级，1-4星统计周期为三个月，5星统计周期为半年
	 * 根据餐厅ID统计犯规频率
	 */
	
	public int countWrong(String restaurantId, String thirdCode, double cycle) {
//		根据餐厅id查询餐厅信息并获取合同的开始和结束时间，如果没有查到，则返回-1并通知前端
		DiningRoom canting = baseService.findOneById(restaurantId, DiningRoom.class);
		if (null == canting) {
			return -1;
		}
		Date contractStart = canting.getContractStart();//合同开始时间
		LocalDateTime startDate = contractStart.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();//将contractStart转换成LocalDate类型
		
		Date contractEnd = canting.getContractEnd();//合同结束时间
		LocalDateTime endDate = contractEnd.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();//将contractStart转换成LocalDate类型
		
		LocalDateTime now = LocalDateTime.now();//当前时间
		if (now.isBefore(startDate)) {//合同开始时间还没到，还要过一段时间才开始生效
			logger.debug("合同开始时间还没到，还要过一段时间才开始生效");
			return -2;
		}else if (now.isAfter(endDate)) {//当前时间超过合同结束日期，合同已过期
			logger.debug("当前时间超过合同结束日期，合同已过期");
			return -3;
		}else {
			/**
			 * 根据条件计算合同开始时间的统计周期,cycle是统计周期，如果cycle=3，代表从统计周期是三个月，三个月后频率归0，重新统计
			 */
			Month startMmonth = now.getMonth();
			Month firstMonthOfQuarter = startMmonth.firstMonthOfQuarter();
			if (cycle == 3) {//每季度清零
				startDate = LocalDateTime.of(now.getYear(), firstMonthOfQuarter, 1, 00, 00);
			} else {// 每半年清零
				if (firstMonthOfQuarter.getValue() >= 7) {//计算三四季度开始时间
					startDate = LocalDateTime.of(now.getYear(), 7, 1, 00, 00);
				} else {
					startDate = LocalDateTime.of(now.getYear(), 1, 1, 00, 00);
					endDate = startDate.plusMonths(6);
				}
			}
		}
//		System.out.println("得到的开始时间："+startDate.getYear()+"年"+startDate.getMonthValue()+"月"+startDate.getDayOfMonth()+"日");
//		System.out.println("得到的结束时间："+endDate.getYear()+"年"+endDate.getMonthValue()+"月"+endDate.getDayOfMonth()+"日");
//		System.out.println("参数"+restaurantId+"---"+thirdCode+"--"+startDate+"--"+endDate);
		int i = mapper.countPinLv(restaurantId, thirdCode, startDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")), endDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
//		System.out.println(" 频率pinlv：" + i);
		return i;
	}

	@Override
	public List<String> findProblemIdByTotalId(String id) {
		// TODO Auto-generated method stub
		return mapper.findProblemIdByTotalId(id);
	}

	@Override
	public int updatePinLv(int pinlv, String problemId) {
		// TODO Auto-generated method stub
		return mapper.updatePinLv(pinlv, problemId);
	}

	public static void main(String[] args) {
		LocalDateTime now = LocalDateTime.of(2021, 4, 1, 00, 00);
		Month monthValue = now.getMonth();
		Month firstMonthOfQuarter = monthValue.firstMonthOfQuarter();
		System.out.println(firstMonthOfQuarter.getValue());
//		now = LocalDateTime.of(now.getYear(),firstMonthOfQuarter,1,00,00);
////		int quarter = ((monthValue%3) == 0)?(monthValue/3):((int)monthValue/3 + 1);
////		System.out.println(value);
//		
//		
//		
//		System.out.println(now.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
	}
	
}
