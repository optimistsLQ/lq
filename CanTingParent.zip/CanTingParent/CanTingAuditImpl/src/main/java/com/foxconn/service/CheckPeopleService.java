package com.foxconn.service;

import java.util.ArrayList;

import com.foxconn.entity.CheckPeople;
import com.github.pagehelper.PageInfo;

public interface CheckPeopleService {

	public int addCheckPeople(CheckPeople total);
	public int delCheckPeople(String id);
	public int updateCheckPeople(CheckPeople total);
	CheckPeople findOne(String id);
	public int addCheckPeopleList(ArrayList<CheckPeople> peopleList);
	public int delCheckPeopleByTotalId(String id);
}
