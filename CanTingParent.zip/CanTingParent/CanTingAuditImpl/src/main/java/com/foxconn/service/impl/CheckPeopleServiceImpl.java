package com.foxconn.service.impl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.entity.CheckPeople;
import com.foxconn.mapper.CheckPeopleMapper;
import com.foxconn.service.CheckPeopleService;
import com.github.pagehelper.PageInfo;

import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;

@Service
public class CheckPeopleServiceImpl implements CheckPeopleService{

	@Autowired
	private CheckPeopleMapper mapper;
	@Override
	public int addCheckPeople(CheckPeople total) {
		// TODO Auto-generated method stub
		return mapper.insertSelective(total);
	}

	@Override
	public int delCheckPeople(String id) {
		// TODO Auto-generated method stub
		return mapper.deleteByPrimaryKey(id);
	}

	@Override
	public int updateCheckPeople(CheckPeople total) {
		// TODO Auto-generated method stub
		return mapper.updateByPrimaryKeySelective(total);
	}

	@Override
	public CheckPeople findOne(String id) {
		// TODO Auto-generated method stub
		return mapper.selectByPrimaryKey(id);
	}

	@Override
	public int addCheckPeopleList(ArrayList<CheckPeople> peopleList) {
		// TODO Auto-generated method stub
		return mapper.addCheckPeopleList(peopleList);
	}

	@Override
	public int delCheckPeopleByTotalId(String id) {
		// TODO Auto-generated method stub
		Example example = new Example(CheckPeople.class);
		Criteria criteria = example.createCriteria();
		criteria.andEqualTo("checkTotalId", id);
		int i = mapper.deleteByExample(example);
		return i;
	}

}
