package com.foxconn.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

/**稽核問題
 * @author C3410596
 *
 */
@Table(name = "T_CHECKPROBLEM")
public class CheckProblem implements Serializable{
	@Transient
	private static final long serialVersionUID = -396813703378645946L;

	@Id
	private String checkProblemId;
//罚单id
    private String checkMtotalId;
//大類名稱
    private String typeBigName;
//三級編碼
    private String thirdCode;
//小類名稱
    private String typeSmallName;
//標準內容
    private String standContent;
//整改前圖片
    private String beforeImg;
//整改後圖片
    private String afterImg;
//發現的問題描述
    private String problemDetail;
//標準扣分
    private Double beforeScore;
//實際扣分
    private Double afterScore;
//標準罰款
    private Double beforeMoney;
//實際罰款
    private Double afterMoney;

    private Date writetime;
//等級
    private String grade;
//確認整改（Y/N）
    private String revise;
//餐厅ID
    private String cantingId;
    //处理措施备注
    private String standRemark;
//统计问题出现的频率
    private Integer pinlv;
//    问题点位置
    private String problemLocation;
	public String getCheckProblemId() {
		return checkProblemId;
	}
	public void setCheckProblemId(String checkProblemId) {
		this.checkProblemId = checkProblemId;
	}
	public String getCheckMtotalId() {
		return checkMtotalId;
	}
	public void setCheckMtotalId(String checkMtotalId) {
		this.checkMtotalId = checkMtotalId;
	}
	public String getTypeBigName() {
		return typeBigName;
	}
	public void setTypeBigName(String typeBigName) {
		this.typeBigName = typeBigName;
	}
	public String getThirdCode() {
		return thirdCode;
	}
	public void setThirdCode(String thirdCode) {
		this.thirdCode = thirdCode;
	}
	public String getTypeSmallName() {
		return typeSmallName;
	}
	public void setTypeSmallName(String typeSmallName) {
		this.typeSmallName = typeSmallName;
	}
	public String getStandContent() {
		return standContent;
	}
	public void setStandContent(String standContent) {
		this.standContent = standContent;
	}
	public String getBeforeImg() {
		return beforeImg;
	}
	public void setBeforeImg(String beforeImg) {
		this.beforeImg = beforeImg;
	}
	public String getAfterImg() {
		return afterImg;
	}
	public void setAfterImg(String afterImg) {
		this.afterImg = afterImg;
	}
	public String getProblemDetail() {
		return problemDetail;
	}
	public void setProblemDetail(String problemDetail) {
		this.problemDetail = problemDetail;
	}
	public Double getBeforeScore() {
		return beforeScore;
	}
	public void setBeforeScore(Double beforeScore) {
		this.beforeScore = beforeScore;
	}
	public Double getAfterScore() {
		return afterScore;
	}
	public void setAfterScore(Double afterScore) {
		this.afterScore = afterScore;
	}
	public Double getBeforeMoney() {
		return beforeMoney;
	}
	public void setBeforeMoney(Double beforeMoney) {
		this.beforeMoney = beforeMoney;
	}
	public Double getAfterMoney() {
		return afterMoney;
	}
	public void setAfterMoney(Double afterMoney) {
		this.afterMoney = afterMoney;
	}
	public Date getWritetime() {
		return writetime;
	}
	public void setWritetime(Date writetime) {
		this.writetime = writetime;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getRevise() {
		return revise;
	}
	public void setRevise(String revise) {
		this.revise = revise;
	}
	public String getCantingId() {
		return cantingId;
	}
	public void setCantingId(String cantingId) {
		this.cantingId = cantingId;
	}
	public String getStandRemark() {
		return standRemark;
	}
	public void setStandRemark(String standRemark) {
		this.standRemark = standRemark;
	}
	public Integer getPinlv() {
		return pinlv;
	}
	public void setPinlv(Integer pinlv) {
		this.pinlv = pinlv;
	}
	public String getProblemLocation() {
		return problemLocation;
	}
	public void setProblemLocation(String problemLocation) {
		this.problemLocation = problemLocation;
	}
	@Override
	public String toString() {
		return "CheckProblem [checkProblemId=" + checkProblemId + ", checkMtotalId=" + checkMtotalId + ", typeBigName="
				+ typeBigName + ", thirdCode=" + thirdCode + ", typeSmallName=" + typeSmallName + ", standContent="
				+ standContent + ", beforeImg=" + beforeImg + ", afterImg=" + afterImg + ", problemDetail="
				+ problemDetail + ", beforeScore=" + beforeScore + ", afterScore=" + afterScore + ", beforeMoney="
				+ beforeMoney + ", afterMoney=" + afterMoney + ", writetime=" + writetime + ", grade=" + grade
				+ ", revise=" + revise + ", cantingId=" + cantingId + ", standRemark=" + standRemark + ", pinlv="
				+ pinlv + ", problemLocation=" + problemLocation + "]";
	}
   
   
}