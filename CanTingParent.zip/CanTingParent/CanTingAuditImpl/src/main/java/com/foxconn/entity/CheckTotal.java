package com.foxconn.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

/**問題匯總實體
 * @author C3410596
 *
 */
@Table(name = "T_CHECKTOTAL")
public class CheckTotal implements Serializable{
	@Transient
	private static final long serialVersionUID = 8748981176708546780L;

	@Id
	private String checktotalId;
//餐包商
    private String mealSeller;
//餐廳位置
    private String restaurantLocation;
//餐廳負責人
    private String leader;
//稽核時間
    private String checktime;
//包商簽字
    private String mealSure;
//總務確認
    private String rearServiceSure;
//有無問題
    private String hastrouble;
//表單狀態
    private String overend;
//憑證URL
    private String proof;
//稽核狀態
    private String jiheStatus;
//餐廳信息ID
    private String restaurantId;
//稽核性質
    private String checkNaturn;
//稽核要點
    private String checkPoint;
//罚单创建人
    private String createUser;
//依据时间的单号
    private String filed2;

    private String filed3;

    private String filed4;
    @Transient
    private List<CheckPeople> peopleList;
    @Transient
    private List<CheckProblem> problemList;

    public String getChecktotalId() {
        return checktotalId;
    }

    public void setChecktotalId(String checktotalId) {
        this.checktotalId = checktotalId == null ? null : checktotalId.trim();
    }

    public String getMealSeller() {
        return mealSeller;
    }

    public void setMealSeller(String mealSeller) {
        this.mealSeller = mealSeller == null ? null : mealSeller.trim();
    }

    public String getRestaurantLocation() {
        return restaurantLocation;
    }

    public void setRestaurantLocation(String restaurantLocation) {
        this.restaurantLocation = restaurantLocation == null ? null : restaurantLocation.trim();
    }

    public String getLeader() {
        return leader;
    }

    public void setLeader(String leader) {
        this.leader = leader == null ? null : leader.trim();
    }

    public String getChecktime() {
        return checktime;
    }

    public void setChecktime(String checktime) {
        this.checktime = checktime == null ? null : checktime.trim();
    }

    public String getMealSure() {
        return mealSure;
    }

    public void setMealSure(String mealSure) {
        this.mealSure = mealSure == null ? null : mealSure.trim();
    }

    public String getRearServiceSure() {
        return rearServiceSure;
    }

    public void setRearServiceSure(String rearServiceSure) {
        this.rearServiceSure = rearServiceSure == null ? null : rearServiceSure.trim();
    }

    public String getHastrouble() {
        return hastrouble;
    }

    public void setHastrouble(String hastrouble) {
        this.hastrouble = hastrouble == null ? null : hastrouble.trim();
    }

    public String getOverend() {
        return overend;
    }

    public void setOverend(String overend) {
        this.overend = overend == null ? null : overend.trim();
    }

    public String getProof() {
        return proof;
    }

    public void setProof(String proof) {
        this.proof = proof == null ? null : proof.trim();
    }

    public String getJiheStatus() {
        return jiheStatus;
    }

    public void setJiheStatus(String jiheStatus) {
        this.jiheStatus = jiheStatus == null ? null : jiheStatus.trim();
    }

    public String getRestaurantId() {
        return restaurantId;
    }

    public void setRestaurantId(String restaurantId) {
        this.restaurantId = restaurantId == null ? null : restaurantId.trim();
    }

    public String getCheckNaturn() {
        return checkNaturn;
    }

    public void setCheckNaturn(String checkNaturn) {
        this.checkNaturn = checkNaturn == null ? null : checkNaturn.trim();
    }

    public String getCheckPoint() {
        return checkPoint;
    }

    public void setCheckPoint(String checkPoint) {
        this.checkPoint = checkPoint == null ? null : checkPoint.trim();
    }

    public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public String getFiled2() {
        return filed2;
    }

    public void setFiled2(String filed2) {
        this.filed2 = filed2 == null ? null : filed2.trim();
    }

    public String getFiled3() {
        return filed3;
    }

    public void setFiled3(String filed3) {
        this.filed3 = filed3 == null ? null : filed3.trim();
    }

    public String getFiled4() {
        return filed4;
    }

    public void setFiled4(String filed4) {
        this.filed4 = filed4 == null ? null : filed4.trim();
    }

	public List<CheckPeople> getPeopleList() {
		return peopleList;
	}

	public void setPeopleList(List<CheckPeople> peopleList) {
		this.peopleList = peopleList;
	}

	public List<CheckProblem> getProblemList() {
		return problemList;
	}

	public void setProblemList(List<CheckProblem> problemList) {
		this.problemList = problemList;
	}

	@Override
	public String toString() {
		return "CheckTotal [checktotalId=" + checktotalId + ", mealSeller=" + mealSeller + ", restaurantLocation="
				+ restaurantLocation + ", leader=" + leader + ", checktime=" + checktime + ", mealSure=" + mealSure
				+ ", rearServiceSure=" + rearServiceSure + ", hastrouble=" + hastrouble + ", overend=" + overend
				+ ", proof=" + proof + ", jiheStatus=" + jiheStatus + ", restaurantId=" + restaurantId
				+ ", checkNaturn=" + checkNaturn + ", checkPoint=" + checkPoint + ", createUser=" + createUser
				+ ", filed2=" + filed2 + ", filed3=" + filed3 + ", filed4=" + filed4 + ", peopleList=" + peopleList
				+ ", problemList=" + problemList + "]";
	}

	
	
}