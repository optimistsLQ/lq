package com.foxconn.mapper;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.CheckTotal;

import tk.mybatis.mapper.common.Mapper;

public interface CheckTotalMapper extends Mapper<CheckTotal>{

	List<CheckTotal> getTotalDataByPage(
			@Param("startDate")String startDate, 
			@Param("endDate")String endDate,
			@Param("checkPeople")String checkPeople, 
			@Param("overend")String overend,
			@Param("createUser")String createUser);

	List<CheckTotal> getTotalData(@Param("idList")List<CheckTotal> idList);

	CheckTotal getCheckTotalById(@Param("checkTotalId")String checkTotalId);

	int addCheckTotalList(@Param("totalList") ArrayList<CheckTotal> totalList);

	List<String> listcheckTotalIdListByCanTingId(@Param("restaurantId")String restaurantId);

    
}