package com.foxconn.service.impl;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.foxconn.entity.Dealer;
import com.foxconn.entity.FoodQualifiction;
import com.foxconn.entity.Result;
import com.foxconn.entity.ResultCode;
import com.foxconn.entity.StallChange;
import com.foxconn.mapper.DealerMapper;
import com.foxconn.mapper.FoodQualifictionMapper;
import com.foxconn.mapper.StallChangeMapper;
import com.foxconn.service.RequisitionService;
import com.foxconn.utils.Utils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;



@Service
public class RequisitionServiceImpl implements RequisitionService{

    @Autowired
    private StallChangeMapper stallChangeMapper;
    
    @Autowired
    private FoodQualifictionMapper foodQualifictionMapper;
    
    @Autowired
    private DealerMapper dealerMapper;
    // 日誌打印
    private Logger logger = Logger.getLogger(this.getClass());
    
    @Transactional
    @Override
    public Result insertStallChange(StallChange stallChange) {
    	try {
    		 String formType = "档口变动申请单";
	        //创建UUID，设置主键id
	        if (ObjectUtils.isEmpty(stallChange.getIdCard())) {
	            String uuid = UUID.randomUUID().toString().replaceAll("-", "");
	            stallChange.setIdCard(uuid);
	            stallChange.setSerialNum(produceNumber(stallChange.getCatererName(),formType));
	            stallChange.setWriteTime(new Date());
	            //插入数据
	            int i = stallChangeMapper.insert(stallChange);
	            //判断数据是否插入成功
	            if (i != 0) {
	                return new Result(ResultCode.SUCCESS,stallChange);
	            }
	            return new Result(ResultCode.FAIL,"上传失败");
	        } else {
	            Example newExample = new Example(StallChange.class);
	            Criteria newCriteria = newExample.createCriteria();
	            newCriteria.andEqualTo("idCard", stallChange.getIdCard());
	            stallChangeMapper.deleteByExample(newExample);
	            stallChange.setWriteTime(new Date());
//    	            stallChange.setStatus("签核中");
	            //插入数据
	            int i = stallChangeMapper.insert(stallChange);
	            //判断数据是否插入成功
	            if (i != 0) {
	                return new Result(ResultCode.SUCCESS,stallChange);
	            }
	            return new Result(ResultCode.FAIL,"上传失败");
	        }
    	} catch(Exception e) {
    		logger.debug("-----RequisitionServiceImpl.insertStallChange------",e);
    		return new Result(ResultCode.FAIL,"數據庫插入失敗！");
    	}
       
    }   

    /**
     * 生成编号
     * @param contractor 餐包商
     * @param formType 申请单类型
     * @return
     */
    private String produceNumber(String contractor,String formType) {
     
        String strDate = Utils.systemDate("yyyy-MM-dd");
        
        Integer num = 0;
        
        if (formType.equals("档口变动申请单")) {
            num = stallChangeMapper.selectStallChangeNum(contractor,strDate) + 1;
        } else if (formType.equals("食材资质申请单")) {
            num = foodQualifictionMapper.selectStallChangeNum(contractor,strDate) + 1;
        } else if (formType.equals("经销商申请")) {
            num = dealerMapper.selectDealer(contractor,strDate);
        } else {
            
        }
        if (num > 10) {
            return Utils.systemDate("yyyyMMdd")  + num.toString();
        }
        return Utils.systemDate("yyyyMMdd")  + "0" + num.toString();
    } 
    
    /**
     * 申请历史
     */
    @Override
    public Result applicationHistory(String catererName,String formType) {
        List<Map<String,Object>> list = new ArrayList<>();
        
        if (formType.equals("stall")) {
            //根據餐包商  查詢档口变动申请單
            list = stallChangeMapper.applicationHistory(catererName) ;
        } else if (formType.equals("foodQualifiction")) {
            list = foodQualifictionMapper.applicationHistory(catererName) ;
        } else if (formType.equals("dealer")) {
            list = dealerMapper.applicationHistory(catererName);
        } else {
            
        }
        
        //判断有无申请历史数据
        if (list.size() == 0) {
            return new Result(ResultCode.FAIL,list);
        }
        return new Result(ResultCode.SUCCESS,list);
    }
    
    
    @Transactional
    @Override
    public Result insertFoodQualifiction(FoodQualifiction foodQualifiction) {
    	try {
    		String formType = "食材资质申请单";
            Calendar calendar = Calendar.getInstance();
            Date licenseDate = foodQualifiction.getLicenseDate();
            Date productInspection = foodQualifiction.getProductInspection();//产品检验到期日期
            /**
             * 判斷入時間是否為空
             */
            Date date = new Date();//當前時間
            calendar.setTime(date);
            Long dateLong = calendar.getTimeInMillis();//當前時間毫秒数
            Integer dayNum = 86400000;//一天的毫秒數
            if (!ObjectUtils.isEmpty(licenseDate)) {
                calendar.setTime(licenseDate);
                Long licenseDateLong = calendar.getTimeInMillis();//許可證到期日期毫秒数
                Long discrepancy = licenseDateLong - dateLong;
                if ((discrepancy/dayNum) < 90) {
                    return new Result(ResultCode.FAIL,"许可证到期日期小于90天");
                }
            }
           
           if (!ObjectUtils.isEmpty(productInspection)) {
               calendar.setTime(productInspection);
               Long productInspectionLong = calendar.getTimeInMillis();//产品检验到期日期毫秒数
               if ( (productInspectionLong - dateLong)/dayNum < 90 ) {
                   return new Result(ResultCode.FAIL,"产品检验到期日期小于90天");
               }
           }
           
            //判斷uuid是否存在，存在表示單子已存在，重新發起單子
           if (StringUtils.isEmpty(foodQualifiction.getIdCard())) {
        	   //创建UUID，设置主键id
        	   String uuid = UUID.randomUUID().toString().replaceAll("-", "");
        	   foodQualifiction.setIdCard(uuid);
        	   foodQualifiction.setSerialNum(produceNumber(foodQualifiction.getCatererName(),formType));
        	   foodQualifiction.setWriteTime(new Date());
        	   //插入数据
        	   int i = foodQualifictionMapper.insertSelective(foodQualifiction);
        	   //判断数据是否插入成功
        	   if (i != 0) {
        		   return new Result(ResultCode.SUCCESS,foodQualifiction);
        	   }
        	   return new Result(ResultCode.FAIL,"上传失败");
           } else {
               
               // 判断是否为共享单子
               if (StringUtils.isEmpty(foodQualifiction.getIsShare()) || foodQualifiction.getIsShare().equals("N")) {
                   // 单子存在不为共享单子 只是重新发起
                   Example newExample = new Example(FoodQualifiction.class);
                   Criteria newCriteria = newExample.createCriteria();
                   newCriteria.andEqualTo("idCard", foodQualifiction.getIdCard());
                   //删除原来的单子
                   foodQualifictionMapper.deleteByExample(newExample);
                   foodQualifiction.setWriteTime(new Date());
//                    foodQualifiction.setStatus("签核中");
                   //重新插入数据
                   int i = foodQualifictionMapper.insertSelective(foodQualifiction);
                   //判断数据是否插入成功
                   if (i != 0) {
                        return new Result(ResultCode.SUCCESS,foodQualifiction);
                   }
               } else if (foodQualifiction.getIsShare().equals("Y")){
                   // 发起共享食材资质单子
                   String uuid = UUID.randomUUID().toString().replaceAll("-", "");
                   foodQualifiction.setIdCard(uuid);
                   foodQualifiction.setSerialNum(produceNumber(foodQualifiction.getCatererName(),formType));
                   foodQualifiction.setWriteTime(new Date());
                   int i = foodQualifictionMapper.insertSelective(foodQualifiction);
                   if (i != 0) {
                       return new Result(ResultCode.SUCCESS,foodQualifiction);
                  }
               }
               return new Result(ResultCode.FAIL,"上传失败");
            }
    	} catch (Exception e) {
    		logger.debug("-----RequisitionServiceImpl.insertFoodQualifiction-----",e);
    		return new Result(ResultCode.FAIL,"數據庫插入失敗！");
    	}
        
    }

    @Override
    public Result getStallInfo(String idCard) {
        //根據表單id獲取整張單子詳情
        Example newExample = new Example(StallChange.class);
        Criteria newCriteria = newExample.createCriteria();
        newCriteria.andEqualTo("idCard", idCard);
        return new Result(ResultCode.SUCCESS, stallChangeMapper.selectOneByExample(newExample));
    }

    @Override
    public Result Pagination(String uuid,Map<String,Object> map) {
        //檔口變更數據
        List<Map<String,Object>> stallList = stallChangeMapper.selectPagination(uuid);
        //食材資質數據
        List<Map<String,Object>> foodList = foodQualifictionMapper.selectPagination(uuid);
        //经销商数据
        List<Map<String,Object>> dealerList = dealerMapper.selectPagination(uuid);
        /**
         * 表單都為空則直接返回空数组
         */
        if (stallList.size() == 0 && foodList.size() == 0 && dealerList.size() == 0) {
            Map<String,Object> pageMap = new HashMap<>();
            pageMap.put("total", 0);
            pageMap.put("value", stallList);
            return new Result(ResultCode.FAIL,pageMap);
        }
        Integer start = Integer.parseInt(map.get("start").toString()); //頁碼
        Integer length = Integer.parseInt(map.get("length").toString()); //每頁大小
        //設置name
        for (Map<String, Object> map2 : stallList) {
            map2.put("name", "档口变更");
            map2.put("type", "stall");
        }

        /**
         * 將食材資質的待簽表單加入list
         */
        for (Map<String, Object> map2 : foodList) {
            map2.put("name", "食材资质");
            map2.put("type", "foodQualifiction");
            stallList.add(map2);
        }
        
        /**
         * 将经销商的待签表单数据放入list中
         */
        for (Map<String, Object> map2 : dealerList) {
            map2.put("name", "供应商申请");
            map2.put("type", "dealer");
            stallList.add(map2);
        }
        List<Object> list = new ArrayList<>(stallList);
        Map<String,Object> pageMap = new HashMap<>();
        pageMap.put("total", stallList.size());
        pageMap.put("value", Utils.fakePagination(list,start,length));
        return new Result(ResultCode.SUCCESS,pageMap);
    }  
    

    @Override
    public Result getFoodsQualifiction(String idCard) {
        Example newExample = new Example(FoodQualifiction.class);
        Criteria newCriteria = newExample.createCriteria();
        newCriteria.andEqualTo("idCard", idCard);
        return new Result(ResultCode.SUCCESS, foodQualifictionMapper.selectOneByExample(newExample));
    }

    @Override
    public Result SummaryTable(Map<String, Object> map) {
        Integer start = Integer.parseInt(map.get("start").toString());
        Integer length = Integer.parseInt(map.get("length").toString());
        // 获取查询条件
        String catererName = (String) map.get("catererName");
        String largeCategories = (String) map.get("largeCategories");
        String startDate = (String) map.get("startDate");
        String endDate = (String) map.get("endDate");
        // 分页
        if (ObjectUtils.isNotEmpty(start) && ObjectUtils.isNotEmpty(length)) {
            PageHelper.startPage(start, length);
        }
        List<FoodQualifiction> list =  foodQualifictionMapper.selectByInfo(catererName,largeCategories,startDate,endDate);
        PageInfo<FoodQualifiction> info = new PageInfo<FoodQualifiction>(list);
        return new Result(ResultCode.SUCCESS,info);
    }
    @Transactional
    @Override
    public Result insertDealer(Dealer dealer) {
    	try {
    		Calendar calendar = Calendar.getInstance();
            Date licenseDate = dealer.getLicenseDate();
            Date date = new Date();//當前時間
            calendar.setTime(date);
            Long dateLong = calendar.getTimeInMillis();//當前時間毫秒数
            Integer dayNum = 86400000;//一天的毫秒數
            if (!ObjectUtils.isEmpty(licenseDate)) {
                calendar.setTime(licenseDate);
                Long licenseDateLong = calendar.getTimeInMillis();//許可證到期日期毫秒数
                Long discrepancy = licenseDateLong - dateLong;
                if ((discrepancy/dayNum) < 90) {
                    return new Result(ResultCode.FAIL,"许可证到期日期小于90天");
                }
            }
           String formType = "经销商申请";
           //创建UUID，设置主键id
           if (ObjectUtils.isEmpty(dealer.getIdCard())) {
               String uuid = UUID.randomUUID().toString().replaceAll("-", "");
               dealer.setIdCard(uuid);
               dealer.setSerialNum(produceNumber(dealer.getCatererName(),formType));
               dealer.setWriteTime(new Date());
               
               //插入数据
               int i = dealerMapper.insertSelective(dealer);
               //判断数据是否插入成功
               if (i != 0) {
                   return new Result(ResultCode.SUCCESS,dealer);
               }
               return new Result(ResultCode.FAIL,"上传失败");
           } else {
               Example newExample = new Example(Dealer.class);
               Criteria newCriteria = newExample.createCriteria();
               newCriteria.andEqualTo("idCard", dealer.getIdCard());
               dealerMapper.deleteByExample(newExample);
               dealer.setWriteTime(new Date());
//               dealer.setStatus("签核中");
               //插入数据
               Integer i = dealerMapper.insertSelective(dealer);
               //判断数据是否插入成功
               if (i != 0) {
                   return new Result(ResultCode.SUCCESS,dealer);
               }
               return new Result(ResultCode.FAIL,"上传失败");
           }
    	} catch (Exception e) {
    		logger.debug("-----RequisitionServiceImpl.insertDealer-----",e);
    		return new Result(ResultCode.FAIL,"數據庫插入失敗！");
    	}
         
    }

	@Override
	public Result getDealer(String idCard) {
		Example newExample = new Example(Dealer.class);
        Criteria newCriteria = newExample.createCriteria();
        newCriteria.andEqualTo("idCard", idCard);
        return new Result(ResultCode.SUCCESS, dealerMapper.selectOneByExample(newExample));
	}

	/**
	 * {@link com.foxconn.service.RequisitionService#LikeProductName(String)}
	 */
	@Override
	public Result LikeProductName(String name) {
		// TODO Auto-generated method stub
		return new Result(ResultCode.SUCCESS,foodQualifictionMapper.ListProductName(name));
	}
	/**
	 * {@link com.foxconn.service.RequisitionService#LikeDealer(String)}
	 */
	@Override
	public Result LikeDealer(String name) {
		// TODO Auto-generated method stub
	    
	    Example newExample = new Example(Dealer.class);
        Criteria newCriteria = newExample.createCriteria();
        newCriteria.andLike("dealerName", name);
		return new Result(ResultCode.SUCCESS,dealerMapper.ListDealer(name));
	}
	/**
	 * {@link com.foxconn.service.RequisitionService#LikeBrand(String)}
	 */
	@Override
	public Result LikeBrand(String name) {
		// TODO Auto-generated method stub
		return new Result(ResultCode.SUCCESS,foodQualifictionMapper.ListBrand(name));
	}
    /**
     * {@link com.foxconn.service.RequisitionService#ListSharedFoodQualifiction(String)}
     */
    @Override
    public Result ListSharedFoodQualifiction(String contractor) {
        // TODO Auto-generated method stub
        
        // 查询当前餐包商名下所有有资质的经销商
        List<String> listDealerName = dealerMapper.ListDealerName(contractor);
        
        // 反回查询到的可以共享食材资质
        return new Result(ResultCode.SUCCESS, foodQualifictionMapper.ListSharedFoodQualifiction(listDealerName,contractor));
    }
    /**
     * {@link com.foxconn.service.RequisitionService#ListShareDealWith(String)}
     */
    @Override
    public Result ListShareDealWith(String length, String start, String uuid) {
        
        
        List<Map<String,Object>> foodList = foodQualifictionMapper.selectPaginationByShare(uuid);
        
        /**
         * 表單為空則直接返回空数组
         */
        if (foodList.size() == 0) {
            Map<String,Object> pageMap = new HashMap<>();
            pageMap.put("total", 0);
            pageMap.put("value", foodList);
            return new Result(ResultCode.FAIL,pageMap);
        }
        Integer startInt = Integer.parseInt(start); //頁碼
        Integer lengthInt = Integer.parseInt(length); //每頁大小
        
        /**
         * 將食材資質的待簽表單加入list
         */
        for (Map<String, Object> map2 : foodList) {
            map2.put("name", "食材资质");
            map2.put("type", "foodQualifiction");
            
        }
        List<Object> list = new ArrayList<>(foodList);
        Map<String,Object> pageMap = new HashMap<>();
        pageMap.put("total", foodList.size());
        pageMap.put("value", Utils.fakePagination(list,startInt,lengthInt));
        return new Result(ResultCode.SUCCESS,pageMap);
    }
    

    /**
     * {@link com.foxconn.service.CheckTotalService#getProblemStatistics}
     */
    @Override
    public Result getProblemStatistics() {
        // TODO Auto-generated method stub
        
        //设置时间格式
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd"); 
        //获得实体类
        Calendar ca = Calendar.getInstance();    
        //设置當月最后一天
        ca.set(Calendar.DAY_OF_MONTH, ca.getActualMaximum(Calendar.DAY_OF_MONTH));
        //最后一天格式化
        String lastDay = format.format(ca.getTime());
 
        // 設置當月第一天
        ca.set(Calendar.DAY_OF_MONTH, ca.getActualMinimum(Calendar.DAY_OF_MONTH));
        // 第一天格式化
        String firstDay = format.format(ca.getTime());
        
        List<Map<String,Object>> list =  dealerMapper.ListCountProblemGroup(firstDay,lastDay);
        Map<String,Integer> problemMap = new HashMap<>();// 问题种类
        Map<String,Integer> gradeMap = new HashMap<>();// 问题等级
        Integer total = 0;// 總計扣分數量
        
        for (Map<String, Object> map : list) {
            String problem = (String) map.get("TYPE_BIG_NAME");// 問題類
            String grade = (String) map.get("GRADE");// 星級
            int num = ((BigDecimal) map.get("NUM")).intValue();// 扣分次數
            // 判断是否为空 为空则添0
            if (ObjectUtils.isEmpty(problemMap.get(problem))) {
                problemMap.put(problem, num);
            } else {
                problemMap.put(problem, problemMap.get(problem) + num);
            }
            if (ObjectUtils.isEmpty(gradeMap.get(grade))) {
                gradeMap.put(grade, num);
            } else {
                gradeMap.put(grade, gradeMap.get(grade) + num);
            }
            total = num + total;
        }
        List<Map<String,Object>> gradeList = new ArrayList<>();
        List<Map<String,Object>> problemList = new ArrayList<>();
        /**
         * 统计问题种类数量
         */
        // 轉換為Iteratir對象進行遍歷map
        Set<Map.Entry<String,Integer>> attSet = problemMap.entrySet();
        Iterator<Entry<String, Integer>> attIterator = attSet.iterator();
        while (attIterator.hasNext()) {
            Entry<String, Integer> attEntry = attIterator.next();
            String k = attEntry.getKey();
            Integer v = attEntry.getValue();
            Map<String,Object> map = new HashMap<>();
            map.put("name", k);
            map.put("value", v);
            map.put("rate", v/total.doubleValue());
            problemList.add(map);
        }
        
        
        Set<Map.Entry<String,Integer>> gradeSet = gradeMap.entrySet();
        Iterator<Entry<String, Integer>> gradeIterator = gradeSet.iterator();
        while (gradeIterator.hasNext()) {
            Entry<String, Integer> attEntry = gradeIterator.next();
            String k = attEntry.getKey();
            Integer v = attEntry.getValue();
            Map<String,Object> map = new HashMap<>(); 
            map.put("name", k);
            map.put("value", v);
            map.put("rate", v/total.doubleValue());
            gradeList.add(map);
        }
        
        // 統計餐廳扣分最多前五項
        List<Map<String,Object>> restaurantList = dealerMapper.CountRestaurant(firstDay,lastDay);
        // 統計包商扣分最多前五項
        List<Map<String,Object>> catererList = dealerMapper.CountCaterer(firstDay,lastDay);
        
        
        /**
        * 問題分類模塊
        */
        Map<String,Object> mapA = new HashMap<>();
        mapA.put("name", "問題分類");
        mapA.put("total", total);
        mapA.put("value", problemList);
        /**
         * 星級分類模塊
         */
        Map<String,Object> mapB = new HashMap<>();
        mapB.put("name", "星級分類");
        mapB.put("total", total);
        mapB.put("value", gradeList);
        /**
         * 餐廳扣分排行榜模塊
         */
        Map<String,Object> mapC = new HashMap<>();
        mapC.put("name", "餐廳排行");
        mapC.put("value", restaurantList);
        /**
         * 包商扣分排行榜模塊
         */
        Map<String,Object> mapD = new HashMap<>();
        mapD.put("name", "包商排行");
        mapD.put("value", catererList);
        /**
         * 返回數據
         */
        Map<String,Object> map = new HashMap<>();
        map.put("problem", mapA);
        map.put("grade", mapB);
        map.put("restaurant", mapC);
        map.put("caterer", mapD);
        return new Result(ResultCode.SUCCESS, map);
    }

}
