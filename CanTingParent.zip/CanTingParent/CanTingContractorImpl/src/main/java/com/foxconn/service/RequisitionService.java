package com.foxconn.service;

import java.util.Map;

import com.foxconn.entity.Dealer;
import com.foxconn.entity.FoodQualifiction;
import com.foxconn.entity.Result;
import com.foxconn.entity.StallChange;

/**
 * 申请单
 * @author C3414208
 *
 */
public interface RequisitionService {

    /**
     * 插入数据
     * @param stallChange 档口变动信息类
     * @return
     */
    Result insertStallChange(StallChange stallChange);

    /**
     * 历史申请数据
     * @param catererName 餐包商名称
     * @return 
     */
    Result applicationHistory(String catererName,String formType);


    /**
     * 插入数据
     * @param stallChange 食材资质信息
     * @return
     */
    Result insertFoodQualifiction(FoodQualifiction foodQualifiction);
    
    /**
     * 档口申请详情
     */
    Result getStallInfo(String idCard);

    /**
     *  包商专区表单待簽核分頁查詢
     * @param uuid
     */
    Result Pagination(String uuid,Map<String,Object> map);

//    /**
//     *归档查询 
//     * @return
//     */
//    Result ArchiveQuery(String length, String start, String type,String uuid);

    /**
     * 食材資質詳情
     * @param idCard
     * @return
     */
    Result getFoodsQualifiction(String idCard);

    /**
     * 食材資質匯總表
     * @param map
     * @return
     */
    Result SummaryTable(Map<String, Object> map);

    /**
     * 经销商申请
     * @param dealr
     * @return
     */
    Result insertDealer(Dealer dealr);

    /**
     * 经销商申请详情
     * @param idCard
     * @return
     */
	Result getDealer(String idCard);

	/**
	 * 品名模糊查询
	 * @param name 查询条件商品名称
	 * @return
	 */
	Result LikeProductName(String name);

	/**
	 * 经销商模糊查询
	 * @param name
	 * @return
	 */
	Result LikeDealer(String name);

	/**
	 * 品牌模糊查询
	 * @param name
	 * @return
	 */
	Result LikeBrand(String name);

	/**
	 * 查询可共享食材资质表单
	 * @param contractor 餐包商
	 * @return
	 */
    Result ListSharedFoodQualifiction(String contractor);

    /**
     * 食材资质共享数据待签核表单数据
     * @param length
     * @param start
     * @param uuid 当前签核人员id
     * @return
     */
    Result ListShareDealWith(String length, String start, String uuid);

    /**
     * 餐包商战情图
     * @return
     */
    Result getProblemStatistics();
}
