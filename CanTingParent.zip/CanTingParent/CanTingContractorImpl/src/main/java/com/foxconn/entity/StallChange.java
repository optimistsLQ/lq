package com.foxconn.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 档口变动申請表
 * @author C3414208
 *
 */
@Table(name = "T_STALL_CHANGE")
public class StallChange implements Serializable{

    /**
     * 
     */
    private static final long serialVersionUID = -4803087420626010986L;
    @Id
    private String idCard;
    
    private String serialNum; //编号
    private String catererName; //餐包商名称
    private String restaurantLocation;//餐厅位置
    private String restaurantPrincipal;// 负责人
    private String applicants;//申请人
    private String slogan;// 档口号
    private String sloganName;//档口名称
    private String sloganPrincipal;//档口负责人
    
    @DateTimeFormat(pattern = "yyyy/MM/dd")
    @JSONField(format = "yyyy/MM/dd")
    @JsonFormat(pattern = "yyyy/MM/dd", timezone = "GMT+8")
    private Date applicationTime;//申请时间
    private String applicationType;//申请类型
    private String applicationDescription;//申请说明
    private String status;
    @DateTimeFormat(pattern = "yyyy/MM/dd")
    @JSONField(format = "yyyy/MM/dd")
    @JsonFormat(pattern = "yyyy/MM/dd", timezone = "GMT+8")
    private Date writeTime;//写入时间
    private String lever;// 餐厅性质
    
    
    
    
    public String getLever() {
		return lever;
	}
	public void setLever(String lever) {
		this.lever = lever;
	}
	public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public Date getWriteTime() {
        return writeTime;
    }
    public void setWriteTime(Date writeTime) {
        this.writeTime = writeTime;
    }
    public String getIdCard() {
        return idCard ;
    }
    public void setIdCard(String idCard) {
        this.idCard = idCard == null ? null : idCard.trim();
    }
    public String getSerialNum() {
        return serialNum;
    }
    public void setSerialNum(String serialNum) {
        this.serialNum = serialNum;
    }
    public String getCatererName() {
        return catererName;
    }
    public void setCatererName(String catererName) {
        this.catererName = catererName;
    }
    public String getRestaurantLocation() {
        return restaurantLocation;
    }
    public void setRestaurantLocation(String restaurantLocation) {
        this.restaurantLocation = restaurantLocation;
    }
    public String getRestaurantPrincipal() {
        return restaurantPrincipal;
    }
    public void setRestaurantPrincipal(String restaurantPrincipal) {
        this.restaurantPrincipal = restaurantPrincipal;
    }

    public String getSlogan() {
        return slogan;
    }
    public void setSlogan(String slogan) {
        this.slogan = slogan;
    }
    public String getSloganName() {
        return sloganName;
    }
    public void setSloganName(String sloganName) {
        this.sloganName = sloganName;
    }
    public String getSloganPrincipal() {
        return sloganPrincipal;
    }
    public void setSloganPrincipal(String sloganPrincipal) {
        this.sloganPrincipal = sloganPrincipal;
    }
    public Date getApplicationTime() {
        return applicationTime;
    }
    public void setApplicationTime(Date applicationTime) {
        this.applicationTime = applicationTime;
    }
    public String getApplicationType() {
        return applicationType;
    }
    public void setApplicationType(String applicationType) {
        this.applicationType = applicationType;
    }
    public String getApplicationDescription() {
        return applicationDescription;
    }
    public void setApplicationDescription(String applicationDescription) {
        this.applicationDescription = applicationDescription;
    }
    public String getApplicants() {
        return applicants;
    }
    public void setApplicants(String applicants) {
        this.applicants = applicants;
    }
	@Override
	public String toString() {
		return "StallChange [idCard=" + idCard + ", serialNum=" + serialNum + ", catererName=" + catererName
				+ ", restaurantLocation=" + restaurantLocation + ", restaurantPrincipal=" + restaurantPrincipal
				+ ", applicants=" + applicants + ", slogan=" + slogan + ", sloganName=" + sloganName
				+ ", sloganPrincipal=" + sloganPrincipal + ", applicationTime=" + applicationTime + ", applicationType="
				+ applicationType + ", applicationDescription=" + applicationDescription + ", status=" + status
				+ ", writeTime=" + writeTime + ", lever=" + lever + "]";
	}

}
