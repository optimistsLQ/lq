package com.foxconn.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.entity.Foods;
import com.foxconn.entity.Result;
import com.foxconn.entity.ResultCode;
import com.foxconn.mapper.FoodsMapper;
import com.foxconn.service.FoodsService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;

@Service
public class FoodsServiceImpl implements FoodsService{

    @Autowired
    private FoodsMapper foodsMapper;
    @Override
    public PageInfo<Foods>  getLargeCateGories(Integer start, Integer length) {
        
        List<Foods> foodList = null;
        if (ObjectUtils.isNotEmpty(start) && ObjectUtils.isNotEmpty(length)) {
            PageHelper.startPage(start, length);
        }
        foodList =  foodsMapper.findAll();
        PageInfo<Foods> info = new PageInfo<Foods>(foodList);
        return info;
    }
    
    @Override
    public Map<String, String> updateFood(Foods food) {
        // TODO Auto-generated method stub
        Example newExample = new Example(Foods.class);
        Criteria newCriteria = newExample.createCriteria();
        newCriteria.andEqualTo("idCard", food.getIdCard());
        Integer integer = foodsMapper.updateByExample(food, newExample);
        Map<String,String> map = new HashMap<>();
        if (integer != 0) {
            map.put("msg", "OK");
            return map;
        }
        return null;
    }

    @Override
    public Result insertFoods(Foods food) {
        // TODO Auto-generated method stub
        Integer integer = foodsMapper.insertSelective(food);
        if (integer != 0) {
           
            return new Result(ResultCode.SUCCESS);
        }
        return new Result(ResultCode.FAIL);
    }

    @Override
    public Result deleteTolsig(List<String> deleteIds) {
        Integer i = foodsMapper.deleteFoods(deleteIds);
        if (i != 0) {
            return new Result(ResultCode.SUCCESS); 
        } else {
            return new Result(ResultCode.FAIL);
        }
       
    }

    @Override
    public Result getLargeCategories() {
        // TODO Auto-generated method stub
        List<String> list = foodsMapper.getLargeCategories();
        return new Result(ResultCode.SUCCESS,list);
    }

    @Override
    public Result getSubcategory(String largeCategories) {
        // TODO Auto-generated method stub
        List<Map<String,String>> list = foodsMapper.getSubcategory(largeCategories);
        return new Result(ResultCode.SUCCESS,list);
    }

}
