package com.foxconn.service;

import java.util.List;
import java.util.Map;

import com.foxconn.entity.Foods;
import com.foxconn.entity.Result;
import com.github.pagehelper.PageInfo;

public interface FoodsService {

    /**
     * 分頁查詢所有的
     * @param start
     * @param length
     * @return
     */
    PageInfo<Foods> getLargeCateGories(Integer start, Integer length);

    /**
     * 修改食物類
     * @param food
     * @return
     */
    Map<String,String> updateFood(Foods food);

    /**
     * 插入一條foods數據
     * @param food
     * @return
     */
    Result insertFoods(Foods food);

    /**
     * 批量删除
     * @param deleteIds
     * @return
     */
    Result deleteTolsig(List<String> deleteIds);

    /**
     * 获取食材大类
     * @return
     */
    Result getLargeCategories();

    /**
     * 通过食材大类获取相因的小类
     * @param largeCategories
     * @return
     */
    Result getSubcategory(String largeCategories);

}
