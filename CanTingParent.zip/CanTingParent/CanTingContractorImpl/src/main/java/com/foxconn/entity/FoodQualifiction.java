package com.foxconn.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 食材資質申請表
 * @author C3414208
 *
 */
@Table(name = "T_FOOD_QUALIFICATION")
public class FoodQualifiction implements Serializable{

    /**
     * 
     */
    private static final long serialVersionUID = 6280667009746518062L;

    @Id
    private String idCard;
    @DateTimeFormat(pattern = "yyyy/MM/dd")
    @JSONField(format = "yyyy/MM/dd")
    @JsonFormat(pattern = "yyyy/MM/dd", timezone = "GMT+8")
    private Date applicationTime;//申请时间
    private String catererName; //餐包商名称
    private String serialNum; //编号
    private String dealer;//经销商
    private String applicants;//申請人
    private String manufacturer;//生產廠商
    private String brand;//品牌
    private String productName;//品名
    private String largeCategories;//食材大类
    private String subcategory;//食材小類
    private String specifications;//規格
    private String grade;//等级
    @DateTimeFormat(pattern = "yyyy/MM/dd")
    @JSONField(format = "yyyy/MM/dd")
    @JsonFormat(pattern = "yyyy/MM/dd", timezone = "GMT+8")
    private Date licenseDate;//許可證到期日期
    @DateTimeFormat(pattern = "yyyy/MM/dd")
    @JSONField(format = "yyyy/MM/dd")
    @JsonFormat(pattern = "yyyy/MM/dd", timezone = "GMT+8")
    private Date productInspection;//產品檢驗到期日期
    private String remark;//申請說明
    private String status;
    
    private String isShare;// 表单类型
    private String serialNumber;// 经营许可证编号
    
    @DateTimeFormat(pattern = "yyyy/MM/dd")
    @JSONField(format = "yyyy/MM/dd")
    @JsonFormat(pattern = "yyyy/MM/dd", timezone = "GMT+8")
    private Date writeTime;
    
    
    
    
    

	public String getIsShare() {
        return isShare;
    }
    public void setIsShare(String isShare) {
        this.isShare = isShare;
    }
    public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getApplicants() {
        return applicants;
    }
    public void setApplicants(String applicants) {
        this.applicants = applicants;
    }
    public Date getWriteTime() {
        return writeTime;
    }
    public void setWriteTime(Date writeTime) {
        this.writeTime = writeTime;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public String getIdCard() {
        return idCard;
    }
    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }
    public Date getApplicationTime() {
        return applicationTime;
    }
    public void setApplicationTime(Date applicationTime) {
        this.applicationTime = applicationTime;
    }
    public String getCatererName() {
        return catererName;
    }
    public void setCatererName(String catererName) {
        this.catererName = catererName;
    }
    public String getSerialNum() {
        return serialNum;
    }
    public void setSerialNum(String serialNum) {
        this.serialNum = serialNum;
    }
    public String getDealer() {
        return dealer;
    }
    public void setDealer(String dealer) {
        this.dealer = dealer;
    }
    public String getManufacturer() {
        return manufacturer;
    }
    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }
    public String getBrand() {
        return brand;
    }
    public void setBrand(String brand) {
        this.brand = brand;
    }
    public String getProductName() {
        return productName;
    }
    public void setProductName(String productName) {
        this.productName = productName;
    }

    
    public String getLargeCategories() {
        return largeCategories;
    }
    public void setLargeCategories(String largeCategories) {
        this.largeCategories = largeCategories;
    }
    public String getSubcategory() {
        return subcategory;
    }
    public void setSubcategory(String subcategory) {
        this.subcategory = subcategory;
    }
    public String getSpecifications() {
        return specifications;
    }
    public void setSpecifications(String specifications) {
        this.specifications = specifications;
    }
    public String getGrade() {
        return grade;
    }
    public void setGrade(String grade) {
        this.grade = grade;
    }
    public Date getLicenseDate() {
        return licenseDate;
    }
    public void setLicenseDate(Date licenseDate) {
        this.licenseDate = licenseDate;
    }
    public Date getProductInspection() {
        return productInspection;
    }
    public void setProductInspection(Date productInspection) {
        this.productInspection = productInspection;
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark;
    }
    @Override
    public String toString() {
        return "FoodQualifiction [idCard=" + idCard + ", applicationTime=" + applicationTime + ", catererName="
                + catererName + ", serialNum=" + serialNum + ", dealer=" + dealer + ", applicants=" + applicants
                + ", manufacturer=" + manufacturer + ", brand=" + brand + ", productName=" + productName
                + ", largeCategories=" + largeCategories + ", subcategory=" + subcategory + ", specifications="
                + specifications + ", grade=" + grade + ", licenseDate=" + licenseDate + ", productInspection="
                + productInspection + ", remark=" + remark + ", status=" + status + ", isShare=" + isShare
                + ", serialNumber=" + serialNumber + ", writeTime=" + writeTime + "]";
    }

    
    
}
