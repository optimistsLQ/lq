package com.foxconn.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 經銷商申請表
 * @author C3414208
 *
 */
@Table(name = "T_DEALER")
public class Dealer implements Serializable{

    /**
     * 
     */
    private static final long serialVersionUID = -8682042107171611784L;
    @Id
    private String idCard;
    @DateTimeFormat(pattern = "yyyy/MM/dd")
    @JSONField(format = "yyyy/MM/dd")
    @JsonFormat(pattern = "yyyy/MM/dd", timezone = "GMT+8")
    private Date applicationTime;//申请时间
    private String serialNum; //编号
    private String catererName; //餐包商名称
    private String dealerName;//经销商
    @DateTimeFormat(pattern = "yyyy/MM/dd")
    @JSONField(format = "yyyy/MM/dd")
    @JsonFormat(pattern = "yyyy/MM/dd", timezone = "GMT+8")
    private Date licenseDate;    //食品經營許可證到期日期
    private String remark;//備註
    @DateTimeFormat(pattern = "yyyy/MM/dd")
    @JSONField(format = "yyyy/MM/dd")
    @JsonFormat(pattern = "yyyy/MM/dd", timezone = "GMT+8")
    private Date writeTime;//写入时间
    private String applicants;//申请人
    private String status;//表单状态
    
    private String serialNumber;// 许可证编号
    
    
    public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public void setDealerName(String dealerName) {
		this.dealerName = dealerName;
	}
	public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public Date getApplicationTime() {
        return applicationTime;
    }
    public void setApplicationTime(Date applicationTime) {
        this.applicationTime = applicationTime;
    }
    public String getApplicants() {
        return applicants;
    }
    public void setApplicants(String applicants) {
        this.applicants = applicants;
    }
    public String getIdCard() {
        return idCard;
    }
    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }
    public String getSerialNum() {
        return serialNum;
    }
    public void setSerialNum(String serialNum) {
        this.serialNum = serialNum;
    }
    public String getCatererName() {
        return catererName;
    }
    public void setCatererName(String catererName) {
        this.catererName = catererName;
    }
    public String getDealerName() {
        return dealerName;
    }
    public void setNewDealerName(String dealerName) {
        this.dealerName = dealerName;
    }
    public Date getLicenseDate() {
        return licenseDate;
    }
    public void setLicenseDate(Date licenseDate) {
        this.licenseDate = licenseDate;
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark;
    }
    public Date getWriteTime() {
        return writeTime;
    }
    public void setWriteTime(Date writeTime) {
        this.writeTime = writeTime;
    }
	@Override
	public String toString() {
		return "Dealer [idCard=" + idCard + ", applicationTime=" + applicationTime + ", serialNum=" + serialNum
				+ ", catererName=" + catererName + ", dealerName=" + dealerName + ", licenseDate=" + licenseDate
				+ ", remark=" + remark + ", writeTime=" + writeTime + ", applicants=" + applicants + ", status="
				+ status + ", serialNumber=" + serialNumber + "]";
	}


    
    
    
}
