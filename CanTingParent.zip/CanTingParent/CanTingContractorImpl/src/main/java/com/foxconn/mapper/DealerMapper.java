package com.foxconn.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.Dealer;

import tk.mybatis.mapper.common.Mapper;

public interface DealerMapper extends Mapper<Dealer>{

    Integer selectDealer(@Param("contractor")String catererName, @Param("strDate")String strDate);

    List<Map<String, Object>> applicationHistory(String catererName);

    List<Map<String, Object>> selectPagination(String uuid);

	List<Map<String, Object>> getArchiveQuery(String uuid);

	List<String> ListDealer(String name);

	/**
	 * 签核已完成的经销商by餐包商
	 * @param contractor 餐包商
	 * @return
	 */
    List<String> ListDealerName(String contractor);
    

    /**
     * 分组求和 group by 星级，大类
     * @return
     */
    List<Map<String,Object>> ListCountProblemGroup(@Param("firstDay")String firstDay, @Param("lastDay")String lastDay);


    /**
     * 统计餐厅扣分排行
     * @return
     */
    List<Map<String, Object>> CountRestaurant(@Param("firstDay")String firstDay, @Param("lastDay")String lastDay);

    /**
     * 统计餐包商扣分排行
     * @return
     */
    List<Map<String, Object>> CountCaterer(@Param("firstDay")String firstDay, @Param("lastDay")String lastDay);
}
