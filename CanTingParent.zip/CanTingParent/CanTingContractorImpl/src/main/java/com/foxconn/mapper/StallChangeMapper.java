package com.foxconn.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.StallChange;

import tk.mybatis.mapper.common.Mapper;

public interface StallChangeMapper  extends Mapper<StallChange>{

    /**
     * 获取当天产生表单数量
     * @param contractor
     * @param strDate
     * @return
     */
    Integer selectStallChangeNum(@Param("contractor")String catererName, @Param("strDate")String strDate);

    /**
     * 申请历史
     */
    List<Map<String,Object>> applicationHistory(String catererName);

    /**
     * 查詢代簽表單
     * @param uuid
     * @return
     */
    List<Map<String,Object>> selectPagination(String uuid);

    /**
     * 归档查询（查询所有资料）
     * @return
     */
    List<Map<String,Object>> getArchiveQuery(String uuid);

}
