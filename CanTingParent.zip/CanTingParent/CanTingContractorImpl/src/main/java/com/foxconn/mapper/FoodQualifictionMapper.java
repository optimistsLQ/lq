package com.foxconn.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.FoodQualifiction;

import tk.mybatis.mapper.common.Mapper;
import tk.mybatis.mapper.entity.Example.Criteria;

public interface FoodQualifictionMapper extends Mapper<FoodQualifiction> {

    /**
     * 申请历史
     */
    List<Map<String, Object>> applicationHistory(String catererName);
    
   /**
     * 获取当天产生表单数量
     * @return
     */
    Integer selectStallChangeNum(@Param("contractor")String catererName, @Param("strDate")String strDate);

    /**
     * 食材資質待簽核表單
     * @return
     */
    List<Map<String, Object>> selectPagination(@Param("uuid")String uuid);

    /**
     * 歸檔查詢
     * @return
     */
    List<Map<String, Object>> getArchiveQuery(String uuid);

    /**
     * 食材資質匯總表
     * @return
     */
    List<FoodQualifiction> selectByInfo(@Param("catererName")String catererName, @Param("largeCategories")String largeCategories,
            @Param("startDate")String startDate, @Param("endDate")String endDate);

    /**
     * 模糊查询商品名称
     * @param name
     * @return
     */
	List<String> ListProductName(String name);
    /**
     * 模糊查询商品品牌
     * @param name
     * @return
     */
	List<String> ListBrand(String name);

	/**
	 * 可共享食材资质信息
	 * @param listDealerName
	 * @param contractor
	 * @return
	 */
    List<Map<String,Object>> ListSharedFoodQualifiction(@Param("listDealerName")List<String> listDealerName, @Param("contractor")String contractor);

    /**
     * 共享的食材资质待签表单
     * @param uuid 当前待签人员id
     * @return
     */
    List<Map<String, Object>> selectPaginationByShare(String uuid);

    
    
}
