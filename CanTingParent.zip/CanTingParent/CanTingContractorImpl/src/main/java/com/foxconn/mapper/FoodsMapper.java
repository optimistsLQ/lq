package com.foxconn.mapper;


import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.Foods;

import tk.mybatis.mapper.common.Mapper;

public interface FoodsMapper extends Mapper<Foods>{

    List<Foods>  findAll();

    /**
     * 根据id批量删除
     * @param deleteIds
     * @return
     */
    Integer deleteFoods(@Param("tList")List<String> deleteIds);

    /**
     * 获取食物大类
     * @return
     */
    List<String> getLargeCategories();

    /**
     * 通过食材大类获取食材小类
     * @param largeCategories
     * @return
     */
    List<Map<String,String>> getSubcategory(String largeCategories);

}
