package com.foxconn.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
/**
 * 食材類別
 * @author C3414208
 *
 */
@Table(name = "T_FOODS")
public class Foods implements Serializable{

    /**
     * 
     */
    private static final long serialVersionUID = 8502179393103314797L;
    @Id
    private String idCard;
    //LARGE_CATEGORIES
    private String largeCategories;
    //SUBCATEGORY
    private String  subcategory;
    @DateTimeFormat(pattern = "yyyy/MM/dd")
    @JSONField(format = "yyyy/MM/dd")
    @JsonFormat(pattern = "yyyy/MM/dd", timezone = "GMT+8")
    private Date writeTime;

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public String getLargeCategories() {
        return largeCategories;
    }

    public void setLargeCategories(String largeCategories) {
        this.largeCategories = largeCategories;
    }

    public String getSubcategory() {
        return subcategory;
    }

    public void setSubcategory(String subcategory) {
        this.subcategory = subcategory;
    }

    public Date getWriteTime() {
        return writeTime;
    }

    public void setWriteTime(Date writeTime) {
        this.writeTime = writeTime;
    }

    @Override
    public String toString() {
        return "Foods [idCard=" + idCard + ", largeCategories=" + largeCategories + ", subcategory=" + subcategory
                + ", writeTime=" + writeTime + "]";
    }
    
    
}
