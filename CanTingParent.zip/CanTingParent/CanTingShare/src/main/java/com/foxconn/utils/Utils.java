package com.foxconn.utils;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.CellValue;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSONObject;
import com.github.nobodxbodon.zhconverter.简繁转换类;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfCopy;
import com.itextpdf.text.pdf.PdfGState;
import com.itextpdf.text.pdf.PdfImportedPage;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;

public class Utils {
	
	
	
    /**判断字符串是否全是数字
     * @param str
     * @return
     */
    public static boolean isNumeric(String str) {
        //Pattern pattern = Pattern.compile("^-?[0-9]+"); //这个也行
        Pattern pattern = Pattern.compile("^-?\\d+(\\.\\d+)?$");//这个也行
        Matcher isNum = pattern.matcher(str);
        if (!isNum.matches()) {
            return false;
        }
        return true;
    }
	
	/**obj類型轉換成想要的類型
	 * @param obj
	 * @param cla
	 * @return
	 */
	public static <T> List<T> objToList(Object obj, Class<T> t){
		List<T> list = new ArrayList<T>();
    	if (obj instanceof List<?>) {
	        for (Object o : (List<?>) obj) {
	            list.add(JSONObject.parseObject(JSONObject.toJSONString(o), t));
	        }
	        return list;
        }
        return null;
	}
	
	

	/**
	 * 下划线命名转为驼峰命名
	 * @param underlineByName 下面线命名
	 **/
	public static String underlineToHump(String underlineByName) {
		StringBuilder result=new StringBuilder();
		String tempArray[]=underlineByName.split("_");
		for(String elements:tempArray) {
			if(result.length() == 0) {
				result.append(elements.toLowerCase());
			} else {
				result.append(elements.substring(0, 1).toUpperCase());
				result.append(elements.substring(1).toLowerCase());
			}
		}
		return result.toString();
	}
		
	/**
	 * 驼峰转下划线-并轉為數據庫的大寫
	 * @param str
	 * @return
	 */
	public static String humpToLine(String str){
		Matcher matcher = Pattern.compile("[A-Z]").matcher(str);
		StringBuffer sb = new StringBuffer();
		while (matcher.find()) {
			matcher.appendReplacement(sb, "_"+matcher.group(0));
		}
		matcher.appendTail(sb);
		return sb.toString().toUpperCase();
	}
	
	/**解析Excel成Javabean对象
	 * @param <T>
	 * @param in
	 * @return
	 */
	public static <T> List<T> readExcel(MultipartFile file, Class<T> cla) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		InputStream in = null;
		Workbook workbook = null;
		try {
			in  = file.getInputStream();
			if (file.getOriginalFilename().endsWith("xls")) { // Excel 2003
				workbook = new HSSFWorkbook(in);
			} else if (file.getOriginalFilename().endsWith("xlsx")) { // Excel 2007/2010
				workbook = new XSSFWorkbook(in);
			}
			Sheet sheet0 = workbook.getSheetAt(0);
//			处理公式的对象
			FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
			int maxRowNum = sheet0.getPhysicalNumberOfRows();//获取当前sheet页最大的行数
			int maxColNum = sheet0.getRow(0).getPhysicalNumberOfCells();//获取当前sheet页的第一行的最大列数
			Map<String, List<Object>> map = new HashMap<String, List<Object>>();
//			先遍历列（竖着遍历）
			for(int c = 0; c < maxColNum; c++) {
				ArrayList<Object> colList = new ArrayList<Object>();
				for(int r = 1; r < maxRowNum; r++) {
					Row rows = sheet0.getRow(r);
					Cell cell = rows.getCell(c);
					if (null == cell) {
						colList.add("");
					}else {
						CellType cellType = cell.getCellTypeEnum();
						switch (cellType) {
						case STRING:
							colList.add(cell.getStringCellValue().trim());
							break;
						case NUMERIC:
							double value = cell.getNumericCellValue();
							// 日期格式
							if(HSSFDateUtil.isCellDateFormatted(cell)){
								Date dateValue = HSSFDateUtil.getJavaDate(value);
								colList.add(sdf.format(dateValue));
							//判断是否科学计数法
							} else if((Double.toString(value)).contains("E")) {
								//取消科学计数法
					            NumberFormat nf = NumberFormat.getInstance();
					            //设置保留多少位小数
					            nf.setMaximumFractionDigits(2);
					            // 取消科学计数法
					            nf.setGroupingUsed(false);
					            colList.add(nf.format(value));
							} else {// 数字格式
								colList.add(Double.toString(cell.getNumericCellValue()));
							}
							break;
						case FORMULA: // 公式
							CellValue evaluate = evaluator.evaluate(cell);//获取公式
							CellType cellTypeEnum = evaluate.getCellTypeEnum();//获取公式值的类型并做判断
							switch (cellTypeEnum) {
							case STRING:
								colList.add(cell.getStringCellValue());
								break;
							case NUMERIC:
								value = cell.getNumericCellValue();
								if(HSSFDateUtil.isCellDateFormatted(cell)){
									Date dateValue = HSSFDateUtil.getJavaDate(value);
									colList.add(sdf.format(dateValue));
								//判断是否科学计数法
								} else if((Double.toString(value)).contains("E")) {
									//取消科学计数法
						            NumberFormat nf = NumberFormat.getInstance();
						            //设置保留多少位小数
						            nf.setMaximumFractionDigits(2);
						            // 取消科学计数法
						            nf.setGroupingUsed(false);
						            colList.add(nf.format(value));
								} else {
									colList.add(Double.toString(cell.getNumericCellValue()));
								}
								break;
							default:
								colList.add("");
								break;
							}
							break;

						default:
							colList.add("");
							break;
						}
					}
				}
				//装数据
				String key = (String) colList.get(0);
				colList.remove(0);
				map.put(key, colList);
			}
			return converJavaListBean(map, cla);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (null != in) {
						in.close();
				}
				if (workbook != null) {
					workbook.close();
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return null;
	}
	
	/**转换
	 * @param <T>
	 * @param map
	 * @param cla
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	private static <T> List<T> converJavaListBean(Map<String, List<Object>> map, Class<T> cla) throws Exception{
		List<T> result = new ArrayList<T>();
		String firstKey = null;
		Map<String, String> methodNameMap = new HashMap<String, String>();
		Map<String, String> methodParameterType = new HashMap<String, String>();
		for (Method m : cla.getDeclaredMethods()) {
			String methodName = m.getName();
			if (!methodName.startsWith("set")) {
				continue;
			}
			methodName = methodName.substring(3);
			methodName = (methodName.substring(0, 1).toLowerCase() + methodName.substring(1));
			if (map.containsKey(methodName)) {
				methodNameMap.put(methodName, m.getName());
				methodParameterType.put(methodName, m.getParameterTypes()[0].getName());
				if (firstKey == null) {
					firstKey = methodName;
				}
			}
		}
		System.out.println(map);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		for (int i = 0; i < map.get(firstKey).size(); i++) {
			Object newObj = cla.newInstance();
			Integer ii = new Integer(i);
			map.forEach((field,list) -> {
				try {
					Method setMethod = newObj.getClass().getMethod(methodNameMap.get(field), Class.forName(methodParameterType.get(field)));
					System.out.println("String:"+setMethod.getName()+" val "+list.get(ii).toString());
					String type = setMethod.getParameterTypes()[0].getSimpleName();
					if (setMethod.getParameterCount() == 1) {
						switch (type) {
						case "String":
							try {
								sdf.parse(list.get(ii).toString());// 字符串日期，转换成功存储日期格式，转换失败存储字符串格式
								setMethod.invoke(newObj, sdf.parse(list.get(ii).toString()));
							}catch(Exception e) {
								setMethod.invoke(newObj, simplifiedConverter(list.get(ii).toString()));
							}
							break;
						case "Integer":
							setMethod.invoke(newObj, (int) Double.parseDouble(list.get(ii).toString()));
							break;
						case "Double":
							setMethod.invoke(newObj, Double.parseDouble(list.get(ii).toString()));
							break;
						case "Date":
							setMethod.invoke(newObj, sdf.parse(list.get(ii).toString()));
							break;
						default:
							break;
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			});
			result.add((T) newObj);
		}
		return result;
	}
	
	/**
	 * map转Javabean
	 */
	@SuppressWarnings("unchecked")
	public static <T> T mapToJavabean(Map<String, Object> objMap, Class<T> cla) {
		Object obj = null;
		try {
			obj = cla.newInstance();
			Method[] methods = cla.getDeclaredMethods();
			for(Method m: methods) {
				if (m.getName().startsWith("set")) {
					String _name = m.getName().substring(3);//例子：JobCard
					String objMapKey = Utils.humpToLine(_name).substring(1);//例子：_Job_Card --> Job_Card
					Object value = objMap.get(objMapKey);
					if (value instanceof BigDecimal) {
						if (m.getParameters()[0].getType().getSimpleName().equals("Integer")) {
							m.invoke(obj, ((BigDecimal)value).intValue());
						} else {
							m.invoke(obj, ((BigDecimal)value).doubleValue());
						}
					} else if (value instanceof String) {
						m.invoke(obj, simplifiedConverter((String)value));
					} else {
						m.invoke(obj, value);
					}
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return (T)obj;
	}
	
	/**
	 * 簡體轉繁體
	 **/
	public static String simplifiedConverter(String str) {
		// 替换单引号的作用是防止sql注入
		return 简繁转换类.转换(str.trim().replaceAll("'", ""), 简繁转换类.目标.繁体);
	}
	
	/**
	 * 獲取系統當前日期
	 **/
	public static String systemDate(String format) {
		SimpleDateFormat dateFormat = new SimpleDateFormat(format);
		return dateFormat.format(new Date());
	}
	
	/**
	 * 將日期字符串轉換為日期對象
	 **/
	public static Date dateStrParse(String dateStr, String format) {
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat(format);
			return dateFormat.parse(dateStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * 將日期對象轉換為字符串
	 **/
	public static String dateFormatStr(Object date, String format) {
		SimpleDateFormat dateFormat = new SimpleDateFormat(format);
		return dateFormat.format(date);
	}
    /**
     * 假分页
     * @param length 
     * @param start
     * @param type
     * @return
     */
    public static List<Object> fakePagination(List<Object> list,Integer start,Integer length){
        Integer limit = (start - 1) * length;//获取数据最大條數
        Integer size = list.size();
        Integer totalPage = getTotalPage(length,size);//一共多少頁
        List<Object> subList = new ArrayList<>();
        if(start > totalPage){
        	subList = new ArrayList<Object>();
        	subList.add("页码超出");
            return subList;
        }
        if(start.equals(totalPage)){
            //判斷是否為最後一頁
            subList = list.subList(limit, size);
        }else{
            
            Integer end = limit + length;
            subList = list.subList(limit, end);
        }
        return subList;
    }
    
    /**
     * 根据总条数获取总页数
     * @param start 一頁有多少條數據
     * @param length 总共有多少数据
     * @return
     */
    private static Integer getTotalPage(Integer start,Integer length){
        Integer totalPage = 0;
        if (length % start == 0) {
            totalPage = length / start;
        } else {
            totalPage = (length / start )+ 1;
        }
        return totalPage;
    }
	 /**
     * 合并原pdf为新文件
     *
     * @param files   pdf绝对路径集
     * @param newfile 新pdf绝对路径
     * @return
     * @throws IOException
     * @throws DocumentException
     */
    public static void mergePdfFiles(List<String> files, OutputStream ops) throws IOException, DocumentException {
        Document document = new Document(new PdfReader(files.get(0)).getPageSize(1));
        PdfCopy copy = new PdfCopy(document, ops);
        document.open();
        for (int i = 0; i < files.size(); i++) {
            PdfReader reader = new PdfReader(files.get(i));
            int n = reader.getNumberOfPages();
            for (int j = 1; j <= n; j++) {
                document.newPage();
                PdfImportedPage page = copy.getImportedPage(reader, j);
                copy.addPage(page);
            }
        }
        document.close();
    }
	 /**
     * 合并原pdf为新文件
     *
     * @param lists   pdf需要合併的byte[]集合
     * @param newfile 新pdf绝对路径
     * @return
     * @throws IOException
     * @throws DocumentException
     */
    public static void mergePdfPutStream(List<byte[]> lists, OutputStream ops){
    	try {
	        Document document = new Document(new PdfReader(lists.get(0)).getPageSize(1));
	        PdfCopy copy = new PdfCopy(document,ops);
	        document.open();
	        for (int i = 0; i < lists.size(); i++) {
	            PdfReader reader = new PdfReader(lists.get(i));
	            int n = reader.getNumberOfPages();
	            for (int j = 1; j <= n; j++) {
	                document.newPage();
	                PdfImportedPage page = copy.getImportedPage(reader, j);
	                copy.addPage(page);
	            }
	        }
	        document.close();
	    } catch(IOException e) {
	    	e.printStackTrace();
	    } catch(DocumentException e) {
	    	e.printStackTrace();
	    } 
    }
    /**
     * PDF添加水印
     * @param inputFile
     * @param outputFile
     * @param waterMarkName
     * @return
     */
    public static byte [] waterMarkStream(byte[] inputFile, String waterMarkName) {
        try (
        	ByteArrayOutputStream baos = new ByteArrayOutputStream();
        	BufferedOutputStream bos = new BufferedOutputStream(baos);
        	) {
            PdfReader reader = new PdfReader(inputFile);
            PdfStamper stamper = new PdfStamper(reader, bos);
            //这里的字体设置比较关键，这个设置是支持中文的写法
            BaseFont base = BaseFont.createFont("STSong-Light", "UniGB-UCS2-H", BaseFont.NOT_EMBEDDED);// 使用系统字体
            int total = reader.getNumberOfPages() + 1;
            PdfContentByte under;
            for (int i = 1; i < total; i++) {
                // 计算水印X,Y坐标
                float x = 290;//pageRect.getWidth() / 2;
                float y = 400;//pageRect.getHeight() / 2;
                // 获得PDF最顶层
                under = stamper.getOverContent(i);//在内容上方加水印
                //under = stamper.getUnderContent(i);// 在内容下方加水印
                under.saveState();
                // set Transparency
                PdfGState gs = new PdfGState();
                // 设置透明度范围为0到1
                gs.setFillOpacity(0.2f);
                under.setGState(gs);
                under.beginText();
                under.setFontAndSize(base, 120);//字体大小
                under.setColorFill(BaseColor.RED);//字体颜色
                // 水印文字成45度角倾斜
                under.showTextAligned(Element.ALIGN_CENTER, waterMarkName, x, y, 45);
                // 添加水印文字
                under.endText();
                under.setLineWidth(1f);
                under.stroke();
            }
            stamper.close();
            reader.close();
            return baos.toByteArray();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
}
