package com.foxconn.entity;

public enum ResultCode {

	SUCCESS(1000,"操作成功"),
	FAIL(1001,"操作失敗"),
	LOGIN_TIMEOUT(1002,"登錄超時"),
	ACCESS_DENIED(1003,"沒有權限");
	
	private Integer code;
	private String msg;
	
	private ResultCode(Integer code, String msg) {
		this.code = code;
		this.msg = msg;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public Integer getCode() {
		return code;
	}
	public void setCode(Integer code) {
		this.code = code;
	}
}
