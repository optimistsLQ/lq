package com.foxconn.entity;

import java.io.Serializable;

public class Result implements Serializable{
	
	private static final long serialVersionUID = 8632655374286534152L;
	
	private String message;
	private Integer code;
	private Object data;
	
	public Result(ResultCode resultCode, Object data) {
		this.message = resultCode.getMsg();
		this.code = resultCode.getCode();
		this.data = data;
	}
	public Result(ResultCode resultCode) {
		this.message = resultCode.getMsg();
		this.code = resultCode.getCode();
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Integer getCode() {
		return code;
	}
	public void setCode(Integer code) {
		this.code = code;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
    @Override
    public String toString() {
        return "Result [message=" + message + ", code=" + code + ", data=" + data + "]";
    }
	
	
}
