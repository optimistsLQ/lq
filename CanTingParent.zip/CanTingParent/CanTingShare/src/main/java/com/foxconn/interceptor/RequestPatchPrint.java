package com.foxconn.interceptor;

import org.apache.log4j.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

/**
 * 打印請求路徑
 **/
public class RequestPatchPrint extends HandlerInterceptorAdapter {
		
	private Logger logger = Logger.getLogger(this.getClass());
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		String ipAddr = request.getRemoteHost();
		logger.debug("訪問路徑:" + request.getServletPath());
		logger.debug("訪問者IP:" + ipAddr);
		return true;
	}
}
