package com.foxconn.utils;

import java.util.Date;
import java.util.Properties;

import javax.mail.Message.RecipientType;
import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;

/**
 * 电子邮件发送工具类
 **/
public class EmailToolkit
{
    // 邮件发送协议 
    private final static String PROTOCOL = "smtp"; 
    // SMTP邮件服务器 
    private final static String HOST = "10.134.28.95"; 
    // SMTP邮件服务器默认端口 
    private final static String PORT = "25"; 
    // 是否要求身份认证 
    private final static String IS_AUTH = "true"; 
    // 是否启用调试模式（启用调试模式可打印客户端与服务器交互过程时一问一答的响应消息） 
    private final static String IS_ENABLED_DEBUG_MOD = "true";
    // 初始化连接邮件服务器的会话信息
    private static Properties props = null;
    // 发件人 
    private static String from = "System@mail.foxconn.com";
    
    static 
    { 
        props = new Properties(); 
        props.setProperty("mail.transport.protocol", PROTOCOL); 
        props.setProperty("mail.smtp.host", HOST); 
        props.setProperty("mail.smtp.port", PORT); 
        props.setProperty("mail.smtp.auth", IS_AUTH); 
        props.setProperty("mail.debug",IS_ENABLED_DEBUG_MOD); 
        props.setProperty("mail.smtp.starttls.enable","true"); 
        props.setProperty("mail.smtp.EnableSSL.enable","true");
        props.setProperty("mail.smtp.ssl.trust", HOST);
    }
    
    /**
     * 发送邮件
     * @param mailSubject 邮件主题
     * @param mailContent 邮件内容(HTML格式)
     * @param addressee 收件人地址,多个用","隔开
     */ 
    public static boolean sendEmail(String mailSubject,String mailContent,String addressee)
    { 
    	try
    	{
	        // 创建Session实例对象 
	        Session session = Session.getInstance(props, new MyAuthenticator()); 
	        // 创建MimeMessage实例对象 
	        MimeMessage message = new MimeMessage(session); 
	        // 设置邮件主题 
	        message.setSubject(mailSubject); 
	        // 设置发送人 
	        message.setFrom(new InternetAddress(from)); 
	        // 设置发送时间 
	        message.setSentDate(new Date()); 
	        // 设置收件人 
	        message.setRecipients(RecipientType.TO, InternetAddress.parse(addressee)); 
	        // 设置html内容为邮件正文，指定MIME类型为text/html类型，并指定字符编码为utf-8 
	        message.setContent("<div style='color:red;'>溫馨提示﹕此郵件為系統自動發送,無須回復,謝謝!</div>"
	        		+ "<br>"
	        		+ "<div>主管/同仁您好：</div>"
	        		+ "<br>"
	        		+ "<div>"+mailContent+"</div>"
	        		+ "<br>"
	        		+ "<div>--------------------------------------------------------------------------------------------------------------------------------------------</div>"
	        		+ "<div>資訊服務窗口(如遇系統使用問題，請聯繫此窗口):</div>"
	        		+ "<div>聯繫人:陳建宇&nbsp;TEL:5073-86915&nbsp;Email: idsbg-cd-cmproject@mail.foxconn.com</div>"
	        		+ "<div>聯繫人:何建平&nbsp;TEL:5073-86910&nbsp;Email: idsbg-cd-cmproject@mail.foxconn.com</div>","text/html;charset=utf-8"); 
	        // 保存并生成最终的邮件内容 
	        message.saveChanges();
	        // 发送邮件 
	        Transport.send(message);
	        // 返回结果
	        return true;
    	}
    	catch(Exception e)
    	{
    		Logger.getLogger(EmailToolkit.class).debug("發送郵件發生異常:", e);
    	}
    	return false;
    } 
	
    /**
     * 向邮件服务器提交认证信息
     */ 
    static class MyAuthenticator extends Authenticator
    { 
 
        private String username = ""; 
 
        private String password = "";
 
        public MyAuthenticator() 
        { 
            super(); 
        } 
 
        public MyAuthenticator(String username, String password)
        { 
            super(); 
            this.username = username; 
            this.password = password; 
        } 
 
        @Override 
        protected PasswordAuthentication getPasswordAuthentication() 
        { 
            return new PasswordAuthentication(username, password); 
        } 
    }
}
