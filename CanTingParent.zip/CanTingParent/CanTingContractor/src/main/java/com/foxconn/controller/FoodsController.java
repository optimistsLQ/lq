package com.foxconn.controller;


import java.util.HashMap;
import java.util.List;
import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.foxconn.entity.Foods;
import com.foxconn.entity.Result;
import com.foxconn.service.FoodsService;
import com.github.pagehelper.PageInfo;

/**
 * 基礎質料食物
 * @author C3414208
 *
 */
@CrossOrigin
@RestController
@RequestMapping("/foods")
public class FoodsController {

    @Autowired
    private FoodsService foodsService;
    
    /**
     * 分页獲取食品類
     */
    @PostMapping(value = "getFoodsInfo.do")
    public Map<String,Object> getFoodsInfo( Integer start, Integer length){
        
        PageInfo<Foods>  info = foodsService.getLargeCateGories(start, length);
        Map<String,Object> result = new HashMap<String,Object>();
        result.put("iTotalDisplayRecords", info.getTotal());
        result.put("iTotalRecords", info.getTotal());
        result.put("data", info.getList());
        return result;
    }

    /**
     * 修改食物类的数据
     * @param food
     * @return
     */
    @PostMapping(value = "updateFood.do")
    public Map<String,String> updateFood(Foods food){
        return foodsService.updateFood(food);
    }
    /**
     * 添加食物类
     * @param food
     * @return
     */
    @PostMapping(value = "insertFoods.do")
    public Result insertFoods(Foods food){
        return foodsService.insertFoods(food);
    }
    
    /**
     * 刪除食物类
     * @param deleteIds
     * @return
     */
    @PostMapping("/deleteFoodsId.do")
    public Result deleteTolsig(@RequestParam(name="deleteIds[]")List<String> deleteIds) {
        return foodsService.deleteTolsig(deleteIds);
    }
    
    /**
     * 获取食材大类 
     */
    @GetMapping(value = "getLargeCategories.do")
    public Result getLargeCategories(){
        return foodsService.getLargeCategories();
    }
    
    /**
     * 通过食材大类获取食材小类
     */
    @GetMapping(value = "getSubcategory.do")
    public Result getLargeCategories(String largeCategories){
        return foodsService.getSubcategory(largeCategories);
    }
}

