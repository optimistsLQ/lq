package com.foxconn.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.foxconn.entity.Dealer;
import com.foxconn.entity.FoodQualifiction;
import com.foxconn.entity.Result;
import com.foxconn.entity.ResultCode;
import com.foxconn.entity.StallChange;
import com.foxconn.entity.UserEntity;
import com.foxconn.service.RequisitionService;

/**
 * 包商专区业务申请
 * @author C3414208
 *
 */
@CrossOrigin
@RestController
@RequestMapping("/requisition")
public class RequisitionController {

    
    @Autowired
    private RequisitionService requisitionService;
    /**
     * 档口变动申请
     * @param stallChange
     * @return
     */
    @PostMapping(value = "insertStallChange.do" ,produces = "application/json;charset=utf-8")
    public Result insertStallChange(@RequestBody StallChange stallChange){
        return requisitionService.insertStallChange(stallChange);
    }
    /**
     * 档口变动申请历史
     */
    @GetMapping(value = "applicationHistory.do")
    public Result selectStallChangeByInfo(String formType,HttpSession session){
        UserEntity user = (UserEntity) session.getAttribute("user");
        if (ObjectUtils.isEmpty(user.getContractor())) {
            return new Result(ResultCode.FAIL,new ArrayList<>());
        }
        return requisitionService.applicationHistory(user.getContractor(),formType);
    }
    
    /**
     * 食材资质申请
     * @param stallChange
     * @return
     */
    @PostMapping(value = "insertFoodQualifiction.do" ,produces = "application/json;charset=utf-8")
    public Result insertFoodQualifiction(@RequestBody FoodQualifiction foodQualifiction,HttpSession session){
        UserEntity user = (UserEntity) session.getAttribute("user");//获取当前登录账号的信息
        foodQualifiction.setApplicants(user.getUserName());//将当前本人设置为申请人
        return requisitionService.insertFoodQualifiction(foodQualifiction);
    }
    /**
     * 档口详情
     */
    @GetMapping(value = "getStallInfo.do")
    public Result getStallInfo(String idCard){
        return requisitionService.getStallInfo(idCard);
    }
    /**
     * 食材資質申請詳情
     */
    @GetMapping(value = "getFoodsQualifiction.do")
    public Result getFoodsQualifiction(String idCard){
        return requisitionService.getFoodsQualifiction(idCard);
    }
    /**
     * 经销商申请详情
     */
    @GetMapping(value = "getDealer.do")
    public Result getDealer(String idCard){
    	 return requisitionService.getDealer(idCard);
    }
    /**
     * 经销商申请
     */
    @PostMapping(value = "insertDealer.do" ,produces = "application/json;charset=utf-8")
    public Result insertDealer(@RequestBody Dealer dealr,HttpSession session){
        UserEntity user = (UserEntity) session.getAttribute("user");
        dealr.setApplicants(user.getUserName());
        return requisitionService.insertDealer(dealr);
    }
    /**
     * 業務表單待簽核数据
     */
    @GetMapping(value = "pagination.do")
    public Result Pagination(String length,String start ,HttpSession session){
        UserEntity user = (UserEntity) session.getAttribute("user");
        Map<String,Object> map = new HashMap<>();
        map.put("length", length);
        map.put("start", start);
        return requisitionService.Pagination(user.getUuid(),map);
    }
    

    /**
     * 食材資質匯總表
     */
    @PostMapping(value = "summaryTable.do")
    public Result SummaryTable(@RequestParam Map<String,Object> map){
        return requisitionService.SummaryTable(map);
    }
    /**
     * 品名模糊查询
     */
    @GetMapping(value = "likeProductName.do")
    public Result LikeProductName(String name){
    	 return requisitionService.LikeProductName(name);
    }
    /**
     * 经销商模糊查询
     */
    @GetMapping(value = "likeDealer.do")
    public Result LikeDealer(String name){
        return requisitionService.LikeDealer(name);
    }
    /**
     * 品名模糊查询
     */
    @GetMapping(value = "likeBrand.do")
    public Result LikeBrand(String name){
        return requisitionService.LikeBrand(name);
    }
    
    /**
     * 可共享食材资质表单
     */
    @GetMapping(value = "SharedFoodQualifiction.do")
    public Result SharedFoodQualifiction(HttpSession session){
        UserEntity user = (UserEntity) session.getAttribute("user");
        String contractor = user.getContractor();
        if (StringUtils.isEmpty(contractor)) {
            return new Result(ResultCode.FAIL,new ArrayList<>());
        }
        return  requisitionService.ListSharedFoodQualifiction(contractor);
    }
    /**
     * 食材资质共享待签数据
     */
    @GetMapping(value = "shareDealWith.do")
    public Result ShareDealWith(String length,String start ,HttpSession session){
        UserEntity user = (UserEntity) session.getAttribute("user");
        return requisitionService.ListShareDealWith(length,start,user.getUuid());
    }
    
    /**
     * 稽核战情图
     */
    @GetMapping(value = "problemStatistics.do")
    public Result ProblemStatistics(){
       
        return  requisitionService.getProblemStatistics();
    } 
}
