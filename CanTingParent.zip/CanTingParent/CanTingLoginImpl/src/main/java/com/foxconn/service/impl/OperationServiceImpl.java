package com.foxconn.service.impl;

import java.util.List;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.foxconn.entity.OperationEntity;
import com.foxconn.mapper.OperationEntityMapper;
import com.foxconn.service.OperationService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;

@Service
public class OperationServiceImpl implements OperationService{

	@Autowired
	private OperationEntityMapper OperationMapper;

	@Override
	public int insertOperation(OperationEntity operation) {
		// TODO Auto-generated method stub
		return OperationMapper.insertSelective(operation);
	}

	@Override
	public int delOperation(List<String> oId) {
		int i = 0;
		for (String id : oId) {
			i += OperationMapper.deleteByPrimaryKey(id);
		}
		return i;
	}

	@Override
	public PageInfo<OperationEntity> listAllOperation(String search1, Integer start, Integer length) {
		// TODO Auto-generated method stub
		Example example = new Example(OperationEntity.class);
		example.setOrderByClause("O_DESCRIPTIONS asc");
		if (ObjectUtils.isNotEmpty(search1)) {
			Criteria criteria = example.createCriteria();
			
			criteria.andLike("oDescriptions", "%"+search1+"%");
		}
		if(ObjectUtils.isNotEmpty(start) && ObjectUtils.isNotEmpty(length)) {
			PageHelper.startPage(start, length);
		}
		List<OperationEntity> list = OperationMapper.selectByExample(example);
		PageInfo<OperationEntity> pageInfo = new PageInfo<OperationEntity>(list);
		return pageInfo;
	}

	@Override
	public OperationEntity getOperationBydescriptions(String oName, String oUrl) {
		// TODO Auto-generated method stub
		Example example = new Example(OperationEntity.class);
		Criteria criteria = example.createCriteria();
		criteria.andEqualTo("descriptions", oName);
		criteria.andEqualTo("oAddress", oUrl);
		OperationEntity entity = OperationMapper.selectOneByExample(example);
		return entity;
	}

	@Override
	public OperationEntity getOperationByUrl(String url) {
		// TODO Auto-generated method stub
		Example example = new Example(OperationEntity.class);
		Criteria criteria = example.createCriteria();
		criteria.andEqualTo("address", url);
		OperationEntity entity = OperationMapper.selectOneByExample(example);
		return entity;
	}

	@Override
	public OperationEntity getOperationByPerId(String oId) {
		// TODO Auto-generated method stub
		return OperationMapper.selectByPrimaryKey(oId);
	}

	@Override
	public int updateOperation(OperationEntity operation) {
		// TODO Auto-generated method stub
		return OperationMapper.updateByPrimaryKeySelective(operation);
	}

}
