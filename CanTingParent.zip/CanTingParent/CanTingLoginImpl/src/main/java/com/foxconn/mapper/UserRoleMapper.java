package com.foxconn.mapper;

import com.foxconn.entity.UserRole;

import tk.mybatis.mapper.common.BaseMapper;

public interface UserRoleMapper extends BaseMapper<UserRole>{

}