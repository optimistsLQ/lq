package com.foxconn.mapper;

import com.foxconn.entity.OperationEntity;

import tk.mybatis.mapper.common.Mapper;

public interface OperationEntityMapper extends Mapper<OperationEntity>{
   
}