package com.foxconn.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;

@Table(name = "T_OPERATION")
public class OperationEntity implements Serializable{
	private static final long serialVersionUID = -3736533672971187964L;

	@Id
	private String ouid;

    private String oAddress;

    private String oDescriptions;
    
    @DateTimeFormat(pattern = "yyyy-MM-dd")
	@JSONField(format = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date oCreateTime;

    public String getOuid() {
        return ouid;
    }

    public void setOuid(String ouid) {
        this.ouid = ouid == null ? null : ouid.trim();
    }

	public String getoAddress() {
		return oAddress;
	}

	public void setoAddress(String oAddress) {
		this.oAddress = oAddress;
	}

	public String getoDescriptions() {
		return oDescriptions;
	}

	public void setoDescriptions(String oDescriptions) {
		this.oDescriptions = oDescriptions;
	}

	public Date getoCreateTime() {
		return oCreateTime;
	}

	public void setoCreateTime(Date oCreateTime) {
		this.oCreateTime = oCreateTime;
	}

	@Override
	public String toString() {
		return "OperationEntity [ouid=" + ouid + ", oAddress=" + oAddress + ", oDescriptions=" + oDescriptions
				+ ", oCreateTime=" + oCreateTime + "]";
	}
}