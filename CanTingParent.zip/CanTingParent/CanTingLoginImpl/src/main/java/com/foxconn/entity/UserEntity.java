package com.foxconn.entity;

import java.io.Serializable;

import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Table(name = "T_USER")
public class UserEntity implements Serializable{
	private static final long serialVersionUID = 5234722004523824391L;

	@Id
	private String uuid;

    private String userName;

    private String cardNum;

    private String pwd;

    private String telephone;

    private String email;
    //厂区
    private String factoryArea;
    
    private Integer isLock;
    
    @Transient
    private RoleEntity roles;
    
    private String contractor;
    
    
    public String getContractor() {
        return contractor;
    }

    public void setContractor(String contractor) {
        this.contractor = contractor;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid == null ? null : uuid.trim();
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName == null ? null : userName.trim();
    }

    public String getCardNum() {
        return cardNum;
    }

    public void setCardNum(String cardNum) {
        this.cardNum = cardNum == null ? null : cardNum.trim();
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd == null ? null : pwd.trim();
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone == null ? null : telephone.trim();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email == null ? null : email.trim();
    }

    public String getFactoryArea() {
        return factoryArea;
    }

    public void setFactoryArea(String factoryArea) {
        this.factoryArea = factoryArea == null ? null : factoryArea.trim();
    }

	public RoleEntity getRoles() {
		return roles;
	}

	public void setRoles(RoleEntity roles) {
		this.roles = roles;
	}

	public Integer getIsLock() {
		return isLock;
	}

	public void setIsLock(Integer isLock) {
		this.isLock = isLock;
	}

    @Override
    public String toString() {
        return "UserEntity [uuid=" + uuid + ", userName=" + userName + ", cardNum=" + cardNum + ", pwd=" + pwd
                + ", telephone=" + telephone + ", email=" + email + ", factoryArea=" + factoryArea + ", isLock="
                + isLock + ", roles=" + roles + ", contractor=" + contractor + "]";
    }

	
}