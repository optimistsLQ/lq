package com.foxconn.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.RoleEntity;

import tk.mybatis.mapper.common.Mapper;

public interface RoleEntityMapper extends Mapper<RoleEntity> {
	
	/**
	 * 查詢角色分頁id
	 **/
	List<RoleEntity> listRoleId(@Param("search") String search);
	
	/**
	 * 查询所有角色
	 **/
	List<RoleEntity> listRole(@Param("roleIds") List<RoleEntity> roleIds);
	
	/**
	 * 删除角色
	 **/
	Integer deleteRole(@Param("list") List<String> deleteIds);
	
	/**
	 * 添加角色
	 **/
	Integer addRole(@Param("rName")String rName, @Param("rDescriptions")String rDescriptions);
	
	/**
	 * 查询角色是否存在
	 **/
	Integer existsRole(@Param("rName")String rName);
	
	/**
	 * 查詢角色的id
	 **/
	String getRoleIdByName(@Param("rName")String rName);
	
	/**
	 * 添加角色與操作中間表
	 **/
	Integer insertRoleOperation(@Param("roleId")String roleId,@Param("list")List<String> operationList);
	
	/**
	 * 删除角色和操作的中间表
	 **/
	Integer deleteRoleOperation(@Param("list") List<String> deleteIds);
	
	/**
	 * 根据角色id,删除用户和角色的中间表
	 **/
	Integer deleteUserRole(@Param("list") List<String> deleteIds);
}