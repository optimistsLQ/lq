package com.foxconn.service;

import java.util.List;

import com.foxconn.entity.OperationEntity;
import com.foxconn.entity.Result;
import com.foxconn.entity.UserEntity;
import com.github.pagehelper.PageInfo;

public interface UserService {
    
    /**
     * 將用戶數據插入到數據庫中
     * @param user 用戶數據對象
     * @return boolean 是否插入成功
     **/
	Result insertUser(UserEntity user);
	/**
	 * 用户管理-查询所有用戶
	 **/
    PageInfo<UserEntity> listAllUser(String search, Integer start, Integer length);
	/**
	 * 更新用戶
	 **/
    Result updateUser(UserEntity user,String roleId);
	/**
	 * 用戶啟用/停用
	 **/
    Result updateUserLock(String uuid,Integer lockStatus);
	/**
	 * 用戶刪除
	 **/
    Result deleteUser(List<String> deleteIds);
	/**
	 * 查询所有的角色名称
	 **/
    Result roleNameList();
    /**
     * 根据昵称查询用户
     */
    UserEntity getUserByNickname(String nickname);
    /**
     * 根据工号，姓名，uuid模糊查找用户
     */
    List<UserEntity> listAllUser(String item);
    /**
     * 根據工號查詢用戶
     **/
    UserEntity getUserEntityByCardNum(String cardNum);
    /**
     * 用戶登錄
     **/
    Result login(String cardNum,String pwd);
    /**
     * 獲取所有權限地址
     **/
    List<OperationEntity> listAllOperation();
    /**
     * 修改密碼
     */
    Result updatePassWord(String userName, String cardNum, String telephone,String pwd);
}
