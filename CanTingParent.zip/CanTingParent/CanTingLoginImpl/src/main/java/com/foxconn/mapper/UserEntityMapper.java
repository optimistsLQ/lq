package com.foxconn.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.UserEntity;

import tk.mybatis.mapper.common.Mapper;

public interface UserEntityMapper extends Mapper<UserEntity>{
	
	/**
	 * 根據搜索條件查詢用戶信息
	 **/
	List<UserEntity> listAllUser(@Param("item") String item);
	
	/**
	 * 根據用戶id刪除 用戶與角色中間表
	 **/
	Integer deleteUserRoleById(@Param("list") List<String> deleteIds);
	
	/**
	 * 根據用戶id插入用戶與角色中間表
	 **/
	Integer insertUserRoleById(@Param("userId") String userId,@Param("roleId") String roleId);
	
	/**
	 * 根據用戶id刪除 用戶表
	 **/
	Integer deleteUserById(@Param("list") List<String> deleteIds);
	
	/**
	 * 根據工號查詢用戶
	 **/
	UserEntity getUserEntityByCardNum(@Param("cardNum") String cardNum);
}