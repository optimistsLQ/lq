package com.foxconn.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.foxconn.entity.OperationEntity;
import com.foxconn.entity.Result;
import com.foxconn.entity.ResultCode;
import com.foxconn.entity.RoleEntity;
import com.foxconn.mapper.OperationEntityMapper;
import com.foxconn.mapper.RoleEntityMapper;
import com.foxconn.service.RoleService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

@Service
public class RoleServiceImpl implements RoleService{
	
	@Autowired
	private RoleEntityMapper roleMapper;
	@Autowired
	private OperationEntityMapper operationMapper;
	
    /**
	 * 查詢所有角色
	 * @return
	 */
	@Override
	public PageInfo<RoleEntity> listRoleAll(Integer start,Integer length,String search) {
		if (ObjectUtils.isNotEmpty(start) && ObjectUtils.isNotEmpty(length)) {
			PageHelper.startPage(start, length);
		}
		List<RoleEntity> roleIds = roleMapper.listRoleId(search);
		List<RoleEntity> resultList = null;
		if (!roleIds.isEmpty()) {
			resultList = roleMapper.listRole(roleIds);
		}
		roleIds.clear();
		if (resultList != null) {
			roleIds.addAll(resultList);
		}
		return new PageInfo<RoleEntity>(roleIds);
	}
	
	/**
	 * 添加角色
	 **/
	@Transactional
	@Override
	public Result addRole(String rName,String rDescriptions, List<String> operationList) {
		if (roleMapper.existsRole(rName) > 0) {
			Result r = new Result(ResultCode.FAIL);
			r.setMessage("角色已存在，請勿重複添加！");
			return r;
		}
		roleMapper.addRole(rName, rDescriptions);
		if (operationList != null && !operationList.isEmpty()) {
			roleMapper.insertRoleOperation(roleMapper.getRoleIdByName(rName), operationList);
		}
		return new Result(ResultCode.SUCCESS);
	}
	
	/**
	 * 角色修改
	 **/
	@Transactional
	@Override
	public Result changeRole(String rid,String rName,String rDescriptions, List<String> operationList) {
		// 通過id更新角色
		RoleEntity roleEntity = new RoleEntity();
		roleEntity.setRid(rid);
		roleEntity.setrName(rName);
		roleEntity.setrDescriptions(rDescriptions);
		roleMapper.updateByPrimaryKeySelective(roleEntity);
		// 刪除角色的權限
		List<String> deleteIds = new ArrayList<String>();
		deleteIds.add(rid);
		roleMapper.deleteRoleOperation(deleteIds);
		// 重新寫入角色的權限
		roleMapper.insertRoleOperation(rid, operationList);
		return new Result(ResultCode.SUCCESS);
	}
	
	/**
	 * 删除角色
	 **/
	@Transactional
	@Override
	public Result deleteRole(List<String> deleteIds) {
		try {
			roleMapper.deleteUserRole(deleteIds);
			roleMapper.deleteRoleOperation(deleteIds);
			roleMapper.deleteRole(deleteIds);
			return new Result(ResultCode.SUCCESS);
		} catch(Exception e) {
			e.printStackTrace();
		}
		return new Result(ResultCode.FAIL);
	}
	
	/**
	 * 查询权限列表
	 **/
	public List<OperationEntity> listOperation() {
		return operationMapper.selectAll();
	}
}
