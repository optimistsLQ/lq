package com.foxconn.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.format.annotation.DateTimeFormat;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;

@Table(name = "T_ROLE")
public class RoleEntity implements Serializable{
	
	private static final long serialVersionUID = -7224969184360624791L;
	
	@Id
	private String rid;

    private String rName;
    
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    @JSONField(format="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date rCreateTime;

    private String rDescriptions;
    
    @Transient
    private List<OperationEntity> operationList;

    public String getRid() {
        return rid;
    }

    public void setRid(String rid) {
        this.rid = rid == null ? null : rid.trim();
    }

	public String getrName() {
		return rName;
	}

	public void setrName(String rName) {
		this.rName = rName;
	}

	public Date getrCreateTime() {
		return rCreateTime;
	}

	public void setrCreateTime(Date rCreateTime) {
		this.rCreateTime = rCreateTime;
	}

	public String getrDescriptions() {
		return rDescriptions;
	}

	public void setrDescriptions(String rDescriptions) {
		this.rDescriptions = rDescriptions;
	}

	public List<OperationEntity> getOperationList() {
		return operationList;
	}

	public void setOperationList(List<OperationEntity> operationList) {
		this.operationList = operationList;
	}

	@Override
	public String toString() {
		return "RoleEntity [rid=" + rid + ", rName=" + rName + ", rCreateTime=" + rCreateTime + ", rDescriptions="
				+ rDescriptions + ", operationList=" + operationList + "]";
	}
}