package com.foxconn.service;

import java.util.List;

import com.foxconn.entity.OperationEntity;
import com.github.pagehelper.PageInfo;

public interface OperationService {

	/**添加权限
	 * @param permission
	 */
	int insertOperation(OperationEntity operation);
	/**根据id删除权限
	 * @param preId
	 */
	int delOperation(List<String> oId);
	/**分页查询所有权限
	 * @return
	 */
	PageInfo<OperationEntity> listAllOperation(String search1, Integer start, Integer length);
	/**验证权限名是否存在
	 * @param perName
	 * @return
	 */
	OperationEntity getOperationBydescriptions(String oName, String oUrl);
	OperationEntity getOperationByUrl(String url);
	/**根据ID查询权限
	 * @param perId
	 * @return
	 */
	OperationEntity getOperationByPerId(String oId);
	/**修改权限信息
	 * @param permission
	 * @return
	 */
	int updateOperation(OperationEntity operation);
}
