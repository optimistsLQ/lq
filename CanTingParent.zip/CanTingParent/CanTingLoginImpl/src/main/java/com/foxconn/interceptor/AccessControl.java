package com.foxconn.interceptor;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.alibaba.fastjson.JSONObject;
import com.foxconn.entity.OperationEntity;
import com.foxconn.entity.Result;
import com.foxconn.entity.ResultCode;
import com.foxconn.entity.UserEntity;

/**
 * 訪問控制
 **/
public class AccessControl extends HandlerInterceptorAdapter {
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		// 請求地址
		String path = request.getServletPath();
		// 跨域问题
		response.setHeader("Access-Control-Allow-Origin","*");
		response.setHeader("Access-Control-Allow-Headers","Token,X-Requested-With,content-type");
		response.setHeader("Access-Control-Allow-Methods","*");
		response.setHeader("Access-Control-Allow-Credentials","true");
		response.setHeader("Access-Control-Max-Age","3600");
		// 放过options请求
		if (request.getMethod().equals("OPTIONS")) {
			return true;
		}
		// 從請求頭header中獲取token
		String token = request.getHeader("Token");
		// 如果沒有token，則判斷請求參數是否攜帶token
		if (StringUtils.isEmpty(token)) {
			token = request.getParameter("Token");
		}
		// 用戶的登錄對象
		Object obj = request.getSession().getAttribute("user");
		// 如果沒有token，說明沒有登錄
		if (StringUtils.isEmpty(token) || ObjectUtils.isEmpty(obj)) {
			String json = JSONObject.toJSONString(new Result(ResultCode.LOGIN_TIMEOUT));
			response.setHeader("Content-Type", "application/json");
			response.getOutputStream().write(json.getBytes("UTF-8"));
			return false;
		}
		// 權限判斷
		UserEntity userEntity = (UserEntity) obj;
		// 如果是admin，将拥有所有权限
		if (userEntity.getCardNum().equals("admin")) {
			return true;
		}
		// 判斷該地址是否已加入權限管控
		boolean isAccessControl = false;
		@SuppressWarnings("unchecked")
		List<OperationEntity> listAllOperation = (List<OperationEntity>) request.getSession().getAttribute("listAllOperation");
		for (OperationEntity o:listAllOperation) {
			if (path.endsWith(o.getoAddress())) {
				isAccessControl = true;
			}
		}
		// 如果沒有權限管控,直接返回true
		if (!isAccessControl) {
			return true;
		}
		// 權限檢查
		List<OperationEntity> operationList = userEntity.getRoles().getOperationList();
		if (ObjectUtils.isNotEmpty(operationList)) {
			for (OperationEntity o:operationList) {
				if (path.endsWith(o.getoAddress())) {
					return true;
				}
			}
		}
		// 沒有權限
		String json = JSONObject.toJSONString(new Result(ResultCode.ACCESS_DENIED));
		response.setHeader("Content-Type", "application/json");
		response.getOutputStream().write(json.getBytes("UTF-8"));
		return false;
	}
}
