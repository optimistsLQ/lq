package com.foxconn.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.RoleOperation;

import tk.mybatis.mapper.common.Mapper;

public interface RoleOperationMapper extends Mapper<RoleOperation>{

	int delRoleOperationByRoleId(@Param("rid") String rid);

	int insertList(@Param("rOList") List<RoleOperation> rOList);

}