package com.foxconn.entity;

import java.io.Serializable;

import javax.persistence.Id;
import javax.persistence.Table;
@Table(name = "T_USER_ROLE")
public class UserRole implements Serializable{
	private static final long serialVersionUID = 5442865274750154644L;

	@Id
	private String urid;

    private String uuid;

    private String rid;

    public String getUrid() {
        return urid;
    }

    public void setUrid(String urid) {
        this.urid = urid == null ? null : urid.trim();
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid == null ? null : uuid.trim();
    }

    public String getRid() {
        return rid;
    }

    public void setRid(String rid) {
        this.rid = rid == null ? null : rid.trim();
    }

	@Override
	public String toString() {
		return "UserRole [urid=" + urid + ", uuid=" + uuid + ", rid=" + rid + "]";
	}
}