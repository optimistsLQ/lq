package com.foxconn.entity;

import java.io.Serializable;

import javax.persistence.Id;
import javax.persistence.Table;
@Table(name = "T_ROLE_OPERATION")
public class RoleOperation implements Serializable{
	private static final long serialVersionUID = -6492210543905092840L;

	@Id
	private String roid;

    private String roleId;

    private String operationId;

    public String getRoid() {
        return roid;
    }

    public void setRoid(String roid) {
        this.roid = roid == null ? null : roid.trim();
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId == null ? null : roleId.trim();
    }

    public String getOperationId() {
        return operationId;
    }

    public void setOperationId(String operationId) {
        this.operationId = operationId == null ? null : operationId.trim();
    }

	@Override
	public String toString() {
		return "RoleOperation [roid=" + roid + ", roleId=" + roleId + ", operationId=" + operationId + "]";
	}
}