package com.foxconn.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.foxconn.entity.OperationEntity;
import com.foxconn.entity.Result;
import com.foxconn.entity.ResultCode;
import com.foxconn.entity.RoleEntity;
import com.foxconn.entity.UserEntity;
import com.foxconn.mapper.OperationEntityMapper;
import com.foxconn.mapper.RoleEntityMapper;
import com.foxconn.mapper.UserEntityMapper;
import com.foxconn.service.UserService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserEntityMapper userMapper;
	@Autowired
	private RoleEntityMapper roleMapper;
	@Autowired
	private OperationEntityMapper operationMapper;
	
	/**
	 * 新用户插入
	 **/
	@Transactional
	@Override
	public Result insertUser(UserEntity user) {
		// TODO Auto-generated method stub
		Result r = null;
		UserEntity userExize = userMapper.getUserEntityByCardNum(user.getCardNum());
		if (ObjectUtils.isEmpty(userExize)) {
			int i = userMapper.insertSelective(user);
			if (i > 0) {
				r = new Result(ResultCode.SUCCESS);
				r.setMessage("註冊成功");
			}else {
				r = new Result(ResultCode.FAIL);
				r.setMessage("註冊失敗");
			}
		}else {
			r = new Result(ResultCode.FAIL);
			r.setMessage("該賬戶已註冊");
		}
		return r;
	}

	/**
	 * 用户管理-查询所有用戶
	 **/
	@Override
	public PageInfo<UserEntity> listAllUser(String search, Integer start, Integer length) {
		if (ObjectUtils.isNotEmpty(start) && ObjectUtils.isNotEmpty(length)) {
			PageHelper.startPage(start, length);
		}
		List<UserEntity> userList = userMapper.listAllUser(search);
		PageInfo<UserEntity> info = new PageInfo<UserEntity>(userList);
		return info;
	}
	
	/**
	 * 更新用戶
	 **/
	@Transactional
    public Result updateUser(UserEntity user,String roleId) {
    	// 刪除該賬號的角色
		List<String> deleteIds = new ArrayList<String>();
		deleteIds.add(user.getUuid());
		userMapper.deleteUserRoleById(deleteIds);
		// 如果不等於-1，插入新的角色
        if (!roleId.equals("-1")) {
        	userMapper.insertUserRoleById(user.getUuid(), roleId);
        }
        // 更新用戶信息
        userMapper.updateByPrimaryKeySelective(user);
        return new Result(ResultCode.SUCCESS);
    }
	
	/**
	 * 用戶啟用/停用
	 **/
    public Result updateUserLock(String uuid,Integer lockStatus) {
    	UserEntity updateObj = new UserEntity();
    	updateObj.setUuid(uuid);
    	updateObj.setIsLock(lockStatus);
    	if (userMapper.updateByPrimaryKeySelective(updateObj) > 0) {
    		return new Result(ResultCode.SUCCESS);
    	}
    	return new Result(ResultCode.FAIL);
    }
    
	/**
	 * 用戶刪除
	 **/
    @Transactional
    public Result deleteUser(List<String> deleteIds) {
    	Integer executeResult = 0;
    	executeResult += userMapper.deleteUserRoleById(deleteIds);
    	executeResult += userMapper.deleteUserById(deleteIds);
    	if (executeResult > 0) {
    		return new Result(ResultCode.SUCCESS);
    	}
    	return new Result(ResultCode.FAIL);
    }
    
	/**
	 * 查询所有的角色名称
	 **/
    public Result roleNameList() {
    	List<Map<String, String>> list = new ArrayList<Map<String, String>>();
    	for (RoleEntity roleEntity:roleMapper.selectAll()) {
    		Map<String, String> obj = new HashMap<String, String>();
    		obj.put("id", roleEntity.getRid());
    		obj.put("name", roleEntity.getrName());
    		list.add(obj);
    	}
    	return new Result(ResultCode.SUCCESS,list);
    }
    
    /**
     * 根据昵称查询用户
     */
    @Override
    public UserEntity getUserByNickname(String nickname) {
        Example example = new Example(UserEntity.class);
        Criteria criteria = example.createCriteria();
        criteria.andEqualTo("userName", nickname);
        UserEntity user = userMapper.selectOneByExample(example);
        return user;
    }
    
    /**
     * 根据工号，姓名，uuid模糊查找用户
     */
    @Override
    public List<UserEntity> listAllUser(String item) {
        Example example = new Example(UserEntity.class);
        Criteria criteria = example.createCriteria();
        criteria.orLike("userName", "%"+item+"%");
        criteria.orLike("cardNum", "%"+item+"%");
        criteria.orLike("uuid", "%"+item+"%");
        return userMapper.selectByExample(example);
    }
    
    /**
     * 根據工號查詢用戶
     **/
    @Override
    public UserEntity getUserEntityByCardNum(String cardNum) {
    	return userMapper.getUserEntityByCardNum(cardNum);
    }
    
    /**
     * 用戶登錄
     **/
    @Override
    public Result login(String cardNum,String pwd) {
    	// 根据工号查询用户
    	UserEntity userEntity = userMapper.getUserEntityByCardNum(cardNum);
    	if (ObjectUtils.isEmpty(userEntity) || !userEntity.getPwd().equals(pwd)) {
    		Result r = new Result(ResultCode.FAIL);
    		r.setMessage("賬號或密碼錯誤！");
    		return r;
    	}
    	// 判斷賬號的鎖定狀態
    	if (userEntity.getIsLock() == 0) {
    		Result r = new Result(ResultCode.FAIL);
    		r.setMessage("賬號審核中！");
    		return r;
    	}
    	// 如果該賬號沒有角色
    	if (userEntity.getRoles() == null) {
    		userEntity.setRoles(new RoleEntity());
    	}
		// 返回狀態及用戶數據
		Result r = new Result(ResultCode.SUCCESS);
		r.setData(userEntity);
		return r;
    }
    
    /**
     * 獲取所有權限地址
     **/
    @Override
    public List<OperationEntity> listAllOperation() {
    	return operationMapper.selectAll();
    }

    @Override
    public Result updatePassWord(String userName, String cardNum, String telephone,String pwd) {
        Example example = new Example(UserEntity.class);
        Criteria criteria = example.createCriteria();
        criteria.andEqualTo("userName", userName);
        criteria.andEqualTo("cardNum", cardNum);
        criteria.andEqualTo("telephone", telephone);
        UserEntity user = userMapper.selectOneByExample(example);
        if (ObjectUtils.isEmpty(user)) {
            return new Result(ResultCode.FAIL,"輸入信息錯誤，請重新輸入！");
        }
        user.setPwd(pwd);
        Integer i = userMapper.updateByExampleSelective(user, example);
        if ( i != 0) {
            Map<String,String> map = new HashMap<>();
            map.put("message", "密碼修改成功！");
            map.put("pwd", pwd);
            return new Result(ResultCode.SUCCESS,map);
        }
        return new Result(ResultCode.FAIL,"密碼修改失敗！");
    }
}
