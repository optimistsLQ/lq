package com.foxconn.service;

import java.util.List;

import com.foxconn.entity.OperationEntity;
import com.foxconn.entity.Result;
import com.foxconn.entity.RoleEntity;
import com.github.pagehelper.PageInfo;

public interface RoleService {
	
    /**
	 * 查詢所有角色
	 * @return
	 */
	PageInfo<RoleEntity> listRoleAll(Integer start,Integer length,String search);
	
	/**
	 * 删除角色
	 **/
	Result deleteRole(List<String> deleteIds);
	
	/**
	 * 添加角色
	 **/
	Result addRole(String rName,String rDescriptions, List<String> operationList);
	
	/**
	 * 角色修改
	 **/
	Result changeRole(String rid,String rName,String rDescriptions, List<String> operationList);
	
	/**
	 * 查询权限列表
	 **/
	List<OperationEntity> listOperation();
}
