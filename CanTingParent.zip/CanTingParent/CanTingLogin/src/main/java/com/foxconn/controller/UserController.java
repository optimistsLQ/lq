package com.foxconn.controller;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.foxconn.entity.Result;
import com.foxconn.entity.ResultCode;
import com.foxconn.entity.UserEntity;
import com.foxconn.service.BaseService;
import com.foxconn.service.UserService;
import com.github.pagehelper.PageInfo;


@CrossOrigin
@RestController
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	private UserService userService;
	@Autowired
	private BaseService baseService;
	
	@RequestMapping(value = "/addUser.do", produces = "application/json;charset=utf-8")
	public Result addUser(@RequestBody UserEntity user) {
		Result r = null;
		if (ObjectUtils.isEmpty(user)) {
			r = new Result(ResultCode.FAIL);
			r.setMessage("請填寫用戶信息");
			return r;
		}
		r = userService.insertUser(user);
		return r;
	}	
	
	/**
	 * 用户管理-查询所有用戶
	 **/
	@RequestMapping(value = "/listAllUser.do")
	public Map<String,Object> listAllUserByItem(String search, Integer start, Integer length) {
		PageInfo<UserEntity> info = userService.listAllUser(search, start, length);
		Map<String,Object> result = new HashMap<String,Object>();
		result.put("iTotalDisplayRecords", info.getTotal());
		result.put("iTotalRecords", info.getTotal());
		result.put("data", info.getList());
		return result;
	}
	
	/**
	 * 更新用戶
	 **/
	@RequestMapping(value = "/updateUser.do")
	public Result updateUser(UserEntity user,String roles_rName) {
		return userService.updateUser(user, roles_rName);
	}
	
	/**
	 * 用戶啟用/停用
	 **/
	@RequestMapping(value = "/updateUserLock.do")
	public Result updateUserLock(String uuid,Integer lockStatus) {
		return userService.updateUserLock(uuid, lockStatus);
	}
	
	/**
	 * 用戶刪除
	 **/
	@RequestMapping(value = "/deleteUser.do")
	public Result deleteUser(@RequestParam(name="deleteIds[]") List<String> deleteIds) {
		return userService.deleteUser(deleteIds);
	}
	
	/**
	 * 查询所有的角色名称
	 **/
	@RequestMapping(value = "/roleNameList.do")
	public Result roleNameList() {
		return userService.roleNameList();
	}
	
	/**
	 * 获取游客的token 
	 **/
	@RequestMapping(value = "/getVisitorToken.do")
	public Result getVisitorToken(HttpSession session) {
		Result r = new Result(ResultCode.SUCCESS);
		r.setData(session.getId());
		return r;
	}
	
	/**
	 * 用戶登錄
	 **/
	@RequestMapping(value = "/login.do")
	public Result login(String cardNum,String pwd,String verification,HttpSession session) {
		// 獲取登錄驗證碼
		Object sessionVerification = session.getAttribute("verification");
		// 判斷驗證碼輸入是否有誤
		if (ObjectUtils.isEmpty(sessionVerification) || (!verification.equals(sessionVerification))) {
			Result r = new Result(ResultCode.FAIL);
			r.setMessage("驗證碼錯誤！");
			return r;
		}
		Result r = userService.login(cardNum, pwd);
		// 登錄成功,獲取登錄對象保存到session
		if (r.getCode() == ResultCode.SUCCESS.getCode()) {
			UserEntity userEntity = (UserEntity) r.getData();
			session.setAttribute("user", userEntity);
			session.setAttribute("listAllOperation", userService.listAllOperation());
			// 重新設置值后,返回給前端
			JSONObject result = new JSONObject();
			result.put("uuid", userEntity.getUuid());
			result.put("userName", userEntity.getUserName());
			result.put("role", userEntity.getRoles());
			result.put("token", session.getId());
			result.put("contractor", userEntity.getContractor());
			r.setData(result);
		}
		return r;
	}
	
	/**
	 * 登錄驗證碼
	 **/
    @GetMapping(value = "/verification.do")
    public void userLogin(HttpSession session,HttpServletResponse resp) throws Exception {
        Random random = new Random(System.currentTimeMillis());
        StringBuffer codeBuff = new StringBuffer();
        for (int i = 0;i < 4; i++) {
            codeBuff.append(random.nextInt(9));
        }
        session.setAttribute("verification", codeBuff.toString());
        BufferedImage img = new BufferedImage(110, 41, BufferedImage.TYPE_4BYTE_ABGR);
        Graphics g = img.getGraphics();
        g.setColor(Color.decode("#eeeeee"));
        g.fillRect(0, 0, 110, 41);
        g.setFont(new Font("微軟雅黑",2,40));
        g.setColor(Color.decode("#3f52b4"));
        g.drawString(codeBuff.toString(), 10, 35);
        Random r = new Random();
        g.setFont(new Font("微軟雅黑", 0, 25));
        for(int i=0;i<48;i++){
            g.setColor(new Color(r.nextInt(256), r.nextInt(256), r.nextInt(256)));
            g.drawLine(r.nextInt(200), r.nextInt(200), r.nextInt(200), r.nextInt(200));
        }
        resp.setHeader("Content-Type", "image/png");
        ImageIO.write(img, "PNG", resp.getOutputStream());
    }
    
    /**
     * 修改密碼
     */
    @PostMapping(value = "/reSetPwd.do")
    public Result reSetPwd(@RequestParam Map<String,Object> params) {
        
        String userName = params.get("userName").toString();
        String cardNum = params.get("cardNum").toString();
        String telephone = params.get("telephone").toString();
        String pwd = params.get("pwd").toString();
    	return userService.updatePassWord(userName,cardNum,telephone,pwd);
    }
    
    /**
     * 獲取餐包商信息
     */
    @GetMapping(value = "/getContractors.do")
    public Result getContractors() {
       
        return  new Result(ResultCode.SUCCESS, baseService.getContractors());
    }
}
