package com.foxconn.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.foxconn.entity.OperationEntity;
import com.foxconn.entity.Result;
import com.foxconn.entity.ResultCode;
import com.foxconn.service.OperationService;
import com.github.pagehelper.PageInfo;

@RestController
@RequestMapping("opera")
@CrossOrigin
public class OperaController {

	@Autowired
	private OperationService operaService;
	
	@RequestMapping("addOpera.do")
	public Result addOpera(OperationEntity opera) {
		int i = operaService.insertOperation(opera);
		if (i > 0) {
			return new Result(ResultCode.SUCCESS);
		}else {
			return new Result(ResultCode.FAIL);
		}
	}
	
	@RequestMapping("delOpera.do")
	public Result delOpera(@RequestParam("deleteIds[]") List<String> deleteIds) {
		int i = operaService.delOperation(deleteIds);
		if (i > 0) {
			return new Result(ResultCode.SUCCESS);
		}else {
			return new Result(ResultCode.FAIL);
		}
	}
	
	@RequestMapping("updateOpera.do")
	public Result updateOpera(OperationEntity operation) {
		int i = operaService.updateOperation(operation);
		if (i > 0) {
			return new Result(ResultCode.SUCCESS);
		}else {
			return new Result(ResultCode.FAIL);
		}
	}
	
	@RequestMapping("findOpera.do")
	public Map<String, Object> findOpera(String search1, int start, int length) {
		PageInfo<OperationEntity> info = operaService.listAllOperation(search1, start, length);
		Map<String,Object> result = new HashMap<String,Object>();
		result.put("iTotalDisplayRecords", info.getTotal());
		result.put("iTotalRecords", info.getTotal());
		result.put("data", info.getList());
		return result;
	}
	
	@RequestMapping("findOperaByOuid.do")
	public OperationEntity findOperaByOuid(String ouid) {
		OperationEntity operation = operaService.getOperationByPerId(ouid);
		return operation;
	}
	
	@RequestMapping("findOperaByOurl.do")
	public String findOperaByOurl(String ourl) {
		OperationEntity operation = operaService.getOperationByUrl(ourl);
		if (ObjectUtils.isNotEmpty(operation)) {
			return "OK";
		}else {
			return "NG";
		}
	}
	
	@RequestMapping("findOperaByOnameAndOurl.do")
	public String findOperaByOname(String oName, String oUrl) {
		OperationEntity operation = operaService.getOperationBydescriptions(oName, oUrl);
		if (ObjectUtils.isNotEmpty(operation)) {
			return "OK";
		}else {
			return "NG";
		}
	}
}
