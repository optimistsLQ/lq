package com.foxconn.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.foxconn.entity.OperationEntity;
import com.foxconn.entity.Result;
import com.foxconn.entity.RoleEntity;
import com.foxconn.service.RoleService;
import com.github.pagehelper.PageInfo;

@RestController
@RequestMapping("/role")
@CrossOrigin
public class RoleController {

	@Autowired
	private RoleService roleService;
		
	/**
	 * 查询角色列表
	 **/
	@RequestMapping("/listRole.do")
	public Map<String,Object> listRole(Integer start,Integer length,String search) {
		PageInfo<RoleEntity> info = roleService.listRoleAll(start, length, search);
		Map<String,Object> result = new HashMap<String,Object>();
		result.put("iTotalDisplayRecords", info.getTotal());
		result.put("iTotalRecords", info.getTotal());
		result.put("data", info.getList());
		return result;
	}
	
	/**
	 * 添加角色
	 **/
	@RequestMapping("/addRole.do")
	public Result addRole(String rName,String rDescriptions,
			@RequestParam(name="param[operationList]",required = false)List<String> operationList) {
		return roleService.addRole(rName, rDescriptions, operationList);
	}
	
	/**
	 * 角色修改
	 **/
	@RequestMapping("/changeRole.do")
	public Result changeRole(String rid,String rName,String rDescriptions,
			@RequestParam(name="operationList",required = false)List<String> operationList) {
		return roleService.changeRole(rid, rName, rDescriptions, operationList);
	}
	
	/**
	 * 删除角色
	 **/
	@RequestMapping("/deleteRole.do")
	public Result deleteRole(@RequestParam(name="deleteIds[]") List<String> deleteIds) {
		return roleService.deleteRole(deleteIds);
	}
	
	/**
	 * 查询权限列表
	 **/
	@RequestMapping("/listOperation.do")
	public List<OperationEntity> listOperation() {
		return roleService.listOperation();
	}
}
