//餐具清潔
function handleSyncTableCanJu(oTd,newVal){
	var index = oTd.index();
	var oldVal = oTd.text();//旧值
	oldVal = removeComma(oldVal);
	newVal = removeComma(newVal);
	var diff = newVal - oldVal;//差异值
	diff = diff.toFixed(2)*1;
	var currTr = oTd.parent();
	var tds = currTr.find("td");
	var legalName = tds.eq(0).text() + tds.eq(1).text();//法人名字
	var currTable = currTr.parent().parent();//当前点击的table对象
	var anotherTable = getAnotherTable(currTable);
	var dexArr = [0,1]
	var anotherTdArr = getTableByLegalPersonForDex(anotherTable,legalName,dexArr,index);
	return handleSyncTable(anotherTdArr,diff);
}
//處理園區清潔
function handleSyncTableQingjie(oTd,newVal){
	var index = oTd.index();
	var oldVal = oTd.text();//旧值
	oldVal = removeComma(oldVal);
	newVal = removeComma(newVal);
	var diff = newVal - oldVal;//差异值
	diff = diff.toFixed(2)*1;
	var oTr = oTd.parent();
	var legalName = oTr.find("td").eq(0).text();
	singleTable_getTr($("#tab tbody"),"style",legalName,index);
	var isTotalTable = singleTable_isTotalTable(oTr);
	var tdArr;
	if(isTotalTable){
		//当前修改的就是总表
		//需要获得明细表的tr
		tdArr = getGolab().list;
	}else{
		//当前修改的是明细
		//需要获得总表的tr
		tdArr = getGolab().total;
	}
	return handleSyncTable(tdArr,diff);
}
//處理修改園區能耗費用
function handleSyncTableYuanQu(oTd,newVal){
	var index = oTd.index();
	var oldVal = oTd.text();//旧值
	oldVal = removeComma(oldVal);
	newVal = removeComma(newVal);
	var diff = newVal - oldVal;//差异值
	diff = diff.toFixed(2)*1;
	var oTr = oTd.parent();
	if(checkIsFirstTr(oTr)){
		//true 表示修改的就是匯總
		var oTable = $("#tab tbody");
		var oTdArr = getTrForTable(oTable, index);
		oTdArr.splice(0,1);//移除第一個匯總欄位
		return handleSyncTable(oTdArr, diff);
	}else{
		//false表示修改的是明細,需要同步到匯總表
		var firstTr = $("#tab tbody").find("tr").first();
		var totalTd = firstTr.find("td").eq(index);
		var oTdArr = [totalTd];
		return handleTdVal(diff,oTdArr,1);
	}
}
/**
 * 處理修改數據同步改變值
 currTd 當前雙擊的元素td - newVal 單元格修改後的值
 */
function handleSyncChange1(oTd,newVal){
	 var oldVal = oTd.text();//旧值
	 oldVal = removeComma(oldVal)
	 newVal = removeComma(newVal)
	 var diff = newVal - oldVal;//差异值
	 var index = oTd.index();//当前点击td的所在行的哪个位置
	 var currTr = oTd.parent();
	 var legalPerson = currTr.find("td").eq(0).text();//法人名字
	 //---------------------------
	 var currTable = currTr.parent().parent();//当前点击的table对象
	 var anotherTable = getAnotherTable(currTable);
	 var anotherTdArr = getTableByLegalPerson(anotherTable,legalPerson,index,false);
	 //同步另一個表格的數據修正差異值
	 return handleSyncTable(anotherTdArr,diff);//處理通用費用
     //return handleSyncTable();
	 //以下文字為理解代碼 -- 可刪除可不刪除 | 理解handleSyncTable(anotherTdArr,diff)|
	 /* if(currTdArr.length > anotherTdArr.length){
		 //修改的明细表
		 //currTdArr 为 明细表
		 //将差异值 平分给总表
		 return handleSyncTable(anotherTdArr,diff);
	 }else{
		 //修改的 总表
		 //currTdArr 为 总表
		 //将差异值平分给明细表
		 return handleSyncTable(anotherTdArr,diff);
	 } */
}
function handleSyncTableHenBoDorm(oTd,newVal){
	//DG6AA7 DG6917 DG6267
	var oldVal = oTd.text();
	newVal = removeComma(newVal);
	oldVal = removeComma(oldVal);
	var diff = newVal - oldVal;
	var index = oTd.index();
	var currTr = oTd.parent();
	var currTable = currTr.parent().parent();
	var isTotalTab = isTotalTable(currTable);//是否是總表
	var anotherTable = getAnotherTable(currTable);
	var tdFirst = currTr.find("td").eq(0);
	var legalPerson = tdFirst.text();
	var operaSuccess = true;
	if(isTotalTab){//currTable是總表
        //改的就是總表
        //判斷該的是否是小計 還是明細 還需要判斷costCode是否屬於3個費用代碼,
        //如果是,就需要同步到子明細表 - 并更改子明細表的小計
        if(hasAttr(tdFirst,"colspan")){//表示當前行屬於 小計
        	//改的是總表的小計-同步明细
            index += tdFirst.attr("colspan")*1-1;
            var currTdArr = getTableByLegalPerson(currTable,legalPerson,index,true);
            var anotherTdArr = getTableByLegalPerson(anotherTable,legalPerson,index,true);
            setGolab(anotherTdArr);
            operaSuccess = handleSyncHenBO(currTdArr,diff,true,index);
        }else{
        	//改的總表的明細-同步小计
	        //判断是否是该的二次分摊的明细,如果是,还需要同步到另一个表单
        	var currTdArr = getTableByLegalPerson(currTable,legalPerson,index,false);
        	var anotherTdArr = getTableByLegalPerson(anotherTable,legalPerson,index,false);
            setGolab(currTdArr);
            syncSubTotal(diff,index,"是否同步到<匯總表>小計!");
        	if(existsCostCode(oTd)){
        		operaSuccess = handleSyncHenBO(anotherTdArr,diff,false,index);
                setGolab(anotherTdArr);
                syncSubTotal(diff,index,"是否同步到<明細表>小計!");
        	}
        }
    }else{
        //改的就是明細表-currTable是明細表 anotherTable是總表
        //判斷該的是否是小計 還是 明細 都需要同步到 總表中的3個費用代碼
        if(hasAttr(tdFirst,"colspan")){
            //改的是明細表的小計
	    	index += tdFirst.attr("colspan")*1-1;
	        var currTdArr = getTableByLegalPerson(currTable,legalPerson,index,true);
	        var anotherTdArr = getTableByLegalPerson(anotherTable,legalPerson,index,true);
	        //修改的是明細表中的明細
	        handleSyncHenBO(currTdArr,diff,false,index);
	        var costCodeArr = getCostCodeTdByLegalPerson(anotherTable,legalPerson,index,true);
	        //修改的總表的明細(對應法人下的三個二次分攤費用代碼)
	        operaSuccess = handleSyncHenBO(costCodeArr,diff,false,index);
	        //修改總表的小計subTotal
	        setGolab(anotherTdArr);
	        syncSubTotal(diff,index,"是否同步到<匯總表>小計!");
        }else{
        	//改的是明細表的明細
        	var currTdArr = getTableByLegalPerson(currTable,legalPerson,index,false);
            var anotherTdArr = getTableByLegalPerson(anotherTable,legalPerson,index,false);
            setGolab(currTdArr);
            syncSubTotal(diff,index,"是否同步到<明細表>小計!");
            var costCodeArr = getCostCodeTdByLegalPerson(anotherTable,legalPerson,index,false);
            operaSuccess = handleSyncHenBO(costCodeArr,diff,false,index);
            setGolab(anotherTdArr);
            syncSubTotal(diff,index,"是否同步到<匯總表>小計!");
        }
    }
	return operaSuccess;
}
//=====================通用費用同步邏輯===================
//将差异值赋值给对应的table下对应的单元格- 修改成功返回true
function handleSyncTable(oTdArr,diff){
	//分摊规则:分摊部门代码的数量 来平分差异值,如果平分数小于0.01,就分摊差异值数量的事业群即可,并随机分配
	var operate = true;
	diff = diff.toFixed(2);
	var absDiff = Math.abs(diff);
	if(absDiff/oTdArr.length < 0.01){
		//差異值不夠均分 均分后小於0.01,至少得分配0.01
		var dispatchCount = absDiff/0.01;//獲得可以分配給幾個人
		var newVal = diff/dispatchCount;
		operate = handleTdVal(newVal,oTdArr,dispatchCount);
	}else{
		//差異值夠均分
		var len = oTdArr.length;
		var dispatchCount = len;//獲得可以分配給所有人
		var newVal = diff/len;
		operate = handleTdVal(newVal,oTdArr,dispatchCount);
	}
	return operate;
}
//處理需要同步數據的table(oTdArr)數組,各Td元素值的加減修正-dispatchLength:是分配給多少個費用代碼(人)
function handleTdVal(newVal,oTdArr,dispatchLength){
	var flag = true;
	for(var i = 0; i<dispatchLength; i++){
		var randomIndex = getRandomByNum(oTdArr.length);
	    var otd = oTdArr[randomIndex];
	    var oldText = otd.text();
	    oldText = removeComma(oldText)
	    if(!isNaN(oldText)){
	        oldText += newVal;
	        oldText = oldText.toFixed(2);
	        oldText = sinceCountNumber(oldText);
	        otd.text(oldText);
	        otd.attr("title","備註:"+oldText+"\n修改人:"+cardNumber+"("+nickName+")\n修改時間:"+new Date().format("yyyy-MM-dd hh:mm")).css("background-color","oldLace");
	    }else{
	        layer.msg("欄位修改錯誤!此處還有缺陷尚未完善,修改的數字如果存在逗號,請不要保存表單",{time:1500});
	        flag = false;
	        break;
	    }
		//移除已經賦過值的元素（避免重複+diff）
      oTdArr.splice(randomIndex,1);
	}
  return flag;
}
//=====================恒博住宿同步邏輯===================
//isPass 是用来取消判断同步给另一个表格(分摊明细表) 时,不要再判断费用代码,因为明细表中,
//依然存在这三个费用代码,如果依然还判断,有几率导致递归无法退出
//该方法只能在修改明细表时才指定isPass 的值给为false即可, 默认为True 需要去判断修改的值是否为二次分摊的代码
function handleSyncHenBO(oTdArr,diff,isPass,index){
	var operate = true;
	diff = diff.toFixed(2);
  var absDiff = Math.abs(diff);
  var newVal, dispatchCount;
  if(absDiff/oTdArr.length < 0.01){
  	//不够均分-分0.01
  	dispatchCount = absDiff/0.01;//獲得可以分配給幾個人
      newVal = diff/dispatchCount;
  }else{
  	//差異值夠均分
      var len = oTdArr.length;
      dispatchCount = len;//獲得可以分配給所有人
      newVal = diff/len;
  }
  operate = handleTdValHenBo(newVal,oTdArr,dispatchCount,isPass,index);
  return operate;
}
//isPass 是为了 如果更新总表的小计 同步更新自身明细的时候,更新到含有二次分摊的代码时,
//需要同步到另一个明细表格, 明细表格中就不需要再判断costCode,每一份都有几率被分摊
function handleTdValHenBo(newVal,oTdArr,dispatchLength,isPass,index){
	var flag = true;
	for(var i = 0; i<dispatchLength; i++){
      var randomIndex = getRandomByNum(oTdArr.length);
      var otd = oTdArr[randomIndex];
      if(isPass && existsCostCode(otd)){
      	//改动另一个表的数据-明細
      	var anotherTdArr = getGolab();
	        //改動明細表的明細過后,需要將明細表的小計也同時更新
      	handleSyncHenBO(anotherTdArr,newVal,false,index);
      	syncSubTotal(newVal,index,"是否同步到<明細表>小計!");
      }
      var oldText = otd.text();
      oldText = removeComma(oldText);
      if(!isNaN(oldText)){
          oldText += newVal;
          oldText = oldText.toFixed(2);
          oldText = sinceCountNumber(oldText);
          otd.text(oldText);
          otd.attr("title","備註:"+oldText+"\n修改人:"+cardNumber+"("+nickName+")\n修改時間:"+new Date().format("yyyy-MM-dd hh:mm")).css("background-color","oldLace");
      }else{
          layer.msg("欄位修改錯誤!此處還有缺陷尚未完善,修改的數字如果存在逗號,請不要保存表單",{time:1500});
          flag = false;
          break;
      }
      //移除已經賦過值的元素（避免重複+diff）
      oTdArr.splice(randomIndex,1);
  }
	return flag
}
//同步小計
function syncSubTotal(newVal, index, msg){
	var tdArr = getGolab();
	if(confirm(msg)){
      var oTr = tdArr[0].parent();
      var subTotalTd = getSubTotalTd(oTr,index);
      var len = subTotalTd.length;
      handleTdValHenBo(newVal,subTotalTd,len,false);
  }else{
      layer.alert("請手動檢查表中的小計是否正確!");
  }
}
//true 表示存在costCode二次分摊的费用
function existsCostCode(td){
	var costCode = "DG6267,DG6917,DG6AA7";
	var _costCode = td.parent().find("td").eq(2).text().toUpperCase();
	if(costCode.indexOf(_costCode) == -1){
		return false;
	}
	return true;
}
//=========辅助方法========
//用於獲得表單的subTotal
var golab;
function setGolab(val){
	golab = val;
}
function getGolab(){
	return golab;
}
function distoryGolab(){
	golab = null;
}
//元素是否包含某个属性-此处用于判断是否包含colspan 识别为小计栏位
function hasAttr(oJq,attrName){
	if(!oJq.attr(attrName)){
		return false;
	}
	return true;
}
//去掉逗号-返回为数字类型
function removeComma(num){
	num = num.replace(/,/g,'');
	return num*1;
}
//判斷是否為總表-判斷下一個兄弟元素是否為table
function isTotalTable(oTable){
	var nextObj = oTable.next("table");
	var nextObj1 = oTable.next("div").next("table");
	if(!checkObjIsNull(nextObj) || !checkObjIsNull(nextObj1)){
		return true;
	}
	return false;
}
//获取指定数以下的随机数
function getRandomByNum(num){
	return Math.floor(Math.random()*num);
}
//傳入table 和 需要的td 下標,返回對應表單的所有行
function getTrForTable(oTable, index){
	var arr = [];
	oTable.find("tr").each(function(){
		arr.push($(this).find("td").eq(index));
	})
	return arr;
}
//返回符合的Td数组
//isSubTotalLegalName:true - 用非数值一样的匹配 比如业城 = 业城(小计),认为是相同的
//isSubTotalLegalName:false- 用数值一样的匹配 比如业城 = 业城,认为是相同的
function getTableByLegalPerson(oTable,legalName,index,isSubTotalLegalName){
  var arr = [];
  oTable.find("tr").each(function(){
	  var tds = $(this).find("td");
	  if(!checkObjIsNull(tds)){
		  var text = tds.eq(0).text();
	      if(isSubTotalLegalName){
		      //text是總表的明細表每行的法人
	          if(legalName.indexOf(text) > -1){
	              //排除小计自己
	              if(text != legalName){
	                  arr.push(tds.eq(index));
	              }
	          }
	      }else{
	          if(legalName == text){
	              arr.push(tds.eq(index));
	          }
	      }
	  }
  })
  return arr;
}
//isSubTotalLegalName 是用來指明點擊修改的td法人是小計還是明細中的普通明字,例如 鴻富錦成都  鴻富錦成都(小計)
function getCostCodeTdByLegalPerson(oTable,legalName,index,isSubTotalLegalName){
  var arr = [];
  oTable.find("tr").each(function(){
      var tds = $(this).find("td");
      if(!checkObjIsNull(tds)){
          var td = tds.eq(0);
          var text = td.text();
          if(legalName.indexOf(text) > -1){
              if(isSubTotalLegalName){
              	//排除小計自己
	                if(text != legalName && existsCostCode(td)){
	                    arr.push(tds.eq(index));
	                }
              }else{
	                if(text == legalName && existsCostCode(td)){
	                    arr.push(tds.eq(index));
	                }
              }
          }
      }
  })
  return arr;
}
function getTableByLegalPersonForDex(oTable,legalName,legalIndexArr,index){
	  var arr = [];
	  oTable.find("tr").each(function(){
		  var tds = $(this).find("td");
		  if(!checkObjIsNull(tds)){
			  var text = "";
			  for(var i in legalIndexArr){
				  var dex = legalIndexArr[i];
				  text += tds.eq(dex).text();
			  }
	          if(legalName == text){
	              arr.push(tds.eq(index));
	          }
		  }
	  })
	  return arr;
	}
//通过法人获得小计对应的td
function getSubTotalTd(oTr,index){
	var tdFirst = oTr.find("td").eq(0);
	if(hasAttr(tdFirst,"colspan")){//表示當前行屬於 小計
		//改的是總表的小計-同步明细
		var arr = [];
      	index -= tdFirst.attr("colspan")*1-1;
      	var tds = oTr.find("td");
      	arr.push(tds.eq(index));
      	return arr;
	}else{
		return getSubTotalTd(oTr.next(),index);
	}
}
//通过点击元素 得到所属的table，寻找到另一个table 
function getAnotherTable(oCurrTab){
	var idName = oCurrTab.attr("id");
	var obj;
	if(idName == "totaltab" || idName == "tableAll"){
	    obj = $("#tab");
	    if(checkObjIsNull(obj)){
	    	obj = $("#tableList");
	    }
	}else{
		obj = $("#totaltab");
		if(checkObjIsNull(obj)){
			obj = $("#tableAll");
		}
	}
	return obj;
}
function checkObjIsNull(obj){
	if(!obj[0]){
		return true;
	}
	return false;
}
//檢查是否為第一個tr
function checkIsFirstTr(oTr){
	var len = oTr.prev().length
	return len == 0 ? true : false;
}
//获得当张表格中的汇总表和明细表两张表单 obj{total:arr1,list:arr2}
//separatorField 总表和明细表的分割属性 不然无法识别隔开
function singleTable_getTr(oTable,separatorField,legalName,index){
	var arr = [],_arr = [];
	var flag = true;
	oTable.find("tr").each(function(){
		var oCtr = $(this);
		if(hasAttr(oCtr,separatorField)){
			flag = false;
		}else{
			var tds = oCtr.find("td");
			if(tds.eq(0).text() == legalName){
				if(flag){
					arr.push(tds.eq(index));
				}else{
					_arr.push(tds.eq(index));
				}
			}
		}
	})
	var obj = {};
	obj.total = arr;
	obj.list = _arr;
	setGolab(obj);
}
//在一个table中判断是汇总部分行还是明细部分tr
function singleTable_isTotalTable(oTr){
	var nOtr = oTr.next();
	var flag = false;
	if(checkObjIsNull(nOtr)){
		return flag;
	}
	if(hasAttr(nOtr,"style")){
		flag = true;
		return flag;
	}else{
		return singleTable_isTotalTable(nOtr);
	}
}