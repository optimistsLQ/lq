package com.foxconn.mapper;

import java.util.List;
import java.util.Map;

import com.foxconn.entity.Signature;

import tk.mybatis.mapper.common.Mapper;

public interface SignatureMapper extends Mapper<Signature>{

    List<Map<String,Object>> selectByTolsigId(String tolsigId);

}