package com.foxconn.util;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.cursor.Cursor;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
//import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.foxconn.entity.Archive;
import com.foxconn.entity.CheckPeople;

public class ExcelUtil {

	
	
    /**
     * 导出Excel
     * @param sheetName sheet名称
     * @param title 标题
     * @param mapList 内容
     * @param wb HSSFWorkbook对象
     * @return
     */
    public static HSSFWorkbook getHSSFWorkbook(String sheetName, String []title, List<Archive> mapList, HSSFWorkbook wb){

        // 第一步，创建一个HSSFWorkbook，对应一个Excel文件
        if(wb == null){
            wb = new HSSFWorkbook();
        }

        // 第二步，在workbook中添加一个sheet,对应Excel文件中的sheet
        HSSFSheet sheet = wb.createSheet(sheetName);

        // 第三步，在sheet中添加表头第0行,注意老版本poi对Excel的行数列数有限制
        HSSFRow row = sheet.createRow(0);

        // 第四步，创建单元格，并设置值表头 设置表头居中
        HSSFCellStyle style = wb.createCellStyle();
//        style.setAlignment(HSSFCellStyle.ALIGN_CENTER); // 创建一个居中格式

        //声明列对象
        HSSFCell cell = null;

        //创建标题
        for(int i=0;i<title.length;i++){
            cell = row.createCell(i);
            cell.setCellValue(title[i]);
            cell.setCellStyle(style);
        }
       /**
        String [] title = {"编号","排配编号","餐厅","包商","稽核要点","大类","问题描述","问题星级","稽核员","处理措施","扣分"
        ,"稽核类别","状态","待签人员"};
        */
        //创建内容
        for(int i=0;i<mapList.size();i++){
            Archive archive = mapList.get(i);
            row = sheet.createRow(i + 1);
            //将内容按顺序赋给对应的列对象
            row.createCell(0).setCellValue(i);
            row.createCell(1).setCellValue(archive.getArrangementNum());
            row.createCell(2).setCellValue(archive.getRestaurantLocation());
            row.createCell(3).setCellValue(archive.getMealSeller());
            row.createCell(4).setCellValue(archive.getCheckPoint());
            row.createCell(5).setCellValue(archive.getTypeBigName());
            row.createCell(6).setCellValue(archive.getProblemDetail());
            row.createCell(7).setCellValue(archive.getGrade());
            List<CheckPeople> checkPeopleList = archive.getCheckpeople();
            String names = "";
            //将List集合中的对象里面的元素转换为set集合
            Set<String> nameSet = checkPeopleList.stream().map(CheckPeople :: getCheckManname).collect(Collectors.toSet());
            for (String name : nameSet) {
                names = names +" " +name;
            }
            row.createCell(8).setCellValue(names);
            String standRemark =  archive.getStandRemark();
            if (!StringUtils.isEmpty(standRemark)) {
                row.createCell(9).setCellValue(standRemark);
            } else {
                Double money = archive.getAfterMoney();
                if (ObjectUtils.isEmpty(money)) {
                    row.createCell(9).setCellValue("");
                } else {
                    if (money == -1) {
                        row.createCell(9).setCellValue(archive.getBeforeMoney());
                    } else {
                        row.createCell(9).setCellValue(money);
                    }
                }
            }
            if (ObjectUtils.isEmpty(archive.getAfterScore())) {
                row.createCell(10).setCellValue("");
            } else {
                row.createCell(10).setCellValue(archive.getAfterScore());
            }
            row.createCell(11).setCellValue(archive.getCheckNaturn());
            row.createCell(12).setCellValue(archive.getOverend());
            row.createCell(13).setCellValue(archive.getUserName());
            row.createCell(14).setCellValue(archive.getProblemLocation());
        }
        return wb;
    }

	public static HSSFWorkbook getDealerHSSFWorkbook(String sheetName, String[] title,List<Object> list,
			 HSSFWorkbook wb) {
		// 第一步，创建一个HSSFWorkbook，对应一个Excel文件
        if(wb == null){
            wb = new HSSFWorkbook();
        }

        // 第二步，在workbook中添加一个sheet,对应Excel文件中的sheet
        HSSFSheet sheet = wb.createSheet(sheetName);

        // 第三步，在sheet中添加表头第0行,注意老版本poi对Excel的行数列数有限制
        HSSFRow row = sheet.createRow(0);

        // 第四步，创建单元格，并设置值表头 设置表头居中
        HSSFCellStyle style = wb.createCellStyle();
//        style.setAlignment(HSSFCellStyle.ALIGN_CENTER); // 创建一个居中格式

        //声明列对象
        HSSFCell cell = null;

        //创建标题
        for(int i=0;i<title.length;i++){
            cell = row.createCell(i);
            cell.setCellValue(title[i]);
            cell.setCellStyle(style);
        }
       /**
        * 
        	String [] title = {"餐饮厂商","经销商","食品許可證到證日期","食品許可證編號","申請日期","申請人","簽核狀態"};
        */
        //创建内容
        for(int i=0;i<list.size();i++){
        	Map<String,String> map = (Map<String,String>) list.get(i);
            row = sheet.createRow(i + 1);
            //将内容按顺序赋给对应的列对象
            /**
             * 			id_card,
			serial_num,
			caterer_name,
			time,
			applicants,
			status, 
			dealer_name,
			LICENSE_DATE,
			SERIAL_NUMBER
             */
            row.createCell(0).setCellValue(map.get("CATERER_NAME"));
            row.createCell(1).setCellValue(map.get("DEALER_NAME"));
            if (ObjectUtils.isEmpty(map.get("LICENSE_DATE"))) {
            	 row.createCell(2).setCellValue("无");
            } else {
            	row.createCell(2).setCellValue(map.get("LICENSE_DATE"));
            }
           
            row.createCell(3).setCellValue(map.get("SERIAL_NUMBER"));
            row.createCell(4).setCellValue(map.get("TIME"));
            row.createCell(5).setCellValue(map.get("APPLICANTS"));
            row.createCell(6).setCellValue(map.get("STATUS"));
        }
        return wb;
	}

	public static HSSFWorkbook getStallChangeHSSFWorkbook(String sheetName, String[] title,List<Object> list,
			 HSSFWorkbook wb) {
		// 第一步，创建一个HSSFWorkbook，对应一个Excel文件
        if(wb == null){
            wb = new HSSFWorkbook();
        }

        // 第二步，在workbook中添加一个sheet,对应Excel文件中的sheet
        HSSFSheet sheet = wb.createSheet(sheetName);

        // 第三步，在sheet中添加表头第0行,注意老版本poi对Excel的行数列数有限制
        HSSFRow row = sheet.createRow(0);

        // 第四步，创建单元格，并设置值表头 设置表头居中
        HSSFCellStyle style = wb.createCellStyle();
//        style.setAlignment(HSSFCellStyle.ALIGN_CENTER); // 创建一个居中格式

        //声明列对象
        HSSFCell cell = null;

        //创建标题
        for(int i=0;i<title.length;i++){
            cell = row.createCell(i);
            cell.setCellValue(title[i]);
            cell.setCellStyle(style);
        }
     
        //   String [] title ={"餐包商","餐廳位置","包商負責人","檔口號","檔口名稱","檔口負責人","申請變更時間","變更類型","檔口性質","申請人","簽核狀態"};
        //创建内容
        for(int i=0;i<list.size();i++){
            Map<String,String> map = (Map<String,String>) list.get(i);
            row = sheet.createRow(i + 1);
            //将内容按顺序赋给对应的列对象
            row.createCell(0).setCellValue(map.get("CATERER_NAME"));
            row.createCell(1).setCellValue(map.get("RESTAURANT_LOCATION"));
            row.createCell(2).setCellValue(map.get("RESTAURANT_PRINCIPAL"));
            row.createCell(3).setCellValue(map.get("SLOGAN"));
            row.createCell(4).setCellValue(map.get("SLOGAN_NAME"));
            row.createCell(5).setCellValue(map.get("SLOGAN_PRINCIPAL"));
            row.createCell(6).setCellValue(map.get("TIME"));
            row.createCell(7).setCellValue(map.get("APPLICATION_TYPE"));
            row.createCell(8).setCellValue(map.get("LEVER"));
            row.createCell(9).setCellValue(map.get("APPLICANTS"));
            row.createCell(10).setCellValue(map.get("STATUS"));
        }
        return wb;
	}

	public static HSSFWorkbook getFoodQualifictionHSSFWorkbook(String sheetName, String[] title,List<Object> list,
			 HSSFWorkbook wb) {
		// TODO Auto-generated method stub
		// 第一步，创建一个HSSFWorkbook，对应一个Excel文件
        if(wb == null){
            wb = new HSSFWorkbook();
        }

        // 第二步，在workbook中添加一个sheet,对应Excel文件中的sheet
        HSSFSheet sheet = wb.createSheet(sheetName);

        // 第三步，在sheet中添加表头第0行,注意老版本poi对Excel的行数列数有限制
        HSSFRow row = sheet.createRow(0);

        // 第四步，创建单元格，并设置值表头 设置表头居中
        HSSFCellStyle style = wb.createCellStyle();
//        style.setAlignment(HSSFCellStyle.ALIGN_CENTER); // 创建一个居中格式

        //声明列对象
        HSSFCell cell = null;

        //创建标题
        for(int i=0;i<title.length;i++){
            cell = row.createCell(i);
            cell.setCellValue(title[i]);
            cell.setCellStyle(style);
        }
     
        /**
         *    String [] title = "餐飲廠商","生產商","经销商","大類","小類","品牌","品名","規格","等級","食材經營許可證到證日期","食品經營許可證編號"
         *    ,"食品生產許可證到期日","食品生產許可證編號","產品檢驗報告到期日","申請日期","申請人","單據狀態"};
         */
        //创建内容
        for(int i=0;i<list.size();i++){
            @SuppressWarnings("unchecked")
            Map<String,String> map = (Map<String,String>) list.get(i);
            row = sheet.createRow(i + 1);
            //将内容按顺序赋给对应的列对象
            row.createCell(0).setCellValue(map.get("CATERER_NAME"));
            row.createCell(1).setCellValue(map.get("MANUFACTURER"));
            row.createCell(2).setCellValue(map.get("DEALER"));
            row.createCell(3).setCellValue(map.get("LARGE_CATEGORIES"));
            row.createCell(4).setCellValue(map.get("SUBCATEGORY"));
            row.createCell(5).setCellValue(map.get("BRAND"));
            row.createCell(6).setCellValue(map.get("PRODUCT_NAME"));
            row.createCell(7).setCellValue(map.get("SPECIFICATIONS"));
            row.createCell(8).setCellValue(map.get("GRADE"));
            
            if (ObjectUtils.isEmpty(map.get("dealerLicenseDate"))) {
            	row.createCell(9).setCellValue("无");
            } else {
            	row.createCell(9).setCellValue(map.get("dealerLicenseDate"));
            }
            row.createCell(10).setCellValue(map.get("dealerSerialNumber"));
            
            if (ObjectUtils.isEmpty(map.get("LICENSE_DATE"))) {
            	row.createCell(11).setCellValue("无");
            } else {
            	row.createCell(11).setCellValue(map.get("LICENSE_DATE"));
            }
            row.createCell(12).setCellValue(map.get("SERIAL_NUMBER"));
            row.createCell(13).setCellValue(map.get("PRODUCT_INSPECTION"));
            row.createCell(14).setCellValue(map.get("TIME"));
            row.createCell(15).setCellValue(map.get("APPLICANTS"));
            row.createCell(16).setCellValue(map.get("STATUS"));
          
        }
        return wb;
	}

}
