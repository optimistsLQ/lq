package com.foxconn.mapper;

import java.util.List;
import java.util.Map;

import com.foxconn.entity.Proxy;

import tk.mybatis.mapper.common.Mapper;

public interface ProxyMapper extends Mapper<Proxy>{

    List<Map<String,Object>> selectByUuid(String uuid);

}
