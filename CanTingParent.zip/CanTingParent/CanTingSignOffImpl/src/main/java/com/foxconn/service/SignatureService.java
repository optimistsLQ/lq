package com.foxconn.service;

import java.util.List;
import java.util.Map;

import com.foxconn.entity.Signature;

/**
 * @author C3414208
 *
 */
public interface SignatureService {
   
    /**
     * 根据流程id查询所有的签核节点
     * @param tolsigId
     * @return
     */
    public List<Signature> findAllByTolsigId(String tolsigId);

    /**
     * 删除此流程id下所有的节点信息
     * @param tolsigId
     */
    public void delByTolSigId(String tolsigId);

    /**
     * 插入一个节点
     * @param signature
     */
    public void insertSig(Signature signature);

    public List<Map<String,Object>> findSig(String tolsigId);
    /**
     * 根据签核流程id获取流程
     * @param tolsigId
     * @return
     */
    public List<Map<String, Object>> findByTolsigId(String tolsigId);
}
