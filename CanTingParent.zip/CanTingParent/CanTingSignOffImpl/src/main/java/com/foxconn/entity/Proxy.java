package com.foxconn.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Table;
import javax.persistence.Id;
@Table(name = "T_PROXY")
public class Proxy implements Serializable{
    /**
     * 
     */
    private static final long serialVersionUID = -7124023191775208803L;
    @Id
    private String pid;
    private String uuid;//当事人
    private String proxyId;//代理人
    private Date startTime;
    private Date endTime;
    private String remark;
    public String getPid() {
        return pid;
    }
    public void setPid(String pid) {
        this.pid = pid == null ? null : pid.trim();
    }
    public String getUuid() {
        return uuid;
    }
    public void setUuid(String uuid) {
        this.uuid = uuid == null ? null : uuid.trim();
    }
    public String getProxyId() {
        return proxyId;
    }
    public void setProxyId(String proxyId) {
        this.proxyId = proxyId == null ? null : proxyId.trim();
    }
    public Date getStartTime() {
        return startTime;
    }
    public void setStartTime(Date stratTime) {
        this.startTime = stratTime;
    }
    public Date getEndTime() {
        return endTime;
    }
    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }
    public static long getSerialversionuid() {
        return serialVersionUID;
    }
    @Override
    public String toString() {
        return "Proxy [pid=" + pid + ", uuid=" + uuid + ", proxyId=" + proxyId + ", startTime=" + startTime
                + ", endTime=" + endTime + ", remark=" + remark + "]";
    }
}
