package com.foxconn.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Table;

import com.github.nobodxbodon.zhconverter.简繁转换类;
import com.github.nobodxbodon.zhconverter.简繁转换类.目标;

import javax.persistence.Id;
@Table(name = "T_FILE")
public class Files implements Serializable{

    /**
     * 
     */
    private static final long serialVersionUID = 3851225867487437589L;
    @Id
    private String fid;//附件id
    private String foreignKey;//表单id
    private String fileName;//附件名称
    private byte[] entity;//附件内容
    private Date writeTime;
    
    
    public Date getWriteTime() {
        return writeTime;
    }
    public void setWriteTime(Date writeTime) {
        this.writeTime = writeTime;
    }
    public String getFid() {
        return fid;
    }
    public void setFid(String fid) {
        this.fid = fid;
    }
    public String getForeignKey() {
        return foreignKey;
    }
    public void setForeignKey(String foreignKey) {
        this.foreignKey = foreignKey;
    }
    public byte[] getEntity() {
        return entity;
    }
    public String getFileName() {
        return fileName;
    }
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    public void setEntity(byte[] entity) {
        this.entity = entity;
    }
    public static long getSerialversionuid() {
        return serialVersionUID;
    }
    
    
   

}
