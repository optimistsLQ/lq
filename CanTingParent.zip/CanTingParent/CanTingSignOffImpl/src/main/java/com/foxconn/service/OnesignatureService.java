package com.foxconn.service;

import java.util.List;
import java.util.Map;


import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.foxconn.entity.Archive;
import com.foxconn.entity.EndSignInfo;
import com.foxconn.entity.Result;

public interface OnesignatureService {

    /**
     * 插入节点顺序，节点名，uuid和表单id
     * @param list
     */
    Integer insertOnesignature(List<Map<String, Object>> list,String type);

    /**
     * 根据uuid，表单id修改状态和签核意见
     * @param uuid
     * @param formCode
     * @param sigidea
     */
    Result updateOnesignature(String uuid, String formCode, String sigidea,String userName,String type,String orderNumber);

    /**
     * 加签/会签/驳回/作废
     * @param uuid
     * @param formCode
     * @param orderNumber
     */
    Result insertEndorsement(String uuid, String formCode,String nodeName , String orderNumber,final String status,String type);

    /**
     * 查询稽核表单待签核数据
     * @param uuid
     * @return
     */
    Map<String,Object> findSignOffByUuid(String uuid,Integer start, Integer length);

    /**
     * 查询当前表单签核流程
     * @param formCode
     * @return
     */
    List<Map<String,Object>> findSignOffByFormCode(String formCode);


    /**
     * 归档查询
     * @param uuid
     * @param start
     * @param length
     * @return
     */
    List<Archive> getNewAllSignOff(EndSignInfo endSignInfo);
    
    Map<String, Object> newEndAllSignOff(EndSignInfo endSignInfo, Integer start, Integer length);

    /**
     * 查找所有待签核表单数据
     * @param uuid
     * @return
     */
    Map<String, Object> findSignOffAll(String uuid);

    /**
     * 查询餐厅变动申请单的归档查询
     * @param uuid 当前本人id
     * @param startDate  开始时间
     * @param endDate 结束时间
     * @param catererName 餐饮厂商
     * @param restaurantLocation 餐厅位置
     * @param applicationType 申请状态
     * @param status 表单签核状态
     * @param start 分页查询的开始页码
     * @param length 分页查询每页长度
     * @return
     */
	Map<String,Object> selectStallChangeFile(String uuid, String startDate, String endDate, String catererName,
			String restaurantLocation, String applicationType,String status,String length,String start);

	/**
	 * 经销商申请单归档查询
	 * @param uuid 当前本人id
	 * @param startDate 开始时间
	 * @param endDate 结束时间
	 * @param catererName 餐饮厂商
	 * @param dealer 经销商
	 * @param status 表单签核状态
	 * @param length 分页查询的开始页码
	 * @param start 分页查询每页长度
	 * @return
	 */
	Map<String, Object> selectDealerFile(String uuid, String startDate, String endDate, String catererName,
			String dealer, String status, String length, String start);

	/**
	 * 食材资质申请单归档查询
	 * @param uuid 当前本人id
	 * @param startDate 开始时间
	 * @param endDate 结束时间
	 * @param catererName 餐饮厂商
	 * @param brand
	 * @param productName
	 * @param status 表单签核状态
	 * @param length 分页查询每页长度
	 * @param start 分页查询的开始页码
	 * @return
	 */
	Map<String, Object> selectFoodQualifictionFile(String uuid, String startDate, String endDate, String catererName,
			String brand, String productName, String status, String length, String start);

	/**
	 * 表單簽核狀態
	 * @param formCode
	 * @param formType
	 * @return
	 */
	String getFormStatus(String formCode, String formType);

	/**
	 * 歷史簽核流程查詢
	 * @param formCode
	 * @return
	 */
    Result historyOnesignature(String formCode);


	/**
	 * 流式查询数据
	 * @param excelWriter
	 * @param writeSheet
	 */
//    void ioReader(ExcelWriter excelWriter, WriteSheet writeSheet);



}
