package com.foxconn.service.impl;


import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.foxconn.entity.Archive;
import com.foxconn.entity.CheckTotal;
import com.foxconn.entity.Dealer;
import com.foxconn.entity.EndSignInfo;
import com.foxconn.entity.FoodQualifiction;
import com.foxconn.entity.Onesignature;
import com.foxconn.entity.Result;
import com.foxconn.entity.ResultCode;
import com.foxconn.entity.SignOffInfo;
import com.foxconn.entity.StallChange;
import com.foxconn.entity.UserEntity;
import com.foxconn.mapper.CheckTotalMapper;
import com.foxconn.mapper.DealerMapper;
import com.foxconn.mapper.FoodQualifictionMapper;
import com.foxconn.mapper.OnesignatureMapper;
import com.foxconn.mapper.StallChangeMapper;
import com.foxconn.mapper.UserEntityMapper;
import com.foxconn.service.OnesignatureService;
import com.foxconn.utils.EmailToolkit;
import com.foxconn.utils.Utils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;
@Service
public class OnesignatureServiceImpl implements OnesignatureService{

    @Autowired
    private OnesignatureMapper onesignatureMapper;
    @Autowired
    private CheckTotalMapper checkTotalMapper;
    @Autowired
    private UserEntityMapper userEntityMapper;
    
    @Autowired
    private StallChangeMapper stallChangeMapper;
    @Autowired
    private FoodQualifictionMapper foodQualifictionMapper;
    @Autowired
    private DealerMapper dealerMapper;
    @Transactional
    @Override
    public Integer insertOnesignature(List<Map<String, Object>> list,String type) {
        Integer i = 0;
        // TODO Auto-generated method stub
        Map<String,Object> map = list.get(0);
        String formCode = map.get("formCode").toString();
        String uuid = map.get("uuid").toString();
        //创建签核
        Example example = new Example(Onesignature.class);
        Criteria criteria = example.createCriteria();
        criteria.andEqualTo("formCode", formCode);
        //删除formCode所有签核流程
        onesignatureMapper.deleteByExample(example);
        //插入formCode的签核流程
        i = onesignatureMapper.insertOnesignature(list);
        
        /**
         * 假如发起人跟下一节点是同一人，将所有签核备注改为自动签核
         */
        SignOff(uuid, formCode, "1", "Y", "", true);
        //判断是否为最后一个人签核，并将能否签核权限移交给下一个人
        lastOne("1", formCode,type);
        return i;
    }
    
    
    /**
     * 郵件提醒簽核
     * uuid 當前簽核本人id
     * formCode 當前簽核表單id
     * sponsor 承辦人uuid
     * status 判断当前表单类别 
     */
    public void sendEmail(String uuid,String formCode,String sponsor,String status){
        Example sponsorexample = new Example(UserEntity.class);
        Criteria sponsorcriteria = sponsorexample.createCriteria();
        sponsorcriteria.andEqualTo("uuid", sponsor);
        List<UserEntity> sponsorlist = userEntityMapper.selectByExample(sponsorexample);
        String userName = sponsorlist.get(0).getUserName();
        
        new Thread(()->{
            Example example = new Example(UserEntity.class);
            Criteria criteria = example.createCriteria();
            criteria.andEqualTo("uuid", uuid);
            List<UserEntity> list = userEntityMapper.selectByExample(example);
            String email = list.get(0).getEmail();
            if (!email.contains("@") || email.contains("@qq")) {
                return ;
            }
            String str = "";
            if (ObjectUtils.isEmpty(status)) {
                /**
                 * 稽核模塊
                 */
            	
	        	Archive archive = onesignatureMapper.selectOnesignatureInfo(uuid,formCode); 
	            str = archive.getMealSeller() + "-" + archive.getRestaurantLocation() +"餐廳表單";
         
            } else if (status.equals("stall")) {
                /**
                 * 檔口變更申請
                 */
            	Example stallChangeExample = new Example(StallChange.class);
                Criteria checkTotalCriteria = stallChangeExample.createCriteria();
                checkTotalCriteria.andEqualTo("idCard", formCode);
                StallChange checkTotal = stallChangeMapper.selectOneByExample(stallChangeExample);
                str = checkTotal.getCatererName() + "-" + checkTotal.getRestaurantLocation();
       
            } else if (status.equals("foodQualifiction")) {
                /**
                 * 食材資質申請
                 */
            	Example stallChangeExample = new Example(FoodQualifiction.class);
                Criteria checkTotalCriteria = stallChangeExample.createCriteria();
                checkTotalCriteria.andEqualTo("idCard", formCode);
                FoodQualifiction checkTotal = foodQualifictionMapper.selectOneByExample(stallChangeExample);
                str = "餐包商(" + checkTotal.getCatererName() + ")--经销商(" + checkTotal.getDealer()+")";
            } else if (status.equals("dealer")) {
            	/**
                 * 经销商申请
                 */
            	Example stallChangeExample = new Example(Dealer.class);
                Criteria checkTotalCriteria = stallChangeExample.createCriteria();
                checkTotalCriteria.andEqualTo("idCard", formCode);
                Dealer checkTotal = dealerMapper.selectOneByExample(stallChangeExample);
                str = "餐包商(" + checkTotal.getCatererName() + ")--经销商(" + checkTotal.getDealerName()+")";
            }
            EmailToolkit.sendEmail("尊敬的『"+list.get(0).getUserName()+"』主管/同仁,您有新的表單『"+str+"』需要簽核（Fr:餐飲管理平台）", "<span style='font-weight:bold;'>尊敬的用戶："+list.get(0).getUserName()+"</span><br>感謝你使用及支持集團餐飲管理平台系統。<br><span style='color:red;'>"+userName+"</span>&nbsp;通過系統提交了一份<span style='color:red;'>『"+str+"』</span>給你<br>請您盡快<a href='http://10.244.170.244:8585/CanTing'>登錄系統</a>查看詳情並進行電子簽核，謝謝!", email);

        }).start();
       
   }
    
    /**
     * 确定签核
     */
    @Transactional
    @Override
    public Result updateOnesignature(String uuid, String formCode, String sigidea,String userName,String type,String orderNumber) {
        // TODO Auto-generated method stub
        /**
         * 判断是否为代理人，代理人签核
         */
        Map<String,Object> statusMap = agentSignOff(uuid, formCode, sigidea,userName,type,orderNumber);
        if ((Boolean)statusMap.get("boolean")) {
            return (Result) statusMap.get("result");
        }
    
        List<Boolean> whetherSignOffList = new ArrayList<>();
        List<Boolean> processList = new ArrayList<>();
        List<Onesignature> thisOnesignatureList = onesignatureMapper.selectMinOrderNumByExample(uuid,formCode);
        for (Onesignature onesignature : thisOnesignatureList) {
            /**
             * 判断当前节点是否未签核   true=签核
             */
            if (onesignature.getSigstatus().equals("Y")) {
                
                whetherSignOffList.add(true);
            } else {
                whetherSignOffList.add(false);
            }
//            whetherSignOffList.add(onesignature.getSigstatus().equals("Y"));
            
            /**
             * 判断当前节点能否签核    true=能签核
             */
        	 if ("Y".equals(onesignature.getMyselfSign())) {
                 processList.add(true);
             } else {
                 processList.add(false);
             }
//        	 processList.add("Y".equals(onesignature.getMyselfSign()));
        }
        //不存在false表示已全部簽核
        if (!whetherSignOffList.contains(false)) {
            return new Result(ResultCode.FAIL, "你已签核，请勿重复签核！");
        }
        //不存在true表示不該當前節點簽核
        if (!processList.contains(true)) {
            return new Result(ResultCode.FAIL, "流程错误");
        }
        SignOff(uuid, formCode, orderNumber, sigidea, userName, true);
        lastOne(orderNumber, formCode,type);
        return new Result(ResultCode.SUCCESS, "签核成功");
    }

    
    
    private void SignOff (String uuid,String formCode,String orderNumber,String sigidea,String userName,Boolean proxyStatus) {
        
        String remark = "";
        Example example = new Example(Onesignature.class);
        Criteria criteria = example.createCriteria();

    	criteria.andEqualTo("formCode", formCode);
    	criteria.andEqualTo("orderNumber",orderNumber);
        
        List<Onesignature> list = null;
        if (proxyStatus) {
        	list = onesignatureMapper.selectMinOrderNumByExample(uuid,formCode);
        } else {
        	list = onesignatureMapper.selectMinOrderNumByProxyId(uuid,formCode);
        	list.addAll(onesignatureMapper.selectMinOrderNumByExample(uuid,formCode));
        }
        Onesignature newOnesignature = onesignatureMapper.selectOneByExample(example);
        String nodeName = newOnesignature.getNodeName();
        newOnesignature.setSignTime(Utils.dateFormatStr(new Date(), "yyyy-MM-dd HH:mm:ss"));
        Integer orderNumberInteger = Integer.parseInt(newOnesignature.getOrderNumber());
        /**
         * 设置自动签核
         */
        for (int i = 0; i < list.size(); i++) {
        	Onesignature os = list.get(i);
        	String nodeNameOs = os.getNodeName();
        	String thisUUID = os.getUuid();
        	Integer newOrderNumberInteger = Integer.parseInt(os.getOrderNumber());
        	if  (newOrderNumberInteger < orderNumberInteger) {
        		continue;
        	}
         	if (!thisUUID.equals(uuid)) {
    			remark  = "代理人("+userName+")";
    		} else {
    			remark  = "自动签核";
    		}
        	if (nodeName.equals(nodeNameOs)) {
        		onesignatureMapper.updateByOnesignature(getOnesignature(os,remark,sigidea));
        	} else {
        		if (nodeNameOs.length() == nodeName.length()) {
        			String str = nodeNameOs.substring(0, nodeNameOs.length()-1);
        			if (nodeName.contains(str)) {
        				onesignatureMapper.updateByOnesignature(getOnesignature(os,remark,sigidea));
        			}
        		} else if (nodeNameOs.length() > nodeName.length()) {
        			if (nodeNameOs.contains(nodeName)) {
        				onesignatureMapper.updateByOnesignature(getOnesignature(os,remark,sigidea));
        			}
        		} else if (nodeNameOs.length() < nodeName.length()) {
        			if (nodeName.contains(nodeNameOs)) {
        				onesignatureMapper.updateByOnesignature(getOnesignature(os,remark,sigidea));
        			}
        		}
        	}
		}
        
        /**
         * 修改第一个节点
         */
        newOnesignature.setRemark(" ");
        newOnesignature.setSigstatus("Y");
        newOnesignature.setMyselfSign("N");
        newOnesignature.setMyselfSign("");
        criteria.andEqualTo("onesigId", newOnesignature.getOnesigId());
        onesignatureMapper.updateByExampleSelective(newOnesignature, example);
    }
    
    private Onesignature getOnesignature(Onesignature os,String remark,String sigidea) {
    	String sigstatus = "Y";
 		os.setSigstatus(sigstatus);
		os.setSigidea(sigidea);
		os.setRemark(remark);
        os.setMyselfSign("N");
        os.setSignTime(Utils.dateFormatStr(new Date(), "yyyy-MM-dd HH:mm:ss"));
        return os;
    }
    
    /**
     * 判断是否是最后一个签核，并將簽核權限移交下一人
     * orderNumber 当前节点
     */
    private void lastOne (String orderNumber,String formCode,String type) {
        Example example = new Example(Onesignature.class);
        Criteria criteria = example.createCriteria();
        criteria.andEqualTo("formCode", formCode);
        example.setOrderByClause("ORDER_NUMBER");
        //簽核流程
        List<Onesignature> list = onesignatureMapper.selectByExample(example);
        
        //最後一人節點
        Onesignature newOnesignature = list.get(list.size()-1);
        
        //發起人id
        String uuid = list.get(0).getUuid();
        
        //最後一人的節點編號
        Integer lastOrderNumber = Integer.parseInt(newOnesignature.getOrderNumber());
        //當前人的節點編號
        Integer thisOrderNumber = Integer.parseInt(orderNumber);
        
        
        if (lastOrderNumber > thisOrderNumber) {
            for (Onesignature onesignature : list) {
                if (onesignature.getSigstatus().equals("N")) {
                    //将能否签核节点转交给下一个人
                	Onesignature o = new Onesignature();
                    o.setMyselfSign("Y");
                    Example checkTotalExample = new Example(Onesignature.class);
                    Criteria checkTotalCriteria = checkTotalExample.createCriteria();
                    checkTotalCriteria.andEqualTo("orderNumber", onesignature.getOrderNumber());
                    checkTotalCriteria.andEqualTo("formCode", formCode);
                    onesignatureMapper.updateByExampleSelective(o, checkTotalExample);
                    sendEmail(onesignature.getUuid(),formCode,uuid,type);
                    return;
                }
            }
            if (list.get(list.size() -1).getSigstatus().equals("Y")) {
                changeStatus(type,formCode,"已结案");
            }
        }  else {
            for (Onesignature onesignature : list) {
                //判斷中間是否有人漏簽
                if (onesignature.getSigstatus().equals("N")) {
                    return;
                }
            }
            //签核完成 将表单改为已结案
            changeStatus(type,formCode,"已结案");
        }
    }
    
    /**
     * 修改单子状态
     */
    private void changeStatus(String type,String formCode,String status){
        if (ObjectUtils.isEmpty(type)) {
            /**
             * 稽核模塊
             */
            //签核完成 将表单状态修改status
            Example checkTotalExample = new Example(CheckTotal.class);
            Criteria checkTotalCriteria = checkTotalExample.createCriteria();
            checkTotalCriteria.andEqualTo("checktotalId", formCode);
            CheckTotal checkTotal = checkTotalMapper.selectOneByExample(checkTotalExample);
            if (!ObjectUtils.isEmpty(checkTotal)) {
                checkTotal.setOverend(status);
                checkTotalMapper.updateByExampleSelective(checkTotal, checkTotalExample);
            }
        } else if (type.equals("stall")) {
            /**
             * 檔口變更申請
             */
            Example stallExample = new Example(StallChange.class);
            Criteria stallCriteria = stallExample.createCriteria();
            stallCriteria.andEqualTo("idCard", formCode);
            StallChange stallChange = stallChangeMapper.selectOneByExample(stallExample);
            if (!ObjectUtils.isEmpty(stallChange)) {
                stallChange.setStatus(status);
                stallChangeMapper.updateByExampleSelective(stallChange, stallExample);
            }
        } else if (type.equals("foodQualifiction")) {
            /**
             * 食材資質申請
             */
            Example foodQualifictionExample = new Example(FoodQualifiction.class);
            Criteria foodQualifictionCriteria = foodQualifictionExample.createCriteria();
            foodQualifictionCriteria.andEqualTo("idCard", formCode);
            FoodQualifiction foodQualifiction = foodQualifictionMapper.selectOneByExample(foodQualifictionExample);
            if (!ObjectUtils.isEmpty(foodQualifiction)) {
                foodQualifiction.setStatus(status);
                foodQualifictionMapper.updateByExampleSelective(foodQualifiction, foodQualifictionExample);
            }
        } else if (type.equals("dealer")) {
        	/**
             * 经销商申请
             */
            Example dealerExample = new Example(Dealer.class);
            Criteria fdealerCriteria = dealerExample.createCriteria();
            fdealerCriteria.andEqualTo("idCard", formCode);
            Dealer dealer = dealerMapper.selectOneByExample(dealerExample);
            if (!ObjectUtils.isEmpty(dealer)) {
                dealer.setStatus(status);
                dealerMapper.updateByExampleSelective(dealer, dealerExample);
            }
        }
    }
    
    /**
     * 代理人签核
     * @param uuid //当前本人id（代理人或自己）
     * @param formCode
     * @param sigidea 
     * @return
     */
    private Map<String,Object> agentSignOff(String uuid, String formCode, String sigidea,String userName,String type,String thisOrderNumber){
        
        //判断是否该当前本人签核
       Onesignature oList = onesignatureMapper.selectMinOrderNumByAgen(uuid,formCode,thisOrderNumber);
        Map<String,Object> map = new HashMap<>();
        if (ObjectUtils.isEmpty(oList)) {
            map.put("boolean", false);
            map.put("result", new Result(ResultCode.FAIL, "流程错误"));
            return map;
        }
        if (oList.getSigstatus().equals("Y")) {
            map.put("boolean", true);
            map.put("result",  new Result(ResultCode.FAIL, "你已签核，请勿重复签核！"));
            return map;
        }
        if (!oList.getMyselfSign().equals("Y")) {
            map.put("boolean", true);
            map.put("result",  new Result(ResultCode.FAIL, "流程错误"));
            return map;
        }
        SignOff(uuid, formCode, thisOrderNumber, sigidea, userName, false);
        map.put("boolean", true);
        map.put("result", new Result(ResultCode.SUCCESS, "签核成功"));
        
        lastOne(thisOrderNumber, formCode,type);
        return map;
    }
    /**
     * uuid :被加签的人或被会签的人的id /驳回本人的id 本人id
     * 
     */
    @Transactional
    @Override
    public Result insertEndorsement(String uuid, String formCode, String nodeName ,String orderNumber,final String status,String type) {
        //判断当前本人是否签核，签核成功不能再加签，会签，驳回 或作废
        Onesignature thisOnesignature = null;
        if (status.equals("J") || status.equals("H")) {
            Example example = new Example(Onesignature.class);
            Criteria criteria = example.createCriteria();
            criteria.andEqualTo("formCode", formCode);
            criteria.andEqualTo("orderNumber", orderNumber);
            thisOnesignature = onesignatureMapper.selectByExample(example).get(0);
            if (thisOnesignature.getSigstatus().equals("Y") && status.equals("H")) {
                return new Result(ResultCode.FAIL, "错误操作，你已签核，不能加签！");
            } else if (thisOnesignature.getSigstatus().equals("Y") && status.equals("J")) {
                return new Result(ResultCode.FAIL, "错误操作，你已签核，不能会签！");

            }
            
        } else {
            thisOnesignature = onesignatureMapper.selectByUuid(formCode,uuid).get(0);
            if (thisOnesignature.getSigstatus().equals("Y") && status.equals("B")) {
                return new Result(ResultCode.FAIL, "错误操作，你已签核，不能驳回！");
            } else if (thisOnesignature.getSigstatus().equals("Y") && status.equals("Z")) {
                return new Result(ResultCode.FAIL, "错误操作，你已签核，不能作废！");
            }
        }
        if (!thisOnesignature.getMyselfSign().equals("Y")) {
            return new Result(ResultCode.FAIL, "流程错误");
        }
        Example example = new Example(Onesignature.class);
        Criteria criteria = example.createCriteria();
        criteria.andEqualTo("formCode", formCode);
        example.setOrderByClause("ORDER_NUMBER");
        List<Onesignature> onesList = onesignatureMapper.selectByExample(example);
        List<Onesignature> newOneList = null;
        if (status.equals("J")) {
            //nodeName=节点名称   orderNumber=当前节点
            newOneList = endorsement(onesList, orderNumber, nodeName, formCode, uuid);
        } else if (status.equals("H")) {
            //nodeName=节点名称      orderNumber=当前节点
            newOneList = countersign(onesList, orderNumber, nodeName, formCode, uuid);
        } else if (status.equals("B")) {
            //nodeName=签核意见       orderNumber=驳回到某一节
            newOneList = turnDown(onesList,orderNumber,formCode,nodeName,thisOnesignature.getOrderNumber(),type);
        } else {
            //nodeName 签核意见
            newOneList = doWaste(onesList,orderNumber,formCode,nodeName,thisOnesignature.getOrderNumber(),type);
        }
        onesignatureMapper.deleteByFormCode(formCode);
        onesignatureMapper.insertOsg(newOneList);
        return new Result(ResultCode.SUCCESS, "操作成功！");
    }

    /**
     * 作废
     * @param onesList 簽核流程
     * @param orderNumber 
     * @param formCode 表單id
     * @param sigIdea 簽核意見
     * @param thisOrderNumber 作廢人所在的節點
     * @param type 簽核類型
     * @return
     */
    private List<Onesignature> doWaste(List<Onesignature> onesList,String orderNumber ,String formCode,String sigIdea,String thisOrderNumber,String type){
        List<Onesignature> newOneList = new ArrayList<Onesignature>();
        Integer orderNum = Integer.parseInt(thisOrderNumber) - 1;
        for (int i = 0; i < onesList.size(); i++) {
            Onesignature onesignature = onesList.get(i);
            if (i <= orderNum) {
            	//将小于当前节点的签核改为已作废
                onesignature.setSigstatus("Z");
                if ( i == orderNum) {
                	//设置当前节点信息
                    onesignature.setSignTime(Utils.dateFormatStr(new Date(), "yyyy-MM-dd HH:mm:ss"));
                    onesignature.setSigidea(sigIdea);//作废意见
                    onesignature.setRemark("已作废");
                }
            }
            newOneList.add(onesignature);
        }
        changeStatus(type,formCode,"已作废");//将表单状态改为已作废
        return newOneList;
    }
 
    /**
     * 驳回
     * @param onesList 簽核流程
     * @param orderNumber 驳回到某一节点
     * @param formCode 簽核表單id
     * @param sigIdea 駁回意見
     * @param thisOrderNumber 駁回人所在節點
     * @param type 駁回類型
     * @return
     */
    private List<Onesignature> turnDown(List<Onesignature> onesList,String orderNumber ,String formCode,String sigIdea,String thisOrderNumber,String type){
        String time = Utils.dateFormatStr(new Date(), "yyyy-MM-dd HH:mm:ss");
        // 查詢駁回次數
        Integer frequency = onesignatureMapper.countHistoryFrequency(formCode);
        frequency = frequency+1;
        // 將當前簽核流程添加到歷史簽核節點中去
        onesignatureMapper.insertHistoryOnesignature(onesList,frequency);
        // 修改歷史簽核流程表里駁人節點信息
        onesignatureMapper.updateHistoryOnesignature(sigIdea,thisOrderNumber,formCode,frequency,time);
        
        List<Onesignature> newOneList = new ArrayList<Onesignature>();
        Integer orderNum = Integer.parseInt(orderNumber);
        for (int i = 0; i < onesList.size(); i++) {
            Onesignature onesignature = onesList.get(i);
            Integer num = i+1;
            if (num < orderNum) {
            	/**
            	 * 节点小于驳回节点 信息不变
            	 */
                onesignature.setMyselfSign("N");
                newOneList.add(onesignature);
            }  else {
                if (num == orderNum) {
                	/**
                	 * 等于驳回节点 将签核权限交给当前节点 
                	 */
                    onesignature.setMyselfSign("Y");// Y（能签核） N（不能签核）
                } else {
                	
                    onesignature.setMyselfSign("N");
                }
                if (num == Integer.parseInt(thisOrderNumber)) {
                	/**
                	 * 等于当前节点 设置驳回信息
                	 */
                    onesignature.setSigidea(sigIdea);
                    onesignature.setRemark("已驳回！");
                    onesignature.setSignTime(time);
                }
                onesignature.setSigstatus("N");
                newOneList.add(onesignature);
            }
        }
        changeStatus(type,formCode,"已驳回");// 将表单状态改为已驳回
        return newOneList;
    }
    /**
     * 加签
     * @return
     */
    private List<Onesignature> countersign(List<Onesignature> onesList,String orderNumber ,String nodeName,String formCode,String uuid){
        List<Onesignature> newOneList = new ArrayList<Onesignature>();
        Integer orderNum = Integer.parseInt(orderNumber);
        for (int i = 0; i < onesList.size(); i++) {
            Onesignature o = onesList.get(i);
            Integer num = i+1;
            if (num < orderNum) {
            	/**
            	 * 小于当期节点不变
            	 */
                newOneList.add(o);
            } else if (num == orderNum) {
            	/**
            	 * 等于当前节点
            	 */
                Integer newNum = orderNum + 1;
                
                Onesignature newO = new Onesignature();//创建加签的节点
                newO.setOnesigId(UUID.randomUUID().toString().replaceAll("-",""));
                newO.setUuid(uuid);
                newO.setFormCode(formCode);
                newO.setOrderNumber(newNum.toString());
                newO.setNodeName(nodeName);
                newO.setSigstatus("N");
                newO.setMyselfSign("N");
                newOneList.add(newO);//加入流程
                o.setOrderNumber(orderNum.toString());
                newOneList.add(o);//节点顺序不变
            } else {
            	/**
            	 * 大于当前节点  节点顺序往后挪一位
            	 */
                Integer newNum = num+1;
                o.setOrderNumber(newNum.toString());
                newOneList.add(o);
            }
        }
        return newOneList;
    }

    /**
     * 会签
     * onesList 签核流程 （按照节点小到大顺序排序）
     * orderNumber 当前节点
     * orderName 节点名称
     */
    private List<Onesignature> endorsement(List<Onesignature> onesList,String orderNumber ,String nodeName,String formCode,String uuid){
        List<Onesignature> newOneList = new ArrayList<Onesignature>();
        Integer orderNum = Integer.parseInt(orderNumber);
        //遍历签核流程
        for (int i = 0; i < onesList.size(); i++) {
            Onesignature o = onesList.get(i);//节点信息
            Integer num = i+1;
            if (num < orderNum) {
            	/**
            	 * 小于当前节点不变
            	 */
                newOneList.add(o);
            } else if (num == orderNum) {
            	/**
            	 * 等于当前节点
            	 */
                Onesignature newO = new Onesignature();//创建会签节点
                newO.setOnesigId(UUID.randomUUID().toString().replaceAll("-",""));
                newO.setUuid(uuid);
                newO.setFormCode(formCode);
                newO.setOrderNumber(orderNum.toString());
                newO.setNodeName(nodeName);
                newO.setSigstatus("N");
                newO.setMyselfSign("Y");//将能否签核权限交给新建节点
                newOneList.add(newO);
                Integer newNum = num + 1;//当前节点往后挪一位
                o.setOrderNumber(newNum.toString());
                o.setMyselfSign("N");
                newOneList.add(o);
            } else {
            	/**
            	 * 大于当前节点往后挪一位
            	 */
                Integer newNum = num+1;
                o.setOrderNumber(newNum.toString());
                newOneList.add(o);
            }
        }
        
        return newOneList;
    }

    /**
     * 分页查询
     */
    @Override
    public Map<String,Object> findSignOffByUuid(String uuid,Integer start, Integer length) {
        Map<String,Object> map = new HashMap<>();
        List<String> list = null;
        if (ObjectUtils.isNotEmpty(start) && ObjectUtils.isNotEmpty(length)) {
            PageHelper.startPage(start, length);
        }
        list = onesignatureMapper.findSignOffByUuid(uuid,"N");
        PageInfo<String> info = new PageInfo<String>(list);
        List<String> strList = info.getList();
        if (strList.size() == 0) {
            map.put("total", 0);
            map.put("value", strList);
            return  map;
        }
        List<SignOffInfo> signOffList = onesignatureMapper.getSignOff(strList);
        List<String> thisList = onesignatureMapper.findSignOffByUuid(uuid,"N");
        map.put("total", thisList.size());
        map.put("value", signOffList);
        return  map;
    }

    @Override
    public List<Map<String, Object>> findSignOffByFormCode(String formCode) {
        
        List<Map<String, Object>> oList = onesignatureMapper.findSignOffByFormCode(formCode);
        return oList;
    }
    @Override
    public Result historyOnesignature(String formCode) {
        
        List<Map<String, Object>> oList = onesignatureMapper.listHistoryOnesignature(formCode);
        Map<String,List<Map<String, Object>>> dataMap = new LinkedHashMap<>();
        for (Map<String, Object> map : oList) {
            String frequency =  map.get("FREQUENCY").toString();
            List<Map<String, Object>> list = dataMap.get(frequency);
            if (ObjectUtils.isEmpty(list)) {
                list = new ArrayList<Map<String, Object>>();
                dataMap.put(frequency, list);
            }
            list.add(map);
        }
        
        Result result = new Result(ResultCode.SUCCESS, dataMap.values());
        return result;
    }
    
    @Override
    public Map<String, Object> newEndAllSignOff(EndSignInfo endSignInfo, Integer start, Integer length) {
        Map<String,Object> map = new HashMap<>();
        List<String> list = null;
        if (ObjectUtils.isNotEmpty(start) && ObjectUtils.isNotEmpty(length)) {
            PageHelper.startPage(start, length);
        }
        list = onesignatureMapper.findFormCodeSignOffByUuid(endSignInfo);
        PageInfo<String> info = new PageInfo<String>(list);
        List<String> strList = info.getList();
        if (strList.size() == 0) {
            map.put("total", 0);
            map.put("value", strList);
            return  map;
        }
        List<Archive> aList = onesignatureMapper.getSignOffByFormCode(strList);
        Integer thisSize = onesignatureMapper.findSignOffByUuidSize(endSignInfo);
        map.put("total", thisSize);
        map.put("value", aList);
        return map;
    }
    @Override
    public List<Archive> getNewAllSignOff(EndSignInfo endSignInfo) {
        List<Archive> thisList = onesignatureMapper.getAllSignOffByUuid(endSignInfo);
        /**
         * 获取所有节点签核人签核信息  
         */
        List<Map<String,String>> oList = onesignatureMapper.selectAllUser();

      
        Map<String,String> userNameMap = new HashMap<>();
        for (Map<String, String> map : oList) {
            String userName = map.get("USER_NAME");
            String formCode = map.get("FORM_CODE");
            String sigstatus = map.get("SIGSTATUS");
            String myselfSign = map.get("MYSELF_SIGN");
            if (sigstatus.equals("N") && myselfSign.equals("Y")) {
                userNameMap.put(formCode, userName);
            }
        }
        for (Archive a : thisList) {
            String endover = a.getOverend();
            String checktotalId = a.getChecktotalId();
            if (endover.equals("签核中")) {
                a.setUserName((String) userNameMap.get(checktotalId));
            } else {
                a.setUserName(endover);
            }
        }
        return thisList;
    }


    /**
     * 查询总的待签核数据
     */
    @Override
    public Map<String, Object> findSignOffAll(String uuid) {
        List<String> thisList = onesignatureMapper.findSignOffByUuid(uuid,"N");// 稽核待签表单
        List<Map<String,Object>> stallList = stallChangeMapper.selectPagination(uuid);// 档口待签表单
        
        List<Map<String,Object>> foodList = foodQualifictionMapper.selectPagination(uuid);// 食材资质申请待签表单
        //经销商数据
        List<Map<String,Object>> dealerList = dealerMapper.selectPagination(uuid);// 经销商待签表单
        Map<String,Object> map = new HashMap<>();
        map.put("total", thisList.size() + stallList.size() + foodList.size() + dealerList.size());
        return map;
    }

	@Override
	public Map<String, Object> selectStallChangeFile(String uuid, String startDate, String endDate,
			String catererName, String restaurantLocation, String applicationType, String status,String length,String start) {
		List<Map<String,Object>> strlist = null;
		strlist = onesignatureMapper.ListStallChangeFile(uuid,startDate,endDate,catererName,restaurantLocation,status,applicationType);
		if (StringUtils.isEmpty(length) || StringUtils.isEmpty(start)) {
			Map<String,Object> pageMap = new HashMap<>();
            pageMap.put("total", strlist.size());
            pageMap.put("value",strlist );
			return pageMap;
		}
		return fakerPage(length,start,strlist);// 假分页处理
	}

	/**
	 * 假分页
	 * @param length 每页长度
	 * @param start 开始页码
	 * @param strlist 分页的数据
	 * @return
	 */
    private Map<String, Object> fakerPage(String length,String start,List<Map<String,Object>> strlist){
		if (strlist.size() == 0) {
        	Map<String,Object> pageMap = new HashMap<>();
            pageMap.put("total", strlist.size());
            pageMap.put("value",strlist );
        	return pageMap;
        }
		Integer page = Integer.parseInt(start); //頁碼
        Integer size = Integer.parseInt(length); //每頁大小
        List<Object> list = new ArrayList<>(strlist);
        Map<String,Object> pageMap = new HashMap<>();
        List<Object> subList = Utils.fakePagination(list,page,size);
        pageMap.put("total", strlist.size());
        if (subList.get(0).equals("页码超出")) {
        	 pageMap.put("value", "页码超出");
        } else {
        	 pageMap.put("value", subList);
        }
		return pageMap;
    }
	
	/**
	 * {@link com.foxconn.service.OnesignatureService#selectDealerFile}
	 */
	@Override
	public Map<String, Object> selectDealerFile(String uuid, String startDate, String endDate,
			String catererName, String dealer, String status, String length, String start) {
		// TODO Auto-generated method stub
		List<Map<String,Object>> strlist = onesignatureMapper.ListDealerFile(uuid,startDate,endDate,catererName,dealer,status);
		if (StringUtils.isEmpty(length) || StringUtils.isEmpty(start)) {
			Map<String,Object> pageMap = new HashMap<>();
            pageMap.put("total", strlist.size());
            pageMap.put("value",strlist );
			return pageMap;
		}
		return fakerPage(length,start,strlist);
	}

	/**
	 * {@link com.foxconn.service.OnesignatureService#selectFoodQualifictionFile}
	 */
	@Override
	public Map<String, Object> selectFoodQualifictionFile(String uuid, String startDate, String endDate,
			String catererName, String brand, String productName, String status, String length, String start) {
		// TODO Auto-generated method stub
		List<Map<String,Object>> strlist = onesignatureMapper.ListFoodQualifictionFile(uuid,startDate,endDate,catererName,brand,productName,status);
		if (StringUtils.isEmpty(length) || StringUtils.isEmpty(start)) {
			Map<String,Object> pageMap = new HashMap<>();
            pageMap.put("total", strlist.size());
            pageMap.put("value",strlist );
			return pageMap;
		}
		return fakerPage(length,start,strlist);
	}

	/**
	 * 流式读取
	 */
//    @Override
//    public void ioReader(ExcelWriter excelWriter, WriteSheet writeSheet) {
//        // TODO Auto-generated method stub
//        onesignatureMapper.ioReader(resultContext -> {
//            Onesignature vo = resultContext.getResultObject();
//            try{
//                List<Onesignature> list = new ArrayList<>();
//                list.add(vo);
//                excelWriter.write(list, writeSheet);
//            }catch (Exception e){
//                e.printStackTrace();
//            }
//        });
//    }
//	
	/**
	 * {@link com.foxconn.service.OnesignatureService#getFormStatus}
	 */
	@Override
	public String getFormStatus(String formCode, String formType) {
		// TODO Auto-generated method stub
		 if (ObjectUtils.isEmpty(formType)) {
	          
	        } else if (formType.equals("stall")) {
	            /**
	             * 檔口變更申請
	             */
	            Example stallExample = new Example(StallChange.class);
	            Criteria stallCriteria = stallExample.createCriteria();
	            stallCriteria.andEqualTo("idCard", formCode);
	            StallChange stallChange = stallChangeMapper.selectOneByExample(stallExample);
	            if (!ObjectUtils.isEmpty(stallChange)) {
	            	 return stallChange.getStatus();
	            }
	        } else if (formType.equals("foodQualifiction")) {
	            /**
	             * 食材資質申請
	             */
	            Example foodQualifictionExample = new Example(FoodQualifiction.class);
	            Criteria foodQualifictionCriteria = foodQualifictionExample.createCriteria();
	            foodQualifictionCriteria.andEqualTo("idCard", formCode);
	            FoodQualifiction foodQualifiction = foodQualifictionMapper.selectOneByExample(foodQualifictionExample);
	            if (!ObjectUtils.isEmpty(foodQualifiction)) {
	                return foodQualifiction.getStatus();
	            }
	        } else if (formType.equals("dealer")) {
	        	/**
	             * 经销商申请
	             */
	            Example dealerExample = new Example(Dealer.class);
	            Criteria fdealerCriteria = dealerExample.createCriteria();
	            fdealerCriteria.andEqualTo("idCard", formCode);
	            Dealer dealer = dealerMapper.selectOneByExample(dealerExample);
	            if (!ObjectUtils.isEmpty(dealer)) {
	            	return dealer.getStatus();
	            }
	        }
		 return " ";
	}
}
