package com.foxconn.entity;

import java.util.Date;

/**
 * 歷史簽核節點
 * @author C3414208
 *
 */
public class HistoryOnesignature extends Onesignature{

    /**
     * 
     */
    private static final long serialVersionUID = 5675941229683290206L;
    private Integer frequency;// 駁回頻率
    private Date writeTime;// 寫入時間
    public Integer getFrequency() {
        return frequency;
    }
    public void setFrequency(Integer frequency) {
        this.frequency = frequency;
    }
    public Date getWriteTime() {
        return writeTime;
    }
    public void setWriteTime(Date writeTime) {
        this.writeTime = writeTime;
    }

    
    
}
