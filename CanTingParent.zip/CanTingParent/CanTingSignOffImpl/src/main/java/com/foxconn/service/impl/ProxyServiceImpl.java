package com.foxconn.service.impl;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.entity.Proxy;
import com.foxconn.entity.UserEntity;
import com.foxconn.mapper.OnesignatureMapper;
import com.foxconn.mapper.ProxyMapper;
import com.foxconn.mapper.UserEntityMapper;
import com.foxconn.service.ProxyService;

import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;

/**
 * 代理人
 * @author C3414208
 *
 */
@Service
public class ProxyServiceImpl implements ProxyService{

    @Autowired
    private UserEntityMapper userEntityMapper;
    @Autowired
    private ProxyMapper proxyMapper;
    @Autowired
    private OnesignatureMapper onesignatureMapper;
    public UserEntity getProxy(String proxyCardNum) {
        Example example = new Example(UserEntity.class);
        Criteria criteria = example.createCriteria();
        criteria.andEqualTo("cardNum", proxyCardNum);
        UserEntity user = userEntityMapper.selectOneByExample(example);
        return user;
    }
    public Boolean checkProxyExists(String userId, Date date) {
        Example example = new Example(Proxy.class);
        Criteria criteria = example.createCriteria();
        criteria.andEqualTo("uuid", userId);
        Proxy proxy = proxyMapper.selectOneByExample(example);
        if (proxy == null) {
            return false;
        } else {
            Calendar ca = Calendar.getInstance();
            Date startTime = proxy.getStartTime();
            Date endTime = proxy.getEndTime();
            ca.setTime(startTime);
            Long startLong = ca.getTimeInMillis();
            ca.setTime(endTime);
            Long endLong = ca.getTimeInMillis();
            ca.setTime(date);
            Long dateLong = ca.getTimeInMillis();
            //判断当前时间是否一段时间里面
            if (startLong <= dateLong && endLong >dateLong) {
                return true;
            } 
        }
        return false;
    }
    public void deleteByUserId(String userId) {
        Example example = new Example(Proxy.class);
        Criteria criteria = example.createCriteria();
        criteria.andEqualTo("uuid", userId);
        proxyMapper.deleteByExample(example);
    }
    public UserEntity getUserById(String proxyId) {
        Example example = new Example(Proxy.class);
        Criteria criteria = example.createCriteria();
        criteria.andEqualTo("cardNum", proxyId);
        return userEntityMapper.selectOneByExample(example);
    }
    public void insertSelective(Proxy param) {
        proxyMapper.insertSelective(param);
    }
    public List<Map<String,Object>> getProxyByUuid(String uuid) {
        List<Map<String,Object>> user = proxyMapper.selectByUuid(uuid);
        return user;
    }
    public void toDelProxy(String pid) {
        // TODO Auto-generated method stub
        //刪除代理人表單數據
        Example example = new Example(Proxy.class);
        Criteria criteria = example.createCriteria();
        criteria.andEqualTo("pid", pid);
        Proxy proxy = proxyMapper.selectOneByExample(example);
        proxyMapper.deleteByExample(example);
        
        //刪除簽核表單裡面代理人數據
        String uuid = proxy.getUuid();
        String sigstatus = "N";
        onesignatureMapper.updateOnesignature("",uuid,sigstatus);
    }
    
    public void getProxyInfo(String uuid) {
        Example example = new Example(Proxy.class);
        Criteria criteria = example.createCriteria();
        criteria.andEqualTo("proxyId", uuid);
        List<Proxy> list = proxyMapper.selectByExample(example);
        for (Proxy proxy : list) {
            setProxy(proxy);
        }
    }


    /**
     * 设置代理人
     */
    private void setProxy(Proxy proxy) {
        Calendar ca = Calendar.getInstance();
        Date date = new Date();
        ca.setTime(date);
        Long thisTime = ca.getTimeInMillis();
        Date StratDate = proxy.getStartTime();
        ca.setTime(StratDate);
        Long startTime = ca.getTimeInMillis();
        Date endDate = proxy.getEndTime();
        ca.setTime(endDate);
        Long endTime = ca.getTimeInMillis();
        if (thisTime > startTime && endTime > thisTime) {
            //给签核设定代理人
            String uuid = proxy.getUuid();//当事人
            String proxyId = proxy.getProxyId();//代理人
            String sigstatus = "N";
            onesignatureMapper.updateOnesignature(proxyId,uuid,sigstatus);
        } else {
            //代理时间过期删除代理
            String uuid = proxy.getUuid();
            String proxyId = "";//代理人
            String sigstatus = "N";
            onesignatureMapper.updateOnesignature(proxyId,uuid,sigstatus);
            String pid = proxy.getPid();
            Example pExample = new Example(Proxy.class);
            Criteria pCriteria = pExample.createCriteria();
            pCriteria.andEqualTo("pid", pid);
            proxyMapper.deleteByExample(pExample);
          
        }
    }
}
