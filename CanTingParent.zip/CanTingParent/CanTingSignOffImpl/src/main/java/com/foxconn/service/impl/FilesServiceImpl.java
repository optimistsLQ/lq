package com.foxconn.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.entity.Files;
import com.foxconn.entity.Result;
import com.foxconn.entity.ResultCode;
import com.foxconn.mapper.FilesMapper;
import com.foxconn.service.FilesService;
import com.foxconn.utils.Utils;

import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;
@Service
public class FilesServiceImpl implements FilesService{

    @Autowired
    private FilesMapper filesMapper;
    
    @Override
    public Result insertFile(Files files) {
        // TODO Auto-generated method stub
        Integer i = filesMapper.insertSelective(files);
        if (i != 0) {
            String foreignKey = files.getForeignKey();
            String fileName = files.getFileName();
            Example newExample = new Example(Files.class);
            Criteria newCriteria = newExample.createCriteria();
            newCriteria.andEqualTo("foreignKey", foreignKey);
            newCriteria.andEqualTo("fileName", fileName);
            
            Files file = filesMapper.selectOneByExample(newExample);
            String fid = file.getFid();
            Map<String,String> map = new HashMap<String, String>();
            map.put("fileName",fileName);
            map.put("fid", fid);
            return new Result(ResultCode.SUCCESS,map);
        } else {
            return new Result(ResultCode.FAIL,"上传失败");
        }
        
    }
    @Override
    public Files findFile(String fid) {
        // TODO Auto-generated method stub
        Example newExample = new Example(Files.class);
        Criteria newCriteria = newExample.createCriteria();
        newCriteria.andEqualTo("fid", fid);
        return filesMapper.selectOneByExample(newExample);
    }
    @Override
    public List<Map<String, String>> findFiles(String formCode) {
        // TODO Auto-generated method stub
        Example newExample = new Example(Files.class);
        Criteria newCriteria = newExample.createCriteria();
        newCriteria.andEqualTo("foreignKey", formCode);
        newExample.setOrderByClause("WRITE_TIME");
        List<Files> filesList = filesMapper.selectByExample(newExample);
        List<Map<String,String>> list = new ArrayList<Map<String,String>>();
        for (Files files : filesList) {
            Map<String,String> map = new HashMap<String, String>();
            map.put("fileName", files.getFileName());
            map.put("fid", files.getFid());
            list.add(map);
        }
        return list;
    }
    @Override
    public Result deleteFiles(String fid) {
        // TODO Auto-generated method stub
        if (StringUtils.isEmpty(fid)) {
            return new Result(ResultCode.FAIL);
        }
        
        Example newExample = new Example(Files.class);
        Criteria newCriteria = newExample.createCriteria();
        newCriteria.andEqualTo("fid", fid);
        int i = filesMapper.deleteByExample(newExample);
        if (i != 0) {
            return new Result(ResultCode.SUCCESS);
        }
        return new Result(ResultCode.FAIL);
    }
	@Override
	public List<byte[]> ListFiles(String formCode) {

		// TODO Auto-generated method stub
        Example newExample = new Example(Files.class);
        Criteria newCriteria = newExample.createCriteria();
        newCriteria.andEqualTo("foreignKey", formCode);
        
        List<Files> list = filesMapper.selectByExample(newExample);
        List<byte[]> byteList = new ArrayList<>();
        for (Files files : list) {
        	String name = files.getFileName();
        	if (name.contains(".PDF") || name.contains(".pdf")) {
        		byteList.add(Utils.waterMarkStream(files.getEntity(), "已審核"));
        	}
		}
		return byteList;
	}

}
