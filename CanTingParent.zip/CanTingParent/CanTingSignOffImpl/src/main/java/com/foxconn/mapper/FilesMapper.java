package com.foxconn.mapper;

import com.foxconn.entity.Files;

import tk.mybatis.mapper.common.Mapper;

  
public interface FilesMapper extends Mapper<Files>{

}
