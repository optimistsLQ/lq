package com.foxconn.service.impl;


import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.entity.Result;
import com.foxconn.entity.ResultCode;
import com.foxconn.entity.Signature;
import com.foxconn.entity.Totalsignature;
import com.foxconn.mapper.SignatureMapper;
import com.foxconn.mapper.TotalsignatureMapper;
import com.foxconn.service.TotalSignatureService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

@Service
public class TotalSignatureServiceImple implements TotalSignatureService {

	@Autowired
	private TotalsignatureMapper tolSigMapper;
	@Autowired
    private SignatureMapper sinMapper;
	
	@Override
	public int insertTolSig(Totalsignature sig) {
		// TODO Auto-generated method stub
		return tolSigMapper.insertSelective(sig);
	}
    @Override
    public PageInfo<Totalsignature> findAll(String signatureName, Integer start, Integer length) {
        List<Totalsignature> userList = null;
        if (signatureName == null) {
            if (ObjectUtils.isNotEmpty(start) && ObjectUtils.isNotEmpty(length)) {
                PageHelper.startPage(start, length);
            }
            userList =  tolSigMapper.findAll();
        } else {
            if (ObjectUtils.isNotEmpty(start) && ObjectUtils.isNotEmpty(length)) {
                PageHelper.startPage(start, length);
            }
            userList = tolSigMapper.findByExample(signatureName);
        }
        PageInfo<Totalsignature> info = new PageInfo<Totalsignature>(userList);
        return info;
    }
    /**
     * 修改狀態
     */
    @Override
    public Result updateSignatureLock(String tolsigId, Integer lockStatus) {
        // TODO Auto-generated method stub
       
        Totalsignature t = new Totalsignature();
        t.setTolsigId(tolsigId);
        t.setStatus(lockStatus.toString());
        if ( tolSigMapper.updateByPrimaryKeySelective(t) > 0) {
            return new Result(ResultCode.SUCCESS);
        }
        return new Result(ResultCode.FAIL);
    }
    /**
     * 刪除
     */
    @Override
    public Result deleteTolsig(List<String> tolsigId) {
        for (String string : tolsigId) {
            Totalsignature t = new Totalsignature();
            t.setTolsigId(string);
            Signature s = new Signature();
            s.setTolsigId(string);
            tolSigMapper.delete(t);
            sinMapper.delete(s);
        }
        return new Result(ResultCode.SUCCESS);
    }
    @Override
    public List<Map<String,String>> getTotalsignature() {
       
         return tolSigMapper.getTotalsignature();
        
    }


}
