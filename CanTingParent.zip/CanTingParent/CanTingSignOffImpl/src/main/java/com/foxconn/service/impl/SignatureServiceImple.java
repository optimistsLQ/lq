package com.foxconn.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.entity.Signature;
import com.foxconn.mapper.SignatureMapper;
import com.foxconn.service.SignatureService;

import tk.mybatis.mapper.entity.Example;
@Service
public class SignatureServiceImple implements SignatureService {

	@Autowired
	private SignatureMapper sinMapper;

    @Override
    public List<Signature> findAllByTolsigId(String tolsigId) {
        // TODO Auto-generated method stub
        Example example = new Example(Signature.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andLike("tolsigId", tolsigId);
        Signature s = new Signature();
        s.setTolsigId(tolsigId);
        return  sinMapper.select(s);
    }

    @Override
    public void delByTolSigId(String tolsigId) {
        // TODO Auto-generated method stub
        Example example = new Example(Signature.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("tolsigId", tolsigId);
        sinMapper.deleteByExample(example);
    }

    @Override
    public void insertSig(Signature signature) {
        // TODO Auto-generated method stub
        sinMapper.insertSelective(signature);
    }

    @Override
    public List<Map<String,Object>> findSig(String tolsigId) {
        // TODO Auto-generated method stub
        
        return sinMapper.selectByTolsigId(tolsigId);
    }

    @Override
    public List<Map<String, Object>> findByTolsigId(String tolsigId) {
        // TODO Auto-generated method stub
        List<Map<String, Object>> list = sinMapper.selectByTolsigId(tolsigId);
        Map <String,Map<String,Object>> mapInfo = new LinkedHashMap<>();
        for (Map<String, Object> map : list) {
            String orderNumber = null;
            if (map.get("ORDER_NUMBER") == null) {
                orderNumber = (String) map.get("ORDER_NUMBER");
            } else {
                orderNumber = map.get("ORDER_NUMBER").toString();
            }
            String candidate =(String) map.get("CANDIDATE");
            String nodeName = map.get("NODE_NAME").toString();
            String uuid = map.get("UUID").toString();
            String userName = map.get("USER_NAME").toString();
            if (candidate == null) {
               Map<String,Object> newMap = new HashMap<>();
               List<Map<String,String>> mapList = new ArrayList<>();
               Map<String,String> sMap = new HashMap<>();
               newMap.put("nodeName", nodeName);
               newMap.put("orderNumber", orderNumber);
               sMap.put("userName", userName);
               sMap.put("uuid", uuid);
               mapList.add(sMap);
               newMap.put("nameList", mapList);
               mapInfo.put(orderNumber, newMap);
            } else {
               Map<String,Object> newMap = mapInfo.get(candidate);
               List<Map<String,String>> mapList = (List<Map<String, String>>) newMap.get("nameList");
               Map<String,String> sMap = new HashMap<>();
               sMap.put("userName", userName);
               sMap.put("uuid", uuid);
               mapList.add(sMap);
               newMap.put("nameList", mapList);
               mapInfo.put(candidate, newMap);
            }
        }
        List<Map<String,Object>> newList = new ArrayList<>();
        mapInfo.forEach((k,v)->{
            newList.add(v);
        });
        return newList;
    }


}
