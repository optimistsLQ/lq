package com.foxconn.mapper;


import java.util.List;
import java.util.Map;

import com.foxconn.entity.Totalsignature;

import tk.mybatis.mapper.common.Mapper;

public interface TotalsignatureMapper extends Mapper<Totalsignature>{

    List<Totalsignature> findByExample(String signatureName);

    List<Totalsignature> findAll();

    List<Map<String,String>> getTotalsignature();
   
}