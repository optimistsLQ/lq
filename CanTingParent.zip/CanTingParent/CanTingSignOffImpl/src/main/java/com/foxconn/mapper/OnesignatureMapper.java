package com.foxconn.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.cursor.Cursor;
import org.apache.ibatis.session.ResultHandler;

import com.foxconn.entity.Archive;
import com.foxconn.entity.EndSignInfo;
import com.foxconn.entity.Onesignature;
import com.foxconn.entity.SignOffInfo;

import tk.mybatis.mapper.common.Mapper;

public interface OnesignatureMapper extends Mapper<Onesignature>{

    List<Map<String,String>> getTotalsignature();
    /**
     * 创建当前表单签核流程
     */
    Integer insertOnesignature(@Param("tList")List<Map<String, Object>> list);

    /**
     * 获取当前表单签核流程
     * @param uuid
     * @param formCode
     * @return
     */
    List<Onesignature> selectMinOrderNumByExample(@Param("uuid")String uuid, @Param("formCode")String formCode);
    List<Onesignature> selectMinOrderNumByProxyId(@Param("uuid")String uuid, @Param("formCode")String formCode);   
    /**
     * 关联查询待签表单信息
     * @param uuid
     * @param sigstatus
     */
    List<String> findSignOffByUuid(@Param("uuid")String uuid,@Param("sigstatus")String sigstatus);

    Integer insertOsg(@Param("tList")List<Onesignature> newOneList);

    /**
     * 关联查询签核流程
     * @param formCode
     * @return
     */
    List<Map<String, Object>> findSignOffByFormCode(String formCode);

    /**
     * 获取代理人签核的数据
     * @param uuid
     * @param formCode
     * @return
     */
    Onesignature selectMinOrderNumByAgen(@Param("uuid")String uuid, @Param("formCode")String formCode,@Param("orderNumber")String orderNumber);
    /**
     * 删除当前表单单号下所有数据
     * @param formCode
     * @return
     */
    Integer deleteByFormCode(String formCode);
    
    List<SignOffInfo> getSignOff(@Param("strList")List<String> strList);

    /**
     * 根据条件关联查询归档类的数据
     * @param archive
     * @return
     */
    List<Archive> getAllSignOffByUuid(@Param("obj")EndSignInfo archive);

    /**
     * 添加代理人id
     * @param proxyId 代理人id
     * @param uuid   当是人id
     * @param sigstatus 签核状态
     * @return
     */
    Integer updateOnesignature(@Param("proxyId")String proxyId, @Param("uuid")String uuid, @Param("sigstatus")String sigstatus);
    
    List<Onesignature> selectByUuid(@Param("formCode")String formCode,@Param("uuid") String uuid);

    Integer findSignOffByUuidSize(@Param("obj")EndSignInfo endSignInfo);

    List<String> findFormCodeSignOffByUuid(@Param("obj")EndSignInfo endSignInfo);

    List<Archive> getSignOffByFormCode(@Param("strList")List<String> strList);

    
    List<Map<String, String>> selectAllUser();
    
    Archive  selectOnesignatureInfo(@Param("uuid")String uuid ,@Param("formCode")String formCode);
    /**
     * 查询餐厅变动申请单
     */
	List<Map<String,Object>> ListStallChangeFile(@Param("uuid")String uuid, @Param("startDate")String startDate, @Param("endDate")String endDate, 
			@Param("catererName")String catererName,
			@Param("restaurantLocation")String restaurantLocation, @Param("status")String status,@Param("applicationType")String applicationType);

	/** 
	 * 
	 * 经销商申请单
	 * @return
	 */
	List<Map<String, Object>> ListDealerFile(@Param("uuid")String uuid,  @Param("startDate")String startDate, @Param("endDate")String endDate,
			@Param("catererName")String catererName, @Param("dealer")String dealer, @Param("status")String status);
    /**
     * 查询食材资质申请单
     */
	List<Map<String, Object>> ListFoodQualifictionFile(@Param("uuid")String uuid,@Param("startDate") String startDate, @Param("endDate") String endDate,
			@Param("catererName")String catererName,  @Param("brand")String brand,  @Param("productName")String productName,  @Param("status")String status);
	
	/**
	 * 修改签核
	 * @param os
	 * @return
	 */
	Integer updateByOnesignature(@Param("obj")Onesignature os);
	/**
	 * 查询说有信息
	 * @return
	 */
//	void ioReader(ResultHandler<Onesignature> resultHandler);
	/**
	 * 通過表單id 統計歷史簽核的次數
	 * @param formCode
	 * @return
	 */
    Integer countHistoryFrequency(String formCode);
    /**
     * 插入歷史簽核流程數據
     * @param onesList
     * @param frequency
     * @return
     */
    Integer insertHistoryOnesignature(@Param("tList")List<Onesignature> onesList, @Param("frequency")Integer frequency);
    /**
     * 修改歷史簽核流程表 駁回信息
     * @param sigIdea
     * @param thisOrderNumber
     * @param formCode
     * @param frequency
     * @return
     */
    Integer updateHistoryOnesignature(@Param("sigIdea")String sigIdea, @Param("thisOrderNumber")String thisOrderNumber, 
            @Param("formCode")String formCode, @Param("frequency")Integer frequency,@Param("time")String time);
    /**
     * 通過表單id獲取歷史簽核流程
     * @param formCode
     * @return
     */
    List<Map<String, Object>> listHistoryOnesignature(@Param("formCode")String formCode);
 

}
