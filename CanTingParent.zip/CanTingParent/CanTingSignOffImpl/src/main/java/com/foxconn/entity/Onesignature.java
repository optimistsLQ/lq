package com.foxconn.entity;

import java.io.Serializable;

import javax.persistence.Id;
import javax.persistence.Table;
@Table(name = "T_ONESIGNATURE")
public class Onesignature implements Serializable{

    /**
     * 
     */
    @Id
    private static final long serialVersionUID = 9182738400374106017L;
    /**
     * 签核id
     */
    private String onesigId;
    /**
     * 签核节点
     */
    private String orderNumber;
    /**
     * 节点名称
     */
    private String nodeName;
    /**
     * 当前节点签核人id
     */
    private String uuid;
    /**
     * 签核表单id
     */
    private String formCode;
    /**
     * 签核状态
     */
    private String sigstatus;
    /**
     * 签核意见
     */
    private String sigidea;
    /**
     * 签核备注
     */
    private String remark;
    /**
     * 代理人id
     */
    private String proxyId;
    /**
     * 签核权限
     */
    private String myselfSign;
    /**
     * 签核时间
     */
    private String signTime;
    /**
     * 获取签核时间
     * @return
     */
    public String getSignTime() {
        return signTime;
    }
    /**
     * 设置签核时间
     * @param signTime
     */
    public void setSignTime(String signTime) {
        this.signTime = signTime;
    }
    /**
     * 获取签核权限
     */
    public String getMyselfSign() {
        return myselfSign;
    }
    /**
     * 设置签核权限
     * @param myselfSign
     */
    public void setMyselfSign(String myselfSign) {
        this.myselfSign = myselfSign;
    }
    /**
     * 获取签核id
     * @return
     */
    public String getOnesigId() {
        return onesigId;
    }
    /**
     * 设置签核id
     * @param onesigId
     */
    public void setOnesigId(String onesigId) {
        this.onesigId = onesigId;
    }
    /**
     * 获取签核节点顺序
     * @return
     */
    public String getOrderNumber() {
        return orderNumber;
    }
    /**
     * 设置签核节点顺序
     * @param orderNumber
     */
    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }
    /**
     * 获取签核节点名称
     * @return
     */
    public String getNodeName() {
        return nodeName;
    }
    /**
     * 设置签核节点名称
     * @param nodeName
     */
    public void setNodeName(String nodeName) {
        this.nodeName = nodeName;
    }
    /**
     * 获取签核人id
     * @return
     */
    public String getUuid() {
        return uuid;
    }
    /**
     * 设置签核人id
     * @param uuid
     */
    public void setUuid(String uuid) {
        this.uuid = uuid;
    }
    /**
     * 获取表单id
     * @return
     */
    public String getFormCode() {
        return formCode;
    }
    /**
     * 设置表单id
     * @param formCode
     */
    public void setFormCode(String formCode) {
        this.formCode = formCode;
    }
    /**
     * 获取签核状态
     * @return
     */
    public String getSigstatus() {
        return sigstatus;
    }
    /**
     * 设置签核状态
     * @param sigstatus
     */
    public void setSigstatus(String sigstatus) {
        this.sigstatus = sigstatus;
    }
    /**
     * 获取签核意见
     * @return
     */
    public String getSigidea() {
        return sigidea;
    }
    /**
     * 设置签核意见
     * @param sigidea
     */
    public void setSigidea(String sigidea) {
        this.sigidea = sigidea;
    }
    /**
     * 获取签核备注
     * @return
     */
    public String getRemark() {
        return remark;
    }
    /**
     * 设置签核备注
     * @param remark
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }
    /**
     * 获取代理人id
     * @return
     */
    public String getProxyId() {
        return proxyId;
    }
    /**
     * 设置代理人id
     * @param proxyId
     */
    public void setProxyId(String proxyId) {
        this.proxyId = proxyId;
    }
    public static long getSerialversionuid() {
        return serialVersionUID;
    }
    @Override
    public String toString() {
        return "Onesignature [onesigId=" + onesigId + ", orderNumber=" + orderNumber + ", nodeName=" + nodeName
                + ", uuid=" + uuid + ", formCode=" + formCode + ", sigstatus=" + sigstatus + ", sigidea=" + sigidea
                + ", remark=" + remark + ", proxyId=" + proxyId + ", myselfSign=" + myselfSign + ", signTime="
                + signTime + "]";
    }
    
}
