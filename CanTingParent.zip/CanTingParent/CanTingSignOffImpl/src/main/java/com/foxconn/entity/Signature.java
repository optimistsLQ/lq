package com.foxconn.entity;

import java.io.Serializable;

import javax.persistence.Table;

import javax.persistence.Id;
@Table(name = "T_SIGNATURE")
public class Signature implements Serializable{

    /**
     * 
     */
    private static final long serialVersionUID = 2069770796195709436L;
    @Id
    private String sigId;
    private Integer orderNumber;
    private String nodeName;
    private String uuid;
    private String tolsigId;
    private String candidate;
    private String remark;
    public String getSigId() {
        return sigId;
    }
    public void setSigId(String sigId) {
        this.sigId = sigId == null ? null : sigId.trim();
    }
    public Integer getOrderNumber() {
        return orderNumber;
    }
    public void setOrderNumber(Integer orderNumber) {
        this.orderNumber = orderNumber;
    }
    public String getNodeName() {
        return nodeName;
    }
    public void setNodeName(String nodeName) {
        this.nodeName = nodeName == null ? null : nodeName.trim();
    }
    public String getUuid() {
        return uuid;
    }
    public void setUuid(String uuid) {
        this.uuid = uuid == null ? null : uuid.trim();
    }
    public String getTolsigId() {
        return tolsigId;
    }
    public void setTolsigId(String tolsigId) {
        this.tolsigId = tolsigId == null ? null : tolsigId.trim();
    }
    public String getCandidate() {
        return candidate;
    }
    public void setCandidate(String candidate) {
        this.candidate = candidate == null ? null : candidate.trim();
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }
    public static long getSerialversionuid() {
        return serialVersionUID;
    }
    @Override
    public String toString() {
        return "Signature [sigId=" + sigId + ", orderNumber=" + orderNumber + ", nodeName=" + nodeName + ", uuid="
                + uuid + ", tolsigId=" + tolsigId + ", candidate=" + candidate + ", remark=" + remark + "]";
    }
    
    
    
}
