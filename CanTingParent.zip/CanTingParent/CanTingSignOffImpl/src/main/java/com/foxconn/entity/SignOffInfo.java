package com.foxconn.entity;

import java.util.List;

public class SignOffInfo {

    private String onesigId;
    private String formCode;
    private String mealSeller;
    private String filed;
    private String checktime;
    private String checkPoint;
    private List<CheckPeople> cheeckMannames;
    private String restaurantLocation;
    private String restaturantId;//
    private String overend;
    
    public List<CheckPeople> getCheeckMannames() {
        return cheeckMannames;
    }
    public void setCheeckMannames(List<CheckPeople> cheeckMannames) {
        this.cheeckMannames = cheeckMannames;
    }
    public String getOverend() {
        return overend;
    }
    public void setOverend(String overend) {
        this.overend = overend;
    }
    public String getOnesigId() {
        return onesigId;
    }
    public void setOnesigId(String onesigId) {
        this.onesigId = onesigId;
    }
    public String getFormCode() {
        return formCode;
    }
    public void setFormCode(String formCode) {
        this.formCode = formCode;
    }
    public String getMealSeller() {
        return mealSeller;
    }
    public void setMealSeller(String mealSeller) {
        this.mealSeller = mealSeller;
    }
    public String getFiled() {
        return filed;
    }
    public void setFiled(String filed) {
        this.filed = filed;
    }
    public String getChecktime() {
        return checktime;
    }
    public void setChecktime(String checktime) {
        this.checktime = checktime;
    }
    public String getCheckPoint() {
        return checkPoint;
    }
    public void setCheckPoint(String checkPoint) {
        this.checkPoint = checkPoint;
    }
    public List<CheckPeople> getCheeckManname() {
        return cheeckMannames;
    }
    public void setCheeckManname(List<CheckPeople> cheeckMannames) {
        this.cheeckMannames = cheeckMannames;
    }
    public String getRestaurantLocation() {
        return restaurantLocation;
    }
    public void setRestaurantLocation(String restaurantLocation) {
        this.restaurantLocation = restaurantLocation;
    }
    public String getRestaturantId() {
        return restaturantId;
    }
    public void setRestaturantId(String restaturantId) {
        this.restaturantId = restaturantId;
    }
    @Override
    public String toString() {
        return "SignOffInfo [onesigId=" + onesigId + ", formCode=" + formCode + ", mealSeller=" + mealSeller
                + ", filed=" + filed + ", checktime=" + checktime + ", checkPoint=" + checkPoint + ", cheeckMannames="
                + cheeckMannames + ", restaurantLocation=" + restaurantLocation + ", restaturantId=" + restaturantId
                + ", overend=" + overend + "]";
    }
}
