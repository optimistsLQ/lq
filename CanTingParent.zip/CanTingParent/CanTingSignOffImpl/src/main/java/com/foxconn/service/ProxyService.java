package com.foxconn.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.foxconn.entity.Proxy;
import com.foxconn.entity.UserEntity;

public interface ProxyService {

    public UserEntity getProxy(String proxyCardNum);
    
    public Boolean checkProxyExists(String userId, Date date);
    
    public void deleteByUserId(String userId);
    
    public UserEntity getUserById(String proxyId);
    
    public void insertSelective(Proxy param);
    
    public List<Map<String,Object>> getProxyByUuid(String uuid);
    
    public void toDelProxy(String pid);
    
    public void getProxyInfo(String uuid);
    
}
