package com.foxconn.service;

import java.util.List;
import java.util.Map;

import com.foxconn.entity.Files;
import com.foxconn.entity.Result;

public interface FilesService {

    Result insertFile(Files files);

    Files findFile( String fid);

    List<Map<String,String>> findFiles(String formCode);

    Result deleteFiles(String fid);

    /**
     * 根據表單id獲取文件
     * @param formCode
     * @return
     */
	List<byte[]> ListFiles(String formCode);
    

}
