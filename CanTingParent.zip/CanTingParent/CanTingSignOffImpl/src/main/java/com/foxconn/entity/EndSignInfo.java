package com.foxconn.entity;

import java.io.Serializable;

public class EndSignInfo implements Serializable{

    /**
     * 
     */
    private static final long serialVersionUID = -7076897752963998396L;
    private String uuid;
    private String firstTime;
    private String endTime;
    private String restaurantLocation;
    private String mealSeller;
    private String grade;
    private String checkPoint;
    private String standRemark;
    private String overEnd;
    public String getUuid() {
        return uuid;
    }
    public void setUuid(String uuid) {
        this.uuid = uuid;
    }
    public String getFirstTime() {
        return firstTime;
    }
    public void setFirstTime(String firstTime) {
        this.firstTime = firstTime;
    }
    public String getEndTime() {
        return endTime;
    }
    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }
    public String getRestaurantLocation() {
        return restaurantLocation;
    }
    public void setRestaurantLocation(String restaurantLocation) {
        this.restaurantLocation = restaurantLocation;
    }
    public String getMealSeller() {
        return mealSeller;
    }
    public void setMealSeller(String mealSeller) {
        this.mealSeller = mealSeller;
    }
    public String getGrade() {
        return grade;
    }
    public void setGrade(String grade) {
        this.grade = grade;
    }
    public String getCheckPoint() {
        return checkPoint;
    }
    public void setCheckPoint(String checkPoint) {
        this.checkPoint = checkPoint;
    }
    public String getStandRemark() {
        return standRemark;
    }
    public void setStandRemark(String standRemark) {
        this.standRemark = standRemark;
    }
    public String getOverEnd() {
        return overEnd;
    }
    public void setOverEnd(String overEnd) {
        this.overEnd = overEnd;
    }
    @Override
    public String toString() {
        return "EndSignInfo [uuid=" + uuid + ", firstTime=" + firstTime + ", endTime=" + endTime
                + ", restaurantLocation=" + restaurantLocation + ", mealSeller=" + mealSeller + ", grade=" + grade
                + ", checkPoint=" + checkPoint + ", standRemark=" + standRemark + ", overEnd=" + overEnd + "]";
    }
    
}
