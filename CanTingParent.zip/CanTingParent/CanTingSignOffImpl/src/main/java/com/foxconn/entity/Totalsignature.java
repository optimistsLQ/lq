package com.foxconn.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Table;

import javax.persistence.Id;

@Table(name = "T_TOTALSIGNATURE")
public class Totalsignature implements Serializable{
    /**
     * 
     */
    private static final long serialVersionUID = -4815892318774188332L;

    @Id
    private String tolsigId;
    private String signatureName;
    private Date createtime;
    private String uuid;
    private String status;
    private String remark;
    public String getTolsigId() {
        return tolsigId;
    }
    public void setTolsigId(String tolsigId) {
        this.tolsigId = tolsigId == null ? null : tolsigId.trim();
    }
    public String getSignatureName() {
        return signatureName;
    }
    public void setSignatureName(String signatureName) {
        this.signatureName = signatureName == null ? null : signatureName.trim();
    }
    public Date getCreatetime() {
        return createtime;
    }
    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }
    public String getUuid() {
        return uuid;
    }
    public void setUuid(String uuid) {
        this.uuid = uuid == null ? null : uuid.trim();
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }
    public static long getSerialversionuid() {
        return serialVersionUID;
    }
    @Override
    public String toString() {
        return "Totalsignature [tolsigId=" + tolsigId + ", signatureName=" + signatureName 
                + ", createtime=" + createtime + ", uuid=" + uuid + ", status=" + status + ", remark="
                + remark + "]";
    }
    
}
