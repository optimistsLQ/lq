package com.foxconn.service;



import java.util.List;
import java.util.Map;

import com.foxconn.entity.Result;
import com.foxconn.entity.Totalsignature;
import com.github.pagehelper.PageInfo;

/**签核总表业务层接口
 * @author C3414208
 *
 */
public interface TotalSignatureService {
    /**
     * 添加签核流程
     * @param sig
     * @return
     */
    public int insertTolSig(Totalsignature sig);
    /**
     * 分页查询所有签核流程
     * @param sig
     * @return
     */
    public PageInfo<Totalsignature> findAll(String type,Integer start, Integer length);
    /**
     * 根据流程id修改当前流程状态（是否启用）
     * @param tolsigId
     * @param lockStatus
     */
    public Result updateSignatureLock(String tolsigId, Integer lockStatus);
    /**
     * 根据流程id刪除签核流程
     * @param tolsigId
     * @return
     */
    public Result deleteTolsig(List<String> tolsigId);
    /**
     * 查詢已啟用的流程的id，和流程名稱
     */
    public List<Map<String,String>> getTotalsignature();
}
