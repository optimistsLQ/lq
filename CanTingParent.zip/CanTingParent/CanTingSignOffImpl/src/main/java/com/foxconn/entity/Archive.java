package com.foxconn.entity;

import java.io.Serializable;
import java.util.List;

/**
 * 签核资料类（适应于归档查询）
 * @author C3414208
 *
 */
public class Archive implements Serializable{
    /**
     * 
     */
    private static final long serialVersionUID = -854947243883290761L;
    private String arrangementNum;//排配编号
    private String checktotalId;
    private String restaturantId;
    private String restaurantLocation;//餐厅
    private String mealSeller;//
    private String checkPoint;
    private String typeBigName;
    private String problemDetail;
    private String grade;
    private List<CheckPeople> checkpeople;
    private String standRemark;
    private Double afterScore;
    private String overend;
    private String checkNaturn;
    private Double afterMoney;
    private Double beforeMoney;
    private String userName ;

    private String problemLocation;
    
    
    
    public String getProblemLocation() {
        return problemLocation;
    }
    public void setProblemLocation(String problemLocation) {
        this.problemLocation = problemLocation;
    }
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public Double getBeforeMoney() {
        return beforeMoney;
    }
    public void setBeforeMoney(Double beforeMoney) {
        this.beforeMoney = beforeMoney;
    }
    public String getRestaturantId() {
        return restaturantId;
    }
    public void setRestaturantId(String restaturantId) {
        this.restaturantId = restaturantId;
    }
    public Double getAfterMoney() {
        return afterMoney;
    }
    public void setAfterMoney(Double afterMoney) {
        this.afterMoney = afterMoney;
    }
    public static long getSerialversionuid() {
        return serialVersionUID;
    }
    public String getArrangementNum() {
        return arrangementNum;
    }
    public void setArrangementNum(String arrangementNum) {
        this.arrangementNum = arrangementNum;
    }
    public String getChecktotalId() {
        return checktotalId;
    }
    public void setChecktotalId(String checktotalId) {
        this.checktotalId = checktotalId;
    }
    public String getRestaurantId() {
        return restaturantId;
    }
    public void setRestaurantId(String restaturantId) {
        this.restaturantId = restaturantId;
    }
    public String getRestaurantLocation() {
        return restaurantLocation;
    }
    public void setRestaurantLocation(String restaurantLocation) {
        this.restaurantLocation = restaurantLocation;
    }
    public String getMealSeller() {
        return mealSeller;
    }
    public void setMealSeller(String mealSeller) {
        this.mealSeller = mealSeller;
    }
    public String getCheckPoint() {
        return checkPoint;
    }
    public void setCheckPoint(String checkPoint) {
        this.checkPoint = checkPoint;
    }
    public String getTypeBigName() {
        return typeBigName;
    }
    public void setTypeBigName(String typeBigName) {
        this.typeBigName = typeBigName;
    }
    public String getProblemDetail() {
        return problemDetail;
    }
    public void setProblemDetail(String problemDetail) {
        this.problemDetail = problemDetail;
    }
    public String getGrade() {
        return grade;
    }
    public void setGrade(String grade) {
        this.grade = grade;
    }

    public List<CheckPeople> getCheckpeople() {
        return checkpeople;
    }
    public void setCheckpeople(List<CheckPeople> checkpeople) {
        this.checkpeople = checkpeople;
    }
    public String getStandRemark() {
        return standRemark;
    }
    public void setStandRemark(String standRemark) {
        this.standRemark = standRemark;
    }
    public Double getAfterScore() {
        return afterScore;
    }
    public void setAfterScore(Double afterScore) {
        this.afterScore = afterScore;
    }
    public String getOverend() {
        return overend;
    }
    public void setOverend(String overend) {
        this.overend = overend;
    }
    public String getCheckNaturn() {
        return checkNaturn;
    }
    public void setCheckNaturn(String checkNaturn) {
        this.checkNaturn = checkNaturn;
    }
    @Override
    public String toString() {
        return "Archive [arrangementNum=" + arrangementNum + ", checktotalId=" + checktotalId + ", restaturantId="
                + restaturantId + ", restaurantLocation=" + restaurantLocation + ", mealSeller=" + mealSeller
                + ", checkPoint=" + checkPoint + ", typeBigName=" + typeBigName + ", problemDetail=" + problemDetail
                + ", grade=" + grade + ", checkpeople=" + checkpeople + ", standRemark=" + standRemark + ", afterScore="
                + afterScore + ", overend=" + overend + ", checkNaturn=" + checkNaturn + ", afterMoney=" + afterMoney
                + ", beforeMoney=" + beforeMoney + ", userName=" + userName + ", problemLocation=" + problemLocation
                + "]";
    }

    
}
