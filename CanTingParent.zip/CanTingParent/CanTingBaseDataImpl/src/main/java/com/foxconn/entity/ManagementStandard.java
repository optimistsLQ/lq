package com.foxconn.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;

/**标准内容实体
 * @author C3410596
 *
 */
@Table(name = "T_MANAGEMENTSTANDARD")
public class ManagementStandard implements Serializable {
	private static final long serialVersionUID = -2630828995081783862L;

	@Id
	private String nth;
//一级编码
    private String oneCode;
//大类名称
    private String typeBigName;
//二级编码
    private String twoCode;
//小类名称
    private String typeSmallName;
//三级编码
    private String threeCode;
//标准内容
    private String standardContents;
//星级
    private String starLevel;
//标准扣分
    private Double standardScore;
//警告颜色
    private String warningColor;
//第一次处理
    private String firstHandle;
//第二次处理
    private String secondHandle;
//第三次处理
    private String thirdHandle;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date writeTime;


    public String getNth() {
		return nth;
	}

	public void setNth(String nth) {
		this.nth = nth;
	}

	public String getOneCode() {
        return oneCode;
    }

    public void setOneCode(String oneCode) {
        this.oneCode = oneCode == null ? null : oneCode.trim();
    }

    public String getTypeBigName() {
        return typeBigName;
    }

    public void setTypeBigName(String typeBigName) {
        this.typeBigName = typeBigName == null ? null : typeBigName.trim();
    }

    public String getTwoCode() {
        return twoCode;
    }

    public void setTwoCode(String twoCode) {
        this.twoCode = twoCode == null ? null : twoCode.trim();
    }

    public String getTypeSmallName() {
        return typeSmallName;
    }

    public void setTypeSmallName(String typeSmallName) {
        this.typeSmallName = typeSmallName == null ? null : typeSmallName.trim();
    }

    public String getThreeCode() {
        return threeCode;
    }

    public void setThreeCode(String threeCode) {
        this.threeCode = threeCode == null ? null : threeCode.trim();
    }

    public String getStandardContents() {
        return standardContents;
    }

    public void setStandardContents(String standardContents) {
        this.standardContents = standardContents == null ? null : standardContents.trim();
    }

    public String getStarLevel() {
        return starLevel;
    }

    public void setStarLevel(String starLevel) {
        this.starLevel = starLevel == null ? null : starLevel.trim();
    }

    public Double getStandardScore() {
        return standardScore;
    }

    public void setStandardScore(Double standardScore) {
        this.standardScore = standardScore;
    }

    public String getWarningColor() {
        return warningColor;
    }

    public void setWarningColor(String warningColor) {
        this.warningColor = warningColor == null ? null : warningColor.trim();
    }

    public String getFirstHandle() {
        return firstHandle;
    }

    public void setFirstHandle(String firstHandle) {
        this.firstHandle = firstHandle == null ? null : firstHandle.trim();
    }

    public String getSecondHandle() {
        return secondHandle;
    }

    public void setSecondHandle(String secondHandle) {
        this.secondHandle = secondHandle == null ? null : secondHandle.trim();
    }

    public String getThirdHandle() {
        return thirdHandle;
    }

    public void setThirdHandle(String thirdHandle) {
        this.thirdHandle = thirdHandle == null ? null : thirdHandle.trim();
    }

    public Date getWriteTime() {
        return writeTime;
    }

    public void setWriteTime(Date writeTime) {
        this.writeTime = writeTime;
    }
}