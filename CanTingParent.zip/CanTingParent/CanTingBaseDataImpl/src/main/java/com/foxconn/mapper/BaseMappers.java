package com.foxconn.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.ParamDTO;
import com.foxconn.entity.QueryCondition;

public interface BaseMappers {
	
	public List<String> getDBField(@Param("tableName") String tableName);

	public int insertList(@Param("listData")List<?> listData,
							  @Param("tableName") String tableName,
							  @Param("field") List<String> field,
							  @Param("columns") List<String> columns);

	public int delData(@Param("ids")List<String> ids, @Param("tableName")String tableName);
	
	public int updateItem(@Param("uid")String uid,@Param("tableName")String tableName,@Param("map")Map<String,Object> map);

	public Map<String, Object> findOneById(@Param("id")String id, @Param("tableName")String tableName);

//	public List<Map<String, Object>> findByItem(@Param("tableName")String tableName, @Param("query")QueryCondition obj);
	public List<Map<String, Object>> findByItemEase(@Param("tableName")String tableName, @Param("queryMap")Map<String, Object> queryMap,
													@Param("param") ParamDTO param);

    public List<String> getContractors();
}
