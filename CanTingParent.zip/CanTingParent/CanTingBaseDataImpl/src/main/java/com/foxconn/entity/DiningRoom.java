package com.foxconn.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;

/**餐厅信息实体
 * @author C3410596
 *
 */
@Table(name = "T_DININGROOM")
public class DiningRoom implements Serializable{
	private static final long serialVersionUID = 3149053417523933157L;
	@Id
	private String nth;
//餐厅位置
    private String drLocations;
//廠商名稱
    private String drName;
//餐厅状态（正常营业，装修中）
    private String drStatus;
//厨房类型
    private String drTypec;
//合同结束时间
    @DateTimeFormat(pattern = "yyyy-MM-dd")
	@JSONField(format = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date contractEnd;
//供应商用户职责
    private String duty;
//供应商用户
    private String supplierUser;
//大堂经理
    private String lobbyManager;
//就餐人次
    private Integer eatPeopleNum;
//餐厅信息备注
    private String remark;
//照片路径
    private String photoUrl;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date writeTime;
//合同开始时间
    @DateTimeFormat(pattern = "yyyy-MM-dd")
	@JSONField(format = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date contractStart;

//餐厅类型（新型/传统）
    private String drTyper;

    public String getNth() {
		return nth;
	}

	public void setNth(String nth) {
		this.nth = nth;
	}

	public String getDrLocations() {
        return drLocations;
    }

    public void setDrLocations(String drLocations) {
        this.drLocations = drLocations == null ? null : drLocations.trim();
    }

    public String getDrName() {
        return drName;
    }

    public void setDrName(String drName) {
        this.drName = drName == null ? null : drName.trim();
    }

    public String getDrStatus() {
        return drStatus;
    }

    public void setDrStatus(String drStatus) {
        this.drStatus = drStatus == null ? null : drStatus.trim();
    }

    public String getDrTypec() {
        return drTypec;
    }

    public void setDrTypec(String drTypec) {
        this.drTypec = drTypec == null ? null : drTypec.trim();
    }

    public Date getContractEnd() {
        return contractEnd;
    }

    public void setContractEnd(Date contractEnd) {
        this.contractEnd = contractEnd;
    }

    public String getDuty() {
        return duty;
    }

    public void setDuty(String duty) {
        this.duty = duty == null ? null : duty.trim();
    }

    public String getSupplierUser() {
        return supplierUser;
    }

    public void setSupplierUser(String supplierUser) {
        this.supplierUser = supplierUser == null ? null : supplierUser.trim();
    }

    public String getLobbyManager() {
        return lobbyManager;
    }

    public void setLobbyManager(String lobbyManager) {
        this.lobbyManager = lobbyManager == null ? null : lobbyManager.trim();
    }

    public Integer getEatPeopleNum() {
        return eatPeopleNum;
    }

    public void setEatPeopleNum(Integer eatPeopleNum) {
        this.eatPeopleNum = eatPeopleNum;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public String getPhotoUrl() {
        return photoUrl;
    }

    public void setPhotoUrl(String photoUrl) {
        this.photoUrl = photoUrl == null ? null : photoUrl.trim();
    }

    public Date getWriteTime() {
        return writeTime;
    }

    public void setWriteTime(Date writeTime) {
        this.writeTime = writeTime;
    }

    public Date getContractStart() {
        return contractStart;
    }

    public void setContractStart(Date contractStart) {
        this.contractStart = contractStart;
    }


    public String getDrTyper() {
        return drTyper;
    }

    public void setDrTyper(String drTyper) {
        this.drTyper = drTyper == null ? null : drTyper.trim();
    }

	@Override
	public String toString() {
		return "DiningRoom [nth=" + nth + ", drLocations=" + drLocations + ", drName=" + drName + ", drStatus="
				+ drStatus + ", drTypec=" + drTypec + ", contractEnd=" + contractEnd + ", duty=" + duty
				+ ", supplierUser=" + supplierUser + ", lobbyManager=" + lobbyManager + ", eatPeopleNum=" + eatPeopleNum
				+ ", remark=" + remark + ", photoUrl=" + photoUrl + ", writeTime=" + writeTime + ", contractStart="
				+ contractStart + ", drTyper=" + drTyper + "]";
	}
}