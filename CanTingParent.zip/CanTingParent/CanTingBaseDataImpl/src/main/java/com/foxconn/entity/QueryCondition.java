package com.foxconn.entity;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;

public class QueryCondition {

	//连接词（and/or）
	private String connect = " AND ";
	//是否是模糊查询
	private boolean vagueQuery = false; 
	//表名称
	private String tableName;
	//排序字段
	private String orderField;
	//排序规则
	private String order = "asc";
	//时间格式
	private String timeLayOut = "yyyy-MM-dd HH:mm:ss";
	//查询条件（column，value）
	private LinkedHashMap<String, Object> queryMap;
	//查询的字段，如果不设置就是select * from table
	private LinkedHashSet<String> columns;
	//是否去重，默认不去重
	private boolean distinct = false;

	public String getConnect() {
		return connect;
	}

	public void setConnect(String connect) {
		this.connect = connect;
	}

	public boolean isVagueQuery() {
		return vagueQuery;
	}

	public void setVagueQuery(boolean vagueQuery) {
		this.vagueQuery = vagueQuery;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getOrderField() {
		return orderField;
	}

	public void setOrderField(String orderField) {
		this.orderField = orderField;
	}

	public String getOrder() {
		return order;
	}

	public void setOrder(String order) {
		this.order = order;
	}

	public String getTimeLayOut() {
		return timeLayOut;
	}

	public void setTimeLayOut(String timeLayOut) {
		this.timeLayOut = timeLayOut;
	}

	public LinkedHashMap<String, Object> getQueryMap() {
		return queryMap;
	}

	public void setQueryMap(LinkedHashMap<String, Object> queryMap) {
		this.queryMap = queryMap;
	}
	
	
}
