package com.foxconn.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.entity.ImgFile;
import com.foxconn.mapper.ImgFileMapper;
import com.foxconn.service.ImgFileService;

@Service
public class ImgFileServiceImpl implements ImgFileService{

	@Autowired
	private ImgFileMapper imgMapper;
	@Override
	public int addImg(ImgFile img) {
		// TODO Auto-generated method stub
		return imgMapper.insertSelective(img);
	}

	@Override
	public ImgFile getImg(String id) {
		// TODO Auto-generated method stub
		return imgMapper.selectByPrimaryKey(id);
	}

	@Override
	public int delImg(String imgNth) {
		// TODO Auto-generated method stub
		return imgMapper.deleteByPrimaryKey(imgNth);
	}

	@Override
	public int delImgByForeign(List<String> foreignList) {
		// TODO Auto-generated method stub
		return imgMapper.delImgByForeign(foreignList);
	}

	@Override
	public List<ImgFile> getImgId(String foreign) {
		// TODO Auto-generated method stub
		return imgMapper.getImgId(foreign);
	}

	@Override
	public int delImgs(List<String> imgDelId) {
		// TODO Auto-generated method stub
		return imgMapper.delImgs(imgDelId);
	}

}
