package com.foxconn.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Id;
import javax.persistence.Table;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;

/**自检实体
 * @author C3410596
 *
 */
@Table(name = "T_SELFCHECK")
public class SelfCheck implements Serializable{
	private static final long serialVersionUID = 3330153874095699037L;

	@Id
	private String nth;
//自查流程
    private String checkProcess;
//自查类型
    private String checkType;
//類別
    private String classType;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date writeTime;


    public String getNth() {
		return nth;
	}

	public void setNth(String nth) {
		this.nth = nth;
	}

	public String getCheckProcess() {
        return checkProcess;
    }

    public void setCheckProcess(String checkProcess) {
        this.checkProcess = checkProcess == null ? null : checkProcess.trim();
    }

    public String getCheckType() {
        return checkType;
    }

    public void setCheckType(String checkType) {
        this.checkType = checkType == null ? null : checkType.trim();
    }

    public String getClassType() {
		return classType;
	}

	public void setClassType(String classType) {
		this.classType = classType;
	}

	public Date getWriteTime() {
        return writeTime;
    }

    public void setWriteTime(Date writeTime) {
        this.writeTime = writeTime;
    }
}