package com.foxconn.service;

import java.util.List;
import java.util.Map;

import com.foxconn.entity.AuditPeople;
import com.foxconn.entity.ParamDTO;
import com.foxconn.entity.QueryCondition;
import com.foxconn.entity.Result;
import com.github.pagehelper.PageInfo;

/**稽核人员业务接口
 * @author C3410596
 *
 */
public interface BaseService {

	Integer delData(List<String> ids, Class<?> cla);
	Integer updateData(Object obj);
	<T> T findOneById(String id, Class<T> cla);
	<T> PageInfo<T>  findByItem(Class<T> cla, Map<String, Object> queryMap, ParamDTO param);
	Integer addData(List<?> list, Class<?> cla);
	/**
	 * 獲取餐包商信息
	 * @return
	 */
	List<String> getContractors();
}

