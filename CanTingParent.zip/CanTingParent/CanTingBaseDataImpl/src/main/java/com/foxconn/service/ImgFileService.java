package com.foxconn.service;

import java.util.List;

import com.foxconn.entity.ImgFile;

public interface ImgFileService {

	public int addImg(ImgFile img);
	public ImgFile getImg(String id);
	public int delImg(String imgNth);
	public int delImgByForeign(List<String> foreignList);
	public List<ImgFile> getImgId(String foreign);
	public int delImgs(List<String> imgDelId);
}
