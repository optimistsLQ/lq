package com.foxconn.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.ImgFile;

public interface ImgFileMapper {
    int deleteByPrimaryKey(String imgId);

    int insert(ImgFile record);

    int insertSelective(ImgFile record);

    ImgFile selectByPrimaryKey(String imgId);

    int updateByPrimaryKeySelective(ImgFile record);

    int updateByPrimaryKeyWithBLOBs(ImgFile record);

    int updateByPrimaryKey(ImgFile record);

	int delImgByForeign(@Param("foreignList") List<String> foreignList);

	List<ImgFile> getImgId(String foreign);

	int delImgs(@Param("imgDelId")List<String> imgDelId);
}