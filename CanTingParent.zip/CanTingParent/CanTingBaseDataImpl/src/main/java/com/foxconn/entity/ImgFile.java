package com.foxconn.entity;

import java.util.Arrays;

public class ImgFile {
    private String imgId;

    private String imgForeign;

    private String imgName;

    private String imgDescr;

    private byte[] imgEntity;

    public String getImgId() {
        return imgId;
    }

    public void setImgId(String imgId) {
        this.imgId = imgId == null ? null : imgId.trim();
    }

    public String getImgForeign() {
        return imgForeign;
    }

    public void setImgForeign(String imgForeign) {
        this.imgForeign = imgForeign == null ? null : imgForeign.trim();
    }

    public String getImgName() {
        return imgName;
    }

    public void setImgName(String imgName) {
        this.imgName = imgName == null ? null : imgName.trim();
    }

    public String getImgDescr() {
        return imgDescr;
    }

    public void setImgDescr(String imgDescr) {
        this.imgDescr = imgDescr == null ? null : imgDescr.trim();
    }

    public byte[] getImgEntity() {
        return imgEntity;
    }

    public void setImgEntity(byte[] imgEntity) {
        this.imgEntity = imgEntity;
    }

	@Override
	public String toString() {
		return "ImgFile [imgId=" + imgId + ", imgForeign=" + imgForeign + ", imgName=" + imgName + ", imgDescr="
				+ imgDescr + ", imgEntity=" + Arrays.toString(imgEntity) + "]";
	}
}