package com.foxconn.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

/**稽核人员实体
 * @author C3410596
 *
 */
@Table(name = "T_AUDITPEOPLE")
public class AuditPeople implements Serializable{
	private static final long serialVersionUID = 2573469774975389083L;
	@Id
	private String nth;
    //工号
    private String jobCard;
    //名字
    private String uname;
    //岗位
    private String station;
    //岗位性质
    private String stationNature;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date writeTime;
   

	public String getNth() {
		return nth;
	}


	public void setNth(String nth) {
		this.nth = nth;
	}


	public String getJobCard() {
		return jobCard;
	}


	public void setJobCard(String jobCard) {
		this.jobCard = jobCard;
	}


	public String getUname() {
		return uname;
	}


	public void setUname(String uname) {
		this.uname = uname;
	}


	public String getStation() {
		return station;
	}


	public void setStation(String station) {
		this.station = station;
	}


	public String getStationNature() {
		return stationNature;
	}


	public void setStationNature(String stationNature) {
		this.stationNature = stationNature;
	}


	public Date getWriteTime() {
		return writeTime;
	}


	public void setWriteTime(Date writeTime) {
		this.writeTime = writeTime;
	}


	@Override
	public String toString() {
		return "AuditPeople [nth=" + nth + ", jobCard=" + jobCard + ", uname=" + uname + ", station=" + station
				+ ", stationNature=" + stationNature + ", writeTime=" + writeTime + "]";
	}

    
}