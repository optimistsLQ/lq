package com.foxconn.service.impl;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Table;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.foxconn.entity.AuditPeople;
import com.foxconn.entity.ParamDTO;
import com.foxconn.entity.QueryCondition;
import com.foxconn.entity.Result;
import com.foxconn.mapper.BaseMappers;
import com.foxconn.service.BaseService;
import com.foxconn.utils.Utils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
@Service
public class BaseServiceImpl implements BaseService {

	@Autowired
	private BaseMappers baseMappers;
	/**
	 *批量添加
	 */
	@Override
	public Integer addData(List<?> list, Class<?> cla) {
		if (list.size() == 0) {
			return 0;
		}
		Table table = cla.getAnnotation(Table.class);
		String tableName = table.name();
		List<String> DBFields = baseMappers.getDBField(tableName);
		List<String> javaField = new ArrayList<String>();
		for (String DBField : DBFields) {
			String humpField = Utils.underlineToHump(DBField);
			javaField.add(humpField);
		}
		Integer i = baseMappers.insertList(list, tableName, javaField, DBFields);
		return i;
	}
	/**
	 *批量删除
	 */
	@Override
	public Integer delData(List<String> ids, Class<?> cla) {
		if (ObjectUtils.isEmpty(ids)) {
			return 0;
		}
		String tableName = cla.getAnnotation(Table.class).name();
		Integer i = baseMappers.delData(ids,tableName);
		return i;
	}
	/**
	 *单个修改
	 */
	@Override
	public Integer updateData(Object obj) {
		Class<? extends Object> cla = obj.getClass();
		String tableName = cla.getAnnotation(Table.class).name();
		Method m;
		String uid = null;
		Map<String,Object> map = new HashMap<String, Object>();
		try {
			m = cla.getMethod("getNth");
		
			uid = (String) m.invoke(obj);
			for (Method method:cla.getDeclaredMethods()) {
				if (method.getName().startsWith("get")) {
					Object value = method.invoke(obj);
					String fieldName = method.getName().substring(3);
					fieldName = fieldName.substring(0,1).toLowerCase()+fieldName.substring(1);
					String column = Utils.humpToLine(fieldName);
					map.put(column,value);
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return baseMappers.updateItem(uid, tableName, map);
	}
	/**
	 *根据ID查找
	 */
	@Override
	public <T> T findOneById(String id, Class<T> cla) {
		// TODO Auto-generated method stub
		String tableName = cla.getAnnotation(Table.class).name();
		Map<String, Object> objMap = baseMappers.findOneById(id, tableName);
		if (null == objMap) {
			return null;
		}
		T auditPeople = Utils.mapToJavabean(objMap, cla); 
		return auditPeople;
	}
	/**
	 *模糊分页查询
	 */
	@Override
	public <T> PageInfo<T> findByItem(Class<T> cla, Map<String, Object> queryMap, ParamDTO param) {
		// TODO Auto-generated method stub
		String tableName = cla.getAnnotation(Table.class).name();
		if (!ObjectUtils.isEmpty(param)) {
			if (!ObjectUtils.isEmpty(param.getOrderField())) {
				String orderField = Utils.humpToLine(param.getOrderField());
				param.setOrderField(orderField);
			}
			
			if (!ObjectUtils.isEmpty(param.getStart()) && !ObjectUtils.isEmpty(param.getLength())) {
				PageHelper.startPage(param.getStart(), param.getLength(), true);
			}
		}
		List<Map<String, Object>> list = baseMappers.findByItemEase(tableName, queryMap, param);
		PageInfo<Map<String, Object>> info = new PageInfo<Map<String, Object>>(list);
		List<T> resultList = new ArrayList<T>();
		for (Map<String, Object> objMap : list) {
			T javaBean = Utils.mapToJavabean(objMap, cla); 
			resultList.add(javaBean);
		}
		PageInfo<T> pageInfo = new PageInfo<T>(resultList);
		pageInfo.setTotal(info.getTotal());
		return pageInfo;
	}
    @Override
    public List<String> getContractors() {
        // TODO Auto-generated method stub
        
        return baseMappers.getContractors();
    }

}
