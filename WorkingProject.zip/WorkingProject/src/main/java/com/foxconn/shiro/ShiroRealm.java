package com.foxconn.shiro;

import java.util.ArrayList;
import java.util.List;


import org.apache.commons.collections.CollectionUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.springframework.beans.factory.annotation.Autowired;

import com.foxconn.entity.PermissionEntity;
import com.foxconn.entity.RoleEntity;
import com.foxconn.entity.UserEntity;
import com.foxconn.service.UserService;

public class ShiroRealm extends AuthorizingRealm {

	@Autowired
	private UserService userService;

	/**
	 * 授權
	 **/
	@Override
	protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
		UserEntity user = (UserEntity) principals.fromRealm(this.getClass().getName()).iterator().next();
		List<String> roleNameList = new ArrayList<String>();
		List<String> premissionNameList = new ArrayList<String>();
		List<RoleEntity> roleList = user.getRoleList();
		if (CollectionUtils.isNotEmpty(roleList)) {
			for (RoleEntity role : roleList) {
				roleNameList.add(role.getRoleName());
				List<PermissionEntity> premissionList = role.getPermissionList();
				if (CollectionUtils.isNotEmpty(premissionList)) {
					for (PermissionEntity premission : premissionList) {
						premissionNameList.add(premission.getPerName());
					}
				}
			}
		}
		System.out.println("角色集合》》"+roleNameList.toString());
		System.out.println("权限集合》》"+premissionNameList.toString());
		SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
		info.addStringPermissions(premissionNameList);
		info.addRoles(roleNameList);
		return info;
	}

	/**
	 * 認證
	 **/
	@Override
	protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token){
		UsernamePasswordToken Token = (UsernamePasswordToken) token;
		String userName = Token.getUsername();
		UserEntity user = userService.getUserByUserNumber(userName);
		return new SimpleAuthenticationInfo(user, user.getPwd(), this.getClass().getName());
	}

}
