package com.foxconn.shiro;

import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;

import java.util.HashMap;
import java.util.LinkedHashMap;

import org.apache.shiro.cache.MemoryConstrainedCacheManager;
import org.apache.shiro.mgt.SecurityManager;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * shiro權限管理框架配置類
 **/
@Configuration
public class ShiroConfiguration {

	/**
	 * 资源拦截配置
	 **/
	@Bean
	public ShiroFilterFactoryBean shiroFilterFactoryBean(
			@Qualifier(value = "securityManager") SecurityManager securityManager) {
		ShiroFilterFactoryBean bean = new ShiroFilterFactoryBean();
		bean.setSecurityManager(securityManager);
		HashMap<String, String> map = new LinkedHashMap<String, String>();
//		map.put("/login.do", "anon");
//		map.put("/static/**", "anon");
//		map.put("/user/login.do", "anon");
//		map.put("/user/insertUser.do", "anon");
////	map.put("/show_system.do", "roleOrFilter[课长,线长,天外飞仙]");
////	map.put("/show_system.do", "roles[线长]");
//		map.put("/show_system.do", "perms[systemm]");// 该资源必须先授权才能访问
//		map.put("/error.do", "perms[500]");// 该资源必须先授权才能访问
//		map.put("/**", "authc");
//		map.put("/user/login.do", "anon");
//		map.put("/user/insertUser.do", "anon");
//		map.put("/register.do", "anon");
//		map.put("/show_system.do", "roleOrFilter[课长,线长,天外飞仙]");
//		map.put("/show_system.do", "roles[线长]");
		
		map.put("/user/toadminList.do", "perms[用户管理]");// 该资源必须先授权才能访问
		map.put("/permission/listAll.do", "perms[权限管理]");// 该资源必须先授权才能访问
		map.put("/role/listRoleDetail.do", "perms[角色管理]");// 该资源必须先授权才能访问
		map.put("/base/listDepart.do", "perms[部門管理]");// 该资源必须先授权才能访问
//		map.put("/things/delChildlist.do", "perms[删除子事项]");// 该资源必须先授权才能访问
//		map.put("/things/delTotallist.do", "perms[删除总事项]");// 该资源必须先授权才能访问
		map.put("/meet/delMeet.do", "perms[刪除會議記錄]");// 该资源必须先授权才能访问
		map.put("/base/toPublishMsg.do", "perms[发布公告]");// 该资源必须先授权才能访问
		map.put("/jobLog/delJobLog.do", "perms[删除工作日志]");// 该资源必须先授权才能访问
		map.put("/things/toStart.do", "perms[事項評分]");// 该资源必须先授权才能访问
		map.put("/user/uploadAbsent.do", "perms[上传缺勤]");// 该资源必须先授权才能访问
		map.put("/jobLog/toRoster.do", "perms[设置黑白名单]");// 该资源必须先授权才能访问
		
		map.put("/register.do", "anon");
		map.put("/findPwd.do", "anon");
		map.put("/login.do", "anon");
		map.put("/toForgetPwd.do", "anon");
		map.put("/sendVerificationCode.do", "anon");
		map.put("/static/**", "anon");
		map.put("/templates/**", "authc");
		map.put("/*.do", "authc");
		bean.setLoginUrl("login.do");
		bean.setUnauthorizedUrl("/user/fileLogin.do");
		bean.setFilterChainDefinitionMap(map);
		
		return bean;
	}

	@Bean(value = "securityManager")
	public SecurityManager securityManager(@Qualifier(value = "shiroRealm") ShiroRealm shiroRealm) {
		DefaultWebSecurityManager securityManager = new DefaultWebSecurityManager();
		securityManager.setRealm(shiroRealm);
		securityManager.setCacheManager(new MemoryConstrainedCacheManager());// 设置缓存
		return securityManager;
	}

	/**
	 * 自定义身份认证
	 */
	@Bean(value = "shiroRealm")
	public ShiroRealm shiroRealm() {
		return new ShiroRealm();
	}
}
