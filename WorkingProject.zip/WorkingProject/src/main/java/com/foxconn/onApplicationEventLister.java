package com.foxconn;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.annotation.Configuration;
import com.foxconn.entity.ChildlistEntity;
import com.foxconn.entity.TotallistEntity;
import com.foxconn.entity.UserEntity;
import com.foxconn.service.ChildlistService;
import com.foxconn.service.TotallistService;
import com.foxconn.service.UserService;
import com.foxconn.utils.EmailToolkit;
@Configuration
public class onApplicationEventLister implements ApplicationListener<ApplicationEvent>{

	@Autowired
	private TotallistService totalthingService;
	@Autowired
	private UserService userService;
	@Autowired
	private ChildlistService childthingService;
	@Override
	public void onApplicationEvent(ApplicationEvent event) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		// TODO Auto-generated method stub
		 if (event instanceof ApplicationReadyEvent) {// 应用已启动完成
			Runnable runnable = new Runnable() {
				
				@Override
				public void run() {
					long thistime = new Date().getTime();
					// TODO Auto-generated method stub
					System.out.println("定时循环");
					String mailContent = "<table border='1' style='border-collapse:collapse'><tr><td>姓名</td><td>總事項</td><td>子事項</td></tr>";
					Set<String> emailSet = new HashSet<String>();
					List<TotallistEntity> totalThingsList = totalthingService.listByItem("N", null, 0, Integer.MAX_VALUE, null);
					System.out.println(totalThingsList.size());
					for (TotallistEntity totalthings : totalThingsList) {
						//先提取子事項的資料
						List<ChildlistEntity> childThingList = childthingService.listByTotallistId(totalthings.getTotallistId(), "N");
						for (ChildlistEntity childthings : childThingList) {
							try {
								long dueday = dateFormat.parse(childthings.getZichickpoint()).getTime();
								if ((dueday - thistime)/(1000*60*60*24) > 0 && (dueday - thistime)/(1000*60*60*24) < 2) {
									
									String [] userArr = childthings.getZidri().split("，");
									UserEntity user = userService.getUserByNickname(userArr[0]);
									emailSet.add(user.getEmail());
									String temp = "";
									if (childthings.getZichecklist().length() < 10) {
										temp = childthings.getZichecklist();
									}else {
										temp = childthings.getZichecklist().substring(0, 10);
									}
									mailContent += "<tr><td>"+childthings.getZidri()+"</td><td>"+totalthings.getProjectName()+"</td><td>子事項:"+temp+"...</td></tr>";//childthings.getZichecklist().substring(0, 10)+"...";
								}
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
						//再提取總事項
						if (totalthings.getStatus().contains("Risk")){
							try {
									long dueday = dateFormat.parse(totalthings.getDueday()).getTime();
								
									if ((dueday - thistime)/(1000*60*60*24) > 0 && (dueday - thistime)/(1000*60*60*24) < 2) {
										UserEntity user = userService.getUserById(totalthings.getDriId());
										emailSet.add(user.getEmail());
										mailContent += "<tr><td>"+totalthings.getTotaldri()+"</td><td>總事項:"+totalthings.getProjectName()+"</td><td></td></tr>";
									}
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}
					mailContent += "</table>";
					System.out.println(mailContent);
					String emails = emailSet.toString();
					emails = emails.substring(1);
					emails = emails.substring(0,emails.indexOf("]"));
					System.out.println("emails>>"+emails);
					//emails = "idsbg-cd-cmproject@mail.foxconn.com";(_targetTime-currentTime)/1000
					EmailToolkit.sendEmail("你有待辦事項即將到期", "即將到期的待辦事項：<br>"+mailContent, emails);
					
				}
			};
			
			
					try {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(new Date());
						calendar.add(Calendar.DAY_OF_MONTH, 1);
						String targetTime = new SimpleDateFormat("yyyy-MM-dd").format(calendar.getTime())+" 07:50";
						long _targetTime = dateFormat.parse(targetTime).getTime();
						long currentTime = new Date().getTime();
						ScheduledExecutorService service = Executors.newSingleThreadScheduledExecutor();
						service.scheduleAtFixedRate(runnable, (_targetTime-currentTime)/1000, 24*60*60, TimeUnit.SECONDS);
					} catch (Exception e) {
						e.printStackTrace();
					}
			
		} 
	}

}
