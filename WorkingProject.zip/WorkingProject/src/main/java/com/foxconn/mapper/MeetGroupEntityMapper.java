package com.foxconn.mapper;

import com.foxconn.entity.MeetGroupEntity;

public interface MeetGroupEntityMapper {
    int deleteByPrimaryKey(String mgId);

    int insert(MeetGroupEntity record);

    int insertSelective(MeetGroupEntity record);

    MeetGroupEntity selectByPrimaryKey(String mgId);

    int updateByPrimaryKeySelective(MeetGroupEntity record);

    int updateByPrimaryKey(MeetGroupEntity record);
}