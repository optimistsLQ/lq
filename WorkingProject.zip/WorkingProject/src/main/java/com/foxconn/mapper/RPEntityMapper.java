package com.foxconn.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.RPEntity;

public interface RPEntityMapper {
    int deleteByPrimaryKey(String rpId);

    int insert(RPEntity record);

    int insertSelective(RPEntity record);

    RPEntity selectByPrimaryKey(String rpId);

    int updateByPrimaryKeySelective(RPEntity record);

    int updateByPrimaryKey(RPEntity record);
    
    int delRolePermissionByRoleIds(@Param("roleIds") String [] roleIds);
    
    List<RPEntity> listAll();
    
    List<RPEntity> listByRoleId(String roleId);
    
    int delListByIds(@Param("delList")List<String> delList,@Param("roleId") String roleId);
    
    int insertListByIds(@Param("addList")List<String> addList,@Param("roleId") String roleId);
}