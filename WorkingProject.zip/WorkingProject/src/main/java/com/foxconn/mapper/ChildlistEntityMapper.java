package com.foxconn.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.ChildlistEntity;

public interface ChildlistEntityMapper {
    int deleteByPrimaryKey(String childlistId);

    int insert(ChildlistEntity record);

    int insertSelective(ChildlistEntity record);

    ChildlistEntity selectByPrimaryKey(String childlistId);

    int updateByPrimaryKeySelective(ChildlistEntity record);

    int updateByPrimaryKey(ChildlistEntity record);

	List<ChildlistEntity> listByTotallistId(@Param("totallistId")String totallistId, @Param("endover")String endover);

	int delChildlistByTotallistId(String totallistId);

	List<Map<String, Object>> count();

	int updateChildlistByBatch(@Param("childListupdate")List<ChildlistEntity> childListupdate);
}