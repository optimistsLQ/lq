package com.foxconn.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.DatafileEntity;

public interface DatafileEntityMapper {
    int deleteByPrimaryKey(String datafileId);

    int insert(DatafileEntity record);

    int insertSelective(DatafileEntity record);

    DatafileEntity selectByPrimaryKey(String datafileId);

    int updateByPrimaryKeySelective(DatafileEntity record);

    int updateByPrimaryKey(DatafileEntity record);
    
	int delFileByUploader(String uploaderId);

	List<DatafileEntity> findAllFile(@Param("uploaderId")String uploaderId, @Param("uploader")String uploader, @Param("item")String item, @Param("start") String start, @Param("length") String length);
	int countAllFile(@Param("uploaderId")String uploaderId, @Param("uploader")String uploader, @Param("item")String item);
}