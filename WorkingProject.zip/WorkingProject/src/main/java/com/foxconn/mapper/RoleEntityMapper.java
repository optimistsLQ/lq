package com.foxconn.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.RoleEntity;

public interface RoleEntityMapper {
    int deleteByPrimaryKey(@Param("roleids") List<String> roleids);

    int insert(RoleEntity record);

    int insertSelective(RoleEntity record);

    RoleEntity selectByPrimaryKey(String roleId);

    int updateByPrimaryKeySelective(RoleEntity record);

    int updateByPrimaryKey(RoleEntity record);
    
    List<RoleEntity> listAllRole();
    
    List<RoleEntity> findAllRolePermission();
    
    int insertRoleGetId(@Param("obj")RoleEntity obj);
    
    List<RoleEntity> findAllRoleUserPermission();
    
    RoleEntity findOneRoleUserPermission(String roleId);
}