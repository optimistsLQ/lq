package com.foxconn.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.JoblogEntity;

public interface JoblogEntityMapper {
    int deleteByPrimaryKey(String joblogId);

    int insert(JoblogEntity record);

    int insertSelective(JoblogEntity record);

    JoblogEntity selectByPrimaryKey(String joblogId);

    int updateByPrimaryKeySelective(JoblogEntity record);

    int updateByPrimaryKey(JoblogEntity record);

	List<JoblogEntity> findAllByitem(@Param("jobtime")String jobtime,@Param("endtime")String endtime, @Param("item")String item, @Param("start") String start, @Param("length") String length);
	int countAll(@Param("jobtime")String jobtime,@Param("endtime")String endtime, @Param("item")String item);

	List<JoblogEntity> listAllByToday(String time);
}