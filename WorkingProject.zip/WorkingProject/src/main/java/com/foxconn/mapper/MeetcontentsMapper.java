package com.foxconn.mapper;

import java.util.List;

import com.foxconn.entity.Meetcontents;

public interface MeetcontentsMapper {
    int deleteByPrimaryKey(String meetcontantsId);

    int insert(Meetcontents record);

    int insertSelective(Meetcontents record);

    Meetcontents selectByPrimaryKey(String meetcontantsId);

    int updateByPrimaryKeySelective(Meetcontents record);

    int updateByPrimaryKey(Meetcontents record);

	List<Meetcontents> listMeetcontentsByMeetId(String meetId);

	int delMeetcontentsBtMeetId(String meetId);
}