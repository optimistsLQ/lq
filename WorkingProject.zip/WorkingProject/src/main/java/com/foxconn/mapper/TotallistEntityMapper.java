package com.foxconn.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.TotallistEntity;

public interface TotallistEntityMapper {
    int deleteByPrimaryKey(String totallistId);

    int insert(TotallistEntity record);

    int insertSelective(TotallistEntity record);

    TotallistEntity selectByPrimaryKey(String totallistId);

    int updateByPrimaryKeySelective(TotallistEntity record);

    int updateByPrimaryKey(TotallistEntity record);

	List<TotallistEntity> listByItem(@Param("item") String item, @Param("status") String status,@Param("start") String start, @Param("length") String length,@Param("userIdList") List<String> userIdList);
	 
	int countlistByItem (@Param("item") String item, @Param("status") String status,@Param("userIdList") List<String> userIdList);

	List<Map<String, Object>> count();

	int updateTotallistByBatch(@Param("totalListupdate")List<TotallistEntity> totalListupdate);
}