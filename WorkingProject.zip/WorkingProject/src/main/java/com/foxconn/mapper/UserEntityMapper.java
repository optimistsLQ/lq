package com.foxconn.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.UserEntity;

public interface UserEntityMapper {
    int deleteByPrimaryKey(@Param("userId") List<String> userId);

    int insert(@Param("user") UserEntity user);

    int insertSelective(UserEntity record);

    UserEntity selectByPrimaryKey(String userId);

    int updateByPrimaryKeySelective(UserEntity record);

    int updateByPrimaryKey(UserEntity record);
    
    List<UserEntity> listAllUser(@Param("type") String type);
    
    UserEntity getUserByNumber(String userNumber);
    
    List<UserEntity> listUserByDepart(@Param("ids")String[] ids);

	UserEntity getUserByNickname(String nickname);

	int updateUserObj(@Param("argsMap") Map<String, String> argsMap, @Param("whereMap") Map<String, List<String>> whereMap);
}