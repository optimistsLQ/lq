package com.foxconn.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.PermissionEntity;

public interface PermissionEntityMapper {
    int deleteByPrimaryKeys(@Param("perId")String [] perId);

    int insert(PermissionEntity record);

    int insertSelective(PermissionEntity record);

    PermissionEntity selectByPrimaryKey(String perId);

    int updateByPrimaryKeySelective(PermissionEntity record);

    int updateByPrimaryKey(PermissionEntity record);
    
    List<PermissionEntity> listAllPermission();
    
    PermissionEntity getPermissionByPerName(String perName);
}