package com.foxconn.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.Meetionnotes;

public interface MeetionnotesMapper {
    int deleteByPrimaryKey(String meetId);

    int insert(Meetionnotes record);

    int insertSelective(Meetionnotes record);

    Meetionnotes selectByPrimaryKey(String meetId);

    int updateByPrimaryKeySelective(Meetionnotes record);

    int updateByPrimaryKey(Meetionnotes record);
    
    int countlistByItem (@Param("item")String item);

	List<Meetionnotes> listByItem(@Param("item")String item, @Param("start")String start, @Param("length")String length);
}