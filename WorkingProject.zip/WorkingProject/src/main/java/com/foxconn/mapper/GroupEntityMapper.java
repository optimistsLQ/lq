package com.foxconn.mapper;

import java.util.List;

import com.foxconn.entity.GroupEntity;

public interface GroupEntityMapper {
    int deleteByPrimaryKey(String gId);

    int insert(GroupEntity record);

    int insertSelective(GroupEntity record);

    GroupEntity selectByPrimaryKey(String gId);

    int updateByPrimaryKeySelective(GroupEntity record);

    int updateByPrimaryKey(GroupEntity record);

	int delGroupByGroupId(String groupId);

	List<GroupEntity> getGroupsByGroupId(String groupId);

	List<GroupEntity> listAllGroups();
}