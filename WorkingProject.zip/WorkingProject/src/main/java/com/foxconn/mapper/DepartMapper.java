package com.foxconn.mapper;

import java.util.List;

import com.foxconn.entity.Depart;

public interface DepartMapper {
    int deleteByPrimaryKey(String departId);

    int insert(Depart record);

    int insertSelective(Depart record);

    Depart selectByPrimaryKey(String departId);

    int updateByPrimaryKeySelective(Depart record);

    int updateByPrimaryKey(Depart record);
    
    List<Depart> listAllDepart();
}