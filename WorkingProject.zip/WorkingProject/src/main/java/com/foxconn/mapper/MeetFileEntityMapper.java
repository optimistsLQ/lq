package com.foxconn.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.MeetFileEntity;

public interface MeetFileEntityMapper {
    int deleteByPrimaryKey(String mfId);

    int insert(MeetFileEntity record);

    int insertSelective(MeetFileEntity record);

    MeetFileEntity selectByPrimaryKey(String mfId);

    int updateByPrimaryKeySelective(MeetFileEntity record);

    int updateByPrimaryKey(MeetFileEntity record);

	int delFileByMeetId(String meetId);

	List<MeetFileEntity> findByMeetId(String meetId);

	MeetFileEntity getMeetFileBymeetidAndFileurl(@Param("meetid")String meetid, @Param("fileurl")String fileurl);
}