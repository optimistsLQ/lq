package com.foxconn.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.entity.Meetcontents;
import com.foxconn.mapper.MeetcontentsMapper;
import com.foxconn.service.MeetcontentsService;

@Service
public class MeetcontentsServiceImpl implements MeetcontentsService{

	@Autowired
	private MeetcontentsMapper meetcontents;
	
	@Override
	public int addMeetcontents(Meetcontents meet) {
		// TODO Auto-generated method stub
		return meetcontents.insertSelective(meet);
	}

	@Override
	public int delMeetcontentsById(String meetcontantsId) {
		// TODO Auto-generated method stub
		return meetcontents.deleteByPrimaryKey(meetcontantsId);
	}

	@Override
	public int updateMeecontents(Meetcontents meet) {
		// TODO Auto-generated method stub
		return meetcontents.updateByPrimaryKeySelective(meet);
	}

	@Override
	public Meetcontents getMeetcontentsById(String meetcontantsId) {
		// TODO Auto-generated method stub
		return meetcontents.selectByPrimaryKey(meetcontantsId);
	}

	@Override
	public List<Meetcontents> listMeetcontentsByMeetId(String meetId) {
		// TODO Auto-generated method stub
		return meetcontents.listMeetcontentsByMeetId(meetId);
	}

	@Override
	public int delMeetcontentsBtMeetId(String meetId) {
		// TODO Auto-generated method stub
		return meetcontents.delMeetcontentsBtMeetId(meetId);
	}

}
