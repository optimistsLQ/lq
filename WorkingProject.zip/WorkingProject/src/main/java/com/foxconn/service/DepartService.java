package com.foxconn.service;

import java.util.List;

import com.foxconn.entity.Depart;

/**部門業務接口
 * @author C3410596
 *
 */
public interface DepartService {

	public int insertDepart(Depart depart);
	public int delDepartById(String departId);
	public int updateDepart(Depart depart);
	public List<Depart> listAllDepart();
	public Depart getDepartById(String departId);
}
