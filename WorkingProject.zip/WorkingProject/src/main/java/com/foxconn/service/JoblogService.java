package com.foxconn.service;

import java.util.List;

import com.foxconn.entity.JoblogEntity;

public interface JoblogService {

	public int addJoblog(JoblogEntity jobLog);
	public int delJoblog(List<String> jobLogIds);
	public int updateJoblog(JoblogEntity jobLog);
	public JoblogEntity getJoblog(String jobLogId);
	public List<JoblogEntity> findAllByitem(String jobtime,String endTime, String item,String start,String length);
	public int countAll(String jobtime,String endtime, String item);
	public List<JoblogEntity> listAllByToday(String time);
}
