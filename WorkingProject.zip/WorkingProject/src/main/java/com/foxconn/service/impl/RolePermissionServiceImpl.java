package com.foxconn.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.foxconn.entity.RPEntity;
import com.foxconn.mapper.RPEntityMapper;
import com.foxconn.service.RolePermissionService;
@Service
public class RolePermissionServiceImpl implements RolePermissionService {

	@Autowired
	private RPEntityMapper rpMapper;
	@Override
	public int insertRolePermission(RPEntity rpEntity) {
		int i = -1;
		i = rpMapper.insert(rpEntity);
		return i;
	}

	@Override
	public int delRolePermission(String id) {
		int i = -1;
		i = rpMapper.deleteByPrimaryKey(id);
		return i;
	}

	@Override
	public List<RPEntity> listAll() {
		// TODO Auto-generated method stub
		return rpMapper.listAll();
	}

	@Override
	@Transactional
	public List<RPEntity> listByRoleId(String roleId) {
		// TODO Auto-generated method stub
		List<RPEntity> roleList = rpMapper.listByRoleId(roleId);
		return roleList;
	}

	@Override
	public int delRolePermissionByRoleIds(String [] roleIds) {
		int i = -1;
		i = rpMapper.delRolePermissionByRoleIds(roleIds);
		return i;
	}

	@Override
	public int delListByIds(List<String> delList, String roleId) {
		int i = -1;
		i = rpMapper.delListByIds(delList, roleId);
		return i;
	}

	@Override
	public int insertListBtIds(List<String> addList, String roleId) {
		int i = -1;
		i = rpMapper.insertListByIds(addList, roleId);
		return i;
	}

}
