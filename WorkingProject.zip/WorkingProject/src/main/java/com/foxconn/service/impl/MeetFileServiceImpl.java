package com.foxconn.service.impl;

import java.io.File;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.entity.MeetFileEntity;
import com.foxconn.mapper.MeetFileEntityMapper;
import com.foxconn.service.MeetFileService;
@Service
public class MeetFileServiceImpl implements MeetFileService{

	@Autowired
	private MeetFileEntityMapper meetFileMapper;
	@Override
	public int addFile(MeetFileEntity file) {
		// TODO Auto-generated method stub
		return meetFileMapper.insertSelective(file);
	}

	@Override
	public int delFileByid(String mfId) {
		// TODO Auto-generated method stub
		MeetFileEntity meetFile = this.getMeetFileByPrimaryKey(mfId);
		if (null == meetFile) {
			return -1;
		}
		File file = new File(meetFile.getFileurl());
		return meetFileMapper.deleteByPrimaryKey(mfId);
	}

	@Override
	public int delFileByMeetId(String meetId) {
		// TODO Auto-generated method stub
		List<MeetFileEntity> fileMeets = this.findByMeetId(meetId);
		for (MeetFileEntity meetFile : fileMeets) {
			File file = new File(meetFile.getFileurl());
		}
		return meetFileMapper.delFileByMeetId(meetId);
	}

	@Override
	public List<MeetFileEntity> findByMeetId(String meetId) {
		// TODO Auto-generated method stub
		return meetFileMapper.findByMeetId(meetId);
	}

	@Override
	public MeetFileEntity getMeetFileBymeetidAndFileurl(String meetid, String fileurl) {
		// TODO Auto-generated method stub
		return meetFileMapper.getMeetFileBymeetidAndFileurl(meetid,fileurl);
	}

	@Override
	public MeetFileEntity getMeetFileByPrimaryKey(String mfId) {
		// TODO Auto-generated method stub
		return meetFileMapper.selectByPrimaryKey(mfId);
	}

}
