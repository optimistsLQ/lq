package com.foxconn.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.entity.DatafileEntity;
import com.foxconn.mapper.DatafileEntityMapper;
import com.foxconn.service.DatafileService;
@Service
public class DatafileServiceImpl implements DatafileService {

	@Autowired
	private DatafileEntityMapper fileMapper;
	
	@Override
	public int addFile(DatafileEntity datafile) {
		// TODO Auto-generated method stub
		return fileMapper.insertSelective(datafile);
	}

	@Override
	public int delFileById(String datafileId) {
		// TODO Auto-generated method stub
		return fileMapper.deleteByPrimaryKey(datafileId);
	}

	@Override
	public int delFileByUploader(String uploaderId) {
		// TODO Auto-generated method stub
		return fileMapper.delFileByUploader(uploaderId);
	}

	@Override
	public List<DatafileEntity> findAllFile(String uploaderId, String uploader, String item, String start, String length) {
		// TODO Auto-generated method stub
		return fileMapper.findAllFile(uploaderId,uploader,item,start,length);
	}

	@Override
	public int countAllFile(String uploaderId, String uploader, String item) {
		// TODO Auto-generated method stub
		return fileMapper.countAllFile(uploaderId, uploader, item);
	}

	@Override
	public DatafileEntity findFileById(String datafileId) {
		// TODO Auto-generated method stub
		return fileMapper.selectByPrimaryKey(datafileId);
	}

}
