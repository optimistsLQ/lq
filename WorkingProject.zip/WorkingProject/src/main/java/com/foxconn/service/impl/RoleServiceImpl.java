package com.foxconn.service.impl;

import java.util.Arrays;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.foxconn.entity.RoleEntity;
import com.foxconn.mapper.RoleEntityMapper;
import com.foxconn.service.RolePermissionService;
import com.foxconn.service.RoleService;
@Service
public class RoleServiceImpl implements RoleService {

	@Autowired
	private RoleEntityMapper roleMapper;
	@Autowired
	private RolePermissionService rpService;
	@Override
	public String  insertRole(RoleEntity role) {
		int i = roleMapper.insertRoleGetId(role);
		String id = role.getRoleId();
		return id;

	}

	@Override
	@Transactional
	public int  delRoles(List<String> roleids) {
		int code = roleMapper.deleteByPrimaryKey(roleids);
//		rpService.delRolePermissionByRoleId(roleId);
		return code;
	}

	@Override
	public List<RoleEntity> listRoleAll() {
		return roleMapper.listAllRole();
	}
	@Override
	@Transactional
	public int insertRoleGetId(RoleEntity roleEntity, String[] menus) {	
		roleMapper.insertRoleGetId(roleEntity);
		String roleId = roleEntity.getRoleId();
		List<String> list = Arrays.asList(menus);
		int code = rpService.insertListBtIds(list, roleId);
		return code;
	}

	@Override
	public List<RoleEntity> findAllRolePermission() {
		// TODO Auto-generated method stub
		return roleMapper.findAllRolePermission();
	}

	@Override
	public List<RoleEntity> findAllRoleUserPermission() {
		// TODO Auto-generated method stub
		return roleMapper.findAllRoleUserPermission();
	}

	@Override
	public RoleEntity findOneRoleUserPermission(String roleId) {
		// TODO Auto-generated method stub
		return roleMapper.findOneRoleUserPermission(roleId);
	}

	@Override
	public int updateRoel(RoleEntity role) {
		int i = roleMapper.updateByPrimaryKeySelective(role);
		return i;
	}
}
