package com.foxconn.service;

import java.util.List;

import com.foxconn.entity.Meetcontents;

/**會議記錄neirong接口
 * @author C3410596
 *
 */
public interface MeetcontentsService {

	public int addMeetcontents(Meetcontents meet);
	public int delMeetcontentsById(String meetId);
	public int updateMeecontents(Meetcontents meet);
	public Meetcontents getMeetcontentsById(String meetId);
	public List<Meetcontents> listMeetcontentsByMeetId(String meetId);
	public int delMeetcontentsBtMeetId(String meetId);
}
