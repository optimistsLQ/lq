package com.foxconn.service;

import java.util.List;
import java.util.Map;

import com.foxconn.entity.UserEntity;

/**用户业务层接口
 * @author C3410596
 *
 */
public interface UserService {
    
    /**
     * 通過用戶id獲取User對象
     * @param userId 
     * @return User 對象
     **/
	UserEntity getUserById(String userId);
    
    /**
     * 將用戶數據插入到數據庫中
     * @param user 用戶數據對象
     * @return boolean 是否插入成功
     **/
    boolean insertUser(UserEntity user);
    /**查询所有用户
     * @return 返回所有用户集合
     */
    List<UserEntity> listAllUser(String type);

	/**根据用户名查询用户
	 * @param userName
	 * @return
	 */
	UserEntity getUserByUserNumber(String userNumber);

	/**根据ID删除用户
	 * @param userId
	 */
	boolean delUser(List<String> userId);

	/**根据用户ID修改用户
	 * @param user
	 */
	boolean updateUser(UserEntity user);
	
	/**根據部門ID查詢用戶
	 * @param departId
	 * @return
	 */
	List<UserEntity> findUserByDepart(String[] ids);

	UserEntity getUserByNickname(String nickname);

	/**user 多功能修改方法
	 * @param argsMap <數據庫字段名，值> update t_user set 數據庫字段名='值'
	 * @param whereMap<條件字段名，條件list>  where 條件字段名 in (條件list)
	 * @return
	 */
	int updateUserObj(Map<String,String> argsMap, Map<String,List<String>> whereMap);
}
