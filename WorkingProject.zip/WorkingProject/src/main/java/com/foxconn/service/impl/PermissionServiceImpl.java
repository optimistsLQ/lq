package com.foxconn.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.entity.PermissionEntity;
import com.foxconn.mapper.PermissionEntityMapper;
import com.foxconn.service.PermissionService;
@Service
public class PermissionServiceImpl implements PermissionService {

	@Autowired
	private PermissionEntityMapper permissionMapper;
	@Override
	public int insertPermission(PermissionEntity permission) {
		// TODO Auto-generated method stub
		return permissionMapper.insert(permission);

	}

	@Override
	public int delPermission(String [] perId) {
		// TODO Auto-generated method stub
		return permissionMapper.deleteByPrimaryKeys(perId);

	}

	@Override
	public List<PermissionEntity> listAllPermission() {
		List<PermissionEntity> list = permissionMapper.listAllPermission();
		return list;
	}

	@Override
	public PermissionEntity getPermissionByPerName(String perName) {
		// TODO Auto-generated method stub
		return permissionMapper.getPermissionByPerName(perName);
	}

	@Override
	public PermissionEntity getPermissionByPerId(String perId) {
		// TODO Auto-generated method stub
		return permissionMapper.selectByPrimaryKey(perId);
	}

	@Override
	public int updatePermission(PermissionEntity permission) {
		// TODO Auto-generated method stub
		return permissionMapper.updateByPrimaryKeySelective(permission);
	}

	

}
