package com.foxconn.service;

import java.util.List;
import java.util.Map;

import com.foxconn.entity.TotallistEntity;

/**总待办事项业务接口
 * @author C3410596
 *
 */
public interface TotallistService {
	public int addTotallist(TotallistEntity totallist);
	public int delTotallist(String totallistId);
	public int updateTotallist(TotallistEntity totallist);
	public TotallistEntity getTotallistById(String totallistId);
	public List<TotallistEntity> listByItem(String item,String status, int start,int length,List<String> userIdList);
	
	public int countlistByItem (String item, String status,List<String> userIdList);
	
	public List<Map<String,Object>> count();
	public int updateTotallistByBatch(List<TotallistEntity> totalListupdate);

}
