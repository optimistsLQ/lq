package com.foxconn.service;

import java.util.List;
import java.util.Map;

import com.foxconn.entity.ChildlistEntity;



/**子待办事项实体
 * @author C3410596
 *
 */
public interface ChildlistService {
	public int addChildlist(ChildlistEntity Childlist);
	public int delChildlist(String ChildlistId);
	public int updateChildlist(ChildlistEntity Childlist);
	public ChildlistEntity getChildlistById(String ChildlistId);
	public List<ChildlistEntity> listByTotallistId(String totallistId,String endover);
	public int delChildlistByTotallistId(String totallistId);
	public List<Map<String, Object>> count();
	public int updateChildlistByBatch(List<ChildlistEntity> childListupdate);

}
