package com.foxconn.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.entity.UserEntity;
import com.foxconn.mapper.UserEntityMapper;
import com.foxconn.service.UserService;
@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserEntityMapper userMapper; 

	@Override
	public boolean insertUser(UserEntity user) {		
		int i = userMapper.insert(user);
		if (i == 0) {
			return false;			
		} else {
			return true;			
		}
	}

	@Override
	public List<UserEntity> listAllUser(String type) {
		// TODO Auto-generated method stub
		return userMapper.listAllUser(type);
	}

	@Override
	public UserEntity getUserByUserNumber(String userNumber) {
		// TODO Auto-generated method stub
		return userMapper.getUserByNumber(userNumber);
	}

	@Override
	public UserEntity getUserById(String userId) {
		// TODO Auto-generated method stub
		return userMapper.selectByPrimaryKey(userId);
	}

	@Override
	public boolean delUser(List<String> userId) {
		// TODO Auto-generated method stub
		int i = userMapper.deleteByPrimaryKey(userId);
		if(i == 0) {
			return false;
		} else {
			return true;
		}
	}

	@Override
	public boolean updateUser(UserEntity user) {
		// TODO Auto-generated method stub
		int i = userMapper.updateByPrimaryKeySelective(user);
		if(i == 0) {
			return false;
		} else {
			return true;
		}
	}

	@Override
	public List<UserEntity> findUserByDepart(String[] ids) {
		// TODO Auto-generated method stub
		return userMapper.listUserByDepart(ids);
	}

	@Override
	public UserEntity getUserByNickname(String nickname) {
		// TODO Auto-generated method stub
		return userMapper.getUserByNickname(nickname);
	}

	@Override
	public int updateUserObj(Map<String,String> argsMap, Map<String,List<String>> whereMap) {
		// TODO Auto-generated method stub
		return userMapper.updateUserObj(argsMap, whereMap);
	}

	

}
