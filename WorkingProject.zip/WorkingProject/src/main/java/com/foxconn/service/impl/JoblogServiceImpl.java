package com.foxconn.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.entity.JoblogEntity;
import com.foxconn.mapper.JoblogEntityMapper;
import com.foxconn.service.JoblogService;
@Service
public class JoblogServiceImpl implements JoblogService{

	
	@Autowired
	private JoblogEntityMapper jobMapper;
	@Override
	public int addJoblog(JoblogEntity jobLog) {
		// TODO Auto-generated method stub
		return jobMapper.insertSelective(jobLog);
	}

	@Override
	public int delJoblog(List<String> jobLogIds) {
		// TODO Auto-generated method stub
		int i = 0;
		for (String jobLogId : jobLogIds) {
			i += jobMapper.deleteByPrimaryKey(jobLogId);
		}
		return i;
	}

	@Override
	public int updateJoblog(JoblogEntity jobLog) {
		// TODO Auto-generated method stub
		return jobMapper.updateByPrimaryKeySelective(jobLog);
	}

	@Override
	public JoblogEntity getJoblog(String jobLogId) {
		// TODO Auto-generated method stub
		return jobMapper.selectByPrimaryKey(jobLogId);
	}

	@Override
	public List<JoblogEntity> findAllByitem(String jobtime,String endtime,  String item,String start,String length) {
		// TODO Auto-generated method stub
		return jobMapper.findAllByitem(jobtime,endtime,item,start,length);
	}

	@Override
	public int countAll(String jobtime,String endtime, String item) {
		// TODO Auto-generated method stub
		return jobMapper.countAll(jobtime,endtime,item);
	}

	@Override
	public List<JoblogEntity> listAllByToday(String time) {
		// TODO Auto-generated method stub
		return jobMapper.listAllByToday(time);
	}

}
