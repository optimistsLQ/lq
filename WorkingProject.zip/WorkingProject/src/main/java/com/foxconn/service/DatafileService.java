package com.foxconn.service;

import java.util.List;

import com.foxconn.entity.DatafileEntity;

/**文件上传业务接口
 * @author C3410596
 *
 */
public interface DatafileService {

	public int addFile(DatafileEntity datafile);
	public int delFileById(String datafileId);
	public int delFileByUploader(String uploaderId);
	List<DatafileEntity> findAllFile(String uploaderId,String uploader,String item,String start,String length);
	int countAllFile(String uploaderId,String uploader,String item);
	public DatafileEntity findFileById(String datafileId);
	
}
