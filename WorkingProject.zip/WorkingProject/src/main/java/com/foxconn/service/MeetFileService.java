package com.foxconn.service;

import java.util.List;

import com.foxconn.entity.MeetFileEntity;

public interface MeetFileService {

	public int addFile(MeetFileEntity file);
	public int delFileByid(String mfId);
	public int delFileByMeetId(String meetId);
	public List<MeetFileEntity> findByMeetId(String meetId);
	public MeetFileEntity getMeetFileBymeetidAndFileurl(String meetid, String fileurl);
	public MeetFileEntity getMeetFileByPrimaryKey(String mfId);
}
