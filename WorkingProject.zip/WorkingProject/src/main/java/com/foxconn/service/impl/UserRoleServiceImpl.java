package com.foxconn.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.entity.UREntity;
import com.foxconn.mapper.UREntityMapper;
import com.foxconn.service.UserRoleService;
@Service
public class UserRoleServiceImpl implements UserRoleService {

	@Autowired
	private UREntityMapper urMapper;
	@Override
	public void insertUserRole(UREntity urEentity) {
		urMapper.insert(urEentity);
		
	}

	@Override
	public void delUserRoleById(String urId) {
		urMapper.deleteByPrimaryKey(urId);
		
	}

	@Override
	public int delUserRoleByUserId(String userId) {
		
		return urMapper.delByUserId(userId);
	}

	@Override
	public List<UREntity> listByUserId(String userId) {
		// TODO Auto-generated method stub
		return urMapper.listByUserId(userId);
	}

	@Override
	public List<UREntity> listAll() {
		// TODO Auto-generated method stub
		return urMapper.listAll();
	}

	@Override
	public int changeUserRole(String userId, String[] roleIds)
	{
		// TODO Auto-generated method stub
		//查詢用戶原有的角色
		List<UREntity> oldRoleList = urMapper.listByUserId(userId);
		List<String> oldRole = new ArrayList<>();
		for (UREntity obj : oldRoleList){
			oldRole.add(obj.getRoleId());
		}
		List<String> addList = new ArrayList<>();
		for (String role : roleIds){
			if(!oldRole.contains(role)){
				addList.add(role);
			}else{
				oldRole.remove(role);
			}
		}
		int code = 0;
		System.out.println("addList:"+addList.toString());
		System.out.println("delList:"+oldRole.toString());
		if(CollectionUtils.isNotEmpty(addList)){
			code += urMapper.insertListByIds(userId, addList);
		}
		if(CollectionUtils.isNotEmpty(oldRole)){
			code += urMapper.delListByIds(userId, oldRole);
		}
		
		return code;
	}

}
