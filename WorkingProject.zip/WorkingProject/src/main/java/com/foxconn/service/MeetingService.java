package com.foxconn.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.Meetionnotes;

/**會議記錄接口
 * @author C3410596
 *
 */
public interface MeetingService {

	public int addMeeting(Meetionnotes meet);
	public int delMeetingById(String meetId);
	public int updateMeeting(Meetionnotes meet);
	public Meetionnotes getMeetById(String meetId);
	int countlistByItem (String item);
	public List<Meetionnotes> listByItem(String item, String start, String length);
}
