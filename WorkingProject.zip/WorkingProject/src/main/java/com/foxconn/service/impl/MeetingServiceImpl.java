package com.foxconn.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.entity.Meetionnotes;
import com.foxconn.mapper.MeetionnotesMapper;
import com.foxconn.service.MeetingService;

@Service
public class MeetingServiceImpl implements MeetingService{

	@Autowired
	private MeetionnotesMapper meetMapper;
	@Override
	public int addMeeting(Meetionnotes meet) {
		// TODO Auto-generated method stub
		return meetMapper.insertSelective(meet);
	}

	@Override
	public int delMeetingById(String meetId) {
		// TODO Auto-generated method stub
		return meetMapper.deleteByPrimaryKey(meetId);
	}

	@Override
	public int updateMeeting(Meetionnotes meet) {
		// TODO Auto-generated method stub
		return meetMapper.updateByPrimaryKeySelective(meet);
	}

	@Override
	public Meetionnotes getMeetById(String meetId) {
		// TODO Auto-generated method stub
		return meetMapper.selectByPrimaryKey(meetId);
	}

	/**
	 *條件查詢會議記錄
	 */
	@Override
	public List<Meetionnotes> listByItem(String item, String start, String length) {
		// TODO Auto-generated method stub
		return meetMapper.listByItem(item,start, length);
	}

	@Override
	public int countlistByItem(String item) {
		// TODO Auto-generated method stub
		return meetMapper.countlistByItem(item);
	}

}
