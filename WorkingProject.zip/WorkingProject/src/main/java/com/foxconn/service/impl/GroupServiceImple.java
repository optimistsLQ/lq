package com.foxconn.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.entity.GroupEntity;
import com.foxconn.mapper.GroupEntityMapper;
import com.foxconn.service.GroupService;

@Service
public class GroupServiceImple implements GroupService{

	@Autowired
	private GroupEntityMapper groupMapper;
	@Override
	public int addGroup(GroupEntity guoup) {
		// TODO Auto-generated method stub
		return groupMapper.insertSelective(guoup);
	}

	@Override
	public int delGroupByid(String gId) {
		// TODO Auto-generated method stub
		return groupMapper.deleteByPrimaryKey(gId);
	}

	@Override
	public int delGroupByGroupId(String groupId) {
		// TODO Auto-generated method stub
		return groupMapper.delGroupByGroupId(groupId);
	}

	@Override
	public int updateById(GroupEntity guoup) {
		// TODO Auto-generated method stub
		return groupMapper.updateByPrimaryKeySelective(guoup);
	}

	@Override
	public GroupEntity getGroupById(String gId) {
		// TODO Auto-generated method stub
		return groupMapper.selectByPrimaryKey(gId);
	}

	@Override
	public List<GroupEntity> getGroupsByGroupId(String groupId) {
		// TODO Auto-generated method stub
		return groupMapper.getGroupsByGroupId(groupId);
	}

	@Override
	public List<GroupEntity> listAllGroups() {
		// TODO Auto-generated method stub
		return groupMapper.listAllGroups();
	}

}
