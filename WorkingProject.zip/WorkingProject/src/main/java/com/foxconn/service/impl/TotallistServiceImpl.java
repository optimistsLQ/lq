package com.foxconn.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.entity.TotallistEntity;
import com.foxconn.mapper.TotallistEntityMapper;
import com.foxconn.service.TotallistService;

@Service
public class TotallistServiceImpl implements TotallistService{

	@Autowired
	private TotallistEntityMapper totallistMapper;
	@Override
	public int addTotallist(TotallistEntity totallist) {
		// TODO Auto-generated method stub
		return totallistMapper.insertSelective(totallist);
	}

	@Override
	public int delTotallist(String totallistId) {
		// TODO Auto-generated method stub
		return totallistMapper.deleteByPrimaryKey(totallistId);
	}

	@Override
	public int updateTotallist(TotallistEntity totallist) {
		// TODO Auto-generated method stub
		return totallistMapper.updateByPrimaryKeySelective(totallist);
	}

	@Override
	public TotallistEntity getTotallistById(String totallistId) {
		// TODO Auto-generated method stub
		return totallistMapper.selectByPrimaryKey(totallistId);
	}

	@Override
	public List<TotallistEntity> listByItem(String item,String status, int start,int length,List<String> userIdList) {
		// TODO Auto-generated method stub
		return totallistMapper.listByItem(item, status,start+"", length+"",userIdList);
	}

	@Override
	public int countlistByItem(String item, String status,List<String> userIdList) {
		// TODO Auto-generated method stub
		return totallistMapper.countlistByItem(item, status,userIdList);
	}

	@Override
	public List<Map<String, Object>> count() {
		// TODO Auto-generated method stub
		return totallistMapper.count();
	}

	@Override
	public int updateTotallistByBatch(List<TotallistEntity> totalListupdate) {
		// TODO Auto-generated method stub
		return totallistMapper.updateTotallistByBatch(totalListupdate);
	}

}
