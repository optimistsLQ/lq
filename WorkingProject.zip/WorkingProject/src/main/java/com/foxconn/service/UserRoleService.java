package com.foxconn.service;

import java.util.List;

import com.foxconn.entity.UREntity;


/**用户关联角色业务接口
 * @author C3410596
 *
 */
public interface UserRoleService {
	/**给用户添加权限
	 * @param urEentity
	 */
	void insertUserRole(UREntity urEentity);
	/**根据id删除用户权限
	 * @param urId 用户id
	 */
	void delUserRoleById(String urId);
	/**根据用户id删除用户所有权限
	 * @param userId 
	 */
	int delUserRoleByUserId(String userId);
	/**根据用户id查询用户拥有权限
	 * @param userId
	 * @return
	 */
	List<UREntity> listByUserId(String userId);
	/**查询所有用户的权限集合
	 * @return
	 */
	List<UREntity> listAll();
	/**
	 * 修改用戶的角色
	 * @param userId
	 * @param roleIds
	 * @return
	 */
	int changeUserRole(String userId,String [] roleIds);
}
