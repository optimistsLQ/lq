package com.foxconn.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.entity.ChildlistEntity;
import com.foxconn.mapper.ChildlistEntityMapper;
import com.foxconn.service.ChildlistService;

@Service
public class ChildlistServiceImpl implements ChildlistService{

	@Autowired
	private ChildlistEntityMapper childMapper;
	@Override
	public int addChildlist(ChildlistEntity Childlist) {
		// TODO Auto-generated method stub
		return childMapper.insertSelective(Childlist);
	}

	@Override
	public int delChildlist(String ChildlistId) {
		// TODO Auto-generated method stub
		return childMapper.deleteByPrimaryKey(ChildlistId);
	}

	@Override
	public int updateChildlist(ChildlistEntity Childlist) {
		// TODO Auto-generated method stub
		return childMapper.updateByPrimaryKeySelective(Childlist);
	}

	@Override
	public ChildlistEntity getChildlistById(String ChildlistId) {
		// TODO Auto-generated method stub
		return childMapper.selectByPrimaryKey(ChildlistId);
	}

	@Override
	public List<ChildlistEntity> listByTotallistId(String totallistId, String endover) {
		// TODO Auto-generated method stub
		return childMapper.listByTotallistId(totallistId, endover);
	}

	@Override
	public int delChildlistByTotallistId(String totallistId) {
		// TODO Auto-generated method stub
		return childMapper.delChildlistByTotallistId(totallistId);
	}

	@Override
	public List<Map<String, Object>> count() {
		// TODO Auto-generated method stub
		return childMapper.count();
	}

	@Override
	public int updateChildlistByBatch(List<ChildlistEntity> childListupdate) {
		// TODO Auto-generated method stub
//		System.out.println("..."+childListupdate);
		return childMapper.updateChildlistByBatch(childListupdate);
	}

}
