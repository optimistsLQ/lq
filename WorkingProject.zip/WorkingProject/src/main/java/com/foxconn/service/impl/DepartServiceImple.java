package com.foxconn.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.entity.Depart;
import com.foxconn.mapper.DepartMapper;
import com.foxconn.service.DepartService;

@Service
public class DepartServiceImple implements DepartService{

	@Autowired
	private DepartMapper departMapper;
	@Override
	public int insertDepart(Depart depart) {
		// TODO Auto-generated method stub
		return departMapper.insertSelective(depart);
	}

	@Override
	public int delDepartById(String departId) {
		// TODO Auto-generated method stub
		return departMapper.deleteByPrimaryKey(departId);
	}

	@Override
	public int updateDepart(Depart depart) {
		// TODO Auto-generated method stub
		return departMapper.updateByPrimaryKeySelective(depart);
	}

	@Override
	public List<Depart> listAllDepart() {
		// TODO Auto-generated method stub
		return departMapper.listAllDepart();
	}

	@Override
	public Depart getDepartById(String departId) {
		// TODO Auto-generated method stub
		return departMapper.selectByPrimaryKey(departId);
	}

}
