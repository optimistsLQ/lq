package com.foxconn.service;

import java.util.List;

import com.foxconn.entity.GroupEntity;

/**分組業務層接口
 * @author C3410596
 *
 */
public interface GroupService {

	public int addGroup(GroupEntity guoup);
	public int delGroupByid(String gId);
	public int delGroupByGroupId(String groupId);
	public int updateById(GroupEntity guoup);
	public GroupEntity getGroupById(String gId);
	public List<GroupEntity> getGroupsByGroupId(String groupId);
	public List<GroupEntity> listAllGroups();
}
