package com.foxconn.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.CellValue;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.util.ResourceUtils;
import org.springframework.web.multipart.MultipartFile;
public class Utils {

	//private static final Log logger = LogFactory.getLog(Utils.class);
	//正则表达式的预编译功能
	private static final Pattern compile = Pattern.compile("[A-Z]");
	
	/**
	 * 驼峰转下划线
	 * @param str
	 * @return
	 */
	public static String humpToLine(String str){
		Matcher matcher = compile.matcher(str);
		StringBuffer sb = new StringBuffer();
		while (matcher.find()) {
			matcher.appendReplacement(sb, "_"+matcher.group(0));
		}
		matcher.appendTail(sb);
		return sb.toString().toUpperCase();
	}
	
	/**
	 * 下划线命名转为驼峰命名
	 * @param underlineByName 下面线命名
	 **/
	public static String underlineToHump(String underlineByName) {
		StringBuilder result=new StringBuilder();
		String tempArray[]=underlineByName.split("_");
		for(String elements:tempArray) {
			if(result.length() == 0) {
				result.append(elements.toLowerCase());
			} else {
				result.append(elements.substring(0, 1).toUpperCase());
				result.append(elements.substring(1).toLowerCase());
			}
		}
		return result.toString();
	}
	/**
	 * 将集合拆分为多个集合
	 * @param list source List
	 * @param splitSize 拆分大小
	 * @return
	 */
	public static List<List<?>> splitCollection(List<?> list,int splitSize){
		List<List<?>> newList = new ArrayList<>();
		int sizeAll = list.size();
		int splitNum = sizeAll%splitSize;
		int number = sizeAll/splitSize;
		if(splitNum>0){
			number+=1;
		}
		for(int i = 0 ;i<number; i++){
			int listNum = i+1;//集合个数
			int startSize = i*splitSize;//0 500 1000
			int endSize = listNum*splitSize;//500 1000 1500
			
			if(listNum == number){
				newList.add(list.subList(startSize, list.size()));
			}else{
				newList.add(list.subList(startSize, endSize));
			}
		}
		return newList;
	}
	/**
	 * 檢測excel格式是否正確
	 * @param file
	 * @param cla
	 * @param isUpperCase
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("resource")
	public static boolean checkExcelLayout(MultipartFile file,Class<?> cla,int num){
		Integer totalShees = 0;
		InputStream is = null;
		XSSFWorkbook workbook = null;
		try {
			is = file.getInputStream();
			workbook = new XSSFWorkbook(is);
			totalShees = workbook.getNumberOfSheets();
			for(int k=0;k<totalShees;k++)//遍歷多張表
			{
				XSSFSheet sheet = workbook.getSheetAt(k);
				int firstRowNum = sheet.getRow(0).getPhysicalNumberOfCells();
				if(num == firstRowNum) {
					return true;
				}
			}
			return false;
		}catch (Exception e) {
			return false;
		}finally {
			if(workbook != null) {
				try {
					workbook.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if(is != null) {
				try {
					is.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	public static List<Object> readExcel(MultipartFile file,Class<?> cla,boolean isUpperCase) throws Exception{
		boolean checkSuffix = checkSuffix(file);
		Integer totalShees = 0;
		Integer totalRows = 0;
		
		Set<String> exists = new HashSet<String>();
		List<Object> list = new ArrayList<Object>();
		if(checkSuffix){
			InputStream is = null;
			XSSFWorkbook workbook = null;
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			try {
				is = file.getInputStream();
				workbook = new XSSFWorkbook(is);
				FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
				totalShees = workbook.getNumberOfSheets();
				for(int k=0;k<totalShees;k++)//遍歷多張表
				{
					XSSFSheet sheet = workbook.getSheetAt(k);
					Row row = null;
					totalRows = sheet.getPhysicalNumberOfRows();
					if(sheet.getRow(0)==null){
						continue;
					}
					int headLen = sheet.getRow(0).getPhysicalNumberOfCells();//得到表頭每行的總格數
					for (int i = 1; i < totalRows; i++) {//得到每一行
						String value = "";//保存每行的值
						row = sheet.getRow(i);
						for (int j = 0; j < headLen; j++) {
							Cell cell = row.getCell(j);//得到每行的每一格
							if(cell==null){//單元格不存在
								value+="-$";
								continue;
							}
							switch (cell.getCellTypeEnum()) {
							case STRING:
							{//字符串
								cell.setCellType(CellType.STRING);
								String stringValue;
								if (isUpperCase) 
								{
									stringValue = cell.getStringCellValue().toUpperCase().trim();
								}
								else
								{
									stringValue = cell.getStringCellValue().trim();
								}
								value += stringValue+"$";
								break;
							}
							case BOOLEAN:
							{
								boolean valueBol = cell.getBooleanCellValue();
								value += valueBol+"$";
								break;
							}
							case FORMULA:
							{//公式
								CellValue evaluate = evaluator.evaluate(cell);
								switch (evaluate.getCellTypeEnum()) {
									case STRING:
									{
										if (isUpperCase) 
										{
											value+=evaluate.getStringValue().toUpperCase().trim()+"$";
										}
										else
										{
											value+=evaluate.getStringValue().trim()+"$";
										}
										break;
									}
									case NUMERIC:
									{
										if(HSSFDateUtil.isCellDateFormatted(cell)){
											Date date = HSSFDateUtil.getJavaDate(evaluate.getNumberValue());
											value += sdf.format(date)+"$";
										//判断是否科学计数法
										}else if((evaluate.getNumberValue()+"").contains("E")
												|| (evaluate.getNumberValue()+"").length()>5){
											//取消科学计数法
											value += new DecimalFormat("0").format(evaluate.getNumberValue())+"$";
										} else {
											value += evaluate.getNumberValue()+"$";
										}
										break;
									}
									default:
										value += "未知公式$";
										break;
								}
								break;
							}
							case NUMERIC://數字
							{
								double cellNumberValue = cell.getNumericCellValue();
								//判斷是否可以格式化
								if(HSSFDateUtil.isCellDateFormatted(cell)){
									Date dateValue = HSSFDateUtil.getJavaDate(cellNumberValue);
									value += sdf.format(dateValue)+"$";
								//判断是否科学计数法
								} else if((cellNumberValue+"").contains("E")) {
									//取消科学计数法
						            NumberFormat nf = NumberFormat.getInstance();
						            //设置保留多少位小数
						            nf.setMaximumFractionDigits(20);
						            // 取消科学计数法
						            nf.setGroupingUsed(false);
									value += nf.format(cellNumberValue)+"$";
								} else {
									value += cellNumberValue+"$";
								}
								break;
							}
							case BLANK:
							{//空值
								value +="-$";
								break;
							}
							case ERROR:
							{//錯誤
								value +="#N/A$";
								break;
							}
							default:
								value += "未知類型$";
								break;
							}
						}
						String[] values = value.split("\\$");
						Object obj = cla.newInstance();
						int index = 0;
						for (Field fie:cla.getDeclaredFields()) {
							String fieldName = fie.getName().toLowerCase();
							if ("uid".equals(fieldName) || fieldName.startsWith("serial") || "writetime".equals(fieldName) || "createtime".equals(fieldName)) {
								continue;
							}
							for (Method method : cla.getDeclaredMethods()) {
								if(method.getName().startsWith("set") && method.getName().substring(3).toUpperCase().equals(fie.getName().toUpperCase())){
									String methodType = method.getParameterTypes()[0].getSimpleName();
									if(index>=values.length) continue;
									//字符串類型
									if(methodType.toLowerCase().equals("string")){
										method.invoke(obj, values[index]);
									//數字類型
									} else if(methodType.toLowerCase().equals("integer")){
										if(values[index].equals("-")){values[index]="0";}
										method.invoke(obj, (int)Double.parseDouble(values[index]));
									//小數類型
									}else if(methodType.toLowerCase().equals("double")){
										if(values[index].equals("-")){values[index]="0";}
										method.invoke(obj, Double.parseDouble(values[index]));
									//日期類型
									}else if(methodType.toLowerCase().equals("date")){
										Date date = null;
										try{
											String dateStr = values[index].replaceAll("/", "-");
											//正常日期
											if(dateStr.contains("-")){
												date = sdf.parse(dateStr);
											//非正常日期,純數字
											} else if(dateStr.matches("[0-9]+\\.?[0-9]*")){
												date = HSSFDateUtil.getJavaDate(Double.parseDouble(dateStr));
												//非正常日期,以1999年開始的日期,說明是MMdd格式
											    if(sdf.format(date).startsWith("19")){
											    	//补充年份和零
											    	if(dateStr.length()==3){
											    		date = new SimpleDateFormat("yyyyMMdd").parse(sdf.format(new Date()).split("-")[0]+"0"+dateStr);
											    	}
											    	//补充年份和零
											    	else if(dateStr.length()==2){
											    		String newDateSet = "";
											    		for(char c:dateStr.toCharArray()){
											    			newDateSet += ("0"+c);
											    		}
											    		date = new SimpleDateFormat("yyyyMMdd").parse(sdf.format(new Date()).split("-")[0]+newDateSet);
											    	//符合MMDD格式,补充年份
											    	} else {
											    		date = new SimpleDateFormat("yyyyMMdd").parse(sdf.format(new Date()).split("-")[0]+dateStr);
											    	}
												//非正常日期,yyyyMMdd格式的日期
												} else if(Long.parseLong(sdf.format(date).split("-")[0])
														> Long.parseLong(sdf.format(new Date()).split("-")[0])){
													date = new SimpleDateFormat("yyyyMMdd").parse(dateStr);
												}
											} else {
												date = new Date(0);
											}
										} catch(Exception e) {
											date = new Date(0);
										}
										method.invoke(obj, date);
									}
									index++;
									break;
								}
							}
						}
						if(!exists.contains(obj.toString())){
							exists.add(obj.toString());
							list.add(obj);
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
				throw new Exception(e);
			}finally{
				try {
					workbook.close();
					is.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return list;
	}
	/**
	 * 檢查文件後綴
	 * @param suffix
	 * @return
	 */
	public static boolean checkSuffix(MultipartFile file){
		String filename = file.getOriginalFilename();
		String suffix = filename.substring(filename.lastIndexOf(".")+1).toLowerCase();
		if(TYPE_XLSX.equalsIgnoreCase(suffix) && filename!="" && file.getSize()>0){
			return true;
		}else{
			return false;
		}
	}
	/**
	 * 排除static|velocity的修飾符字段
	 * 並且需要是private修飾字段
	 * @return boolean true 表示通過檢查
	 */
	public static boolean excludeField(int mod){
		if (Modifier.isPrivate(mod) && !Modifier.isStatic(mod) && !Modifier.isVolatile(mod)) {
			return true;
		}
		return false;
	}
	
	/**
	 * 生成表單號
	 **/
	public static String formNumber() {
		return UUID.randomUUID().toString().replaceAll("-", "").toUpperCase();
	}
	/**
	 * 生成uuid
	 **/
	public static String getUUID() {
		return UUID.randomUUID().toString().replaceAll("-", "").toUpperCase();
	}
	
	/**
	 * List的深度拷貝
	 * @param src 需要拷貝的集合
	 * @return 返回拷貝對象的結果
	 **/
	public static <T> List<T> ListDeepCopy(List<T> src) {
		if(src==null) return null;
		ByteArrayOutputStream byteOut = null;
		ObjectOutputStream out = null;
		ByteArrayInputStream byteIn = null;
		ObjectInputStream in = null;
		try {
			byteOut = new ByteArrayOutputStream(); 
			out = new ObjectOutputStream(byteOut); 
			out.writeObject(src); 
			byteIn = new ByteArrayInputStream(byteOut.toByteArray()); 
			in = new ObjectInputStream(byteIn); 
			@SuppressWarnings("unchecked") 
			List<T> dest = (List<T>) in.readObject();
			return dest; 
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(byteOut!=null) byteOut.close();
				if(out!=null) out.close();
				if(byteIn!=null) byteIn.close();
				if(in!=null) in.close();
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}
	
	/**
	 * 對象的深度拷貝
	 * @param src 需要拷貝的集合
	 * @return 返回拷貝對象的結果
	 **/
	public static Object ObjectDeepCopy(Object src)
	{
		try {
			ByteArrayOutputStream byteOut = new ByteArrayOutputStream(); 
			ObjectOutputStream out = new ObjectOutputStream(byteOut); 
			out.writeObject(src); 
			ByteArrayInputStream byteIn = new ByteArrayInputStream(byteOut.toByteArray()); 
			ObjectInputStream in = new ObjectInputStream(byteIn); 
			return in.readObject(); 
		} catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static final String TYPE_XLSX = "xlsx";
	public static final String DIR_UP_LOAD = "file";
	
	/**獲取項目路徑，并在該項目路徑下添加static/filedir/子文件夾，用於存放上傳文件
	 * @return 項目路徑+static/filedir/
	 */
	public static String getDataSharingUrl() {
		String projectUrl = null;
		try {
			File path = new File(ResourceUtils.getURL("classpath:").getPath());
			if (!path.exists()) {
				path = new File("");
				System.out.println("1>>>"+path);
			}
			File upload = new File(path.getAbsolutePath(), "static/filedir/");
			if (!upload.exists()) {
				upload.mkdirs();
				System.out.println("2>>>"+upload);
			}
			projectUrl = upload.getAbsolutePath() + File.separator;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return projectUrl;
	}
	
	/**
	 * 隨機生成一個四位數的驗證碼
	 **/
	public static String createVerificationCode() {
		StringBuffer verificationCode = new StringBuffer();
		Random random = new Random(System.currentTimeMillis());
		for (int i = 0; i<4; i++) {
			verificationCode.append(random.nextInt(10));
		}
		return verificationCode.toString();
	}
}
