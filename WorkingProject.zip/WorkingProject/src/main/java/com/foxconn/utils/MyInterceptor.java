package com.foxconn.utils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.foxconn.entity.UserEntity;

@Component
public class MyInterceptor implements HandlerInterceptor {

	private static final Log logger = LogFactory.getLog(MyInterceptor.class);
	/**
	 *進入控制器方法之前執行此方法
	 */
	@Override
	public boolean preHandle(HttpServletRequest req, HttpServletResponse resp, Object handler)
			throws Exception {
		logger.info("訪問地址:"+req.getServletPath());
//		logger.info("訪問主機:"+req.getRemoteAddr());
		UserEntity user = (UserEntity) req.getSession().getAttribute("user");
		if (null != user) {
			logger.info("訪客:"+user.getUserNumber()+" : "+user.getNickname());
			return true;
		} else {
			resp.sendRedirect("login.do");
			return false;
		}
	}

	/**
	 *進入控制器方法之後，返回model之前執行此方法
	 */
	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		// TODO Auto-generated method stub
		
	}

}
