package com.foxconn.utils;

import java.math.BigDecimal;
import java.math.RoundingMode;
/**
 * 精密计算工具类
 * @author Alen
 */
public class Exact {

	/**
	 * 乘法
	 * @param d1
	 * @param d2
	 * @return String 計算結果
	 * @note d1*d2
	 */
	public static String mul(String d1,String d2){
		BigDecimal b1 = new BigDecimal(d1);
		BigDecimal b2 = new BigDecimal(d2);
		return b1.multiply(b2).toPlainString();
	}
	/**
	 * 加法
	 * @param d1
	 * @param d2
	 * @return  String 計算結果
	 * @note d1+d2
	 */
	public static String add(String d1,String d2){
		BigDecimal b1 = new BigDecimal(d1);
		BigDecimal b2 = new BigDecimal(d2);
		return b1.add(b2).toPlainString();
	}
	/**
	 * 除法
	 * @param d1
	 * @param d2
	 * @return String 計算結果
	 * @note d1/d2
	 * 精确19位小数,采取四舍五入
	 */
	public static String div(String d1,String d2){
		// 除数不能为0
		if (Double.parseDouble(d2) == 0) { 
			return "0";
		}
		BigDecimal b1 = new BigDecimal(d1);
		BigDecimal b2 = new BigDecimal(d2);
		return b1.divide(b2,19,RoundingMode.HALF_UP).stripTrailingZeros().toPlainString();
	}
	/**
	 * 减法
	 * @param d1
	 * @param d2
	 * @return String 計算結果
	 * @note d1-d2
	 */
	public static String sub(String d1,String d2){
		BigDecimal b1 = new BigDecimal(d1);
		BigDecimal b2 = new BigDecimal(d2);
		return b1.subtract(b2).toPlainString();
	}
}
