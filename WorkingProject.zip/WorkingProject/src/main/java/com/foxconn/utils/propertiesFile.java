package com.foxconn.utils;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

//使用Properties實現多線層環境讀寫，多線程讀，單線程寫，保證讀沒有NULL
public class propertiesFile {
	
	public static String ReadProp(String path) {
		FileInputStream fileIn = null;
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		try {
			int len = 0;
			byte [] b = new byte[1024];
			fileIn = new FileInputStream(path);
			while((len=fileIn.read(b))!=-1) {
				baos.write(b, 0, len);
			}
			return new String(baos.toByteArray(),"UTF-8");
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (null != fileIn) fileIn.close();
				baos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
	
	public synchronized static boolean WriteProp(String path,String value) {
		boolean bool = false;
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(path);
			fos.write(value.getBytes("UTF-8"));
			bool = true;
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (null != fos) fos.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return bool;
	}

}
