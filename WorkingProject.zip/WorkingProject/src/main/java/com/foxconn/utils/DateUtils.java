package com.foxconn.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 日期獲取工具類
 **/
public class DateUtils {
	

	/**
	 * 獲取當前的系統時間
	 * 
	 * @param pattern 自定義匹配日期格式
	 * @return String 返回符合匹配格式的日期字串
	 **/
	public static String getCurrentDate(String pattern) {
		SimpleDateFormat dateFormat = new SimpleDateFormat(pattern);
		return dateFormat.format(new Date());
	}

	/**
	 * 2019-9-22 ==> 2019-09-22
	 * @param time
	 * @return
	 */
	public static String handleMonth(String time) {
		String[] split = time.split("-");
		if(split[1].length() == 1){
			split[1] = "0"+split[1];
		};
		if(split[2].length() == 7){
			split[2] = "0"+split[2];
		}
		String temp = "";
		for (int i = 0; i < split.length; i++) {
			if (i <= 1) {
				temp+=split[i]+"-";
			} else {
				temp+=split[i];
			}
		}
		time = temp;
		return time;
	}
	public static String _handleMonth(String time){
		String[] split = time.split("-");
		if(split[1].length() == 1){
			split[1] = "0"+split[1];
		}
		if(split[2].length() == 1){
			split[2] = "0"+split[2];
		}
		String temp = "";
		for (String string : split) {
			temp+=string+"-";
		}
		if(temp.endsWith("-")){
			temp = temp.substring(0, temp.length()-1);
		}
		return temp;
	}
}
