package com.foxconn.utils;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;

import com.foxconn.entity.ResponseStatus;
/**假分页工具
 * @author C3410596
 *inList 是传入的集合
 *currPage 当前页码
 *pageSize 每页显示的条数
 */
public class PagingTool {
	
	public static ResponseStatus<List<?>> paging(List<?> inList, int currPage, int pageSize) {
		System.out.println(inList.size()+"--"+currPage+"---"+pageSize);
		ResponseStatus<List<?>> rs = new ResponseStatus<>();
		// 获取当前页码的起始索引
		int startIndex = (currPage - 1) * pageSize;
		List<Object> list = new ArrayList<>();
		if (CollectionUtils.isNotEmpty(inList)) {
		for (int i = startIndex;i < (startIndex + pageSize);i ++) {
				if (inList.size() > i) {					
					list.add(inList.get(i));
				}
			}
			rs.setMessage("有数据");
		} else {
			rs.setMessage("未查到数据，集合为空");
		}
		rs.setData(list);
		rs.setAllPageCode((inList.size() + pageSize - 1)/pageSize);
	
		return rs;
	}
	
}
