package com.foxconn.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.util.ResourceUtils;
import org.springframework.web.multipart.MultipartFile;

public class FileUtils {

	/**上傳文件
	 * @param file
	 * @throws IOException 
	 * @throws Exception 
	 */
	public static String uploadFile(MultipartFile file) throws Exception {
			File path = new File(ResourceUtils.getURL("classpath:").getPath());
			if (!path.exists()) {
				path = new File("");
			}
			File filePath = new File(path.getAbsolutePath(),"static"+File.separator+"filedir"+File.separator);
			if (!filePath.exists()) {//如果static/filedir文件夹不存在，就创建
				filePath.mkdirs();
			}
			String realpath = filePath.getAbsolutePath()+File.separator+Utils.getUUID()+"~~~"+file.getOriginalFilename();
			File realfile = new File(realpath);
			file.transferTo(realfile);
		return realpath;
	}
	
	/**下载文件
	 * @param url
	 * @return
	 * @throws Exception 
	 */
	public static void downFile(HttpServletRequest req,HttpServletResponse resp,String url) {
		File file = new File(url);
		FileInputStream  inputStream = null;
		OutputStream outputstream = null;
		String filename = file.getName();
		System.out.println("***"+filename);
		if (filename.contains("~~~")) {
			filename = filename.split("~~~")[1];
		}
		String agent  = req.getHeader("User-Agent");
		try {
				if (agent.toLowerCase().indexOf("firefox") > 0) {
					filename = new String(filename.getBytes("UTF-8"),"ISO8859-1");
				} else if (agent.toUpperCase().indexOf("MSIE") > 0) {
					filename = URLEncoder.encode(filename, "UTF-8");
				} else {
					filename = new String(filename.getBytes("UTF-8"), "ISO8859-1");
				}
				inputStream = new FileInputStream(file);
				resp.setCharacterEncoding("utf-8");
				resp.setContentType("applicatoin/octet-stream");//支持苹果浏览器下载，避免出现XXX.pdf.doc问题
				resp.setHeader("Content-Disposition", "attachment;Filename="+filename);
				
				outputstream = resp.getOutputStream();
				byte [] bytes = new byte [2048];
				int len = 0;
				while((len = inputStream.read(bytes)) > 0) {
					outputstream.write(bytes,0,len);
				}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			try {
				if (null != outputstream) {
					outputstream.close();
				}if (null != inputStream) {
					inputStream.close();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
