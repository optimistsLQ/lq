package com.foxconn.utils;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

import com.jacob.activeX.ActiveXComponent;
import com.jacob.com.ComThread;
import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

public class ExcelUtil {

	/**
	 * HSSFWorkbook:是操作Excel2003以前（包括2003）的版本,扩展名是.xls
	 * XSSFWorkbook:是操作Excel2007的版本，扩展名是.xlsx
	 * 当数据量超出65536条后,这时应该用SXSSFworkbook.
	 * @param fileName
	 * @param list 内容为map结构
	 * @throws IOException 
	 */
	@SuppressWarnings("unchecked")
	public static void handleExcelDown(String fileName,String title,List<?> list,HttpServletResponse resp) {
		Workbook workbook = new SXSSFWorkbook();
		Sheet sheet = workbook.createSheet();
		// 第0行,生成表头
		Row headRow = sheet.createRow(0);
		int colum = 0;
		for (String titleStr : title.split(",")) {
			Cell cell = headRow.createCell(colum++, CellType.STRING);
			cell.setCellValue(titleStr);
		}
		// 生成表格
		for (int i = 0; i < list.size(); i++) {
			Row row = sheet.createRow(i+1);
			Map<String,Object> map = (Map<String,Object>)list.get(i);
			Set<Entry<String,Object>> entrySet = map.entrySet();
			Iterator<Entry<String, Object>> it = entrySet.iterator();
			colum = 0;
			while (it.hasNext()) {
				Entry<String, Object> entry = it.next();
				Object value = entry.getValue();
				if (value instanceof BigDecimal || value.toString().matches("^-?\\d+(\\.\\d+)?$")) {
					Cell cell = row.createCell(colum++, CellType.NUMERIC);
					cell.setCellValue(value==null?0:Double.parseDouble(value.toString()));
				} else {
					Cell cell = row.createCell(colum++, CellType.STRING);
					cell.setCellValue(value==null?"":value.toString());
				}
			}
		}
		resp.setContentType("application/vnd.ms-excel;charset=utf-8");
		resp.setHeader("Content-Disposition", "attachment;filename="+fileName+".xlsx");
		try {
			workbook.write(resp.getOutputStream());
			resp.getOutputStream().flush();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				workbook.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
//	/**
//	* 判断单元格是否为合并单元格
//	*/
//	private static Boolean isCombineCell(List<CellRangeAddress> listCombineCell, Cell cell, Sheet sheet) {
//		int firstC = 0;
//		int lastC = 0;
//		int firstR = 0;
//		int lastR = 0;
//		for (CellRangeAddress ca : listCombineCell) {
//			// 获得合并单元格的起始行, 结束行, 起始列, 结束列
//			firstC = ca.getFirstColumn();
//			lastC = ca.getLastColumn();
//			firstR = ca.getFirstRow();
//			lastR = ca.getLastRow();
//			if (cell.getColumnIndex() <= lastC && cell.getColumnIndex()>= firstC) {
//				if (cell.getRowIndex() <= lastR && cell.getRowIndex() >= firstR) {
//					return true;
//				}
//			}
//		}
//		return false;
//	}
	
    /**
     * 将EXCEL转为pdf
     * @param xlsfile 需转换的excel文档
     * @param pdffile 转换后pdf存放路径
     * @param isMargin pdf上左右是否存在间距
     */
    public static void excelToPdf(String xlsfile, String pdffile) {
    	excelToPdf(xlsfile,pdffile,true);
    }
	public static void excelToPdf(String xlsfile, String pdffile, boolean isMargin) {
	   	ActiveXComponent app = new ActiveXComponent("Excel.Application");
        try {
	          app.setProperty("Visible", new Variant(false));
	          app.setProperty("AutomationSecurity", new Variant(3));
	          Dispatch excels = app.getProperty("Workbooks").toDispatch();
	  		  Dispatch excel = Dispatch.invoke(excels,"Open",Dispatch.Method,new Object[] {
	  				  xlsfile,
	  				  new Variant(false),
	  				  new Variant(false) },
	  				  new int[9]).toDispatch();
	          Dispatch sheets = Dispatch.call(excel, "Worksheets").toDispatch();
	          Dispatch sheet = Dispatch.call(sheets, "Item", new Integer(1)).toDispatch();
	          Dispatch pageSetup = Dispatch.call(sheet, "PageSetup").toDispatch();
	          Dispatch.put(pageSetup, "PaperSize", new Integer(8));
	          Dispatch.put(pageSetup, "Zoom", false);
	          Dispatch.put(pageSetup, "FitToPagesWide", 1);
	          Dispatch.put(pageSetup, "FitToPagesTall", 100);
	          Dispatch.put(pageSetup, "TopMargin", (isMargin?10:0));
	          Dispatch.put(pageSetup, "RightMargin", (isMargin?10:0));
	          Dispatch.put(pageSetup, "LeftMargin", (isMargin?10:0));
	          Dispatch.put(pageSetup, "CenterHorizontally", true);
	          Dispatch.put(pageSetup, "CenterVertically", false);
	  		  Dispatch.invoke(excel,"ExportAsFixedFormat",Dispatch.Method,new Object[] {
	  				new Variant(0),
	  				pdffile,
	  				new Variant(0)
	  		  },new int[1]);
	          Dispatch.call(excel, "Close", new Variant(false));
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
            	app.invoke("Quit", new Variant[] {});
            	ComThread.Release();
			} catch (Exception e) {
				e.printStackTrace();
			}
        }
	}
	
	public static void main(String[] args) {
		File htmlFile = new File("C:\\Users\\C3410596\\Desktop\\","1.html");
		File pdfFile = new File("C:\\Users\\C3410596\\Desktop\\","100860.pdf");
		htmlToPDF(htmlFile,pdfFile);
	}
	
	/**
	 * HTML转IMG 通过WKHTMLTOPDF插件实现
	 **/
	public static void htmlToImage(File htmlFile, File imgFile) {
		wkHtmlTo(htmlFile,imgFile);
	}
	/**
	 * HTML转PDF 通过WKHTMLTOPDF插件实现
	 **/
	public static void htmlToPDF(File htmlFile, File pdfFile) {
		wkHtmlTo(htmlFile,pdfFile);
	}
	private static void wkHtmlTo(File htmlFile, File targetFile) {
		String htmlPath = htmlFile.getAbsolutePath();
		String targetPath = targetFile.getAbsolutePath();
		Process process = null;
		InputStream errorStream = null;
		InputStream successStream = null;
		try {
			//创建WKHTMLTOPDF允许对象
			Runtime runtime = Runtime.getRuntime();
			if(targetPath.toLowerCase().contains(".pdf"))
				process = runtime.exec("cmd /c wkhtmltopdf -L 0 -R 0  --page-size A3 \""+htmlPath+"\" \""+targetPath+"\"");
			else
				process = runtime.exec("cmd /c wkhtmltoimage \""+htmlPath+"\" \""+targetPath+"\"");
			errorStream = process.getErrorStream();
			successStream = process.getInputStream();
			Thread errorThread = new Thread(htmlToStreamMessage(errorStream));
			Thread successThread = new Thread(htmlToStreamMessage(successStream));
			errorThread.start();
			successThread.start();
			errorThread.join();
			successThread.join();
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(errorStream!=null) errorStream.close();
				if(successStream!=null) successStream.close();
			} catch(Exception e) {
				e.printStackTrace();
			}
			if(process!=null) process.destroy();
		}
	}
	
	/**
	 * HTML转PDF 辅助方法,读取WKHTMLTOPDF的信息
	 **/
	private static Runnable htmlToStreamMessage(InputStream is) {
		return () -> {
			BufferedInputStream bis = null;
			InputStreamReader isr = null;
			BufferedReader br = null;
			try {
				bis = new BufferedInputStream(is);
				isr = new InputStreamReader(bis,"BIG5");
				br = new BufferedReader(isr);
				String message = "";
				while ((message = br.readLine()) != null) {
					System.out.println(message);
				}
			} catch(Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if(bis!=null) bis.close();
					if(isr!=null) isr.close();
					if(br!=null) br.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		};
	}
}
