package com.foxconn.entity;

import java.io.Serializable;
import java.util.Date;

/**待办事项明细实体
 * @author C3410596
 *
 */
public class ChildlistEntity implements Serializable{
	private static final long serialVersionUID = 1226234965209863960L;

	private String childlistId;
	//总待办事项ID
    private String totallistId;
    // 子责任人
    private String zidri;
    // 子事项
    private String zichecklist;
    // 总目标日期
    private String dueday;
    // 子目标日期
    private String zichickpoint;
    // 是否完结
    private String endover;
    // 状态（5种）
    private String status = "On Going";

    private Date createtime;
    //備註
    private String remark1;

    private String zidriId;
    
    private String score;
    
    private String column1;

    public String getChildlistId() {
        return childlistId;
    }

    public void setChildlistId(String childlistId) {
        this.childlistId = childlistId == null ? null : childlistId.trim();
    }

    public String getTotallistId() {
        return totallistId;
    }

    public void setTotallistId(String totallistId) {
        this.totallistId = totallistId == null ? null : totallistId.trim();
    }

    public String getZidri() {
        return zidri;
    }

    public void setZidri(String zidri) {
        this.zidri = zidri == null ? null : zidri.trim();
    }

    public String getZichecklist() {
        return zichecklist;
    }

    public void setZichecklist(String zichecklist) {
        this.zichecklist = zichecklist == null ? null : zichecklist.trim();
    }

    public String getDueday() {
        return dueday;
    }

    public void setDueday(String dueday) {
        this.dueday = dueday == null ? null : dueday.trim();
    }

    public String getZichickpoint() {
        return zichickpoint;
    }

    public void setZichickpoint(String zichickpoint) {
        this.zichickpoint = zichickpoint == null ? null : zichickpoint.trim();
    }

    public String getEndover() {
        return endover;
    }

    public void setEndover(String endover) {
        this.endover = endover == null ? null : endover.trim();
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public String getRemark1() {
        return remark1;
    }

    public void setRemark1(String remark1) {
        this.remark1 = remark1 == null ? null : remark1.trim();
    }

    public String getzidriId() {
        return zidriId;
    }

    public void setzidriId(String zidriId) {
        this.zidriId = zidriId == null ? null : zidriId.trim();
    }

	public String getScore() {
		return score;
	}

	public void setScore(String score) {
		this.score = score;
	}

	public String getColumn1() {
		return column1;
	}

	public void setColumn1(String column1) {
		this.column1 = column1;
	}

	@Override
	public String toString() {
		return "ChildlistEntity [childlistId=" + childlistId + ", totallistId=" + totallistId + ", zidri=" + zidri
				+ ", zichecklist=" + zichecklist + ", dueday=" + dueday + ", zichickpoint=" + zichickpoint
				+ ", endover=" + endover + ", status=" + status + ", createtime=" + createtime + ", remark1=" + remark1
				+ ", zidriId=" + zidriId + ", score=" + score + ", column1=" + column1 + "]";
	}

}