package com.foxconn.entity;

import java.io.Serializable;

/**缺勤臨時對象
 * @author C3410596
 *
 */
public class AbsentDTO implements Serializable{
	private static final long serialVersionUID = 6648039096012270252L;
	private String cardNum;
	private String userName;
	private String absent;
	public String getCardNum() {
		return cardNum;
	}
	public void setCardNum(String cardNum) {
		this.cardNum = cardNum;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getAbsent() {
		return absent;
	}
	public void setAbsent(String absent) {
		this.absent = absent;
	}
	
}
