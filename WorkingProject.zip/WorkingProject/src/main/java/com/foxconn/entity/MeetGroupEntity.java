package com.foxconn.entity;

import java.util.Date;

public class MeetGroupEntity {
    private String mgId;

    private String mgName;

    private String mgDiscribe;

    private Date createtime;

    private String mgMember;

    private String file1;

    private String file2;

    private String file3;

    private String file4;

    public String getMgId() {
        return mgId;
    }

    public void setMgId(String mgId) {
        this.mgId = mgId == null ? null : mgId.trim();
    }

    public String getMgName() {
        return mgName;
    }

    public void setMgName(String mgName) {
        this.mgName = mgName == null ? null : mgName.trim();
    }

    public String getMgDiscribe() {
        return mgDiscribe;
    }

    public void setMgDiscribe(String mgDiscribe) {
        this.mgDiscribe = mgDiscribe == null ? null : mgDiscribe.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public String getMgMember() {
        return mgMember;
    }

    public void setMgMember(String mgMember) {
        this.mgMember = mgMember == null ? null : mgMember.trim();
    }

    public String getFile1() {
        return file1;
    }

    public void setFile1(String file1) {
        this.file1 = file1 == null ? null : file1.trim();
    }

    public String getFile2() {
        return file2;
    }

    public void setFile2(String file2) {
        this.file2 = file2 == null ? null : file2.trim();
    }

    public String getFile3() {
        return file3;
    }

    public void setFile3(String file3) {
        this.file3 = file3 == null ? null : file3.trim();
    }

    public String getFile4() {
        return file4;
    }

    public void setFile4(String file4) {
        this.file4 = file4 == null ? null : file4.trim();
    }
}