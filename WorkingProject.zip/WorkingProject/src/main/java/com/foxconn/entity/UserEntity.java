package com.foxconn.entity;

import java.io.Serializable;
import java.util.List;

/**用户实体
 * @author C3410596
 *
 */
public class UserEntity implements Serializable{
	private static final long serialVersionUID = 2908643773395452452L;
	// 用户ID
    private String userId;
    // 用户名
    private String userNumber;
    // 用户xingming
    private String nickname;
    // 密码
    private String pwd;
    // 电话
    private String phone;
    // 邮箱
    private String email;
    // 用户状态
    private int userStatus;
    // 部門ID
    private String departId;   
    // 最后一次登录时间
    private String lastLogintime;
    // 角色集合
    private List<RoleEntity> roleList;
   
    private Depart depart;
    
    private String proxy;
    
    private String starttime;
    
    private String endtime;
    // 黑白名单字段，用于区分需不需要写日志的人 Y表示要写 null表示不用写；
    private String roster;
    // 缺勤类别（事假、病假。。。）
    private String absent;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserNumber() {
		return userNumber;
	}
	public void setUserNumber(String userNumber) {
		this.userNumber = userNumber;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getUserStatus() {
		return userStatus;
	}
	public void setUserStatus(int userStatus) {
		this.userStatus = userStatus;
	}
	public String getDepartId() {
		return departId;
	}
	public void setDepartId(String departId) {
		this.departId = departId;
	}
	public String getLastLogintime() {
		return lastLogintime;
	}
	public void setLastLogintime(String lastLogintime) {
		this.lastLogintime = lastLogintime;
	}
	public List<RoleEntity> getRoleList() {
		return roleList;
	}
	public void setRoleList(List<RoleEntity> roleList) {
		this.roleList = roleList;
	}
	public Depart getDepart() {
		return depart;
	}
	public void setDepart(Depart depart) {
		this.depart = depart;
	}
	public String getProxy() {
		return proxy;
	}
	public void setProxy(String proxy) {
		this.proxy = proxy;
	}
	public String getStarttime() {
		return starttime;
	}
	public void setStarttime(String starttime) {
		this.starttime = starttime;
	}
	public String getEndtime() {
		return endtime;
	}
	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}
	public String getRoster() {
		return roster;
	}
	public void setRoster(String roster) {
		this.roster = roster;
	}
	public String getAbsent() {
		return absent;
	}
	public void setAbsent(String absent) {
		this.absent = absent;
	}
}