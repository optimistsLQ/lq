package com.foxconn.entity;

import java.io.Serializable;

public class ParamDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8817797004151297619L;
	private int start;
	private int length;
	private String order;
	private String orderField;
	private String mySearch;
	private String myEndover;
	private String groups;
	private String endTime;
	
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getGroups() {
		return groups;
	}
	public void setGroups(String groups) {
		this.groups = groups;
	}
	public String getMyEndover() {
		return myEndover;
	}
	public void setMyEndover(String myEndover) {
		this.myEndover = myEndover;
	}
	public int getStart() {
		return start;
	}
	public void setStart(int start) {
		this.start = start;
	}
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	public String getOrder() {
		return order;
	}
	public void setOrder(String order) {
		this.order = order;
	}
	public String getOrderField() {
		return orderField;
	}
	public void setOrderField(String orderField) {
		this.orderField = orderField;
	}
	
	public String getMySearch() {
		return mySearch;
	}
	public void setMySearch(String mySearch) {
		this.mySearch = mySearch;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "ParamDTO [start=" + start + ", length=" + length + ", order=" + order + ", orderField=" + orderField
				+ ", mySearch=" + mySearch + ", myEndover=" + myEndover + ", groups=" + groups + ", endTime=" + endTime
				+ "]";
	}
	

	

	
}
