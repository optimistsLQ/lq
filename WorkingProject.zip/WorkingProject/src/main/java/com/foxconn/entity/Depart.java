package com.foxconn.entity;

import java.io.Serializable;
import java.util.List;

/**?��??實�??
 * @author C3410596
 *
 */
public class Depart implements Serializable {
  

	private static final long serialVersionUID = -4078899711263788389L;
	private volatile String departId;
    // ?��????�稱
    private String departName;
    // ?��??�?�?
    private String departCode;
    // ??�註
    private String remarker;
    
    private volatile List<UserEntity> userList;


    public String getDepartId() {
		return departId;
	}

	public void setDepartId(String departId) {
		this.departId = departId;
	}

	public String getDepartName() {
        return departName;
    }

    public void setDepartName(String departName) {
        this.departName = departName == null ? null : departName.trim();
    }

    public String getDepartCode() {
        return departCode;
    }

    public void setDepartCode(String departCode) {
        this.departCode = departCode == null ? null : departCode.trim();
    }

    public String getRemarker() {
        return remarker;
    }

    public void setRemarker(String remarker) {
        this.remarker = remarker == null ? null : remarker.trim();
    }

	public List<UserEntity> getUserList() {
		return userList;
	}

	public void setUserList(List<UserEntity> userList) {
		this.userList = userList;
	}

	@Override
	public String toString() {
		return "Depart [departId=" + departId + ", departName=" + departName + ", departCode=" + departCode
				+ ", remarker=" + remarker + ", userList=" + userList + "]";
	}
}