package com.foxconn.entity;

import java.io.Serializable;

/**分組實體
 * @author C3410596
 *
 */
public class GroupEntity implements Serializable {
	private static final long serialVersionUID = 3902229736393904637L;

	private String gId;
//姓名
    private String userName;
//郵箱
    private String email;
//組名
    private String groupName;
//用戶ID
    private String userId;
//組ID
    private String groupsId;

    private String remark1;

    private String remark2;

    public String getgId() {
        return gId;
    }

    public void setgId(String gId) {
        this.gId = gId == null ? null : gId.trim();
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName == null ? null : userName.trim();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email == null ? null : email.trim();
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName == null ? null : groupName.trim();
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId == null ? null : userId.trim();
    }

    public String getGroupsId() {
        return groupsId;
    }

    public void setGroupsId(String groupsId) {
        this.groupsId = groupsId == null ? null : groupsId.trim();
    }

    public String getRemark1() {
        return remark1;
    }

    public void setRemark1(String remark1) {
        this.remark1 = remark1 == null ? null : remark1.trim();
    }

    public String getRemark2() {
        return remark2;
    }

    public void setRemark2(String remark2) {
        this.remark2 = remark2 == null ? null : remark2.trim();
    }

	@Override
	public String toString() {
		return "GroupEntity [gId=" + gId + ", userName=" + userName + ", email=" + email + ", groupName=" + groupName
				+ ", userId=" + userId + ", groupsId=" + groupsId + ", remark1=" + remark1 + ", remark2=" + remark2
				+ "]";
	}
    
}