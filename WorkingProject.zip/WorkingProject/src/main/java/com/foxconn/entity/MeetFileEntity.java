package com.foxconn.entity;

public class MeetFileEntity {
    private String mfId;

    private String meetId;

    private String fileurl;

    private String remark1;

    private String remark2;

    public String getMfId() {
        return mfId;
    }

    public void setMfId(String mfId) {
        this.mfId = mfId == null ? null : mfId.trim();
    }

    public String getMeetId() {
        return meetId;
    }

    public void setMeetId(String meetId) {
        this.meetId = meetId == null ? null : meetId.trim();
    }

    public String getFileurl() {
        return fileurl;
    }

    public void setFileurl(String fileurl) {
        this.fileurl = fileurl == null ? null : fileurl.trim();
    }

    public String getRemark1() {
        return remark1;
    }

    public void setRemark1(String remark1) {
        this.remark1 = remark1 == null ? null : remark1.trim();
    }

    public String getRemark2() {
        return remark2;
    }

    public void setRemark2(String remark2) {
        this.remark2 = remark2 == null ? null : remark2.trim();
    }

	@Override
	public String toString() {
		return "MeetFileEntity [mfId=" + mfId + ", meetId=" + meetId + ", fileurl=" + fileurl + ", remark1=" + remark1
				+ ", remark2=" + remark2 + "]/r/n";
	}
}