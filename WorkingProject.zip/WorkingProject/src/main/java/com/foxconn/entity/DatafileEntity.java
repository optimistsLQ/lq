package com.foxconn.entity;

import java.util.Date;

/**文件上传实体
 * @author C3410596
 *
 */
public class DatafileEntity {
    private String datafileId;

    private String datafileUrl;

    private String uploader;

    private String uploaderId;

    private Date createtime;

    private String remark1;

    private String remark2;

    public String getDatafileId() {
        return datafileId;
    }

    public void setDatafileId(String datafileId) {
        this.datafileId = datafileId == null ? null : datafileId.trim();
    }

    public String getDatafileUrl() {
        return datafileUrl;
    }

    public void setDatafileUrl(String datafileUrl) {
        this.datafileUrl = datafileUrl == null ? null : datafileUrl.trim();
    }

    public String getUploader() {
        return uploader;
    }

    public void setUploader(String uploader) {
        this.uploader = uploader == null ? null : uploader.trim();
    }

    public String getUploaderId() {
        return uploaderId;
    }

    public void setUploaderId(String uploaderId) {
        this.uploaderId = uploaderId == null ? null : uploaderId.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public String getRemark1() {
        return remark1;
    }

    public void setRemark1(String remark1) {
        this.remark1 = remark1 == null ? null : remark1.trim();
    }

    public String getRemark2() {
        return remark2;
    }

    public void setRemark2(String remark2) {
        this.remark2 = remark2 == null ? null : remark2.trim();
    }

	@Override
	public String toString() {
		return "DatafileEntity [datafileId=" + datafileId + ", datafileUrl=" + datafileUrl + ", uploader=" + uploader
				+ ", uploaderId=" + uploaderId + ", createtime=" + createtime + ", remark1=" + remark1 + ", remark2="
				+ remark2 + "]";
	}
    
}