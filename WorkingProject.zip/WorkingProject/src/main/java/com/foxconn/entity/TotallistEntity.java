package com.foxconn.entity;

import java.io.Serializable;
import java.util.Date;

/**总待办事项实体
 * @author C3410596
 *
 */
public class TotallistEntity implements Serializable {
	

	private static final long serialVersionUID = -6349285397720523288L;

	private String totallistId;
	//项次序号
    private String orderNumber;
    //区域
    private String localtion;
    //项目名
    private String projectName;
    //总责任人
    private String totaldri;
   
    //目标完成日期
    private String dueday;
    //备注項目說明
    private String remark;
    //是否完结
    private String endover = "N";
    //状态（5种）
    private String status = "Open";
    // 对应的所有子待办事项
    private ChildlistEntity childlists;

    private Date createtime;

    private String driId;

    private String remark2;
    
    private String changeddremark;
    
    private String score;
    
    private String column1;

	public String getTotallistId() {
		return totallistId;
	}

	public void setTotallistId(String totallistId) {
		this.totallistId = totallistId;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getLocaltion() {
		return localtion;
	}

	public void setLocaltion(String localtion) {
		this.localtion = localtion;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getTotaldri() {
		return totaldri;
	}

	public void setTotaldri(String totaldri) {
		this.totaldri = totaldri;
	}

	public String getDueday() {
		return dueday;
	}

	public void setDueday(String dueday) {
		this.dueday = dueday;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getEndover() {
		return endover;
	}

	public void setEndover(String endover) {
		this.endover = endover;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public ChildlistEntity getChildlists() {
		return childlists;
	}

	public void setChildlists(ChildlistEntity childlists) {
		this.childlists = childlists;
	}

	public Date getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public String getDriId() {
		return driId;
	}

	public void setDriId(String driId) {
		this.driId = driId;
	}

	public String getRemark2() {
		return remark2;
	}

	public void setRemark2(String remark2) {
		this.remark2 = remark2;
	}

	public String getChangeddremark() {
		return changeddremark;
	}

	public void setChangeddremark(String changeddremark) {
		this.changeddremark = changeddremark;
	}

	public String getScore() {
		return score;
	}

	public void setScore(String score) {
		this.score = score;
	}

	public String getColumn1() {
		return column1;
	}

	public void setColumn1(String column1) {
		this.column1 = column1;
	}

	@Override
	public String toString() {
		return "TotallistEntity [totallistId=" + totallistId + ", orderNumber=" + orderNumber + ", localtion="
				+ localtion + ", projectName=" + projectName + ", totaldri=" + totaldri + ", dueday=" + dueday
				+ ", remark=" + remark + ", endover=" + endover + ", status=" + status + ", childlists=" + childlists
				+ ", createtime=" + createtime + ", driId=" + driId + ", remark2=" + remark2 + ", changeddremark="
				+ changeddremark + ", score=" + score + ", column1=" + column1 + "]";
	}

   
}