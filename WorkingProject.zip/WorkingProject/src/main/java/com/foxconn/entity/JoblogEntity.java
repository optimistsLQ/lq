package com.foxconn.entity;

import java.io.Serializable;

/**工作日志实体类
 * @author C3410596
 *
 */
public class JoblogEntity implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 2515103867885531292L;

	private String joblogId;

    private String userId;

    private String userName;

    private String groupId;

    private String groupName;

    private String jobTime;
    //早上待办事项
    private String morning;
    //晚上完成状况
    private String evening;

    private String remark1;

    private String remark2;

    public String getJoblogId() {
        return joblogId;
    }

    public void setJoblogId(String joblogId) {
        this.joblogId = joblogId == null ? null : joblogId.trim();
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId == null ? null : userId.trim();
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName == null ? null : userName.trim();
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId == null ? null : groupId.trim();
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName == null ? null : groupName.trim();
    }

    public String getJobTime() {
        return jobTime;
    }

    public void setJobTime(String jobTime) {
        this.jobTime = jobTime == null ? null : jobTime.trim();
    }

    public String getMorning() {
        return morning;
    }

    public void setMorning(String morning) {
        this.morning = morning == null ? null : morning.trim();
    }

    public String getEvening() {
        return evening;
    }

    public void setEvening(String evening) {
        this.evening = evening == null ? null : evening.trim();
    }

    public String getRemark1() {
        return remark1;
    }

    public void setRemark1(String remark1) {
        this.remark1 = remark1 == null ? null : remark1.trim();
    }

    public String getRemark2() {
        return remark2;
    }

    public void setRemark2(String remark2) {
        this.remark2 = remark2 == null ? null : remark2.trim();
    }

	@Override
	public String toString() {
		return "JoblogEntity [joblogId=" + joblogId + ", userId=" + userId + ", userName=" + userName + ", groupId="
				+ groupId + ", groupName=" + groupName + ", jobTime=" + jobTime + ", morning=" + morning + ", evening="
				+ evening + ", remark1=" + remark1 + ", remark2=" + remark2 + "]";
	}
}