package com.foxconn.entity;

public class Meetcontents {
    private String meetcontantsId;

    private String meetId;

    private String meetType;

    private String typeContent;

    private String dutypeople;

    private String remark2;

    public String getMeetcontantsId() {
        return meetcontantsId;
    }

    public void setMeetcontantsId(String meetcontantsId) {
        this.meetcontantsId = meetcontantsId == null ? null : meetcontantsId.trim();
    }

    public String getMeetId() {
        return meetId;
    }

    public void setMeetId(String meetId) {
        this.meetId = meetId == null ? null : meetId.trim();
    }

    public String getMeetType() {
        return meetType;
    }

    public void setMeetType(String meetType) {
        this.meetType = meetType == null ? null : meetType.trim();
    }

    public String getTypeContent() {
        return typeContent;
    }

    public void setTypeContent(String typeContent) {
        this.typeContent = typeContent == null ? null : typeContent.trim();
    }

  

    public String getDutypeople() {
		return dutypeople;
	}

	public void setDutypeople(String dutypeople) {
		this.dutypeople = dutypeople;
	}

	public String getRemark2() {
        return remark2;
    }

    public void setRemark2(String remark2) {
        this.remark2 = remark2 == null ? null : remark2.trim();
    }
}