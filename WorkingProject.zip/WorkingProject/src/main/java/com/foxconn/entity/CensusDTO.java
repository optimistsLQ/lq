package com.foxconn.entity;

/**统计DTO
 * @author C3410596
 *
 */
public class CensusDTO{
	private String userName;
	private Integer totalOpen;
	private Integer totalGoing;
	private Integer totalRisk;
	private Integer totalOverdue;
	private Integer totalClose;
	private Integer totalNum = 0;
	
	private Integer childOpen;
	private Integer childGoing;
	private Integer childRisk;
	private Integer childOverdue;
	private Integer childClose;
	private Integer childNum = 0;
	
	private Integer thingStart = 0;
	
	private Integer thingEnd = 0; 
	
	public Integer getThingStart() {
		return thingStart;
	}
	public void setThingStart(Integer thingStart) {
		this.thingStart = thingStart;
	}
	public Integer getThingEnd() {
		return thingEnd;
	}
	public void setThingEnd(Integer thingEnd) {
		this.thingEnd = thingEnd;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Integer getTotalOpen() {
		return totalOpen;
	}
	public void setTotalOpen(Integer totalOpen) {
		this.totalOpen = totalOpen;
	}
	public Integer getTotalGoing() {
		return totalGoing;
	}
	public void setTotalGoing(Integer totalGoing) {
		this.totalGoing = totalGoing;
	}
	public Integer getTotalRisk() {
		return totalRisk;
	}
	public void setTotalRisk(Integer totalRisk) {
		this.totalRisk = totalRisk;
	}
	public Integer getTotalOverdue() {
		return totalOverdue;
	}
	public void setTotalOverdue(Integer totalOverdue) {
		this.totalOverdue = totalOverdue;
	}
	public Integer getTotalClose() {
		return totalClose;
	}
	public void setTotalClose(Integer totalClose) {
		this.totalClose = totalClose;
	}
	public Integer getTotalNum() {
		return totalNum;
	}
	public void setTotalNum(Integer totalNum) {
		this.totalNum = totalNum;
	}
	public Integer getChildOpen() {
		return childOpen;
	}
	public void setChildOpen(Integer childOpen) {
		this.childOpen = childOpen;
	}
	public Integer getChildGoing() {
		return childGoing;
	}
	public void setChildGoing(Integer childGoing) {
		this.childGoing = childGoing;
	}
	public Integer getChildRisk() {
		return childRisk;
	}
	public void setChildRisk(Integer childRisk) {
		this.childRisk = childRisk;
	}
	public Integer getChildOverdue() {
		return childOverdue;
	}
	public void setChildOverdue(Integer childOverdue) {
		this.childOverdue = childOverdue;
	}
	public Integer getChildClose() {
		return childClose;
	}
	public void setChildClose(Integer childClose) {
		this.childClose = childClose;
	}
	public Integer getChildNum() {
		return childNum;
	}
	public void setChildNum(Integer childNum) {
		this.childNum = childNum;
	}
	
	
//		list.sort(new Comparator<CensusDTO>() {
//			public Integer compare(CensusDTO o1, CensusDTO o2) {
//				try {
//					Method m1 = o1.getClass().getMethod("get"+type);
//					Method m2 = o2.getClass().getMethod("get"+type);
//					Integereger i1 = (Integereger)m1.invoke(o1);
//					Integereger i2 = (Integereger)m2.invoke(o2);
//					if(i1 < i2) {
//						return -1;
//					}
//				} catch (Exception e) {
//					e.prIntegerStackTrace();
//				}
//				return 1;
//			}
//		});

}
