package com.foxconn.entity;

import java.io.Serializable;

/**会议记录实体
 * @author C3410596
 *
 */
public class Meetionnotes implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 5982210229407227031L;

	private String meetId;
	// 会议名称
    private String meetName;
    // 会议主席
    private String meetChairman;
    // 会议时间
    private String meetTime;
    // 会议地点
    private String meetLocation;
    // 记录人
    private String noteTaker;
    // 参会人员
    private String joinPeople;
    // 缺席人员
    private String absentee;

    private String meetEndtime;

    private String responseBody;

    private String remark3;

    public String getMeetId() {
        return meetId;
    }

    public void setMeetId(String meetId) {
        this.meetId = meetId == null ? null : meetId.trim();
    }

    public String getMeetName() {
        return meetName;
    }

    public void setMeetName(String meetName) {
        this.meetName = meetName == null ? null : meetName.trim();
    }

    public String getMeetChairman() {
        return meetChairman;
    }

    public void setMeetChairman(String meetChairman) {
        this.meetChairman = meetChairman == null ? null : meetChairman.trim();
    }

    public String getMeetTime() {
        return meetTime;
    }

    public void setMeetTime(String meetTime) {
        this.meetTime = meetTime == null ? null : meetTime.trim();
    }

    public String getMeetLocation() {
        return meetLocation;
    }

    public void setMeetLocation(String meetLocation) {
        this.meetLocation = meetLocation == null ? null : meetLocation.trim();
    }

    public String getNoteTaker() {
        return noteTaker;
    }

    public void setNoteTaker(String noteTaker) {
        this.noteTaker = noteTaker == null ? null : noteTaker.trim();
    }

    public String getJoinPeople() {
        return joinPeople;
    }

    public void setJoinPeople(String joinPeople) {
        this.joinPeople = joinPeople == null ? null : joinPeople.trim();
    }

    public String getAbsentee() {
        return absentee;
    }

    public void setAbsentee(String absentee) {
        this.absentee = absentee == null ? null : absentee.trim();
    }
 

    public String getMeetEndtime() {
		return meetEndtime;
	}

	public void setMeetEndtime(String meetEndtime) {
		this.meetEndtime = meetEndtime;
	}

	public String getResponseBody() {
        return responseBody;
    }

    public void setResponseBody(String responseBody) {
        this.responseBody = responseBody == null ? null : responseBody.trim();
    }

    public String getRemark3() {
        return remark3;
    }

    public void setRemark3(String remark3) {
        this.remark3 = remark3 == null ? null : remark3.trim();
    }

	@Override
	public String toString() {
		return "Meetionnotes [meetId=" + meetId + ", meetName=" + meetName + ", meetChairman=" + meetChairman
				+ ", meetTime=" + meetTime + ", meetLocation=" + meetLocation + ", noteTaker=" + noteTaker
				+ ", joinPeople=" + joinPeople + ", absentee=" + absentee + ", meetEndtime=" + meetEndtime
				+ ", responseBody=" + responseBody + ", remark3=" + remark3 + "]";
	}
}