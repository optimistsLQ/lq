package com.foxconn.controller;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.foxconn.entity.AbsentDTO;
import com.foxconn.entity.Depart;
import com.foxconn.entity.ParamTransfer;
import com.foxconn.entity.ResponseStatus;
import com.foxconn.entity.RoleEntity;
import com.foxconn.entity.UREntity;
import com.foxconn.entity.UserEntity;
import com.foxconn.service.DepartService;
import com.foxconn.service.RoleService;
import com.foxconn.service.UserRoleService;
import com.foxconn.service.UserService;
import com.foxconn.utils.PagingTool;
import com.foxconn.utils.Utils;

/**
 * @author C3410596
 *
 */
@Controller
@RequestMapping("/user")
public class UserController {
	@Autowired
	private UserService userService;
	
	@Autowired
	private UserRoleService userRoleService;
	
	@Autowired
	private RoleService roleService;
	
	@Autowired
	private DepartService departService;
	
	
	@RequestMapping("/delUserById.do")
	@ResponseBody
	public String delUser(@RequestParam("userId[]")String [] userId) {
		List<String> useridList = Arrays.asList(userId);
		if (userService.delUser(useridList)) {
			for (String id : useridList) {
				userRoleService.delUserRoleByUserId(id);
			}
			return "删除成功";
		};
		return "删除失败";
	}
	
	@RequestMapping("/updateUser.do")
	@ResponseBody
	public Map<String, Integer> updateUser(UserEntity user,String adminRoleid) {
		Map<String, Integer> map = new HashMap<String, Integer>();
		if (userService.updateUser(user)) {
			userRoleService.delUserRoleByUserId(user.getUserId());
			userRoleService.insertUserRole(new UREntity(user.getUserId(), adminRoleid));
			map.put("msg", 1);
		} else {
			map.put("msg", -1);
		}
		return map;		
	}
	
	@RequestMapping("/updateUserEntity.do")
	@ResponseBody
	public String updateUserEntity(String proxyId,String startTime,String endTime,HttpSession session) {
		UserEntity user = (UserEntity) session.getAttribute("user");
		user.setProxy(proxyId);
		user.setStarttime(startTime);
		user.setEndtime(endTime);
		boolean bool = userService.updateUser(user);
		return bool+"";
	}
	
	@RequestMapping("/listAllUser.do")
	@ResponseBody
	public ResponseStatus<List<?>> listAllUser(String coming, String type, Integer currPage, ModelMap map) {
		if ("".equals(type)) {
			type = null;
		}		
		List<UserEntity> userList = userService.listAllUser(type);
		if ("absent".equals(coming)) {//缺勤
			List<UserEntity> userAbsentList = new ArrayList<UserEntity>();
			for (UserEntity userEntity : userList) {
				if (null != userEntity.getAbsent() && !"".equals(userEntity.getAbsent())) {
					userAbsentList.add(userEntity);
				}
			}
			ResponseStatus<List<?>> Absentlist = PagingTool.paging(userAbsentList, currPage, 10);
			Absentlist.setCurrPage(currPage);
			Absentlist.setMessage(userAbsentList.size()+"");
			return Absentlist;
		}
		ResponseStatus<List<?>> list = PagingTool.paging(userList, currPage, 10);
		list.setCurrPage(currPage);
		list.setMessage(userList.size()+"");
		return list;		
	}
	
	@RequestMapping("/getUserById.do")
	public String getUserById(String userId,ModelMap map, String com){
		UserEntity user = userService.getUserById(userId);
		List<RoleEntity> roleList = roleService.listRoleAll();
		ParamTransfer param = new ParamTransfer();
		param.setStart(0);
		param.setLength(Integer.MAX_VALUE);
		param.setOrderField("departName");
		param.setOrder("ASC");
		List<Depart> departList = departService.listAllDepart();
		map.addAttribute("departList", departList);
		map.addAttribute("user", user);
		map.addAttribute("roleList", roleList);
		map.addAttribute("com", com);
		return "admin/admin-update";		
	}
	
	@RequestMapping("/startStatus.do")
	@ResponseBody
	public Map<String,String> startStatus(String userId) {
		UserEntity user = userService.getUserById(userId);
		Map<String,String> result = new HashMap<String,String>();
		if (user.getUserStatus() == 0) {
			user.setUserStatus(1);
			if(userService.updateUser(user)) {
				result.put("msg", "OK");
				return result;
			}
		}
		result.put("msg", "NG");
		return result;
	}
	
	@RequestMapping("/stopStatus.do")
	@ResponseBody
	public Map<String,String> stopStatus(String userId) {
		UserEntity user = userService.getUserById(userId);
		Map<String,String> result = new HashMap<String,String>();
		if (user.getUserStatus() == 1) {
			user.setUserStatus(0);
			Boolean bl = userService.updateUser(user);
			result.put("msg", "OK");
		} else {
			result.put("msg", "NG");
		}
		return result;
	}
	
	@RequestMapping("/listUserByItem")
	@ResponseBody
	public String listUserByItem(String item) {
		List<UserEntity> userList = userService.listAllUser(item);
		List<String> list = new ArrayList<String>();
		for (UserEntity user : userList) {
			list.add(user.getNickname());
		}
		return JSONObject.toJSONString(list);
	}
	
	@RequestMapping("/getUserByNickname.do")
	@ResponseBody
	public String getUserByNickname(String nickname) {
		UserEntity user = userService.getUserByNickname(nickname);
		return JSONObject.toJSONString(user);
	}
	
	@RequestMapping("/toadminList.do")
	public String toAdminList() {
		return "admin/admin-list";
	}

	@RequestMapping("/fileLogin.do")
	public String fileLogin() {
		return "noPower";
	}

	@RequestMapping("/setRoster.do")
	@ResponseBody
	public String setRoster(String ids) {
		List<String> userIds = JSON.parseArray(ids, String.class);
		Map<String, String> argsMap = new HashMap<String, String>();
		argsMap.put("ROSTER", "null");
		int i = userService.updateUserObj(argsMap, null);
		//argsMap.clear();
		
		Map<String, String> _argsMap = new HashMap<String, String>();
		Map<String, List<String>> whereMap = new HashMap<String, List<String>>();
		whereMap.put("USER_ID", userIds);
		_argsMap.put("ROSTER", "Y");
		int j = userService.updateUserObj(_argsMap, whereMap);
		return ""+j;
	}
		
	/**上傳缺勤人資料，多次上傳會覆蓋
	 * @param file
	 * @return
	 */
	@RequestMapping("/uploadAbsent.do")
	@ResponseBody
	public String uploadAbsent(@RequestParam(value="file_data")MultipartFile file) {
		ResponseStatus<?> rr = new ResponseStatus<Object>();
		if (!Utils.checkSuffix(file)) {
			rr.setError("請上傳Excel文件");
			System.out.println("請上傳Excel文件");
			return JSON.toJSONString(rr);
		}
		if(!Utils.checkExcelLayout(file, AbsentDTO.class, 3)) {
			rr.setError("文件不正確");
			return JSON.toJSONString(rr);
		}
		Map<String, String> argsMap = new HashMap<String, String>();
		argsMap.put("ABSENT", "");
		
		
		List<UserEntity> AllUserList = userService.listAllUser(null);
		try {
			List<Object> list = Utils.readExcel(file, AbsentDTO.class, false);
			
			userService.updateUserObj(argsMap, null);
			//System.out.println(list.toString());
			for (Object object : list) {
				AbsentDTO absentobj = (AbsentDTO) object;
				//System.out.println(">>>"+absentobj.getCardNum()+"***"+absentobj.getUserName());
				String cardNum = absentobj.getCardNum();
				if (absentobj.getCardNum().contains(".")) {
					cardNum = absentobj.getCardNum().split("[.]")[0];
				}
				for (UserEntity user : AllUserList) {
					//System.out.println(user.getUserNumber()+"--"+user.getNickname());
					if (user.getUserNumber().equals(cardNum)) {
						user.setAbsent(absentobj.getAbsent());
						userService.updateUser(user);
					}
				}
			}
			rr.setMessage("上傳成功");
			rr.setStatus(0);
			System.out.println("1");
		} catch (Exception e) {
			System.out.println("2");
			// TODO Auto-generated catch block
			rr.setError("上傳失敗");
			e.getMessage();
			e.printStackTrace();
		}
		return JSON.toJSONString(rr);
	}
	
}
