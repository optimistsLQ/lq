package com.foxconn.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.foxconn.entity.ChildlistEntity;
import com.foxconn.entity.Depart;
import com.foxconn.entity.ParamDTO;
import com.foxconn.entity.ResponseStatus;
import com.foxconn.entity.TotallistEntity;
import com.foxconn.entity.UserEntity;
import com.foxconn.service.ChildlistService;
import com.foxconn.service.DepartService;
import com.foxconn.service.TotallistService;
import com.foxconn.service.UserService;
import com.foxconn.utils.DateUtils;
import com.foxconn.utils.EmailToolkit;
import com.foxconn.utils.PagingTool;

@Controller
@RequestMapping("/things")
public class ThingsController {
	@Autowired
	private TotallistService totalService;
	@Autowired
	private ChildlistService childService;
	@Autowired
	private UserService userService;
	@Autowired
	private DepartService departService;
	/**查詢總待辦事項
	 * @param param
	 * @param endover 是否完結
	 * @return
	 */
	@RequestMapping("/listAllTotallist.do")
	@ResponseBody
	public String listAllTotallist(ParamDTO param) {
		List<ChildlistEntity> childListupdate = new ArrayList<ChildlistEntity>();
		List<TotallistEntity> totalListupdate = new ArrayList<TotallistEntity>();
		
		
		List<String> userIdList = null;
		if (null != param.getGroups()) {
			userIdList = new ArrayList<String>();
			String [] groupIdarr = new String [1];
			groupIdarr[0] = param.getGroups();
			List<UserEntity> userList = userService.findUserByDepart(groupIdarr);
			if (null == userList || userList.size() == 0) {
				userIdList.add("wu");
			} else {
				for (UserEntity user : userList) {
					userIdList.add(user.getUserId());
				}
			}
			
		}
		
		long thisTime = new Date().getTime();//获取系统当前时间
		SimpleDateFormat chickTimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		List<TotallistEntity> listTotal = totalService.listByItem(param.getMySearch(), param.getMyEndover(),param.getStart(),param.getLength(),userIdList);
		boolean close = true;
		for (TotallistEntity totallistEntity : listTotal) {
			List<ChildlistEntity> childList = childService.listByTotallistId(totallistEntity.getTotallistId(), null);
			if (null != childList && childList.size() != 0) {
				TreeSet<Long> timeSet = new TreeSet<Long>();
				Map<Long, ChildlistEntity> ChildMpa = new HashMap<Long, ChildlistEntity>();
				close = true;
				for (ChildlistEntity childthings : childList) {
					try {
						if ("N".equals(childthings.getEndover())) {//筛选不是close的时间最紧迫的数据N
							long checkpointTime = chickTimeFormat.parse(childthings.getZichickpoint()).getTime();
							long time = checkpointTime - thisTime;
							timeSet.add(time);
							ChildMpa.put(time, childthings);
							close = false;
						} else {//Y 直接设置close
							childthings.setStatus("5_Close");
							//把子事项需要更新的实体放入childListupdate集合，由最后统一批量更新
							childListupdate.add(childthings);
						}
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				}
				if (close) {
					totallistEntity.setStatus("5_Close");
					totallistEntity.setEndover("Y");
					//把总事项需要更新的实体放入totalListupdate集合，由最后统一批量更新
					totalListupdate.add(totallistEntity);
//					totalService.updateTotallist(totallistEntity);
				}
				
				//timeSet找出最紧急child 设置近TotallistEntity
				Iterator<Long> it =timeSet.iterator();
				boolean bool = false;
				while(it.hasNext()) {
					long l = it.next();
					if (l > 0) {
						totallistEntity.setChildlists(ChildMpa.get(l));
						totalService.updateTotallist(totallistEntity);
						//把总事项需要更新的实体放入totalListupdate集合，由最后统一批量更新
//						totalListupdate.add(totallistEntity);
						bool = true;
						break;
					}
				}
				if (!bool && !timeSet.isEmpty()) {
					totallistEntity.setChildlists(ChildMpa.get(timeSet.first()));
				}
				
			} else {
				totallistEntity.setStatus("4_Open");
//				totalService.updateTotallist(totallistEntity);
				//把总事项需要更新的实体放入totalListupdate集合，由最后统一批量更新
				totalListupdate.add(totallistEntity);
				continue;
			}
			try {
				if (!close) {
					long duedaytime = chickTimeFormat.parse(totallistEntity.getDueday()).getTime();
					double day = (double)(duedaytime - thisTime)/1000/60/60/24;
					if (day >= 10) {
						totallistEntity.setStatus("3_On Going");
						totallistEntity.setEndover("N");
//						totalService.updateTotallist(totallistEntity);
						//把总事项需要更新的实体放入totalListupdate集合，由最后统一批量更新
						totalListupdate.add(totallistEntity);
					} else if (10 > day && day > 0) {
						totallistEntity.setStatus("2_Risk");
						totallistEntity.setEndover("N");
//						totalService.updateTotallist(totallistEntity);
						//把总事项需要更新的实体放入totalListupdate集合，由最后统一批量更新
						totalListupdate.add(totallistEntity);
					} else if (day <= 0) {
						totallistEntity.setEndover("N");
						totallistEntity.setStatus("1_Overdue");
//						totalService.updateTotallist(totallistEntity);
						//把总事项需要更新的实体放入totalListupdate集合，由最后统一批量更新
						totalListupdate.add(totallistEntity);
					}
				}
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		int i = totalService.countlistByItem(param.getMySearch(), param.getMyEndover(),userIdList);
		/**
		 * note:此处处理返回数据的序号显示问题
		 */
		for (int j = 0; j < listTotal.size(); j++) {
			TotallistEntity obj = listTotal.get(j);
			obj.setOrderNumber(String.valueOf((j+1)));
		}
		Map<String,Object> result = new HashMap<String,Object>();
		result.put("iTotalDisplayRecords", i);
		result.put("iTotalRecords", i);
		result.put("data", listTotal);
		long long2 = new Date().getTime();
		if (childListupdate.size() != 0) {
			childService.updateChildlistByBatch(childListupdate);//childListupdate集合批量更新子事项
		}
		if (totalListupdate.size() != 0) {
			totalService.updateTotallistByBatch(totalListupdate);//totalListupdate集合批量更新总事项
		}
		return JSONObject.toJSONString(result);
	}
	/**
	 * 添加Totallist
	 * @return
	 */
	@RequestMapping("addTotallist.do")
	@ResponseBody
	public String addTotallist(TotallistEntity totallist,String DRIIDS){
		//System.out.println("----"+totallist);
		String dueday = DateUtils.handleMonth(totallist.getDueday() + " 23:59");
		totallist.setDueday(dueday);
		totallist.setDriId(DRIIDS);
		totallist.setStatus("4_Open");
		String msg = "";
		int i = totalService.addTotallist(totallist);
		if (i > 0) {
			msg = "ok";
			if (null != DRIIDS) {
				UserEntity user = userService.getUserById(DRIIDS);
				EmailToolkit.sendEmail("总待辦事項："+totallist.getTotaldri()+"為你指派了新的任務---"+totallist.getProjectName(), "待辦事項為你指派了新的任務！具體請查看待辦事項-"+totallist.getProjectName(), user.getEmail());
			}
		} else {
			msg = "添加失敗！";
		}
		return msg;
	}
	
	@RequestMapping("/delTotallist.do")
	@ResponseBody
	public String delTotallist(String ids) {
		int i = 0;
		List<String> idList = JSONObject.parseArray(ids, String.class);
		for (String id : idList) {
			i += totalService.delTotallist(id);
			childService.delChildlistByTotallistId(id);
		}
		return i+"";
	}
	
	@RequestMapping("/updateTotallist.do")
	@ResponseBody
	public int udateTotallist(TotallistEntity totallist,String DRIIDS) {
		System.out.println(totallist);
		String dueday = DateUtils.handleMonth(totallist.getDueday() + " 23:59");
		totallist.setDueday(dueday);
		//查询
		totallist.setDriId(DRIIDS);
		TotallistEntity totalListDB = totalService.getTotallistById(totallist.getTotallistId());
		String duedayOld = totalListDB.getDueday();
		String duedayNew = totallist.getDueday();
		if (!duedayNew.equals(duedayOld)) {//改变
			String oldRemark = totalListDB.getRemark2();
			if(oldRemark != null){
				oldRemark += duedayOld+",";
				totallist.setRemark2(oldRemark+",");
			}else{
				totallist.setRemark2(duedayOld+",");
			}
		}
		int code = totalService.updateTotallist(totallist);
		return code;
	}
	
	/**跳轉到子待辦事項
	 * @param totallistId
	 * @return
	 */
	@RequestMapping("/toChildlist.do")
	public String toChildlist(String totallistId, ModelMap map) {
		TotallistEntity totalthings = totalService.getTotallistById(totallistId);
		map.addAttribute("totallistId", totallistId);
		map.addAttribute("dueday", totalthings.getDueday());
		map.addAttribute("projectName", totalthings.getProjectName());
		map.addAttribute("totaldriId", totalthings.getDriId());
		return "meet/child-list";
	}
	
	/**查詢zi待辦事項
	 * @param param
	 * @param endover 是否完結
	 * @return
	 */
	@RequestMapping("/listAllChildlist.do")
	@ResponseBody
	public Map<String, Object> listAllChildlist(ParamDTO param, String totallistId) {
		SimpleDateFormat chickTimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		long currentTime = new Date().getTime();
		List<ChildlistEntity> listChild = childService.listByTotallistId(totallistId, param.getMyEndover());
		ResponseStatus<List<?>> source = PagingTool.paging(listChild, param.getStart()/param.getLength()+1, param.getLength());
		for (Object childlistEntity : source.getData()) {
			ChildlistEntity childlist = (ChildlistEntity)childlistEntity;
			try {
				long chickTime = chickTimeFormat.parse(childlist.getZichickpoint()).getTime();
				double day = (double)(chickTime - currentTime)/1000/60/60/24;
				if (day >= 10 && "N".equals(childlist.getEndover())) {
					childlist.setStatus("3_On Going");
					childService.updateChildlist(childlist);
				} else if (10 > day && day > 0 && "N".equals(childlist.getEndover())) {
					childlist.setStatus("2_Risk");
					childService.updateChildlist(childlist);
				} else if (day <= 0 && "N".equals(childlist.getEndover())) {
					childlist.setStatus("1_Overdue");
					childService.updateChildlist(childlist);
				}
				if ("Y".equals(childlist.getEndover())) {
					childlist.setStatus("5_Close");
					childService.updateChildlist(childlist);
				}
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		Map<String,Object> result = new HashMap<String,Object>();
		result.put("iTotalDisplayRecords", listChild.size());
		result.put("iTotalRecords", listChild.size());
		result.put("data", source.getData());
		return result;
	}
	
	/**
	 * 添加子Chlidlist
	 * @return
	 */
	@RequestMapping("addChlidlist.do")
	@ResponseBody
	public String addChlidlist(ChildlistEntity Chlidlist,String DRIIDS, String zidri_DRIIDS){
		String zicheckpoint = DateUtils.handleMonth(Chlidlist.getZichickpoint() + " 23:59");
		Chlidlist.setZichickpoint(zicheckpoint);
		Chlidlist.setzidriId(DRIIDS);
		int i = 0;
		String msg = "";
		if (Chlidlist.getZichickpoint().compareTo(Chlidlist.getDueday()) <= 0) {
			 i = childService.addChildlist(Chlidlist);
		} else {
			msg = "子Dueday时间点必須小於總Dueday時間點";
		}
		if (i > 0) {
			msg = "ok";
			if(null != zidri_DRIIDS && !"".equals(zidri_DRIIDS)) {
				String [] idarr = zidri_DRIIDS.split("，");
				String emails = "";
				for (int j=0; j<idarr.length;j++) {
					if (j == idarr.length-1) {
						emails = emails + userService.getUserById(idarr[j]).getEmail();
					}else {
						emails = emails + userService.getUserById(idarr[j]).getEmail()+",";
					}
				}
				TotallistEntity totallistEntity = totalService.getTotallistById(Chlidlist.getTotallistId());
				EmailToolkit.sendEmail("子待辦事項："+totallistEntity.getTotaldri()+"為你指派了新的任務--"+totallistEntity.getProjectName(), "待辦事項為你指派了新的任務！具體請查看待辦事項-"+totallistEntity.getProjectName(), emails);
				
			}
		} 
		return msg;
	}
	
	/**刪除子待辦事項
	 * @param ids
	 * @return
	 */
	@RequestMapping("/delChildlist.do")
	@ResponseBody
	public String delChildlist(String ids) {
		int i = 0;
		List<String> idList = JSONObject.parseArray(ids, String.class);
		for (String id : idList) {
			i += childService.delChildlist(id);
		}
		return i+"";
	}
	
	/**修改子待辦事項
	 * @param Childlist
	 * @return
	 */
	@RequestMapping("/updateChildlist.do")
	@ResponseBody
	public String udateChildlist(ChildlistEntity Childlist,String DRIIDS) {
		int i = 0;
		String dueday = childService.getChildlistById(Childlist.getChildlistId()).getDueday();
		String zicheckpoint = DateUtils.handleMonth(Childlist.getZichickpoint() + " 23:59");
		if (zicheckpoint.compareTo(dueday) <= 0) {
			Childlist.setZichickpoint(zicheckpoint);
			Childlist.setzidriId(DRIIDS);
			i = childService.updateChildlist(Childlist);
			return i+"";
		}else {
			return 0+"";
		}
		
	}
	/**跳轉totalThings页面
	 * @param url
	 * @return
	 */
	@RequestMapping("/toTotalThings.do")
	public String toTotalThings(ModelMap map) {
		List<Depart> listDepart = departService.listAllDepart();
		map.addAttribute("listDepart", listDepart);
		return "meet/things-list";
	}
	/**跳轉代理設置頁面
	 * @param url
	 * @return
	 */
	@RequestMapping("/toChoseUser.do")
	public String toChoseUser(ModelMap map) {
		List<UserEntity> userList = userService.listAllUser(null);
		map.addAttribute("userList", userList);
		return "meet/choseUser";
	}

	/**跳轉星星頁面
	 * @return
	 */
	@RequestMapping("/toStart.do")
	public String toStart(String come, String ID, ModelMap map) {
		if ("totallist".equals(come)) {
			TotallistEntity totallistEntiey = totalService.getTotallistById(ID);
			String totalScore = totallistEntiey.getScore();
			map.addAttribute("score", totalScore);
		}else if ("childlist".equals(come)) {
			ChildlistEntity childlistEntity = childService.getChildlistById(ID);
			String childScore = childlistEntity.getScore();
			map.addAttribute("score", childScore);
		}
		
		return "meet/start";
	}
	
	@RequestMapping("/updateStart.do")
	@ResponseBody
	public String updateStart(String come, String ID, String score) {
		int i = 0;
		if ("totallist".equals(come)) {//表示從totallist頁面來
			TotallistEntity totallistEntiey = totalService.getTotallistById(ID);
			totallistEntiey.setScore(score);
			i += totalService.updateTotallist(totallistEntiey);
		}else if ("childlist".equals(come)) {
			ChildlistEntity childlistEntity = childService.getChildlistById(ID);
			childlistEntity.setScore(score);
			i += childService.updateChildlist(childlistEntity);
		}
		return i+"";
	}
}
