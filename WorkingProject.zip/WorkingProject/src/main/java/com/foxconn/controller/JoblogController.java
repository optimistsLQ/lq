package com.foxconn.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.foxconn.entity.JoblogEntity;
import com.foxconn.entity.ParamDTO;
import com.foxconn.entity.UserEntity;
import com.foxconn.service.JoblogService;
import com.foxconn.service.UserService;
import com.foxconn.utils.DateUtils;

@Controller
@RequestMapping("/jobLog")
public class JoblogController {

	@Autowired
	private JoblogService jobLogService;
	@Autowired
	private UserService userService;
	
	@RequestMapping("/addJobLog.do")
	@ResponseBody
	public String addJobLog(JoblogEntity joblog,HttpSession session) {
		UserEntity sessionUser = (UserEntity) session.getAttribute("user");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		joblog.setUserId(sessionUser.getUserId());
		joblog.setUserName(sessionUser.getNickname());
		joblog.setGroupId(sessionUser.getDepart().getDepartId());
		joblog.setGroupName(sessionUser.getDepart().getDepartName());
//		String jobtime = DateUtils._handleMonth(joblog.getJobTime());
		String jobtimes;
		try {
			jobtimes = format.format(format.parse(joblog.getJobTime()));
			joblog.setJobTime(jobtimes);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int i = jobLogService.addJoblog(joblog);
		String msg = "";
		if (i > 0) {
			msg = "ok";
		}else {
			msg = "添加失敗！";
		}
		return msg;
	}
	
	@RequestMapping("/delJobLog.do")
	@ResponseBody
	public String delJobLog(String ids) {
		List<String> jobLogIdList = JSON.parseArray(ids, String.class);
		int i = jobLogService.delJoblog(jobLogIdList);
		return i+"";
	}
	
	@RequestMapping("/updateJobLog.do")
	@ResponseBody
	public String updateJobLog(JoblogEntity joblog) {
		int i = jobLogService.updateJoblog(joblog);
		return i+"";
	}
	
	@RequestMapping("/findAll.do")
	@ResponseBody
	public Map<String, Object> findAll(ParamDTO param) {
		
		List<JoblogEntity> list = jobLogService.findAllByitem(param.getMyEndover(),param.getEndTime(), param.getMySearch(),param.getStart()+"",param.getLength()+"");
//		for (JoblogEntity joblogEntity : list) {
//			try {
//				joblogEntity.setJobTime(format.format(format.parse(joblogEntity.getJobTime())));
//				System.out.println("..."+joblogEntity.getJobTime());
//				jobLogService.updateJoblog(joblogEntity);
//			} catch (ParseException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
		int i = jobLogService.countAll(param.getMyEndover(),param.getEndTime(), param.getMySearch());
		Map<String,Object> result = new HashMap<String,Object>();
		result.put("iTotalDisplayRecords", i);
		result.put("iTotalRecords", i);
		result.put("data", list);
		return result;
	}
	
	/**跳轉黑白名單頁面
	 * @return
	 */
	@RequestMapping("/toRoster.do")
	public String toRoster(ModelMap map) {
		List<UserEntity> listAllUser = userService.listAllUser(null);
		Map<String, List<UserEntity>> hashmap = new HashMap<String, List<UserEntity>>();
		List<UserEntity> rosterList = new ArrayList<UserEntity>();
		for (UserEntity userEntity : listAllUser) {
			if (null != userEntity.getRoster() && !"null".equals(userEntity.getRoster())) {
				rosterList.add(userEntity);
			}
			String key = userEntity.getDepart().getDepartName();
			List<UserEntity> value = hashmap.get(key);
			if (null == value) {
				value = new ArrayList<UserEntity>();
				value.add(userEntity);
				hashmap.put(key, value);
			}else {
				value.add(userEntity);
			}
		}
		map.addAttribute("hashmap", hashmap);
		map.addAttribute("rosterList", rosterList);
		return "log/roster";
	}
	
	/**跳轉統計詳情頁面（統計日誌填寫情況）
	 * @param map
	 * @return
	 */
	@RequestMapping("/toDetailCount.do")
	public String toDetailCount(ModelMap map) {
		List<UserEntity> listAllUser = userService.listAllUser(null);
		List<String> rosterList = new ArrayList<String>();//全部要寫的人
		List<String> absentList = new ArrayList<String>();//清假的人
		for (UserEntity userEntity : listAllUser) {
			if (null != userEntity.getRoster() && !"null".equals(userEntity.getRoster())) {
				rosterList.add(userEntity.getNickname());
			}
			if (null != userEntity.getAbsent() && !"null".equals(userEntity.getAbsent())) {
				absentList.add(userEntity.getNickname());
			}
		}
		String time = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
		List<JoblogEntity> listAllJobLog = jobLogService.listAllByToday(time);
		List<String> jobLogUser = new ArrayList<String>();//當天寫了日誌的人
		for (JoblogEntity AllJobLog : listAllJobLog) {
			jobLogUser.add(AllJobLog.getUserName());
		}
		
		absentList.retainAll(rosterList);
		map.addAttribute("rosterList", rosterList);//全部要寫的人
		map.addAttribute("absentList", JSONObject.toJSONString(absentList));//清假的人
		map.addAttribute("listAllJobLog", JSONObject.toJSONString(jobLogUser));//當天寫了日誌的人
		List<String> notWrite = new ArrayList<String>(rosterList);
		notWrite.removeAll(jobLogUser);
		map.addAttribute("noRosterList",JSONObject.toJSONString(notWrite));//沒寫的人
		return "log/detailcount";
	}
	
}
