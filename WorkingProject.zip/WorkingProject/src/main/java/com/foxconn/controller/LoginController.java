package com.foxconn.controller;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import com.foxconn.entity.Depart;
import com.foxconn.entity.ParamTransfer;
import com.foxconn.entity.UREntity;
import com.foxconn.entity.UserEntity;
import com.foxconn.service.DepartService;
import com.foxconn.service.UserRoleService;
import com.foxconn.service.UserService;
import com.foxconn.utils.EmailToolkit;
import com.foxconn.utils.Utils;

@Controller
public class LoginController {

	@Resource
	private UserService userService;
	@Autowired
	private UserRoleService userRoleService;
	
	@Autowired
	private DepartService departService;
	/**
	 * 訪問登錄界面
	 * 
	 * @param userName     Cookie中的用戶名,用於默認填充前端用戶名輸入框
	 * @param pwd          Cookie中的密碼,用於默認填充前端pwd密碼框
	 * @param ModelAndView 模型数据,返回數據到前端
	 **/
	@RequestMapping(value = "/login.do", method = { RequestMethod.GET })
	public ModelAndView login(@CookieValue(value = "userName", required = false) String userNumber,
			@CookieValue(value = "pwd", required = false) String pwd) {
		// 模型數據對象,保持已輸入的用戶名和密碼,返回給前端
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("login");
		if (null != userNumber && null != pwd) {
			modelAndView.addObject("userName", userNumber);
			modelAndView.addObject("pwd", pwd);
		}
		return modelAndView;
	}

	/**
	 * 用戶登錄
	 * 
	 * @param userInfo 表單數據
	 * @param online   是否保持登錄
	 * @param model    模型数据,返回數據到前端,作用域為HttpRequest
	 * @param response 內置對象,用於添加Cookie
	 **/
	@RequestMapping(value = "/login.do", method = { RequestMethod.POST })
	public String login(String userNumber, String pwd, String online, Model model, HttpServletResponse response,HttpSession session) {
		UsernamePasswordToken token = new UsernamePasswordToken(userNumber,pwd);
		Subject subject = SecurityUtils.getSubject();
		try {
			subject.login(token);
			//  将登陆对象保存到Session
			UserEntity userEntity = (UserEntity)subject.getPrincipal();
		
			session.setAttribute("user", userEntity);
			Cookie userNameCookie, passwordCookie, onlineCookie;
			// 是否保持在線
			if (null == online) {
				// 立馬過期
				userNameCookie = new Cookie("userNumber", null);
				passwordCookie = new Cookie("pwd", null);
				onlineCookie = new Cookie("online", null);
				userNameCookie.setMaxAge(0);
				passwordCookie.setMaxAge(0);
				onlineCookie.setMaxAge(0);
			} else {
				// 過期時間為一天
				userNameCookie = new Cookie("userNumber", userNumber);
				passwordCookie = new Cookie("pwd", pwd);
				onlineCookie = new Cookie("online", online==null?"off":"on");
				userNameCookie.setMaxAge(2 * 60 * 60);
				passwordCookie.setMaxAge(2 * 60 * 60);
				onlineCookie.setMaxAge(2 * 60 * 60);
			}
			// 防止JS訪問Cookie
			userNameCookie.setHttpOnly(true);
			passwordCookie.setHttpOnly(true);
			onlineCookie.setHttpOnly(true);
			// 將Cookie添加到Response中,用於保持登錄
			response.addCookie(userNameCookie);
			response.addCookie(passwordCookie);
			response.addCookie(onlineCookie);
			return "redirect:index.do";
		} catch (Exception e) {
			// 驗證失敗
			e.printStackTrace();
			model.addAttribute("info", "用戶名或密碼錯誤!");
		} finally {
			// 返回給前端輸入框
			model.addAttribute("userNumber", userNumber);
			model.addAttribute("pwd", pwd);
			model.addAttribute("online", online);
		}
		return "login";
	}
	
	/**
	 * 訪問註冊頁面 因thymeleaf模板需要通過視圖解析器 故不能直接訪問.html頁面
	 **/
	@RequestMapping(value = "/register.do", method = { RequestMethod.GET })
	public String register(Model model) {
		fullModelDepList(model);
		return "register";
	}
	@SuppressWarnings("unchecked")
	private void fullModelDepList(Model model) {
		
		ParamTransfer param = new ParamTransfer();
		List<Depart> departList = departService.listAllDepart();
		List<String> depList = new ArrayList<String>();
		for (Depart obj : departList) {
			depList.add(obj.getDepartName()+"-"+obj.getDepartId());
		}
		model.addAttribute("depList", depList);
	}
	/**
	 * 註冊提交
	 * @param userInfo 表單數據
	 * @param model    模型数据,返回數據到前端,作用域為HttpRequest
	 **/
	@RequestMapping(value = "/register.do", method = { RequestMethod.POST })
	public String register(UserEntity userInfo,Model model,String adminRoleID,String verificationCode,HttpSession session) {
		// 自動填充表格,用戶前端填充
		model.addAttribute("autoFill", userInfo);
		// 填充部門列表
		fullModelDepList(model);
		// 檢查驗證碼
//		if (session.getAttribute("verificationCode") == null 
//				|| !session.getAttribute("verificationCode").equals(verificationCode)) {
//			model.addAttribute("info", "驗證碼不正確!");
//			return "register";
//		}
		// 檢查用戶名是否已被使用
		if (null != userService.getUserByUserNumber(userInfo.getUserNumber())) {
			model.addAttribute("info", "註冊失敗,賬號已存在!");
			// 將註冊資料寫入到數據庫
		} else if (userService.insertUser(userInfo)) {
			model.addAttribute("info", "註冊成功!");
			if (!"0".equals(adminRoleID) && null != adminRoleID) {
				UREntity urEntity = new UREntity();
				urEntity.setUserId(userInfo.getUserId());
				urEntity.setRoleId(adminRoleID);
				userRoleService.insertUserRole(urEntity);
			}
		} else {
			model.addAttribute("info", "註冊失敗!");
		}
		return "register";
	}
	
	/**
	 * 訪問主頁 因thymeleaf模板需要通過視圖解析器 故不能直接訪問.html頁面
	 **/
	@RequestMapping("/index.do")
	public String index() {
		return "index";
	}

	/**
	 * 訪問主頁
	 **/
	@RequestMapping("/welcome.do")
	public String welcome() {
		return "welcome";
	}
	
	/**
	 * 退出系統
	 **/
	@RequestMapping("/loginOut.do")
	public String loginOut() {
		Subject subject = SecurityUtils.getSubject();
		if (null != subject) {
			UserEntity user = (UserEntity) subject.getSession().getAttribute("user");
			System.out.println(user.getUserNumber()+"--"+user.getNickname()+"-退出了");
			subject.logout();
		}
		return "login";
	}
	
	/**
	 * 跳轉忘記密碼頁面
	 **/
	@RequestMapping("/toForgetPwd.do")
	public String toForgetPwd() {
		return "forgetPwd";
	}
	
	/**
	 * 發送驗證碼到郵箱
	 **/
	@RequestMapping(value = "/sendVerificationCode.do")
	@ResponseBody
	public String sendVerificationCode(String userNumber,String emailAddress,HttpSession session) {
		UserEntity user = userService.getUserByUserNumber(userNumber);
		if (!emailAddress.equals(user.getEmail())) {
			return "輸入郵箱不正確";
		}
		String verificationCode = Utils.createVerificationCode();
		System.out.println("驗證碼："+verificationCode);
		session.setAttribute("verificationCode", verificationCode);
		session.setAttribute("thisTime", new Date().getTime());
		if (EmailToolkit.sendEmail("主管/同仁您好:工作效率提升平台註冊驗證碼!", "您的驗證碼是:"+verificationCode, emailAddress,null)) {
			return "獲取成功,有效時長60秒";
		}
		return "獲取失敗";
	}
	
	/**修改密碼
	 * @param userNumber
	 * @param email
	 * @param verificationCode
	 * @param pwd
	 * @param req
	 * @return
	 */
	@RequestMapping("/findPwd.do")
	@ResponseBody
	public String findPwd(String userNumber, String email, String yanzhengma, String newPwd, HttpSession session) {
		UserEntity user = userService.getUserByUserNumber(userNumber);
		Boolean bool = false;
		if (null != user && user.getEmail().equals(email)) {
			String sessionVerificationCode = (String) session.getAttribute("verificationCode");
			long thatTime = (long) session.getAttribute("thisTime");
			long thistime = new Date().getTime();
			int time = (int) ((thistime - thatTime)/1000);
			session.removeAttribute("thisTime");
			session.removeAttribute("verificationCode");
			System.out.println(thistime+"-"+thatTime);
			if (time > 60) {
				System.out.println("time>>"+time);
				return "驗證碼過期";
			}
			if (sessionVerificationCode.equals(yanzhengma)) {
				user.setPwd(newPwd);
				bool = userService.updateUser(user);
			}
		}
		if (bool) {
			return "修改成功";
		}else {
			return "修改失敗";
		}
	}
	
}
