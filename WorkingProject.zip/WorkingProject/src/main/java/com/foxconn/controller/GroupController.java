package com.foxconn.controller;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.foxconn.entity.GroupEntity;
import com.foxconn.entity.MeetFileEntity;
import com.foxconn.service.GroupService;
import com.foxconn.service.MeetFileService;
import com.foxconn.utils.EmailToolkit;
import com.foxconn.utils.ExcelUtil;
import com.foxconn.utils.Utils;

@Controller
@RequestMapping("/group")
public class GroupController {

	@Autowired
	private GroupService groupService;
	
	@Autowired
	private MeetFileService meetFileService;
	
	@RequestMapping("/addGroup.do")
	@ResponseBody
	public String addGroup(String groupArr) {
		System.out.println("****///"+groupArr);
		List<GroupEntity> groupList = JSONObject.parseArray(groupArr, GroupEntity.class);
		String uuid = Utils.formNumber();
		int i = 0;
		for (GroupEntity groupEntity : groupList) {
			if (null != groupEntity.getGroupsId() || !"".equals(groupEntity.getGroupsId())) {
				groupService.delGroupByGroupId(groupEntity.getGroupsId());
			}
				break;
		}
		
		for (GroupEntity groupEntity : groupList) {
			if (null == groupEntity.getGroupsId() || "".equals(groupEntity.getGroupsId())) {
				groupEntity.setGroupsId(uuid);
			}
			i += groupService.addGroup(groupEntity);
		}
		return i+"";
	}
	
	@RequestMapping("/delGroup.do")
	@ResponseBody
	public String delGroup(String groupsId) {
		int i = groupService.delGroupByGroupId(groupsId);
		return i+"";
	}
	
	/**發送郵件
	 * @param emialArr
	 * @param contents
	 * @param subject
	 * @return
	 */
	@RequestMapping("/sendEmail.do")
	@ResponseBody
	public String sendEmail(HttpServletRequest request,String emialArr, String contents, String subject,String outerEmail,String fileIds) {
		List<String> fileIdList = JSON.parseArray(fileIds, String.class);
		List<String> fileUrlList = new ArrayList<String>();//裡面裝的是要發送郵件的文件路徑
		int maxSize = 0;
		for (String id : fileIdList) {
			MeetFileEntity meetFileByPrimaryKey = meetFileService.getMeetFileByPrimaryKey(id);
			maxSize += Integer.parseInt(meetFileByPrimaryKey.getRemark1());
			fileUrlList.add(meetFileByPrimaryKey.getFileurl());
		}
		if (maxSize > 20000) {
			return "maxSize";
		}
		contents = contents.replaceAll("<table.+?>", "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" /><table border='1' style='width:1200px;border-collapse:collapse;'>\r\n");
		contents = contents.replaceAll("<th ", "<th style='background-color:#F5FAFE;font-weight:normal;word-break: keep-all;padding:8px;' ");
		contents = contents.replaceAll("<td ", "<td style='padding:25px' ");
		contents = contents.replaceAll("<span.+?>", "");
		contents = contents.replaceAll("</span>", "");
		List<Object> emailList = JSONObject.parseArray(emialArr);
		Set<String> set = new HashSet<String>();
		for (Object emailobject : emailList) {
			String obj = (String) emailobject;
			set.add(obj);
		}
		String addressee = "";
		for (String emails : set) {
			addressee = addressee + emails +",";
		}
		if (null != outerEmail && !"".equals(outerEmail)) {
			addressee = addressee + outerEmail;
		} 
		if (addressee.endsWith(",")) {
			addressee = addressee.substring(0, addressee.lastIndexOf(","));
		}
		File imgFile = null;
		try {
			//生成html
			String fileUUID = UUID.randomUUID().toString().toUpperCase();
			String realPath = request.getServletContext().getRealPath("/");
			File htmlFile = new File(realPath,fileUUID+".html");
			OutputStream fos = new FileOutputStream(htmlFile);
			OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8");
			osw.write(contents);
			osw.close();
			fos.close();
			imgFile = new File(realPath,fileUUID+".jpg");
			ExcelUtil.htmlToImage(htmlFile, imgFile);
			htmlFile.delete();
			System.out.println(imgFile.getPath());
			
			List<File> jpgFileList = new ArrayList<File>();
			jpgFileList.add(imgFile);
			
//			File pdfFile = new File(realPath+fileUUID+".pdf");
//            PDDocument doc = PDDocument.load(pdfFile);
//            PDFRenderer renderer = new PDFRenderer(doc);
//            int pageCount = doc.getNumberOfPages();
//            for (int i = 0; i < pageCount; i++) {
//                BufferedImage image = renderer.renderImage(i, 2f);
//                File f = new File(realPath+"img_"+i+".jpeg");
//                ImageIO.write(image, "JPEG", f);
//                jpgFileList.add(f);
//            }
//            doc.close();
//            pdfFile.delete();
            System.out.println("----------"+addressee);
            boolean bool = EmailToolkit.sendEmail(subject, "", jpgFileList, addressee,fileUrlList);
            return bool+"";
		}catch(Exception e) {
			e.printStackTrace();
		}
		return "false";
	}
}
