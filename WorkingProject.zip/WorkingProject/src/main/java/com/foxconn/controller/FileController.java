package com.foxconn.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.foxconn.entity.DatafileEntity;
import com.foxconn.entity.MeetFileEntity;
import com.foxconn.entity.ParamDTO;
import com.foxconn.entity.ResponseStatus;
import com.foxconn.entity.UserEntity;
import com.foxconn.service.DatafileService;
import com.foxconn.service.MeetFileService;
import com.foxconn.utils.FileUtils;
import com.foxconn.utils.Utils;

@Controller
@RequestMapping("/file")
public class FileController {
	@Autowired
	private MeetFileService meetFileService;
	
	@Autowired
	private DatafileService datafileService;
	//会议记录上傳
		@RequestMapping(value = "/UploadFile.do",produces = "application/json; charset=UTF-8")
		@ResponseBody
		public String handleUploadFile(String meetId, HttpServletRequest req,HttpSession session,@RequestParam(value="file_data")MultipartFile file){
			ResponseStatus<?> rr = new ResponseStatus<Object>();
			try {
				File path = new File(ResourceUtils.getURL("classpath:").getPath());
				if (!path.exists()) {
					path = new File("");
				}
				File upload = new File(path.getAbsolutePath(), "static"+File.separator+"filedir"+File.separator);
				if (!upload.exists()) {//如果static/filedir文件夹不存在，就创建
					upload.mkdirs();
				}
				String uploadPath = upload.getAbsolutePath();
				uploadPath = uploadPath+File.separator+file.getOriginalFilename();
				MeetFileEntity meetFileEntity = meetFileService.getMeetFileBymeetidAndFileurl(meetId, uploadPath);
				
				if (null != meetFileEntity) {
					rr.setMessage("重複上傳");
					return JSON.toJSONString(rr);
				}
				MeetFileEntity meetFile = new MeetFileEntity();
				meetFile.setFileurl(uploadPath);
				meetFile.setMeetId(meetId);
				meetFile.setRemark1(file.getSize()/1024+"");
				int i = meetFileService.addFile(meetFile);
				File realfile = new File(uploadPath);
			
				file.transferTo(realfile);
				rr.setStatus(1);
				rr.setMessage("OK");
			} catch (Exception e) {
				e.printStackTrace();
				rr.setStatus(0);
				rr.setMessage("ng");
			}
			return JSON.toJSONString(rr);
		}
		
		/**刪除單個上傳文件
		 * @param mfId
		 * @return
		 */
		@RequestMapping("/delFileUrl.do")
		@ResponseBody
		public String delFileUrl(String idArr) {
			List<String> idArray = JSONObject.parseArray(idArr,String.class);
			int i = 0;String msg = null;
			for (String mfId : idArray) {
//				MeetFileEntity meetFile = meetFileService.getMeetFileByPrimaryKey(mfId);
//				File file = new File(meetFile.getFileurl());
//				file.delete();
				int j = meetFileService.delFileByid(mfId);
				if (j < 0) {
					msg = "该文件已被其他人删除";
					continue;
				} else {
					i += j;
				}
			}
			if (i == 0 && !"".equals(msg)) {
				return msg;
			} else {
				return i+"";
			}
		}
		/**根據meetID刪除上傳文件
		 * @param mfId
		 * @return
		 */
		@RequestMapping("/delFileUrlByMeetId.do")
		@ResponseBody
		public String delFileUrlByMeetId(String meetID) {
			int i = meetFileService.delFileByMeetId(meetID);
			return i+"";
		}
		
		@RequestMapping("/getMeetFile.do")
		@ResponseBody
		public String getMeetFile(String meetId) {
			List<MeetFileEntity> meetFileList = meetFileService.findByMeetId(meetId);
			return JSON.toJSONString(meetFileList);
		}

		/**
		 *  下载临时保存
		 **/
		@RequestMapping("/downloadFile.do")
		@ResponseBody
		public void downloadFile(String idArr,HttpSession session) {
			session.setAttribute("idArr", idArr);
		}
		/**单个下载
		 * @param resp
		 * @param req
		 * @param mfid 文件id
		 * @throws IOException
		 */
		@RequestMapping("/downloadFilerealing.do")
		public void handleSingleDown(HttpServletRequest req,HttpServletResponse resp,String mfid) {
				MeetFileEntity meetFile = meetFileService.getMeetFileByPrimaryKey(mfid);
				if (null == meetFile) {
					return;
				}
				FileUtils.downFile(req, resp, meetFile.getFileurl());
		}
		
		/**下載操作手冊
		 * @param req
		 * @param resp
		 */
		@RequestMapping("/downloadSOP.do")
		public void downloadSOP(HttpServletRequest req,HttpServletResponse resp) {
				try {
					File path = new File(ResourceUtils.getURL("classpath:").getPath());
					if (!path.exists()) {
						path = new File("");
					}
					String realUrl = path.getAbsolutePath() +File.separator + "static"+File.separator+"excel"+File.separator+"工作效率提升平臺操作手冊2019.11.07v1.pdf";
					FileUtils.downFile(req, resp, realUrl);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
		}
		
		/**上传datafile
		 * @param session
		 * @param datafileEntity
		 * @param file
		 * @return
		 */
		@RequestMapping("/addDataFile.do")
		@ResponseBody
		public String addDataFile(HttpSession session, DatafileEntity datafileEntity,@RequestParam("file_data") MultipartFile file) {
			ResponseStatus<?> rr = new ResponseStatus<Object>();
			String datafileUrl = null;
			try {
				datafileUrl = FileUtils.uploadFile(file);
			} catch (Exception e) {
				rr.setError("上傳失敗");
				e.printStackTrace();
			}
			if (null == datafileUrl) {
				return JSON.toJSONString(rr);
			}
			UserEntity user = (UserEntity) session.getAttribute("user");
			datafileEntity.setDatafileUrl(datafileUrl);
			datafileEntity.setUploader(user.getNickname());
			datafileEntity.setUploaderId(user.getUserId());
			int i = datafileService.addFile(datafileEntity);
			if (i > 0) {
				rr.setMessage("上傳成功");
			}else {
				rr.setError("上傳失敗");
				
			}
			return JSON.toJSONString(rr);
		}
		
		/**删除datafile
		 * @param ids
		 * @return
		 */
		@RequestMapping("/delDataFile.do")
		@ResponseBody
		public String delDataFile(String ids) {
			List<String> datafileIds = JSON.parseArray(ids, String.class);
			if (null == datafileIds || datafileIds.size() == 0) {
				return "0";
			}
			File file = null;
			int i = 0;
			for (String datafileId : datafileIds) {
				DatafileEntity data = datafileService.findFileById(datafileId);
				if (null == data) {
					continue;
				}
				String fileurl = data.getDatafileUrl();
				file = new File(fileurl);
				file.delete();
				i += datafileService.delFileById(datafileId);
				file = null;
			}
			return i+"";
		}
		
		/**查询datafile
		 * @param param
		 * @return
		 */
		@RequestMapping("/listDatafile.do")
		@ResponseBody
		public String listDatafile(ParamDTO param) {
			List<DatafileEntity> datafileList = datafileService.findAllFile(param.getMyEndover(),param.getEndTime(), param.getMySearch(), param.getStart()+"", param.getLength()+"");
			int i = datafileService.countAllFile(param.getMyEndover(),param.getEndTime(), param.getMySearch());
			Map<String,Object> result = new HashMap<String,Object>();
			result.put("iTotalDisplayRecords", i);
			result.put("iTotalRecords", i);
			result.put("data", datafileList);
			return JSON.toJSONString(result);
		}
		
		/**下载datafile
		 * @param req
		 * @param resp
		 * @param downFileId
		 * @return
		 */
		@RequestMapping("/downLoad.do")
		public void downLoad(HttpServletRequest req, HttpServletResponse resp, String downFileId) {
			DatafileEntity dataFileEntity = datafileService.findFileById(downFileId);
			if (null != dataFileEntity) {
				FileUtils.downFile(req, resp, dataFileEntity.getDatafileUrl());
			}
		}
}
