package com.foxconn.controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.foxconn.entity.Depart;
import com.foxconn.entity.UserEntity;
import com.foxconn.service.DepartService;
import com.foxconn.service.UserService;
import com.foxconn.utils.propertiesFile;

/**
 * @author C3410596
 *
 */
/**
 * @author C3410596
 *
 */
@Controller
@RequestMapping("/base")
public class BaseController {

	@Autowired
	private DepartService departService;
	@Autowired
	private UserService userServcie;
	
	/**查詢所有部門
	 * @param map
	 * @return
	 */
	@RequestMapping("/listDepart.do")
	public String listDepart(ModelMap map) {
		List<Depart> departList = departService.listAllDepart();
		map.addAttribute("departList", departList);
		map.addAttribute("size", departList.size());
		return "admin/admin-depart";
	}
	
	/**根據部門ID查詢單個部門信息
	 * @param map
	 * @param path 來源 update  表示修改
	 * @param departId 部門ID
	 * @return
	 */
	@RequestMapping("/getDepartById.do")
	public String getDepartById(ModelMap map, String path, String departId) {
		Depart depart = departService.getDepartById(departId);
		map.addAttribute("depart", depart);
		return "admin/admin-depart-update";
	}
	
	/**修改部門信息
	 * @param depart
	 * @param map
	 * @return 返回i 
	 */
	@RequestMapping("/updateDepart.do")
	@ResponseBody
	public String updateDepart(Depart depart) {
		int i = departService.updateDepart(depart);
		return i+"";
	}
	
	/**新增部門信息
	 * @param depart
	 * @param map
	 * @return 返回i 
	 */
	@RequestMapping("/addDepart.do")
	@ResponseBody
	public String addDepart(Depart depart) {
		int i = departService.insertDepart(depart);
		return i+"";
	}
	
	@RequestMapping("/delDepart.do")
	@ResponseBody
	public String delDepart(@RequestParam("departIds[]")String [] departIds) {
		List<String> departids = Arrays.asList(departIds);
		for (String departId : departids) {
			departService.delDepartById(departId);
		}
		return "";
	}
	/**调整发布公告页面
	 * @return
	 */
	@RequestMapping("/toPublishMsg.do")
	public String toPublishMsg() {
		return "PublishMsg";
	}
	/**跳轉頁面通用方法
	 * @param url 要跳转的路径
	 * @param driId 当driId不为空时，会检查当前用户权限，有权限则允许跳转url,否则提示无权限
	 * @return
	 */
	@RequestMapping("/toHtml.do")
	public String toHtml(String url,String driId,HttpSession session) {
		if (null == driId) {
			return url;
		}else {
			
			boolean bool = checkPower(session, driId);//驗證當前用戶是不是DRI
			if (bool) {
				return url;
			}else {
				return "noPower";
			}
		}
		
	}
	
	/**跳转代理页面。
	 * @param map
	 * @param userId 当前用户id
	 * @return 返回所有用户和当前用户的代理人信息
	 */
	@RequestMapping("/toProxyPage.do")
	public String toProxyPage(ModelMap map,String userId) {
		List<UserEntity> userList = userServcie.listAllUser(null);
		map.addAttribute("userList", userList);
		UserEntity user = userServcie.getUserById(userId);//當前系統用戶
		if (null !=user.getProxy()) {
			UserEntity proxyUser = userServcie.getUserById(user.getProxy());
			map.addAttribute("proxyMsg", proxyUser.getNickname());
			map.addAttribute("proxyStartTime", user.getStarttime());
			map.addAttribute("proxyEndTime", user.getEndtime());
		}
		return "proxySet/proxyPage";
	}
	
	/**驗證當前系統用戶是否是總DRI本人
	 * @param session
	 * @param driId 總DRI ID
	 * @return 返回boolean类型
	 */
	private boolean checkPower(HttpSession session,String driId) {
		UserEntity sessionUser = (UserEntity) session.getAttribute("user");
		UserEntity user = userServcie.getUserById(sessionUser.getUserId());
		//查询总DRI的有无代理人，如果有，判断是不是当前系统用户
		UserEntity DRIUser = userServcie.getUserById(driId);
		boolean bool = false;
		if (user.getUserId().equals(DRIUser.getProxy())) {//判断总dri的代理人是当前用户
			String startime = DRIUser.getStarttime();
			String endtime = DRIUser.getEndtime();
			long thistime = new Date().getTime();
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm");
			
				try {
						long timestart = format.parse(startime).getTime();
						long timeend = format.parse(endtime).getTime();
						if (timestart < thistime && thistime < timeend) {
							 bool = true;
						}
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		if (user.getRoleList().size() == 0) {//判断当前用户没有角色
			if (user.getUserId().equals(driId) || bool) {
				return true;
			}else {
				return false;
			}

		} else {//判断当前用户有角色
			
			if (user.getUserId().equals(driId) || bool || "admin".equalsIgnoreCase(user.getRoleList().get(0).getRoleName())) {
				return true;
			}else {
				return false;
			}
		}
	}
	
	/**寫公告
	 * @param text
	 * @return
	 */
	@RequestMapping("/publishMsg.do")
	@ResponseBody
	public String publishMsg(String text) {
		File path;
		try {
			path = new File(ResourceUtils.getURL("classpath:").getPath());
			
			if (!path.exists()) {
				path = new File("");
			}
			File upload = new File(path.getAbsolutePath(), "static"+File.separator+"filedir"+File.separator);
			if (!upload.exists()) {//如果static/filedir文件夹不存在，就创建
				upload.mkdirs();
				
			}
			File fileFile = new File(upload.getAbsolutePath(),"msg.txt");
			if (!fileFile.exists()) {
				fileFile.createNewFile();
			}
			String Filepath = fileFile.getPath();
			boolean bool = propertiesFile.WriteProp(Filepath, text);
			return bool+"";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "false";
	}
	
	/**
	 * 讀公告
	 * @return
	 */
	@RequestMapping("/readPublishMsg.do")
	@ResponseBody
	public String readPublishMsg() {
		
		File path;
		try {
			path = new File(ResourceUtils.getURL("classpath:").getPath());
			
			if (!path.exists()) {
				path = new File("");
			}
			File upload = new File(path.getAbsolutePath(), "static"+File.separator+"filedir"+File.separator);
			if (!upload.exists()) {//如果static/filedir文件夹不存在，就创建
				upload.mkdirs();
			}
			File fileFile = new File(upload.getAbsolutePath(),"msg.txt");
			if (!fileFile.exists()) {
				fileFile.createNewFile();
			}
			String Filepath = fileFile.getPath();
			return propertiesFile.ReadProp(Filepath);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}
}
