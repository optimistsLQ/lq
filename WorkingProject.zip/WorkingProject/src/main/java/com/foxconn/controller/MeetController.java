package com.foxconn.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.foxconn.entity.GroupEntity;
import com.foxconn.entity.Meetcontents;
import com.foxconn.entity.Meetionnotes;
import com.foxconn.entity.ParamDTO;
import com.foxconn.entity.ResponseStatus;
import com.foxconn.entity.UserEntity;
import com.foxconn.service.GroupService;
import com.foxconn.service.MeetFileService;
import com.foxconn.service.MeetcontentsService;
import com.foxconn.service.MeetingService;
import com.foxconn.service.UserService;
import com.foxconn.utils.DateUtils;
import com.foxconn.utils.ExcelUtil;
import com.foxconn.utils.PagingTool;

@Controller
@RequestMapping("/meet")
public class MeetController {

	@Autowired
	private MeetcontentsService meetcontents;
	@Autowired
	private MeetingService meetService;
	@Autowired
	private UserService userService;
	
	@Autowired
	private GroupService groupService;
	@Autowired
	private MeetFileService fileService;
	@RequestMapping("/listAllMeeting.do")
	@ResponseBody
	public Map<String, Object> listAllMeeting(ModelMap map, ParamDTO param) {
		List<Meetionnotes> meetList = meetService.listByItem(param.getMySearch(),param.getStart()+"", param.getLength()+"");
		int i = meetService.countlistByItem(param.getMySearch());
//		ResponseStatus<List<?>> source = PagingTool.paging(meetList, param.getStart()/param.getLength(), param.getLength());
		Map<String,Object> result = new HashMap<String,Object>();
		result.put("iTotalDisplayRecords", i);
		result.put("iTotalRecords", i);
		result.put("data", meetList);
		return result;
	}
	
	/**
	 * 添加會議記錄
	 * @return
	 */
	@RequestMapping("addMeet.do")
	@ResponseBody
	public String addMeet(Meetionnotes meet){
		String meetTime = DateUtils.handleMonth(meet.getMeetTime());
		String meetEndTime = DateUtils.handleMonth(meet.getMeetEndtime());
		meet.setMeetTime(meetTime);
		meet.setMeetEndtime(meetEndTime);
		String msg = "";
		int i = meetService.addMeeting(meet);
		if (i > 0) {
			msg = "ok";
		} else {
			msg = "添加失敗！";
		}
		return msg;
	}
	
	@RequestMapping("/toMeetDetail.do")
	public String toMeetDetail(String meetId, ModelMap map) {
		Meetionnotes meet = meetService.getMeetById(meetId);
		List<Meetcontents> listMeetcontents = meetcontents.listMeetcontentsByMeetId(meetId);
		map.addAttribute("meet", meet);
		map.addAttribute("listMeetcontents", listMeetcontents);
		return "meet/meet-detail";
	}
	
	@RequestMapping("/insertMeetcontents.do")
	@ResponseBody
	public String insertMeetcontents(String contentArr, String meetId) {
		int j = meetcontents.delMeetcontentsBtMeetId(meetId);
		int i=0;
		List<Meetcontents> contentList = JSONObject.parseArray(contentArr, Meetcontents.class);
		for (Meetcontents meetcontent : contentList) {
			i += meetcontents.addMeetcontents(meetcontent);
		}
		return i+"";
	}
	
	@RequestMapping("/updateMeet.do")
	@ResponseBody
	public String udateMeet(Meetionnotes meet) {
		String meetTime = DateUtils.handleMonth(meet.getMeetTime());
		String meetEndTime = DateUtils.handleMonth(meet.getMeetEndtime());
		meet.setMeetTime(meetTime);
		meet.setMeetEndtime(meetEndTime);
		System.out.println("meet>>>"+meet.toString());
		return meetService.updateMeeting(meet)+"";
	}
	
	@RequestMapping("/delMeet.do")
	@ResponseBody
	public String delMeet(String ids) {
		int i = 0;
		List<String> idList = JSONObject.parseArray(ids, String.class);
		for (String id : idList) {
			i += meetService.delMeetingById(id);
			meetcontents.delMeetcontentsBtMeetId(id);
			fileService.delFileByMeetId(id);
		}
		return i+"";
	}
	
	/**跳轉checkboxUser頁面
	 * @param come 表示來源（come=null從會議記錄添加頁面來、childlist子項添加頁面來）
	 * @return
	 */
	@RequestMapping("/toCheckBoxUser.do")
	public String toCheckBoxUser(ModelMap map,String come) {
		System.out.println("come>>"+come);
		List<UserEntity> userList = userService.listAllUser(null);
		if (null == come) {
			Map<String, List<String>> hashmap = new HashMap<String, List<String>>();
			List<GroupEntity> list = groupService.listAllGroups();
			for (GroupEntity group : list) {
				String key = group.getGroupName();
				if (null == hashmap.get(key)) {
					hashmap.put(key, new ArrayList<String>());
				}
				hashmap.get(key).add(group.getUserName()+"*"+group.getUserId());
			}
			map.addAttribute("hashmap", hashmap);
		}
		map.addAttribute("userList", userList);
		map.addAttribute("come", come);
		return "meet/CheckBoxUser";
	}
	
	/**跳轉sendEmail頁面
	 * @param 
	 * @return
	 */
	@RequestMapping("/tosendEmail.do")
	public String tosendEmail(ModelMap map) {
		Map<String,List<GroupEntity>> data = new HashMap<>();
		List<GroupEntity> listGroup = groupService.listAllGroups();
		for (GroupEntity obj : listGroup) {
			String key = obj.getGroupsId()+"-"+obj.getGroupName();
			List<GroupEntity> value = data.get(key);
			if(value == null){
			    value = new ArrayList<>();
				value.add(obj);
				data.put(key, value);
			}else{
				value.add(obj);
			}
		}
		map.addAttribute("data", data);
		return "meet/sendEmail";
	}
	/**跳轉sendEmail頁面
	 * @param 
	 * @return
	 */
	@RequestMapping("/tosendEmailAllUser.do")
	@ResponseBody
	public String tosendEmailAllUser() {
		List<UserEntity> userList = userService.listAllUser(null);
		return JSON.toJSONString(userList);
	}
	
	/**
	 *  下载临时保存
	 **/
	@RequestMapping(value="/saveDownTemp.do",method = {RequestMethod.POST})
	@ResponseBody
	public void saveDownTemp(String tableHtml,String formName,HttpSession session) {
		
		
		session.setAttribute("dwonFile", "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />"+tableHtml.replaceAll("<table.+?>", "<table style='border-collapse:collapse;width:1200px;' border='1'>\r\n"));
		session.setAttribute("formName", formName);
	}
	/**
	 * 下載PDF
	 **/
	@RequestMapping(value="downPdf.do",method = {RequestMethod.GET})
	@ResponseBody
	public synchronized void downPdf(HttpServletRequest request,HttpServletResponse response,HttpSession session) throws IOException {
		File HTMLFile = null;
		File pdfTmepFile = null;
		FileInputStream pdfInputStream = null;
		String uuid = UUID.randomUUID().toString();
		response.setContentType("application/vnd.ms-excel;charset=utf-8");
		response.setHeader("Content-Disposition", "attachment;filename="+URLEncoder.encode((String)session.getAttribute("formName"), "UTF-8")+".pdf");
		try {
			// 生成xls文件
			String realPath = request.getServletContext().getRealPath("/");
			HTMLFile = new File(realPath,uuid+".html");
//			System.out.println(xlsTempFile.getPath());
			String html = session.getAttribute("dwonFile").toString().replaceAll("</tr>", "</tr>\r\n");
			html = html.replaceAll("<th ", "<th style='font-weight:normal;word-break: keep-all;padding:8px' ");
			html = html.replaceAll("<td ", "<td style='padding:25px' ");
			html = html.replaceAll("<span.+?>", "");
			html = html.replaceAll("</span>", "");
//			System.out.println(html);
			OutputStream fos = new FileOutputStream(HTMLFile);
			OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8");
			osw.write(html);
			osw.close();
			fos.close();
			// 生成pdf文件
			pdfTmepFile = new File(realPath,uuid+".pdf");
			ExcelUtil.htmlToPDF(HTMLFile, pdfTmepFile);
		    pdfInputStream = new FileInputStream(pdfTmepFile);
			byte [] b = new byte[1024];
			int len = 0;
			while ((len = pdfInputStream.read(b)) !=-1) {
				response.getOutputStream().write(b, 0, len);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pdfInputStream.close();
			HTMLFile.delete();
			pdfTmepFile.delete();
		}
	}
}
