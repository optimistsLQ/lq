package com.foxconn.controller;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.foxconn.entity.CensusDTO;
import com.foxconn.service.ChildlistService;
import com.foxconn.service.TotallistService;

@Controller
@RequestMapping("/count")
public class CountController {

	@Autowired
	private TotallistService totalService;
	
	@Autowired
	private ChildlistService childService;
	/**事项统计
	 * @param orderField 排序字段
	 * @param order 排序规则
	 * @return
	 */
	@RequestMapping("/countNum.do")
	@ResponseBody
	public String count(String orderField,String order) {
		Map<String, Object> map = new HashMap<String, Object>();
		try {
			//[{STATUS=5_Close, count=1, TOTALDRI=張艷群}, {STATUS=4_Open, count=1, TOTALDRI=伍潔婷}
			List<Map<String, Object>> totalList = totalService.count();
			List<Map<String, Object>> childList = childService.count();
			Map<String,CensusDTO> userMap = new HashMap<String,CensusDTO>();
			for (Map<String, Object> totalmap : totalList) {
				String status = (String)totalmap.get("STATUS");
				String userName = (String)totalmap.get("TOTALDRI");
				Integer count = ((java.math.BigDecimal)totalmap.get("count")).intValue();
				if(userMap.get(userName) == null) {
					CensusDTO censusDTO = new CensusDTO();
					censusDTO.setUserName(userName);
					userMap.put(userName, censusDTO);
				}
				CensusDTO censusDTO = userMap.get(userName);
				if(status.contains("On Going")) {
					censusDTO.setTotalGoing(count);
				} else {
					if(status.contains("_")) {
						status = status.split("_")[1];
					}
					Method m = censusDTO.getClass().getMethod("setTotal"+status, java.lang.Integer.class);
					m.invoke(censusDTO, count);
				}
				censusDTO.setThingStart(censusDTO.getThingStart()+count);
				if(status.contains("Close")) {
					censusDTO.setThingEnd(censusDTO.getThingEnd()+count);
				}
				censusDTO.setTotalNum(censusDTO.getTotalNum()+count);
				
			}
			for (Map<String, Object> childMap : childList) {
				String oldStatus = (String)childMap.get("STATUS");
				String oldUserName = (String)childMap.get("ZIDRI");
				Integer count = ((java.math.BigDecimal)childMap.get("count")).intValue();
				Pattern p = Pattern.compile("[\u4e00-\u9fa5]+|[a-z]+", Pattern.CASE_INSENSITIVE);
//				System.out.println("**"+childMap.toString());
//				System.out.println("--"+oldUserName);
				Matcher matcher = p.matcher(oldUserName);
				while(matcher.find()) {
					String userName = matcher.group();
					if(userMap.get(userName) == null) {
						CensusDTO censusDTO = new CensusDTO();
						censusDTO.setUserName(userName);
						userMap.put(userName, censusDTO);
					}
					CensusDTO censusDTO = userMap.get(userName);
					if(oldStatus.contains("On Going")) {
						censusDTO.setChildGoing(count+(censusDTO.getChildGoing()==null?0:censusDTO.getChildGoing()));
					}  else {
						String status = oldStatus.split("_")[1];
						Method m = censusDTO.getClass().getMethod("setChild"+status, java.lang.Integer.class);
						Method getMethod = censusDTO.getClass().getMethod("getChild"+status);
						Object getMethodObj = getMethod.invoke(censusDTO);
						m.invoke(censusDTO, count+(getMethodObj==null?0:(Integer)getMethodObj));
					}
					censusDTO.setThingStart(censusDTO.getThingStart()+count);
					if(oldStatus.contains("Close")) {
						censusDTO.setThingEnd(censusDTO.getThingEnd()+count);
					}
					censusDTO.setChildNum(censusDTO.getChildNum()+count);
				}
			}
			Iterator<Entry<String, CensusDTO>> iterator = userMap.entrySet().iterator();
			List<CensusDTO> list = new ArrayList<CensusDTO>();
			while(iterator.hasNext()) {
				list.add(iterator.next().getValue());
			}
			//比較排序
			list.sort(new Comparator<CensusDTO>() {
				@Override
				public int compare(CensusDTO o1, CensusDTO o2) {
					try {
						Method m1 = o1.getClass().getMethod("get"+(orderField.substring(0,1).toUpperCase()+orderField.substring(1)));
						Method m2 = o2.getClass().getMethod("get"+(orderField.substring(0,1).toUpperCase()+orderField.substring(1)));
						Object ob1 = m1.invoke(o1);
						Object ob2 = m2.invoke(o2);
						int v1 = (ob1==null?0:(Integer)ob1);
						int v2 = (ob2==null?0:(Integer)ob2);
						if (v1 == v2) {
							return 0;
						}
						if (order.equalsIgnoreCase("desc")) {
							if (v1 > v2) {
								return -1;
							}
						} else {
							if (v1 < v2) {
								return -1;
							}
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} 
					return 1;
				}
			});
			
			
			map.put("iTotalDisplayRecords", list.size());
			map.put("iTotalRecords", list.size());
			map.put("data", list);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return JSON.toJSONString(map);
	}
}
