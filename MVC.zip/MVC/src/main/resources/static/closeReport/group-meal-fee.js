//團膳餐費的趋势图 
var trendChart = echarts.init(document.getElementById("trendChart"));
//判断是否存在趋势图数据
var data = $("#trendChartData").html();
if(!!data) {
	drawTrendChart(JSON.parse(data));
}
//当浏览器发生变更的时候,趋势图进行重绘
$(window).resize(function(){
	trendChart.resize();
});
//绘制趋势图
function drawTrendChart(data) {
	var monthArr = data.monthArr;
	var costObj = data.costMap;	
	//控制滾動範圍內只顯示12個柱狀圖
	var startValue = 0;
	if(monthArr.length > 12) {
		startValue = monthArr.length - 12;
	}
	//創建series
	var seriesDataArr = [];
	//生成圖形
	var lineBackgroundColor = ["#F789B6","#920783","#441360","#E37E1C"];
	var lineBackgroundColorIndex = 0;
	var barBackgroundColor = ["#699EFE","#60D3AA","#57902D","#F39C47"];
	var backgroundIndex = 0;
	//折線圖的轉角樣式
	var lineSymbol = ["circle","rect","triangle","pin","arrow"];
	for(var legend in costObj) {
		//将0替换为null,这样做的目的是让图形不渲染为0的项
		var dataArr = costObj[legend];
		for(var i in dataArr) {
			if(dataArr[i] == 0) {
				dataArr[i] = null;
			}
		}
		if(legend.indexOf("人均")!=-1) {
			seriesDataArr.push({
		        data: costObj[legend],
		        type: 'line',
		        name: legend,
		        symbol: lineSymbol[lineBackgroundColorIndex],
		        symbolSize: 8,//如果显示圆点,这里就是圆点大小
		        yAxisIndex: 1,
		        itemStyle: {
		        	color: lineBackgroundColor[lineBackgroundColorIndex]
		        },
		        lineStyle: {
		        	//type: 'dashed',
		            color: lineBackgroundColor[lineBackgroundColorIndex]
		        }
		    });
			lineBackgroundColorIndex++;
		} else {
			seriesDataArr.push({
				name: legend,
		        data: costObj[legend],
		        type: 'bar',
		        barGap: '0',
		        itemStyle: {
		            color: barBackgroundColor[backgroundIndex++]
		        }
			});
		}
	}
	//設置Option
	trendChart.setOption({
	  title: {
	      text: '費用趨勢圖',
	      textStyle: {
	          fontSize: 16
	      }
	  },
	  dataZoom:{
		  type: 'slider',
		  show: true,
		  startValue: startValue
	  },
	  tooltip:{
		  show: true,
		  trigger: 'axis',
		  axisPointer: {
		      type: 'shadow',
		      crossStyle: {
		    	  color: '#999'
		      }
		  },
		  textStyle: {
			  align: 'left'
		  }
	  },
	  legend:{
		  show: true,
		  type: 'plain',
		  width: '660'
	  },
	  xAxis: {
	      type: 'category',
	      data:  monthArr,
	      splitLine: {
	          show: false
	      },
	      axisLabel: {
	          interval:0,
	          rotate:-20
	      }
	  },
	  yAxis: [{
	      type: 'value',
	      splitLine: {
	          show: false
	      }
	  },{
	      type: 'value',
	      splitLine: {
	          show: false
	      }
	  }],
	  grid:{
	      show: false,
	      top:"50px",
	      left:"20px",
	      right:"30px",
	      bottom:"60px",
	      containLabel:true
	  },
	  series: seriesDataArr
	});
}

//顯示追減項明細
function showDeductionDetailsInfo(a) {
	if($(a).html() == "-" || parseFloat($(a).html()) == 0) {
		return;
	}
	//追減項的篩選條件
    var tr = $(a).parent().parent();
    var manufacturer = tr.find("td").eq(0).find(".select2-selection__rendered").eq(0).html();
    if(!manufacturer) {
    	manufacturer = tr.find("td").eq(0).html();
    }
    var category = tr.find("td").eq(1).html();
    //设置弹窗位置
    var tableDivHeight = $("#tableDiv").height()/2;
    var deductionDetailsDivHeight = $("#deductionDetailsDiv").height()/2;
    $("#deductionDetailsDiv #title").html(manufacturer);
    $("#deductionDetailsTable tbody").empty().append("<tr><td colspan='4'>正在加載數據,請稍後...</td></tr>");
    $("#deductionDetailsOutDiv").show();
    $("#deductionDetailsDiv").css({"top":(tableDivHeight-deductionDetailsDivHeight)+"px","left":"20%"}).show();
    //设置数据,这里的延迟用于模拟加载数据的过程,其实数据在网页上,无需加载
    setTimeout(function(){
	    var deductionDetailsData = eval($("#deductionDetailsData").html());
	    $("#deductionDetailsTable tbody").empty();
	    var trHtml = "";
	    for(var i in deductionDetailsData) {
	    	if(deductionDetailsData[i]["manufacturer"].indexOf(manufacturer) != -1
	    			&& deductionDetailsData[i]["category"].indexOf(category) != -1){
	    		var obj = deductionDetailsData[i];
	    		trHtml += "<tr><td>"+obj.penaltyDeductionNo+"</td>";
	    		trHtml += "<td>"+obj.reasonForDeduction+"</td>";
	    		trHtml += "<td>"+sinceCountNumber(parseFloat(obj.deductionAmount).toFixed(2))+"</td>";
	    		trHtml += "<td><a style=\"text-decoration:none\" class=\"ml-5\" onClick=\"annexes_upload('附件','../onesig/toFootNote.do','"+obj.uid+"',500,400)\" href=\"javascript:void(0);\"title=\"附件\" ><i class=\"Hui-iconfont\">&#xe636;</i></a></td></tr>";
	    	}
	    }
	    $("#deductionDetailsTable tbody").append(trHtml);
    },200);
}

//關閉 追/减项 明細框
function deductionDetailsClose() {
    $("#deductionDetailsOutDiv").hide();
    $("#deductionDetailsDiv").hide();
}

//追/减项 附件查看
var formCode;
function annexes_upload(title,url,data,w,h){
    var idArr = [];
    idArr.push(data);
    layer_show("附件","../onesig/toFootNotes.do?supplierCode="+idArr,500,400);
}

//表单附件
function uploadNote(){
	//listcode來源於表單創建的時候,在送簽過程中,是不存在listcode值的
    var listcode = $("#listcode").val();
    if(!!listcode){
    	layer_show("附件","../onesig/toFootNote.do?formCode="+listcode,500,400);
    	return;
    }
    layer_show("附件","../onesig/toFootNote.do?formCode="+formCode,500,400);
}

//列出合同
function listContract(){
	//獲取表格中所有廠商的UID
	var uidArr = [];
	$("#tableAll").find("tr").each(function() {
		var uid = $(this).attr("uid");
		if(!!uid && $.inArray(uid,uidArr)==-1) {
			uidArr.push(uid);
		}
	});
	//判斷是否存在供應商
	if(uidArr.length == 0) {
		return;
	}
    //通過這個ID數組區查詢它的所有合同
    layer_show("合同","../onesig/toFootNotes.do?supplierCode="+uidArr,500,400);
}