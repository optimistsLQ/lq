//費用的趋势图 
var trendChart = echarts.init(document.getElementById("trendChart"));
//判断是否存在趋势图数据
var data = $("#trendChartData").html();
if(!!data) {
	drawTrendChart(JSON.parse(data));
}
//当浏览器发生变更的时候,趋势图进行重绘
$(window).resize(function(){
	trendChart.resize();
});
//绘制趋势图
function drawTrendChart(data) {
	var monthArr = data.monthArr;
	//控制滾動範圍內只顯示最后12個柱狀圖
	var startValue = 0;
	if(monthArr.length > 12) {
		startValue = monthArr.length - 12;
	}
	var costObj = data.costMap;
	//創建series
	var seriesDataArr = [];
	//生成圖形
	var lineBackgroundColor = ["#236CF4","#3CA454","#920783","#441360","#E37E1C"];
	var barBackgroundColor = ["#699EFE","#60D3AA","#57902D","#F39C47"];
	var backgroundIndex = 0;
	for(var legend in costObj) {
		//過濾不要的值
		if(legend.indexOf("人數")!=-1 || legend.indexOf("總費用")!=-1) {
			continue;
		}
		//如果是人均,就生成折線圖
		if(legend.indexOf("人均")!=-1) {
			seriesDataArr.push({
		        data: costObj[legend],
		        type: 'line',
		        name: legend,
		        symbol: 'none',
		        //symbolSize: 6,
		        yAxisIndex: 1,
		        itemStyle: {
		        	color: '#F789B6'
		        },
		        lineStyle: {
		            color: '#F789B6'
		        }
		    });
		} else {
			seriesDataArr.push({
				name: legend,
		        data: costObj[legend],
		        type: 'bar',
		        stack: 'bus',
		        barWidth: '25',
		        itemStyle: {
		            color: barBackgroundColor[backgroundIndex++]
		        }
			});
		}
	}
	//設置Option
	trendChart.setOption({
		  title: {
		      text: '費用趨勢圖(KRMB)',
		      textStyle: {
		          fontSize: 16
		      }
		  },
		  dataZoom:{
			  type: 'slider',
			  show: true,
			  startValue: startValue
		  },
		  tooltip:{
			  show: true,
			  trigger: 'axis',
			  axisPointer: {
			      type: 'shadow',
			      crossStyle: {
			    	  color: '#999'
			      }
			  },
			  textStyle: {
				  align: 'left'
			  }
		  },
		  legend:{
			  show: true
		  },
		  xAxis: {
		      type: 'category',
		      data:  monthArr,
		      splitLine: {
		          show: false
		      },
		      axisLabel: {
		          interval:0
		      }
		  },
		  yAxis: [{
		      type: 'value',
		      splitLine: {
		          show: false
		      }
		  },{
		      type: 'value',
		      splitLine: {
		          show: false
		      }
		  }],
		  grid:{
		      show: false,
		      top:"50px",
		      left:"50px",
		      right:"35px",
		      bottom:"65px"
		  },
		  series: seriesDataArr
	});
}

//表单附件
function uploadNote(){
	//listcode來源於表單創建的時候,在送簽過程中,是不存在listcode值的
    var listcode = $("#listcode").val();
    if(!!listcode){
    	layer_show("附件","../onesig/toFootNote.do?formCode="+listcode,500,400);
    	return;
    }
    layer_show("附件","../onesig/toFootNote.do?formCode="+formCode,500,400);
}

//列出合同
function listContract(){
	//獲取表格中所有廠商的UID
	var uidArr = [];
	$("#tableAll").find("tr").each(function() {
		var uid = $(this).attr("uid");
		if(!!uid && $.inArray(uid,uidArr)==-1) {
			uidArr.push(uid);
		}
	});
	//判斷是否存在供應商
	if(uidArr.length == 0) {
		return;
	}
    //通過這個ID數組區查詢它的所有合同
    layer_show("合同","../onesig/toFootNotes.do?supplierCode="+uidArr,500,400);
}