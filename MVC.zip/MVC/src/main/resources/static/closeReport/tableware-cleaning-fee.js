//餐具清潔費的趋势图 
var trendChart = echarts.init(document.getElementById("trendChart"));
//判断是否存在趋势图数据
var data = $("#trendChartData").html();
if(!!data) {
	drawTrendChart(JSON.parse(data));
}
//当浏览器发生变更的时候,趋势图进行重绘
$(window).resize(function(){
	trendChart.resize();
});
//绘制趋势图
function drawTrendChart(data) {
	var monthArr = data.monthArr;
	var costObj = data.costMap;
	//控制滾動範圍內只顯示最后12個柱狀圖
	var startValue = 0;
	if(monthArr.length > 12) {
		startValue = monthArr.length - 12;
	}
	//創建series
	var seriesDataArr = [];
	//生成圖形
	var lineBackgroundColor = ["#F789B6","#920783","#441360","#E37E1C"];
	var barBackgroundColor = ["#699EFE","#60D3AA","#57902D","#F39C47"];
	for(var legend in costObj) {
		//過濾其它值
		if(legend.indexOf("D＝A－B") == -1) {
			continue;
		}
		seriesDataArr.push({
			name: legend,
	        data: costObj[legend],
	        type: 'bar',
	        barWidth: '40',
	        barGap: '0',
	        itemStyle: {
	            color: barBackgroundColor[0]
	        }
		});
	}
	//設置Option
	trendChart.setOption({
	  title: {
	      text: '餐具清潔費趨勢圖(KRMB)',
	      textStyle: {
	          fontSize: 16
	      }
	  },
	  dataZoom:{
		  type: 'slider',
		  show: true,
		  startValue: startValue
	  },
	  tooltip:{
		  show: true,
		  trigger: 'axis',
		  axisPointer: {
		      type: 'shadow',
		      crossStyle: {
		    	  color: '#999'
		      }
		  },
		  textStyle: {
			  align: 'left'
		  }
	  },
	  legend:{
		  type: 'plain',
		  width: '500px',
		  show: false
	  },
	  xAxis: {
	      type: 'category',
	      data:  monthArr,
	      splitLine: {
	          show: false
	      },
	      axisLabel: {
	          interval:0
	      }
	  },
	  yAxis: [{
	      type: 'value',
	      splitLine: {
	          show: false
	      }
	  }],
	  grid:{
	      show: false,
	      top:"50px",
	      left:"60px",
	      right:"10px",
	      bottom:"60px"
	  },
	  series: seriesDataArr
	});
}

//顯示追減項明細
function showDeductionDetailsInfo(a) {
	if($(a).html() == "-" || parseFloat($(a).html()) == 0) {
		return;
	}
	//追減項的篩選條件
    var tr = $(a).parent().parent();
    var manufacturer = tr.find("td").eq(0).html();
    var region = tr.find("td").eq(2).html();
    //设置弹窗位置
    var tableDivHeight = $("#tableDiv").height()/2;
    var deductionDetailsDivHeight = $("#deductionDetailsDiv").height()/2;
    $("#deductionDetailsDiv #title").html(manufacturer);
    $("#deductionDetailsTable tbody").empty().append("<tr><td colspan='4'>正在加載數據,請稍後...</td></tr>");
    $("#deductionDetailsOutDiv").show();
    $("#deductionDetailsDiv").css({"top":(tableDivHeight-deductionDetailsDivHeight)+"px","left":"20%"}).show();
    //设置数据,这里的延迟用于模拟加载数据的过程,其实数据在网页上,无需加载
    setTimeout(function(){
	    var deductionDetailsData = eval($("#deductionDetailsData").html());
	    $("#deductionDetailsTable tbody").empty();
	    var trHtml = "";
	    for(var i in deductionDetailsData) {
	    	if(deductionDetailsData[i]["manufacturer"].indexOf(manufacturer) != -1
	    			&& deductionDetailsData[i]["region"].indexOf(region) != -1){
	    		var obj = deductionDetailsData[i];
	    		trHtml += "<tr><td>"+obj.penaltyDeductionNo+"</td>";
	    		trHtml += "<td>"+obj.reasonForDeduction+"</td>";
	    		trHtml += "<td>"+sinceCountNumber(parseFloat(obj.deductionAmount).toFixed(2))+"</td>";
	    		trHtml += "<td><a style=\"text-decoration:none\" class=\"ml-5\" onClick=\"annexes_upload('附件','../onesig/toFootNote.do','"+obj.uid+"',500,400)\" href=\"javascript:void(0);\"title=\"附件\" ><i class=\"Hui-iconfont\">&#xe636;</i></a></td></tr>";
	    	}
	    }
	    $("#deductionDetailsTable tbody").append(trHtml);
    },200);
}

//關閉 追/减项 明細框
function deductionDetailsClose() {
    $("#deductionDetailsOutDiv").hide();
    $("#deductionDetailsDiv").hide();
}

//追/减项 附件查看
var formCode;
function annexes_upload(title,url,data,w,h){
    var idArr = [];
    idArr.push(data);
    layer_show("附件","../onesig/toFootNotes.do?supplierCode="+idArr,500,400);
}

//表单附件
function uploadNote(){
	//listcode來源於表單創建的時候,在送簽過程中,是不存在listcode值的
    var listcode = $("#listcode").val();
    if(!!listcode){
    	layer_show("附件","../onesig/toFootNote.do?formCode="+listcode,500,400);
    	return;
    }
    layer_show("附件","../onesig/toFootNote.do?formCode="+formCode,500,400);
}

//列出合同
function listContract(){
	//獲取表格中所有廠商的UID
	var uidArr = [];
	$("#tableAll").find("tr").each(function() {
		var uid = $(this).attr("uid");
		if(!!uid && $.inArray(uid,uidArr)==-1) {
			uidArr.push(uid);
		}
	});
	//判斷是否存在供應商
	if(uidArr.length == 0) {
		return;
	}
    //通過這個ID數組區查詢它的所有合同
    layer_show("合同","../onesig/toFootNotes.do?supplierCode="+uidArr,500,400);
}