//口罩趨勢圖
var trendChart = echarts.init(document.getElementById("trendChart"));
//判断是否存在趋势图数据
var data = $("#trendChartData").html();
if(!!data) {
	drawTrendChart(JSON.parse(data));
}
//当浏览器发生变更的时候,趋势图进行重绘
$(window).resize(function(){
	trendChart.resize();
});
//绘制趋势图
function drawTrendChart(data) {
	var monthArr = data.monthArr;
	var wkArr = data.wkArr;
	var numberObj = data.numberMap;
	for (var i in monthArr) {
		monthArr[i] = monthArr[i] + "\n" + wkArr[i];
	}
	//控制滾動範圍內只顯示12個柱狀圖
	var startValue = 0;
	if(monthArr.length > 12) {
		startValue = monthArr.length - 12;
	}
	//創建series
	var seriesDataArr = [];
	//顏色代碼
	var barColorArr = ["#FE9844","#43D9A7"];
	var barColorIndex = 0;
	//生成圖形
	for(var legend in numberObj) {
		seriesDataArr.push({
			name: legend,
	        data: numberObj[legend],
	        type: 'bar',
	        barGap: '0',
	        barWidth: '30%',
	        itemStyle: {
	            color: barColorArr[barColorIndex]
	        }
		});
		barColorIndex++;
		if (barColorIndex >= 2) {
			barColorIndex = 0;
		}
	}
	//設置Option
	trendChart.setOption({
	  title: {
	      text: '口罩發放趨勢圖',
	      textStyle: {
	          fontSize: 16
	      }
	  },
	  dataZoom:{
		  type: 'slider',
		  show: true,
		  startValue: startValue
	  },
	  tooltip:{
		  show: true,
		  trigger: 'axis',
		  axisPointer: {
		      type: 'shadow',
		      crossStyle: {
		    	  color: '#999'
		      }
		  },
		  textStyle: {
			  align: 'left'
		  }
	  },
	  legend:{
		  show: true,
		  type: 'plain',
		  width: '660'
	  },
	  xAxis: {
	      type: 'category',
	      data:  monthArr,
	      splitLine: {
	          show: false
	      },
	      axisLabel: {
	          interval:0
	          //rotate:-20
	      }
	  },
	  yAxis: [{
	      type: 'value',
	      splitLine: {
	          show: false
	      }
	  },{
	      type: 'value',
	      splitLine: {
	          show: false
	      }
	  }],
	  grid:{
	      show: false,
	      top:"50px",
	      left:"20px",
	      right:"30px",
	      bottom:"60px",
	      containLabel:true
	  },
	  series: seriesDataArr
	});
}

//表单附件
var formCode;
function uploadNote() {
	//listcode來源於表單創建的時候,在送簽過程中,是不存在listcode值的
    var listcode = $("#listcode").val();
    if(listcode){
    	layer_show("附件","../onesig/toFootNote.do?formCode="+listcode,500,400);
    	return;
    }
    layer_show("附件","../onesig/toFootNote.do?formCode="+formCode,500,400);
}