//打印
function printOut(btn){
	var cloneDom = $("#tabSigList").clone();
	cloneDom.prependTo("#tableDiv");
	$(btn).find("font").text("下载中...");
	var loadIndex = layer.load(0, {shade:[0.5,'#000']});
	$("#tableDiv").css("overflow-y","visible").css("height","auto");
	$("#tableDiv").css("overflow-x","visible").css("width","auto");
    //pdfDown($("#tableDiv")[0],btn,loadIndex);
	download($("#tableDiv")[0],btn,loadIndex);
	cloneDom.remove();
}
/**
 * 具有分页的pdf生成
 * @param dom
 * @param btn
 * @param loadIndex
 */
function pdfDown(dom,btn,loadIndex){
	html2canvas(dom,{
		taintTest: false, 
		allowTaint : false
	}).then(function(canvas){
		var contentWidth = canvas.width;
	      var contentHeight = canvas.height;
	      //一页pdf显示html页面生成的canvas高度;
	      var pageHeight = contentWidth / 592.28 * 841.89;
	      //未生成pdf的html页面高度
	      var leftHeight = contentHeight;
	      //页面偏移
	      var position = 0;
	      //a4纸的尺寸[595.28,841.89]，html页面生成的canvas在pdf中图片的宽高
	      var imgWidth = 555.28;
	      var imgHeight = 555.28/contentWidth * contentHeight;
	      var pageData = canvas.toDataURL('image/jpeg', 1.0);
	      var pdf = new jsPDF('', 'pt', 'a4');
	      //有两个高度需要区分，一个是html页面的实际高度，和生成pdf的页面高度(841.89)
	      //当内容未超过pdf一页显示的范围，无需分页
	      if (leftHeight < pageHeight) {
	    	  pdf.addImage(pageData, 'JPEG', 20, 0, imgWidth, imgHeight );
	      } else {
	          while(leftHeight > 0) {
	              pdf.addImage(pageData, 'JPEG', 20, position, imgWidth, imgHeight)
	              leftHeight -= pageHeight;
	              position -= 841.89;
	              //避免添加空白页
	              if(leftHeight > 0) {
	                pdf.addPage();
	              }
	          }
	      }
	      pdf.save($("#formName").val()+'.pdf');
	}).then(function(){
		$("#tableDiv").css("overflow-y","auto").css("height","100%");
	    $(btn).find("font").text(" PDF下載");
	    layer.close(loadIndex);
	})
}
/*document.querySelector('.download button').onclick = function(e) {
    var content = document.querySelector('.content')
    download(content)
  }*/
//显示为一页
function download(content,btn,loadIndex) {
  html2canvas(content, {
    allowTaint: false
}).then(function (canvas) {
  var contentWidth = canvas.width
  var contentHeight = canvas.height
  // 将canvas转为base64图片
  var pageData = canvas.toDataURL('image/jpeg', 1.0)
  // 设置pdf的尺寸，pdf要使用pt单位 已知 1pt/1px = 0.75   pt = (px/scale)* 0.75
  var orientation = "p";
  if(contentWidth > contentHeight){
      orientation = "l";
  }
  var pdfX = contentWidth;
  var pdfY = contentHeight;
  var imgX = pdfX+10;
  var imgY = pdfY+10; //内容图片这里不需要留白的距离
  // 初始化jspdf 第一个参数方向：默认''时为纵向，第二个参数设置pdf内容图片使用的长度单位为pt，第三个参数为PDF的大小，单位是pt
  var PDF = new jsPDF(orientation, 'pt', [pdfX,pdfY])
  // 将内容图片添加到pdf中，因为内容宽高和pdf宽高一样，就只需要一页，位置就是 0,0
  PDF.addImage(pageData, 'jpeg', 0, 5, imgX, imgY)
  PDF.save($("#formName").val()+'.pdf')
}).then(function(){
	$("#tableDiv").css("overflow-y","auto").css("height","100%");
	$(btn).find("font").text(" PDF下載");
	    layer.close(loadIndex);
	})
}
