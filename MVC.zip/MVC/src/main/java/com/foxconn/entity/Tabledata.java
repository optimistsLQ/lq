package com.foxconn.entity;

import java.io.Serializable;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

public class Tabledata implements Serializable {
	
	private static final long serialVersionUID = 4110421053331971057L;
	// 单据号
    private String formCode;
    // 表单名称
    private String formName;
    // 申请人
    private String applicant;
    // 申请部门
    private String applicantDepart;
    // 创建时间
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")  
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date createTime;
    // 幣別
    private String moneyType;
    // 总金额
    private Double totalMoney;
    // 表格内容
    private String tabtext;
    // 簽核狀態
    private String status;
    // 費用類型
    private String tableType;
    // 暫時無用,保留字段
    private String remark1;
    // 保存送签人的id,用於退回時,發送郵件
    private String remark2;
    // 是否为结报E化表单 1是，0否
    private Integer isCloseReport;
    // 表单是否申请退回 1是，0否
    private Integer applyCancel;
    // 表單申請退回或作廢的原因
    private String applyRemark;
    // 簽核是否延期
    private String isDelay;
    // 對應時限任務表中的TUID，代表該表單對應的時限管控任務
    private String tuid;
    
    public String getFormCode() {
        return formCode;
    }

    public void setFormCode(String formCode) {
        this.formCode = formCode == null ? null : formCode.trim();
    }

    public String getFormName() {
        return formName;
    }

    public void setFormName(String formName) {
        this.formName = formName == null ? null : formName.trim();
    }

    public String getApplicant() {
        return applicant;
    }

    public void setApplicant(String applicant) {
        this.applicant = applicant == null ? null : applicant.trim();
    }

    public String getApplicantDepart() {
        return applicantDepart;
    }

    public void setApplicantDepart(String applicantDepart) {
        this.applicantDepart = applicantDepart == null ? null : applicantDepart.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getMoneyType() {
        return moneyType;
    }

    public void setMoneyType(String moneyType) {
        this.moneyType = moneyType == null ? null : moneyType.trim();
    }

    public Double getTotalMoney() {
        return totalMoney;
    }

    public void setTotalMoney(Double totalMoney) {
        this.totalMoney = totalMoney;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }

    public String getTableType() {
        return tableType;
    }

    public void setTableType(String tableType) {
        this.tableType = tableType == null ? null : tableType.trim();
    }

    public String getRemark1() {
        return remark1;
    }

    public void setRemark1(String remark1) {
        this.remark1 = remark1 == null ? null : remark1.trim();
    }

    public String getRemark2() {
        return remark2;
    }

    public void setRemark2(String remark2) {
        this.remark2 = remark2 == null ? null : remark2.trim();
    }

    public String getTabtext() {
        return tabtext;
    }

    public void setTabtext(String tabtext) {
        this.tabtext = tabtext == null ? null : tabtext.trim();
    }

	public Integer getIsCloseReport() {
		return isCloseReport;
	}

	public void setIsCloseReport(Integer isCloseReport) {
		this.isCloseReport = isCloseReport;
	}

	public Integer getApplyCancel() {
		return applyCancel;
	}

	public void setApplyCancel(Integer applyCancel) {
		this.applyCancel = applyCancel;
	}

	public String getApplyRemark() {
		return applyRemark;
	}

	public void setApplyRemark(String applyRemark) {
		this.applyRemark = applyRemark;
	}

	public String getIsDelay() {
		return isDelay;
	}

	public void setIsDelay(String isDelay) {
		this.isDelay = isDelay;
	}

	public String getTuid() {
		return tuid;
	}

	public void setTuid(String tuid) {
		this.tuid = tuid;
	}
}