package com.foxconn.entity;

import java.io.Serializable;
import java.util.List;

/**
 * 部門實體
 */
public class Depart implements Serializable {
  
	private static final long serialVersionUID = -4078899711263788389L;
	
	private volatile String uid;
    // 部門名稱
    private String departName;
    // 部門代碼
    private String departCode;
    // 備註
    private String remarker;
    
    private volatile List<User> userList;

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid == null ? null : uid.trim();
    }

    public String getDepartName() {
        return departName;
    }

    public void setDepartName(String departName) {
        this.departName = departName == null ? null : departName.trim();
    }

    public String getDepartCode() {
        return departCode;
    }

    public void setDepartCode(String departCode) {
        this.departCode = departCode == null ? null : departCode.trim();
    }

    public String getRemarker() {
        return remarker;
    }

    public void setRemarker(String remarker) {
        this.remarker = remarker == null ? null : remarker.trim();
    }

	public List<User> getUserList() {
		return userList;
	}

	public void setUserList(List<User> userList) {
		this.userList = userList;
	}
}