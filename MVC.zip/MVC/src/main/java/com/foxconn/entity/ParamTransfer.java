package com.foxconn.entity;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.foxconn.utils.Utils;

public class ParamTransfer {

	private Class<?> cla;
	private String tableName;
	private Integer start;
	private Integer length;
	private String order;
	// 该字段一定要转为大写,例如:number在数据库中为特殊字符 "${orderField}"
	private String orderField;
	private String search;
	private String mySearch;
	
	
	// 多條件,KEY代表數據庫字段(注意：是數據庫不是JavaBean),Value代表字段的條件
	private Map<String,List<String>> searchMap; 
	// 多條件鏈接符 OR 或  AND
	private String searchType;
	// 是否進行模糊查詢
	private boolean fuzzyQuery;
	
	private String timeLayout;
	// 存放需要操作类型的属性名-用作数据库表字段(需要转换为带有下滑下的字段)
	private List<String> colums;
	// 指定需要查詢的字段
	private List<String> assignField;
	private boolean distinct;
	public ParamTransfer () {
		timeLayout = "yyyy-MM-dd HH:mm:ss";
		searchMap = new HashMap<String, List<String>>();
		orderField = "uid";
		order = "asc";
		searchType = " AND ";
		fuzzyQuery = false;
	}
	
	public String getTimeLayout() {
		return timeLayout;
	}
	public void setTimeLayout(String timeLayout) {
		this.timeLayout = timeLayout;
	}
	public Class<?> getCla() {
		return cla;
	}
	public void setCla(Class<?> cla) {
		this.cla = cla;
	}
	
	public String getTableName() {
		return tableName;
	}
	public void setTableName(Class<?> cla) {
		String tableName = "T"+Utils.humpToLine(cla.getSimpleName());
		this.tableName = tableName;
	}
	
	public Integer getStart() {
		return start;
	}
	public void setStart(Integer start) {
		this.start = start;
	}
	public Integer getLength() {
		return length;
	}
	public void setLength(Integer length) {
		this.length = length;
	}
	public String getOrder() {
		return order;
	}
	public void setOrder(String order) {
		this.order = order;
	}
	public String getOrderField() {
		return orderField;
	}
	public void setOrderField(String orderField) {
		this.orderField = orderField;
	}
	public String getSearch() {
		return search;
	}
	public void setSearch(String search) {
		this.search = search;
	}
	public String getMySearch() {
		return mySearch;
	}
	public void setMySearch(String mySearch) {
		this.mySearch = mySearch;
	}
	
	public List<String> getColums() {
		return colums;
	}

	/**
	 * 存放数据库字段名 用作多个字段查询 例:(colum1 like % text % OR colum2 like % text %)
	 * {@link com.foxconn.service.impl.BaseServiceImpl#getCloumsField}
	 * 私有方法
	 * @see line 171
	 * @param colums
	 */
	public void setColums(List<String> colums) {
		this.colums = colums;
	}
	
	public List<String> getAssignField() {
		return assignField;
	}

	/**
	 * 存放需要查詢的指定列明,以查詢類型的屬性為準,自動轉換為數據庫字段名
	 * @param assignField
	 */
	public void setAssignField(List<String> assignField) {
		for (int i = 0; i<assignField.size(); i++) {
			assignField.set(i, Utils.humpToLine(assignField.get(i)));
		}
		this.assignField = assignField;
	}
	
	
	public boolean isDistinct() {
		return distinct;
	}
	/**
	 * 是否需要去除重複,默認為false
	 * @param distinct
	 * @note 去重 請注意排序字段的問題
	 */
	public void setDistinct(boolean distinct) {
		this.distinct = distinct;
	}

	public String getSearchType() {
		return searchType;
	}

	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}

	public Map<String, List<String>> getSearchMap() {
		return searchMap;
	}

	public void setSearchMap(Map<String, List<String>> searchMap) {
		this.searchMap = searchMap;
	}

	public boolean isFuzzyQuery() {
		return fuzzyQuery;
	}

	public void setFuzzyQuery(boolean fuzzyQuery) {
		this.fuzzyQuery = fuzzyQuery;
	}

	@Override
	public String toString() {
		return "ParamTransfer [cla=" + cla + ", tableName=" + tableName + ", start=" + start + ", length=" + length
				+ ", order=" + order + ", orderField=" + orderField + ", search=" + search + ", mySearch=" + mySearch
				+ ", searchMap=" + searchMap + ", searchType=" + searchType + ", fuzzyQuery=" + fuzzyQuery
				+ ", timeLayout=" + timeLayout + ", colums=" + colums + ", assignField=" + assignField + ", distinct="
				+ distinct + "]";
	}
}
