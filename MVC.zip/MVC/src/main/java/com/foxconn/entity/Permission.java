package com.foxconn.entity;

import java.io.Serializable;

/**
 * 权限实体
 */
public class Permission implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 4538493281541038700L;
	// 权限ID
	private String perId;
	// 权限名称
    private String perName;
    // 资源路径
    private String perUrl;
    // 权限描述
    private String perDescription;

    public String getPerId() {
        return perId;
    }

    public void setPerId(String perId) {
        this.perId = perId == null ? null : perId.trim();
    }

    public String getPerName() {
        return perName;
    }

    public void setPerName(String perName) {
        this.perName = perName == null ? null : perName.trim();
    }

    public String getPerUrl() {
        return perUrl;
    }

    public void setPerUrl(String perUrl) {
        this.perUrl = perUrl == null ? null : perUrl.trim();
    }

    public String getPerDescription() {
        return perDescription;
    }

    public void setPerDescription(String perDescription) {
        this.perDescription = perDescription == null ? null : perDescription.trim();
    }

	@Override
	public String toString() {
		return "PermissionEntity [perId=" + perId + ", perName=" + perName + ", perUrl=" + perUrl + ", perDescription="
				+ perDescription + "]";
	}
}