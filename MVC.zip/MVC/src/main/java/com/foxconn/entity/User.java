package com.foxconn.entity;

import java.io.Serializable;
import java.util.List;

/**
 * 用户实体
 */
public class User implements Serializable{
	
	private static final long serialVersionUID = -4936271722996696264L;
	// 用户ID
    private String userId;
    // 工號
    private String cardNum;
    // 姓名
    private String userName;
    // 密码
    private String pwd;
    // 电话
    private String phone;
    // 邮箱
    private String email;
    // 用户状态
    private int userStatus;
    // 部門ID
    private String departId;   
    // 最后一次登录时间
    private String lastLogintime;
    // 角色集合
    private List<Role> roleList;
    // 所屬部門
    private Depart depart;

	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getCardNum() {
		return cardNum;
	}
	public void setCardNum(String cardNum) {
		this.cardNum = cardNum;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getUserStatus() {
		return userStatus;
	}
	public void setUserStatus(int userStatus) {
		this.userStatus = userStatus;
	}
	public String getLastLogintime() {
		return lastLogintime;
	}
	public void setLastLogintime(String lastLogintime) {
		this.lastLogintime = lastLogintime;
	}
	public List<Role> getRoleList() {
		return roleList;
	}
	public void setRoleList(List<Role> roleList) {
		this.roleList = roleList;
	}
	public String getDepartId() {
		return departId;
	}
	public void setDepartId(String departId) {
		this.departId = departId;
	}
	public Depart getDepart() {
		return depart;
	}
	public void setDepart(Depart depart) {
		this.depart = depart;
	}
	@Override
	public String toString() {
		return "UserEntity [userId=" + userId + ", cardNum=" + cardNum + ", userName=" + userName + ", pwd=" + pwd
				+ ", phone=" + phone + ", email=" + email + ", userStatus=" + userStatus + ", departId=" + departId
				+ ", lastLogintime=" + lastLogintime + ", roleList=" + roleList + ", depart=" + depart + "]";
	}
}