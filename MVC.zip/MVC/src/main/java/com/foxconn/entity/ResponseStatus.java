package com.foxconn.entity;

public class ResponseStatus<T> {

	public int status;
	public String message;
	public int currPage;
	public int allPageCode;
	public T data;
	
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public int getCurrPage()
	{
		return currPage;
	}
	public void setCurrPage(int currPage)
	{
		this.currPage = currPage;
	}
	public int getAllPageCode()
	{
		return allPageCode;
	}
	public void setAllPageCode(int allPageCode)
	{
		this.allPageCode = allPageCode;
	}
	public T getData() {
		return data;
	}
	public void setData(T data) {
		this.data = data;
	}
	@Override
	public String toString()
	{
		return "ResponseStatus [status=" + status + ", message=" + message + ", currPage=" + currPage + ", allPageCode="
				+ allPageCode + ", data=" + data + "]";
	}
	 
}
