package com.foxconn.entity;

import java.io.Serializable;

public class RPEntity implements Serializable {
	
	private static final long serialVersionUID = -6784342902784248658L;

	private String rpId;

    private String roleId;

    private String perId;

    public String getRpId() {
        return rpId;
    }

    public void setRpId(String rpId) {
        this.rpId = rpId == null ? null : rpId.trim();
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId == null ? null : roleId.trim();
    }

    public String getPerId() {
        return perId;
    }

    public void setPerId(String perId) {
        this.perId = perId == null ? null : perId.trim();
    }

}