package com.foxconn.entity;

import java.io.Serializable;
import java.util.List;
/**
 * 角色实体
 */
public class Role implements Serializable {
	
	private static final long serialVersionUID = -7364921172505165455L;
	// 角色ID
	private String roleId;
	// 角色名称
    private String roleName;
    // 角色描述
    private String description;
    // 用户集合
    private List<User> userList;
    // 权限集合
    private List<Permission> permissionList;

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId == null ? null : roleId.trim();
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName == null ? null : roleName.trim();
    }

	public List<User> getUserList() {
		return userList;
	}

	public void setUserList(List<User> userList) {
		this.userList = userList;
	}

	public List<Permission> getPermissionList() {
		return permissionList;
	}

	public void setPermissionList(List<Permission> permissionList) {
		this.permissionList = permissionList;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "RoleEntity [roleId=" + roleId + ", roleName=" + roleName + ", description=" + description
				+ ", userList=" + userList + ", permissionList=" + permissionList + "]";
	}

	

}