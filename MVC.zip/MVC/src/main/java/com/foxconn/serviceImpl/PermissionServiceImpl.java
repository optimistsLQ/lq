package com.foxconn.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.entity.Permission;
import com.foxconn.mapper.PermissionEntityMapper;
import com.foxconn.service.PermissionService;
@Service
public class PermissionServiceImpl implements PermissionService {

	@Autowired
	private PermissionEntityMapper permissionMapper;
	@Override
	public int insertPermission(Permission permission) {
		return permissionMapper.insert(permission);

	}
	@Override
	public int delPermission(String [] perId) {
		return permissionMapper.deleteByPrimaryKeys(perId);

	}
	@Override
	public List<Permission> listAllPermission() {
		List<Permission> list = permissionMapper.listAllPermission();
		return list;
	}
	@Override
	public Permission getPermissionByPerName(String perName) {
		return permissionMapper.getPermissionByPerName(perName);
	}
	@Override
	public Permission getPermissionByPerId(String perId) {
		return permissionMapper.selectByPrimaryKey(perId);
	}
	@Override
	public int updatePermission(Permission permission) {
		return permissionMapper.updateByPrimaryKeySelective(permission);
	}
	
}
