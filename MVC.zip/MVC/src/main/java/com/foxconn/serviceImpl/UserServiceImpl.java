package com.foxconn.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.entity.User;
import com.foxconn.mapper.UserEntityMapper;
import com.foxconn.service.UserService;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserEntityMapper userMapper; 

	@Override
	public boolean insertUser(User user) {		
		int i = userMapper.insert(user);
		if (i == 0) {
			return false;			
		} else {
			return true;			
		}
	}

	@Override
	public List<User> listAllUser(String type) {
		return userMapper.listAllUser(type);
	}

	@Override
	public User getUserByCardNum(String cardNum) {
		return userMapper.getUserByCardNum(cardNum);
	}

	@Override
	public User getUserById(String userId) {
		return userMapper.selectByPrimaryKey(userId);
	}

	@Override
	public boolean delUser(List<String> userId) {
		int i = userMapper.deleteByPrimaryKey(userId);
		if(i == 0) {
			return false;
		} else {
			return true;
		}
	}

	@Override
	public boolean updateUser(User user) {
		int i = userMapper.updateByPrimaryKeySelective(user);
		if(i == 0) {
			return false;
		} else {
			return true;
		}
	}

	@Override
	public List<User> findUserByDepart(String[] ids) {
		return userMapper.listUserByDepart(ids);
	}

	@Override
	public User getUserByUserName(String userName) {
		return userMapper.getUserByUserName(userName);
	}

	@Override
	public List<User> findUserByUserId(String[] ids) {
		return userMapper.listUserByUserId(ids);
	}
}
