package com.foxconn.serviceImpl;

import java.util.Arrays;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.foxconn.entity.Role;
import com.foxconn.mapper.RoleEntityMapper;
import com.foxconn.service.RolePermissionService;
import com.foxconn.service.RoleService;
@Service
public class RoleServiceImpl implements RoleService {

	@Autowired
	private RoleEntityMapper roleMapper;
	@Autowired
	private RolePermissionService rpService;
	@Override
	public String  insertRole(Role role) {
		roleMapper.insertRoleGetId(role);
		String id = role.getRoleId();
		return id;
	}

	@Override
	@Transactional
	public int  delRoles(List<String> roleids) {
		int code = roleMapper.deleteByPrimaryKey(roleids);
//		rpService.delRolePermissionByRoleId(roleId);
		return code;
	}

	@Override
	public List<Role> listRoleAll() {
		return roleMapper.listAllRole();
	}
	@Override
	@Transactional
	public int insertRoleGetId(Role roleEntity, String[] menus) {	
		roleMapper.insertRoleGetId(roleEntity);
		String roleId = roleEntity.getRoleId();
		List<String> list = Arrays.asList(menus);
		int code = rpService.insertListBtIds(list, roleId);
		return code;
	}

	@Override
	public List<Role> findAllRolePermission() {
		// TODO Auto-generated method stub
		return roleMapper.findAllRolePermission();
	}

	@Override
	public List<Role> findAllRoleUserPermission() {
		// TODO Auto-generated method stub
		return roleMapper.findAllRoleUserPermission();
	}

	@Override
	public Role findOneRoleUserPermission(String roleId) {
		// TODO Auto-generated method stub
		return roleMapper.findOneRoleUserPermission(roleId);
	}

	@Override
	public int updateRoel(Role role) {
		int i = roleMapper.updateByPrimaryKeySelective(role);
		return i;
	}
}
