package com.foxconn.serviceImpl;

import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSONObject;
import com.foxconn.entity.ParamTransfer;
import com.foxconn.entity.ResponseStatus;
import com.foxconn.mapper.BaseMapper;
import com.foxconn.service.BaseService;
import com.foxconn.utils.Utils;

@Service
public class BaseServiceImpl implements BaseService {

	@Resource
	private BaseMapper mapper;
	
	/**
	 * 查询数据
	 * @param cla 查询的数据类型
	 * @param param 查询的相关参数对象
	 */
	@Override
	public List<?> listData(Class<?> cla, ParamTransfer param) {
		
		checkParamSuffixIsZero(param);
		SimpleDateFormat dateFormat = new SimpleDateFormat(param.getTimeLayout());
		param.setOrderField((param.getOrderField().contains("_")?param.getOrderField():Utils.humpToLine(param.getOrderField())));
		param.setTableName(cla);
		param.setColums(getCloumsField(cla,param.getAssignField()));
		List<Map<String, Object>> list = mapper.listData(param);
		for (int i = 0;i<list.size();i++) {
			Map<String, Object> tempMap = new LinkedHashMap<String, Object>();
			Map<String, Object> srcMap = list.get(i);
			Set<Entry<String,Object>> entrySet = srcMap.entrySet();
			Iterator<Entry<String, Object>> ite = entrySet.iterator();
			while (ite.hasNext()) {
				Entry<String, Object> entry = ite.next();
				String fieldName = Utils.underlineToHump(entry.getKey());
				Object filedValue = entry.getValue();
				if(filedValue instanceof Date) {
					tempMap.put(fieldName, dateFormat.format(filedValue));
				} else {
					tempMap.put(fieldName, filedValue);
				}
			}
			srcMap.clear();
			list.set(i, tempMap);
		}
		return list;
	}
	/**
	 * 查询数据总数量
	 * @param cla 查询的数据类型
	 * @param param 查询的参数对象
	 */
	@Override
	public int selectAllCount(Class<?> cla,ParamTransfer param) {
		param.setTableName(cla);
		return mapper.selectAllCount(param);
	}
	@Override
	public int selectAllCountAddCondition(Class<?> cla,ParamTransfer param) {
		param.setTableName(cla);
		return mapper.selectAllCountAddCondition(param);
	}
	/**
	 * 查询带有条件数据数量
	 * @param cla 查询的数据类型
	 * @param param 查询的参数对象
	 */
	@Override
	public int selectHaveConditionCount(Class<?> cla,ParamTransfer param){
		checkParamSuffixIsZero(param);
		param.setTableName(cla);
		param.setColums(getCloumsField(cla,param.getAssignField()));
		return mapper.selectHaveConditionCount(param);
	}
	/**
	 * 编辑单条数据
	 * @param obj 需要写入的对象
	 */
	@Override
	public String updateItem(Object obj) {
		Class<?> cla = obj.getClass();
		String tableName,uid = null;
		tableName = "T"+Utils.humpToLine(cla.getSimpleName());
		Field[] fields = cla.getDeclaredFields();
		Map<String,Object> map = new HashMap<String,Object>();
		for (Field field : fields) {
			field.setAccessible(true);
			int mod = field.getModifiers();
			String fileName = field.getName();
			try {
				if ("uid".equals(fileName)) {
					uid = field.get(obj).toString();
				} else {
					if (Utils.excludeField(mod)) {
						fileName = Utils.humpToLine(fileName);
						Object fieldValue = field.get(obj);
						if(fieldValue!=null && field.getType().getSimpleName().equals("String")) {
							map.put(fileName, Utils.SimplifiedConverter((String)fieldValue));
						} else {
							map.put(fileName, fieldValue);
						}
					}
				}
			} catch (IllegalArgumentException | IllegalAccessException e) {
				e.printStackTrace();
			}
		}
		ResponseStatus<?> rs = new ResponseStatus<>();
		if (mapper.updateItem(uid,tableName,map) > 0) {
			rs.setStatus(1);
			rs.setMessage("修改成功!");
		} else {
			rs.setStatus(0);
			rs.setMessage("修改失敗!");
		}
		return JSONObject.toJSONString(rs);
	}
	@Override
	/**
	 * 通过id批量删除
	 * @param cla 需要删除的对象类型
	 * @param ids 需要删除的id数组集
	 * @return {status:1/0,message:***}
	 */
	public String deleteItem(Class<?> cla,String [] ids) {
		return deleteItem(cla,ids,null);
	}
	/**
	 * 通过id批量删除
	 * @param cla 需要删除的对象类型
	 * @param ids 需要删除的id数组集
	 * @param deleteField 刪除的字段
	 */
	@Transactional
	public String deleteItem(Class<?> cla,String[] ids,String deleteField) {
		ResponseStatus<?> rs = new ResponseStatus<>();
		//刪除表單
		String tableName = "T"+Utils.humpToLine(cla.getSimpleName());
		if (mapper.deleteItem(tableName,ids,(deleteField==null?null:Utils.humpToLine(deleteField))) > 0) {
			rs.setStatus(1);
			rs.setMessage("刪除成功!");
		} else {
			rs.setStatus(0);
			rs.setMessage("刪除失敗!");
		}
		return JSONObject.toJSONString(rs);
	}
	/**
	 * 批量写入/单笔写入
	 * @param cla 需要写入的对象类型
	 * @param params 需要写入的数据集合
	 * @note 批量写入的时候 默认每次提交500
	 */
	public String insertItem(Class<?> cla,List<?> params) throws Exception { 
		return insertItem(cla,params,null);
	}
	public String insertItem(Class<?> cla,List<?> params,String date) throws Exception {
		//簡轉繁
		Utils.SimplifiedConverter(params);
		String tableName = "T"+Utils.humpToLine(cla.getSimpleName());
		// 类中的属性名字(无下划线)-用作写入时params取值使用
		List<String> fieldList = new ArrayList<>();
		// 数据库中的栏位名字(带有下滑线)-用作写入时数据库的栏位名称
		List<String> columnName = new ArrayList<>();
		Field[] fields = cla.getDeclaredFields();
		for (Field field : fields) {
			int mod = field.getModifiers();
			String fieldName = field.getName();
			if (Utils.excludeField(mod)) {
				columnName.add(Utils.humpToLine(fieldName));
				fieldList.add(fieldName);
			}
		}
		// 按日期删除以前的数据
		if (date != null && date.contains("-")) {
			// 查询这个月是否已经存在数据,如果存在,就删除
			if (selectMonthExists(cla,date)) {
				// 删除当前月上传的数据
				deleteAll(cla,date);
			}
		} else if (date != null && date.equals("deleteAll")) {
			// 清空当前表
			deleteAll(cla,null);
		} else if (date != null && date.equals("append")) {
			// 查詢現在已有的資料
			ParamTransfer paramTransfer = new ParamTransfer();
			paramTransfer.setCla(cla);
			paramTransfer.setTableName(cla);
			List<String> assignField = new ArrayList<String>();
			Class<?> clas = params.get(0).getClass();
			for (Field field:clas.getDeclaredFields()) {
				if (Utils.excludeField(field.getModifiers())) {
					assignField.add(field.getName());
				}
			}
			paramTransfer.setAssignField(assignField);
			paramTransfer.setOrderField(assignField.get(0));
			Set<String> existsDataSet = new HashSet<String>();
			for (Map<String,Object> map : mapper.listData(paramTransfer)) {
				StringBuffer valueBuffer = new StringBuffer();
				for (String key : map.keySet()) {
					if (!key.equalsIgnoreCase("rowno")) {
						valueBuffer.append(map.get(key)==null?"":map.get(key).toString());
					}
				}
				existsDataSet.add(valueBuffer.toString());
			}
			//資料追加,過濾重複值
			for (Iterator<?> ite = params.iterator();ite.hasNext();) {
				Object obj = ite.next();
				Class<?> objCla = obj.getClass();
				StringBuffer sb = new StringBuffer();
				for (Field field:objCla.getDeclaredFields()) {
					field.setAccessible(true);
					if (Utils.excludeField(field.getModifiers())) {
						sb.append(field.get(obj));
					}
				}
				if (existsDataSet.contains(sb.toString())) {
					ite.remove();
				}
			}
			existsDataSet.clear();
		}
		ResponseStatus<?> rs = new ResponseStatus<>();
		if (params.isEmpty()) {
			rs.setStatus(0);
			rs.setMessage("數據已存在,請勿重複添加!");
			return JSONObject.toJSONString(rs);
		}
		List<List<?>> splitCollection = Utils.splitCollection(params, 500);
		int code = 0;
		for (List<?> list : splitCollection) {
			code += mapper.insertItem(tableName,list,columnName,fieldList);
		}
		if (code >0) {
			rs.setStatus(1);
			rs.setMessage("新增成功!");
		} else {
			rs.setStatus(0);
			rs.setMessage("新增失敗!");
		}
		return JSONObject.toJSONString(rs);
	}
	/**
	 * 用作获得除id 静态变量 
	 * 得到查询类型的数据库字段名
	 * @return
	 */
	private List<String> getCloumsField(Class<?> cla,List<String> assignFieldList){
		List<String> list = new ArrayList<>();
		Field[] fields = cla.getDeclaredFields();
		for (Field field : fields) {
			int mod = field.getModifiers();
			if (Utils.excludeField(mod)) {
				if (assignFieldList != null) {
					if (assignFieldList.contains(field.getName())) {
						list.add(Utils.humpToLine(field.getName()));
					}
				} else {
					list.add(Utils.humpToLine(field.getName()));
				}
			}
		}
		return list;
	}
	/**
	 * 由于oracle like 查询小数前缀为0 会无法匹配
	 * 解决,匹配前缀是否为0,如果为0 舍去 用.23匹配
	 */
	private void checkParamSuffixIsZero(ParamTransfer param){
		String mySearch = param.getMySearch();
		String search = param.getSearch();
		param.setMySearch(handleParamChange(mySearch));
		param.setSearch(handleParamChange(search));
	}
	private String handleParamChange(String param){
		if(param != null){
			if(param.startsWith("0")){
				param = param.substring(param.indexOf("0")+1);
			}
		}
		return param;
	}
	@Override
	/**
	 * 處理excel上傳-轉換為List<?>
	 */
	public String handleUploadFile(Class<?> cla,MultipartFile file,String date) throws Exception {
		try {
			// 檢查文件大小
			List<Object> list = Utils.readExcel(file,cla,false);
			if (list.size() == 0) {
				throw new Exception("請檢查文件是否選擇正確!");
			}
			// 設置歸屬日期
			if (date != null && date.contains("-")) {
				try {
					for (Object obj : list) {
						String [] dateArray = date.split("-");
						obj.getClass().getMethod("setDataTime", String.class).invoke(obj, dateArray[0]+"-"+dateArray[1]);
					}
				} catch (Exception e) {
					throw new Exception("對象不存在setDataTime方法!");
				}
			}
			return insertItem(cla, list, date);
		} catch (Exception e) {
			//如果是否法人錯誤的異常就直接拋出
			if (e.getMessage().contains("法人") && e.getMessage().contains("錯誤")) {
				throw e;
			}
			//打印異常信息
			e.printStackTrace();
			//前端友好提示
			throw new Exception("請使用正確的Excel模版上傳！");
		}
	}
	
	/**
	 * 查询当月数据是否存在
	 * @param cla 查询的表名
	 */
	public boolean selectMonthExists(Class<?> cla,String date) {
		String tableName = "T"+Utils.humpToLine(cla.getSimpleName());
		String [] dateArray = date.split("-");
		return mapper.selectMonthExists(tableName, dateArray[0]+"-"+dateArray[1])>0;
	}
	/**
	 * 清空表
	 * @param 删除的表名
	 * @isSameMonth 是否只删除当前月
	 **/
	public int deleteAll(Class<?> cla,String date) {
		String tableName = "T"+Utils.humpToLine(cla.getSimpleName());
		if (date != null) {
			String [] dateArray = date.split("-");
			return mapper.deleteAll(tableName, dateArray[0]+"-"+dateArray[1]);
		} else {
			return mapper.deleteAll(tableName, null);
		}
	}
	@Override
	public Map<String, List<String>> getAllField() {
		List<Map<String, Object>> list = mapper.getAllField();
		System.out.println(list.toString());
		Map<String, List<String>> map = new HashMap<String, List<String>>();
		for (Map<String, Object> maptemp : list) {
			String key = (String) maptemp.get("TABLE_NAME");
			String val = (String) maptemp.get("COLUMN_NAME");
			key = Utils.underlineToHump(key.substring(2));
			key = key.substring(0,1).toUpperCase()+key.substring(1);
			val = Utils.underlineToHump(val);
			String chineseName = null;
			try {
				Class<?> cla = Class.forName("com.foxconn.entity."+key);
				Object obj = cla.newInstance();
				chineseName = (String) cla.getMethod("get"+val.substring(0,1).toUpperCase()+val.substring(1)+"Chinese").invoke(obj);
			} catch (Exception e) { e = null; }
			if (chineseName != null) {
				if (map.get(key) == null) {
					map.put(key, new ArrayList<String>());
				}
				map.get(key).add(val+"-"+chineseName);
			}
		}
		return map;
	}
}
