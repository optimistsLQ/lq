package com.foxconn.serviceImpl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.entity.ProxyEntity;
import com.foxconn.mapper.ProxyEntityMapper;
import com.foxconn.service.ProxyService;

@Service	
public class ProxyServiceImpl implements ProxyService{

	@Autowired
	private ProxyEntityMapper proxyMapper;
	
	@Override
	public int deleteByPrimaryKey(String pid) {
		return proxyMapper.deleteByPrimaryKey(pid);
	}

	@Override
	public int insertSelective(ProxyEntity record) {
		return proxyMapper.insertSelective(record);
	}
	
	@Override
	public int deleteByUserId(String userId) {
		return proxyMapper.deleteByUserId(userId);
	}

	@Override
	public ProxyEntity selectByUserId(String userId) {
		return proxyMapper.selectByUserId(userId);
	}
	
	@Override
	public List<ProxyEntity> selectByUserIds(List<String> userIds) {
		return proxyMapper.selectByUserIds(userIds);
	}
	
	@Override
	public ProxyEntity selectByProxyId(String proxyId) {
		return proxyMapper.selectByProxyId(proxyId);
	}
	
	@Override
	public ProxyEntity selectByProxyIdByEndTimeBefore(String proxyId) {
		return proxyMapper.selectByProxyIdByEndTimeBefore(proxyId);
	}

	@Override
	public List<ProxyEntity> findAll() {
		return proxyMapper.findAll();
	}

	@Override
	public List<ProxyEntity> findAllBySelfId(String id) {
		
		return proxyMapper.findAllBySelfId(id);
	}
	@Override
	public ProxyEntity checkProxyExists(String proxyId,Date currTime) {
		return proxyMapper.selectByUserIdTime(proxyId, currTime);
	}
	
}
