package com.foxconn.shiro;

import java.util.ArrayList;
import java.util.List;


import org.apache.commons.collections.CollectionUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.springframework.beans.factory.annotation.Autowired;

import com.foxconn.entity.Permission;
import com.foxconn.entity.Role;
import com.foxconn.entity.User;
import com.foxconn.service.UserService;

public class ShiroRealm extends AuthorizingRealm {

	@Autowired
	private UserService userService;

	/**
	 * 授權
	 **/
	@Override
	protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
		User user = (User) principals.fromRealm(this.getClass().getName()).iterator().next();
		List<String> roleNameList = new ArrayList<String>();
		List<String> premissionNameList = new ArrayList<String>();
		List<Role> roleList = user.getRoleList();
		if (CollectionUtils.isNotEmpty(roleList)) {
			for (Role role : roleList) {
				roleNameList.add(role.getRoleName());
				List<Permission> premissionList = role.getPermissionList();
				if (CollectionUtils.isNotEmpty(premissionList)) {
					for (Permission premission : premissionList) {
						premissionNameList.add(premission.getPerName());
					}
				}
			}
		}
		System.out.println("角色集合》》"+roleNameList.toString());
		System.out.println("权限集合》》"+premissionNameList.toString());
		SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
		info.addStringPermissions(premissionNameList);
		info.addRoles(roleNameList);
		return info;
	}

	/**
	 * 認證
	 **/
	@Override
	protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
		UsernamePasswordToken Token = (UsernamePasswordToken) token;
		String userName = Token.getUsername();
		User user = userService.getUserByCardNum(userName);
		return new SimpleAuthenticationInfo(user, user.getPwd(), this.getClass().getName());
	}

}
