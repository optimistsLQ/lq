package com.foxconn.shiro;

import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;

import java.util.HashMap;
import java.util.LinkedHashMap;

import org.apache.shiro.cache.MemoryConstrainedCacheManager;
import org.apache.shiro.mgt.SecurityManager;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * shiro權限管理框架配置類
 **/
@Configuration
public class ShiroConfiguration {

	/**
	 * 资源拦截配置
	 **/
	@Bean
	public ShiroFilterFactoryBean shiroFilterFactoryBean(
			@Qualifier(value = "securityManager") SecurityManager securityManager) {
		ShiroFilterFactoryBean bean = new ShiroFilterFactoryBean();
		bean.setSecurityManager(securityManager);
		HashMap<String, String> map = new LinkedHashMap<String, String>();
		map.put("/user/toadminList.do", "perms[用户管理]");
		map.put("/permission/listAll.do", "perms[权限管理]");
		map.put("/role/listRoleDetail.do", "perms[角色管理]");
		map.put("/baseData/toDepart.do", "perms[部门管理]");
		map.put("/register.do", "anon");
		map.put("/findPwd.do", "anon");
		map.put("/login.do", "anon");
		map.put("/toForgetPwd.do", "anon");
		map.put("/sendVerificationCode.do", "anon");
		map.put("/static/**", "anon");
		map.put("/templates/**", "authc");
		map.put("/*.do", "authc");
		bean.setLoginUrl("login.do");
		bean.setUnauthorizedUrl("/user/fileLogin.do");
		bean.setFilterChainDefinitionMap(map);
		return bean;
	}

	@Bean(value = "securityManager")
	public SecurityManager securityManager(@Qualifier(value = "shiroRealm") ShiroRealm shiroRealm) {
		DefaultWebSecurityManager securityManager = new DefaultWebSecurityManager();
		securityManager.setRealm(shiroRealm);
		securityManager.setCacheManager(new MemoryConstrainedCacheManager());// 设置缓存
		return securityManager;
	}

	/**
	 * 自定义身份认证
	 */
	@Bean(value = "shiroRealm")
	public ShiroRealm shiroRealm() {
		return new ShiroRealm();
	}
}
