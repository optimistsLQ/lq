package com.foxconn.controller;

import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.Base64Utils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSONObject;
import com.foxconn.entity.Depart;
import com.foxconn.entity.ParamTransfer;
import com.foxconn.entity.ResponseStatus;
import com.foxconn.entity.User;
import com.foxconn.service.BaseService;
import com.foxconn.service.UserService;
import com.foxconn.utils.ExcelUtil;
import com.foxconn.utils.Utils;

/**
 * 基礎資料維護
 **/
@Controller
@RequestMapping(value="/baseData")
public class BaseDataController {
	
	@Autowired
	private UserService userService;
	
	@Resource
	private BaseService service;
	
	/**
	 * 跳转添加页面
	 * @return
	 */
	@RequestMapping("toAdd.do")
	public String add(){
		return "baseData/add";
	}
	/**
	 * 跳转刪除页面
	 * @return
	 */
	@RequestMapping("todel.do")
	public String del(){
		return "baseData/del";
	}
	@RequestMapping("/tomodel.do")
	public String toModel() {
		return "costSharing/parkEnergyConsumption/model";
	}
	/**
	 * 跳转修改页面
	 * @return
	 */
	@RequestMapping("toEdit.do")
	public String edit(){
		return "baseData/edit";
	}
	/**
	 * 跳转上传页面
	 * @return
	 */
	@RequestMapping("toUpload.do")
	public String toUpload(String enableDate,Model model){
		if (enableDate != null) {
			model.addAttribute("enableDate", enableDate);
		}
		return "baseData/upload";
	}
	/**
	 * 轉跳日期選擇頁面
	 **/
	@RequestMapping("toDateSelect.do")
	public String toDateSelect() {
		return "baseData/date-select";
	}
	/**
	 * EXCEL上傳模板下載
	 **/
	@RequestMapping("downExcelUploadModel.do")
	@ResponseBody
	public void downExcelUploadModel(HttpServletRequest req,HttpServletResponse resp,String fileName) {
		try {
			//讀取模板
			ClassPathResource resource = new ClassPathResource("static/excel/"+fileName);
			//判斷文件是否存在
			if(!resource.exists()) {
				resp.getOutputStream().write("<a href='javascript:history.back();'>404 Not found</a>".getBytes());
				return;
			}
			//設置中文響應頭
			String encode = URLEncoder.encode(fileName, "UTF-8");
			encode = encode.replace("+", " ");
			String ua = req.getHeader("user-agent");
			if(ua.toLowerCase().indexOf("firefox") > -1)
			{
				encode = "=?UTF-8?B?" + (new String(Base64Utils.encodeToString((fileName).getBytes("UTF-8")))) + "?=";
			}
			resp.setContentType("application/vnd.ms-excel;charset=utf-8");
			resp.setHeader("Content-Disposition", "attachment;filename="+encode);
			InputStream is = resource.getInputStream();
			byte [] b = new byte[1024];
			int len = 0;
			while((len=is.read(b))!=-1) {
				resp.getOutputStream().write(b, 0, len);
			}
			is.close();
			resp.getOutputStream().close();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * 基础资料数据下载
	 **/
	@GetMapping("listDown.do")
	public void listDown(ParamTransfer param,String title,String className,HttpServletResponse resp) {
		try {
			// 按照javabean属性的顺序进行查询下载
			Class<?> cla = Class.forName("com.foxconn.entity."+className);
			List<String> assignFieldList = new ArrayList<String>();
			Map<String, List<String>> searchMap = param.getSearchMap();
			for (Field field : cla.getDeclaredFields()) {
				if (Modifier.isPrivate(field.getModifiers()) 
						&& !Modifier.isStatic(field.getModifiers())
						&& !Modifier.isVolatile(field.getModifiers())) {
					assignFieldList.add(field.getName());
					String humpName = Utils.humpToLine(field.getName());
					searchMap.put(humpName, new ArrayList<String>());
					searchMap.get(humpName).add(param.getSearch());
				}
			}
			param.setAssignField(assignFieldList);
			param.setTimeLayout("yyyy-MM-dd");
			param.setFuzzyQuery(true);
			param.setSearchType(" OR ");
			List<?> list = service.listData(cla,param);
			if ("Legalperson".equals(className)) {
				ExcelUtil.handleExcelDownText(className, title, list, resp);
			} else {
				ExcelUtil.handleExcelDown(className, title, list, resp);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * 跳转部門信息页面
	 */
	@RequestMapping("toDepart.do")
	public String toDepart(){
		return "baseData/depart-index";
	}
	/**
	 * 查詢部門
	 **/
	@RequestMapping(value="listDepart.do")
	@ResponseBody
	public Map<String,Object> listDepart(ParamTransfer param) {
		param.setTimeLayout("yyyy-MM-dd");
		List<?> list = service.listData(Depart.class,param);
		Map<String,Object> result = new HashMap<String,Object>();
		result.put("iTotalDisplayRecords", service.selectHaveConditionCount(Depart.class,param));
		result.put("iTotalRecords", service.selectAllCount(Depart.class,param));
		result.put("data", list);
		return result;
	}
	/**
	 * 查詢部門
	 **/
	@SuppressWarnings("unchecked")
	@RequestMapping(value="listDepartByItem.do")
	@ResponseBody
	public String listDepartByItem(String item) {
		ParamTransfer param = new ParamTransfer();
		param.setTimeLayout("yyyy-MM-dd");
		List<String> sList = new ArrayList<String>();
		sList.add(item);
		param.getSearchMap().put("DEPART_NAME", sList);// 查询条件
		param.getSearchMap().put("DEPART_CODE", sList);// 查询条件
		param.setSearchType("or");
		param.setFuzzyQuery(true);
		List<?> list = service.listData(Depart.class,param);
		List<String> departList = new ArrayList<String>();
		
		for (Object obj : list) {
			Map<String, Object> map =  (Map<String, Object>) obj;
			String departName = map.get("departName").toString();
			departList.add(departName);
		}
		return JSONObject.toJSONString(departList);
	}
	/**
	 * 部門-添加
	 * @return
	 */
	@RequestMapping("handleDepartAdd.do")
	@ResponseBody
	public String handleDepartAdd(Depart param){
		List<Depart> list = new ArrayList<>();
		list.add(param);
		try {
			return service.insertItem(Depart.class,list);
		} catch (Exception e) {
			ResponseStatus<?> rs = new ResponseStatus<>();
			rs.setStatus(0);
			rs.setMessage(e.getMessage());
			return JSONObject.toJSONString(rs);
		}
	}
	/**
	 * 部門-上傳
	 **/
	@RequestMapping("handleDepartUpload.do")
	@ResponseBody
	public String handleDepartUpload(@RequestParam("file_data")MultipartFile file,
			HttpServletRequest req) throws Exception{
		return service.handleUploadFile(Depart.class,file,"append");
	}
	/**
	 * 部門-修改
	 **/
	@RequestMapping("handleDepartEdit.do")
	@ResponseBody
	public String handleDepartEdit(Depart param) {
		return service.updateItem(param);
	}
	/**
	 * 部門-删除
	 */
	@RequestMapping("handleDepartDelete.do")
	@ResponseBody
	public String handleDepartDelete(@RequestParam("ids[]")String [] ids){
		// 根據部門ID查詢人數
		List<User> userList = userService.findUserByDepart(ids);
		if (null == userList || userList.size() == 0) {
			return service.deleteItem(Depart.class,ids);
		} else {
			ResponseStatus<?> rs = new ResponseStatus<>();
			rs.setStatus(0);
			rs.setMessage("用戶表存在數據,無法刪除!");
			return JSONObject.toJSONString(rs);
		}
	}
}
