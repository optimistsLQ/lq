package com.foxconn.controller;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.foxconn.entity.Depart;
import com.foxconn.entity.ParamTransfer;
import com.foxconn.entity.ProxyEntity;
import com.foxconn.entity.ResponseStatus;
import com.foxconn.entity.Role;
import com.foxconn.entity.UREntity;
import com.foxconn.entity.User;
import com.foxconn.service.BaseService;
import com.foxconn.service.ProxyService;
import com.foxconn.service.RoleService;
import com.foxconn.service.UserRoleService;
import com.foxconn.service.UserService;
import com.foxconn.utils.DateUtils;
import com.foxconn.utils.PublicService;
import com.foxconn.utils.Utils;

@Controller
@RequestMapping("/user")
public class UserController {
	@Autowired
	private UserService userService;
	
	@Autowired
	private UserRoleService userRoleService;
	
	@Autowired
	private RoleService roleService;
	
	@Autowired
	private BaseService baseService;
	
	@Autowired
	private ProxyService proxyService;
	
	@RequestMapping("/delUserById.do")
	@ResponseBody
	public String delUser(@RequestParam("userId[]")String [] userId, @RequestParam("remarks")String remarks) {
		List<String> useridList = Arrays.asList(userId);
		// 郵件通知
		for (User user:userService.findUserByUserId(userId)) {
			PublicService.emailSend("尊敬的『"+user.getUserName()+"』主管/同仁,您的賬號已被管理員刪除,請注意（Fr:AP結報自動化審核系統）", "<span style='font-weight:bold;'>尊敬的用戶："+user.getUserName()+"</span><br>感謝你使用及支持集團AP結報自動化審核系統。<br>您的賬號已被管理員刪除,刪除原因如下：<br><span style='color:red;'>" + remarks + "</span><br>如有需求,請<a href='http://10.244.170.244:8083/register.do'>點擊此處</a>重新申請賬號,謝謝！", user.getEmail());
		}
		// 刪除用戶
		if (userService.delUser(useridList)) {
			for (String id : useridList) {
				userRoleService.delUserRoleByUserId(id);
			}
			return "删除成功";
		};
		return "删除失败";
	}
	
	@RequestMapping("/updateUser.do")
	@ResponseBody
	public Map<String, Integer> updateUser(User user,String adminRoleID) {
		// 更新到數據庫
		Map<String, Integer> map = new HashMap<String, Integer>();
		if (userService.updateUser(user)) {
			userRoleService.delUserRoleByUserId(user.getUserId());
			userRoleService.insertUserRole(new UREntity(user.getUserId(), adminRoleID));
			map.put("msg", 1);
		} else {
			map.put("msg", -1);
		}
		return map;		
	}
	
	@RequestMapping("/listAllUser.do")
	@ResponseBody
	public ResponseStatus<List<?>> listAllUser(String type, Integer currPage, ModelMap map) {
		if ("".equals(type)) {
			type = null;
		}		
		List<User> userList = userService.listAllUser(type);
		ResponseStatus<List<?>> list = Utils.paging(userList, currPage, 10);
		list.setCurrPage(currPage);
		list.setMessage(userList.size()+"");
		return list;
	}
	
	@RequestMapping("/getUserById.do")
	public String getUserById(String userId,ModelMap map, String com){
		User user = userService.getUserById(userId);
		List<Role> roleList = roleService.listRoleAll();
		ParamTransfer param = new ParamTransfer();
		param.setStart(0);
		param.setLength(Integer.MAX_VALUE);
		param.setOrderField("departName");
		param.setOrder("ASC");
		List<?> departList = baseService.listData(Depart.class, param);
		map.addAttribute("departList", departList);
		map.addAttribute("user", user);
		map.addAttribute("roleList", roleList);
		map.addAttribute("com", com);
		return "admin/admin-update";		
	}
	
	@RequestMapping("/startStatus.do")
	@ResponseBody
	public Map<String,String> startStatus(String userId) {
		User user = userService.getUserById(userId);
		Map<String,String> result = new HashMap<String,String>();
		if (user.getUserStatus() == 0) {
			user.setUserStatus(1);
			if(userService.updateUser(user)) {
				//发送邮件通知账号已激活
				String userName = user.getUserName();
				PublicService.emailSend("AP結報自動化審核系統賬號激活提醒[For:"+userName+"]", "您的賬號已激活。點擊登入:http://10.244.170.244:8083/login.do", user.getEmail());
				result.put("msg", "OK");
				return result;
			}
		}
		result.put("msg", "NG");
		return result;
	}
	
	@RequestMapping("/stopStatus.do")
	@ResponseBody
	public Map<String,String> stopStatus(String userId) {
		User user = userService.getUserById(userId);
		Map<String,String> result = new HashMap<String,String>();
		if (user.getUserStatus() == 1) {
			user.setUserStatus(0);
			Boolean bl = userService.updateUser(user);
			System.out.println(bl+"停用OK");
			result.put("msg", "OK");
		} else {
			result.put("msg", "NG");
		}
		return result;
	}
	
	@RequestMapping("/listUserByItem")
	@ResponseBody
	public String listUserByItem(String item) {
		List<User> userList = userService.listAllUser(item);
		List<String> list = new ArrayList<String>();
		for (User user : userList) {
			list.add(user.getUserName());
		}
		return JSONObject.toJSONString(list);
	}
	
	@RequestMapping("/getUserByNickname.do")
	@ResponseBody
	public String getUserByNickname(String nickname) {
		User user = userService.getUserByUserName(nickname);
		return JSONObject.toJSONString(user);
	}
	
	@RequestMapping("/toadminList.do")
	public String toAdminList() {
		return "admin/admin-list";
	}

	@RequestMapping("/fileLogin.do")
	public String fileLogin() {
		return "noPower";
	}
	
	/**
	 * 代理人設置
	 * @return
	 */
	@RequestMapping("toSetProxy.do")
	public String setProxy(HttpSession session,Model model){
		User user = (User) session.getAttribute("user");
		String id = user.getUserId();
		List<ProxyEntity> findAll = proxyService.findAllBySelfId(id);
		model.addAttribute("proxy",JSON.toJSONString(findAll));
		return "admin/proxy-index";
	}
	/**
	 * 通過當前用戶id 移除代理人
	 * @return
	 */
	@RequestMapping("toDelProxy.do")
	@ResponseBody
	public int updateProxy(HttpSession session,String proxyId){
		//刪除代理人
		return proxyService.deleteByPrimaryKey(proxyId);
	}
	@RequestMapping("toAddProxy.do")
	public String toAddProxy(){
		return "admin/proxy-add";
	}
	@RequestMapping("getProxyInfo.do")
	@ResponseBody
	public ResponseStatus<?> getProxy(String proxyCardNum,HttpSession session){
		ResponseStatus<User> rr = new ResponseStatus<>();
		User userEntity = (User)session.getAttribute("user");
		if (userEntity.getCardNum().equals(proxyCardNum)) {
			rr.setStatus(-1);
			rr.setMessage("請設置有效用戶!");
			return rr;
		}
		rr.setStatus(1);
		rr.setData(userService.getUserByCardNum(proxyCardNum));
		return rr;
	}
	@RequestMapping("addProxy.do")
	@ResponseBody
	public String addProxy(HttpSession session, String proxyId,String startTime,String endTime){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		Date _startTime = null,_endTime = null;
		try {
			_startTime = sdf.parse(DateUtils.handleMonth(startTime));
			_endTime = sdf.parse(DateUtils.handleMonth(endTime));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		User userEntity = (User)session.getAttribute("user");
		// 查詢代理人使用情況
		ProxyEntity proxyEntity = proxyService.selectByProxyIdByEndTimeBefore(proxyId);
		//判斷是否添加重複的代理人
		if (null != proxyEntity && proxyEntity.getProxyId().equals(proxyId)) {
			return "代理人已存在,無需重複添加！";
		}
		//判斷該代理人是否已被使用
		if (null != proxyEntity) {
			return "該代理人已代理[" + proxyEntity.getUserName()+"]不能循環代理！";
		}
		//判斷自己是否已成為其他人的代理人
		ProxyEntity proxyEntity2 = proxyService.selectByProxyIdByEndTimeBefore(userEntity.getUserId());
		if (null != proxyEntity2) {
			return "[" + userEntity.getUserName() + "]已成為[" + proxyEntity2.getUserName() + "]的代理,不能循環代理！";
		}
		//通過該工號獲得id號
		User userProxy = userService.getUserById(proxyId);
		ProxyEntity param = new ProxyEntity();
		param.setUserId(userEntity.getUserId());
		param.setUserName(userEntity.getUserName());
		param.setProxyId(userProxy.getUserId());
		param.setProxyName(userProxy.getUserName());
		param.setProxyDepart(userProxy.getDepart().getDepartName());
		param.setStartTime(_startTime);
		param.setEndTime(_endTime);
		proxyService.insertSelective(param);
		return "添加成功";
	}
}
