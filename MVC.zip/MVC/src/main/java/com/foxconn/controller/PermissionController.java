package com.foxconn.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.foxconn.entity.Permission;
import com.foxconn.entity.Role;
import com.foxconn.service.PermissionService;
import com.foxconn.service.RoleService;

@Controller
@RequestMapping("/permission")
public class PermissionController {

	@Autowired
	private PermissionService perService;
	
	@Autowired
	private RoleService roleService;
	
	/**
	 * 查询所有权限和角色对应权限并返回给角色的添加和修改页面
	 * @param path
	 * @param roleId
	 * @param map
	 * @return
	 */
	@RequestMapping("/listAllPermission.do")
	public String listAllPermission(String path, String roleId, ModelMap map) {
		List<Permission> perList = perService.listAllPermission();
		map.addAttribute("perList", perList);
		map.addAttribute("msg", "msg132");
		if ("add".equals(path)) {
			return "admin/admin-role-add";
		} else {
			Role role = roleService.findOneRoleUserPermission(roleId);
			map.addAttribute("role", role);
			return "admin/admin-role-update";
		}
		
	}
	/**
	 * 查询所有权限返回到权限列表
	 * @return
	 */
	@RequestMapping("/listAll.do")
	public String listAll(ModelMap map) {
		List<Permission> perList = perService.listAllPermission();
		map.addAttribute("permission", perList);
		map.addAttribute("size", perList.size());
		map.addAttribute("msg", "msg123");
		return "admin/admin-permission";
	}
	
	@RequestMapping("/addPermission.do")
	@ResponseBody
	public String addPermission(Permission permission) {
		int i = perService.insertPermission(permission);
		if (i > 0) {
			return "添加成功！";
		} else {
			return "添加失败！";
		}
	} 
	
	@RequestMapping("/delPermission.do")
	@ResponseBody
	public String delPermission(@RequestParam("perId[]")String [] perId) {
		int i = perService.delPermission(perId);
		if (i > 0) {
			return "删除成功！";
			
		} else {
			return "删除失败！";
		}
	}
	
	@RequestMapping("/validate.do")
	@ResponseBody
	public String validate(String perName) {
		Permission per = perService.getPermissionByPerName(perName);
		if (null != per) {
			return "false";
		} else {
			
			return "true"; 
		}
	}
	
	@RequestMapping("/toUpdatePermission.do")
	public String toUpdatePermission(String perId, ModelMap map) {
		Permission permission = perService.getPermissionByPerId(perId);
		map.addAttribute("permission", permission);
		return "admin/admin-permission-update";
	}
	
	@RequestMapping("/updatePer.do")
	@ResponseBody
	public String updatePer(Permission permission) {
		int i = perService.updatePermission(permission);
		if (i > 0) {
			return "OK";
		} else {
			return "NG";
		}
	}
	
	@RequestMapping("/toPermissionAdd.do")
	public String toPermissionAdd() {
		return "admin/admin-permission-add";
	}
}
