package com.foxconn.controller;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.foxconn.entity.Depart;
import com.foxconn.entity.ParamTransfer;
import com.foxconn.entity.Role;
import com.foxconn.service.BaseService;
import com.foxconn.service.RolePermissionService;
import com.foxconn.service.RoleService;


@Controller
@RequestMapping("/role")
public class RoleController {

	@Autowired
	private RoleService rs;
	
	@Autowired
	private RolePermissionService rpService;
	
	@Autowired
	private BaseService baseService;
	
	@RequestMapping("/listRole.do")
	public String listRole(ModelMap map) {
		List<Role> roleList = rs.listRoleAll();
		ParamTransfer param = new ParamTransfer();
		param.setStart(0);
		param.setLength(Integer.MAX_VALUE);
		param.setOrderField("departName");
		param.setOrder("ASC");
		List<?> departList = baseService.listData(Depart.class, param);
		map.addAttribute("departList", departList);
		map.addAttribute("roleList", roleList);
		return "admin/admin-add";
	}
	
	@RequestMapping("/listRoleDetail.do")
	public String listRoleDetail(ModelMap map) {
		List<Role> roleList = rs.findAllRolePermission();
		map.addAttribute("roleList", roleList);
		map.addAttribute("size", roleList.size());
		return "admin/admin-role";
	}
	
	@RequestMapping("/addRole.do")
	@ResponseBody
	public Map<String, String> addRole(Role role,String Character) {
		Map<String, String> map = new HashMap<String, String>();
		String id = rs.insertRole(role);
		if (null != id) {
			if (null != Character) {
				String [] checkedId = Character.split(",");
				List<String> perList = Arrays.asList(checkedId);
				rpService.insertListBtIds(perList, id);
			}
			map.put("msg", "添加成功!");
		} else {
			map.put("msg", "添加失败!");
		}
		return map;
	}
	
	@RequestMapping("/delRole.do")
	@ResponseBody
	public String delRole(@RequestParam("roleIds[]")String [] roleIds) {
		List<String> roleids = Arrays.asList(roleIds);
		int i = rs.delRoles(roleids);
		if (i != 0){
			rpService.delRolePermissionByRoleIds(roleIds);
		}
		return "";
	}
	
	@RequestMapping("/updateRole.do")
	@ResponseBody
	public String updateRole(Role role,ModelMap map, String [] Character) {
		int i = rs.updateRoel(role);
		if (i > 0) {
			String [] roleid = new String[] {role.getRoleId()};
			rpService.delRolePermissionByRoleIds(roleid);
			if (null != Character && Character.length > 0) {
				List<String> perIdList = Arrays.asList(Character);
				rpService.insertListBtIds(perIdList, role.getRoleId());
			}
			roleid = null;
			map.addAttribute("msg", "OK");
			
		} else {
			map.addAttribute("msg", "NG");
		}
		return "";
	}
	
}
