package com.foxconn.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.foxconn.entity.Depart;
import com.foxconn.entity.ParamTransfer;
import com.foxconn.entity.UREntity;
import com.foxconn.entity.User;
import com.foxconn.service.BaseService;
import com.foxconn.service.UserRoleService;
import com.foxconn.service.UserService;
import com.foxconn.utils.PublicService;
import com.foxconn.utils.Utils;

@Controller
public class LoginController {

	@Resource
	private UserService userService;
	@Autowired
	private UserRoleService userRoleService;
	@Autowired
	private BaseService baseService;
	
	/**
	 * 訪問登錄界面
	 * 
	 * @param userName     Cookie中的用戶名,用於默認填充前端用戶名輸入框
	 * @param pwd          Cookie中的密碼,用於默認填充前端pwd密碼框
	 * @param ModelAndView 模型数据,返回數據到前端
	 **/
	@RequestMapping(value = "/login.do", method = { RequestMethod.GET })
	public ModelAndView login(@CookieValue(value = "cardNum", required = false) String cardNum,
			@CookieValue(value = "pwd", required = false) String pwd,
			@CookieValue(value = "online", required = false)String online) {
		// 模型數據對象,保持已輸入的用戶名和密碼,返回給前端
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("login");
		if (null != cardNum && null != pwd) {
			modelAndView.addObject("cardNum", cardNum);
			modelAndView.addObject("pwd", pwd);
		}
		if (null != online) {
			modelAndView.addObject("online", online);
		}
		return modelAndView;
	}

	/**
	 * 用戶登錄
	 * 
	 * @param userInfo 表單數據
	 * @param online   是否保持登錄
	 * @param model    模型数据,返回數據到前端,作用域為HttpRequest
	 * @param response 內置對象,用於添加Cookie
	 **/
	@RequestMapping(value = "/login.do", method = { RequestMethod.POST })
	public String login(String cardNum, String pwd, String online, Model model, HttpServletResponse response,HttpSession session) {
		UsernamePasswordToken token = new UsernamePasswordToken(cardNum,pwd);
		Subject subject = SecurityUtils.getSubject();
		try {
			subject.login(token);
			// 将登陆对象保存到Session
			User userEntity = (User)subject.getPrincipal();
			if(userEntity.getUserStatus() == 0){
				model.addAttribute("info", "賬號正在審核中!");
				return "login";
			}
			session.setAttribute("user", userEntity);
			Cookie userNameCookie, passwordCookie, onlineCookie;
			// 是否保持在線
			if (null == online) {
				// 立馬過期
				userNameCookie = new Cookie("cardNum", null);
				passwordCookie = new Cookie("pwd", null);
				onlineCookie = new Cookie("online", null);
				userNameCookie.setMaxAge(0);
				passwordCookie.setMaxAge(0);
				onlineCookie.setMaxAge(0);
			} else {
				// 過期時間為一天
				userNameCookie = new Cookie("cardNum", cardNum);
				passwordCookie = new Cookie("pwd", pwd);
				onlineCookie = new Cookie("online", online==null?"off":"on");
				userNameCookie.setMaxAge(2 * 60 * 60);
				passwordCookie.setMaxAge(2 * 60 * 60);
				onlineCookie.setMaxAge(2 * 60 * 60);
			}
			// 防止JS訪問Cookie
			userNameCookie.setHttpOnly(true);
			passwordCookie.setHttpOnly(true);
			onlineCookie.setHttpOnly(true);
			// 將Cookie添加到Response中,用於保持登錄
			response.addCookie(userNameCookie);
			response.addCookie(passwordCookie);
			response.addCookie(onlineCookie);
			return "redirect:index.do";
		} catch (AuthenticationException e) {
			// 驗證失敗
			model.addAttribute("info", "用戶名或密碼錯誤!");
		} catch (Exception e) {
			// 其它錯誤
			e.printStackTrace();
			model.addAttribute("info", "錯誤代碼:500");
		} finally {
			// 返回給前端輸入框
			model.addAttribute("cardNum", cardNum);
			model.addAttribute("pwd", pwd);
			model.addAttribute("online", online);
		}
		return "login";
	}
	
	/**
	 * 訪問註冊頁面 因thymeleaf模板需要通過視圖解析器 故不能直接訪問.html頁面
	 **/
	@RequestMapping(value = "/register.do", method = { RequestMethod.GET })
	public String register(Model model) {
		fullModelDepList(model);
		return "register";
	}
	@SuppressWarnings("unchecked")
	private void fullModelDepList(Model model) {
		ParamTransfer param = new ParamTransfer();
		List<?> departList = baseService.listData(Depart.class, param);
		List<String> depList = new ArrayList<String>();
		for (Object obj : departList) {
			Map<String, Object> mapobj = (Map<String, Object>) obj;
			depList.add(mapobj.get("departName")+"-"+mapobj.get("uid"));
		}
		model.addAttribute("depList", depList);
	}
	/**
	 * 註冊提交
	 * @param userInfo 表單數據
	 * @param model    模型数据,返回數據到前端,作用域為HttpRequest
	 **/
	@RequestMapping(value = "/register.do", method = { RequestMethod.POST })
	public String register(User userInfo,Model model,String adminRoleID,String verificationCode,HttpSession session) {
		// 自動填充表格,用戶前端填充
		model.addAttribute("autoFill", userInfo);
		// 将昵称和用户设置成一样作为默认值
		//userInfo.setNickname(userInfo.getUserNumber());
		// 填充部門列表
		fullModelDepList(model);
		if (!verificationCode.equals("C10507D6487BBB58E05340DCF40A73F4")) {
			// 檢查驗證碼
			if (session.getAttribute("verificationCode") == null 
					|| !session.getAttribute("verificationCode").equals(verificationCode)) {
				model.addAttribute("info", "驗證碼不正確!");
				return "register";
			}
		}
		// 檢查用工號是否已被使用
		if (null != userService.getUserByCardNum(userInfo.getCardNum())) {
			model.addAttribute("info", "註冊失敗,賬號已存在!");
		// 將註冊資料寫入到數據庫
		} else if (userService.insertUser(userInfo)) {
			model.addAttribute("info", "註冊成功!");
			if (!"0".equals(adminRoleID) && null != adminRoleID) {
				UREntity urEntity = new UREntity();
				urEntity.setUserId(userInfo.getUserId());
				urEntity.setRoleId(adminRoleID);
				userRoleService.insertUserRole(urEntity);
			}
			// 將郵件發送至審核人處 TODO
//			PublicService.emailSend("主管/同仁您好:AP結報自動化審核系統新用戶註冊,請審核!", "註冊人："+userInfo.getUserName()+""
//					+ "<br>註冊賬號："+userInfo.getCardNum()+""
//					+ "<br>請您盡快<a href='http://10.244.170.244:8083/'>登錄系統</a>查看詳情並進審核！", 
//					"li-xia_guo/cen/foxconn@foxconn.com");
		} else {
			model.addAttribute("info", "註冊失敗!");
		}
		return "register";
	}
	
	/**
	 * 發送驗證碼到郵箱
	 **/
	@PostMapping(value = "/sendVerificationCode.do")
	@ResponseBody
	public String sendVerificationCode(String emailAddress,HttpSession session) {
		String verificationCode = Utils.createVerificationCode();
		session.setAttribute("verificationCode", verificationCode);
		if (PublicService.emailSend("主管/同仁您好:AP結報自動化審核系統!", "您的驗證碼是:"+verificationCode, emailAddress)) {
			return "Y";
		}
		return "N";
	}

	/**
	 * 訪問主頁 因thymeleaf模板需要通過視圖解析器 故不能直接訪問.html頁面
	 **/
	@RequestMapping("/index.do")
	public String index() {
		return "index";
	}

	/**
	 * 訪問主頁
	 **/
	@RequestMapping("/welcome.do")
	public String welcome() {
		return "welcome";
	}
	
	/**
	 * 退出系統
	 **/
	@RequestMapping("/loginOut.do")
	public String loginOut() {
		Subject subject = SecurityUtils.getSubject();
		if (null != subject) {
			User user = (User) subject.getSession().getAttribute("user");
			System.out.println(user.getCardNum()+"退出了");
			subject.logout();
		}
		return "login";
	}
	
	/**
	 * 跳轉忘記密碼頁面
	 **/
	@RequestMapping("/toForgetPwd.do")
	public String toForgetPwd() {
		return "forgetPwd";
	}
	
	@RequestMapping("/findPwd.do")
	@ResponseBody
	public String findPwd(String cardNum, String email, String verificationCode, String pwd, HttpServletRequest req) {
		String sessionVerificationCode = (String) req.getSession().getAttribute("verificationCode");
		if (null == sessionVerificationCode) {
			return "VerificationCodeTimeout";
		}
		User user = userService.getUserByCardNum(cardNum);
		if (null == user || !user.getEmail().equals(email)) {
			return "CardNumEmailError";
		}
		if (sessionVerificationCode.equals(verificationCode)) {
			user.setPwd(pwd);
			userService.updateUser(user);
			return "Ok";
		}
		return "VerificationCodeError";
	}
}
