package com.foxconn.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.User;

public interface UserEntityMapper {
	
    Integer deleteByPrimaryKey(@Param("userId") List<String> userId);

    Integer insert(@Param("user") User user);

    Integer insertSelective(User record);

    User selectByPrimaryKey(String userId);

    Integer updateByPrimaryKeySelective(User record);

    Integer updateByPrimaryKey(User record);
    
    List<User> listAllUser(@Param("type") String type);
    
    User getUserByCardNum(String cardNum);
    
    List<User> listUserByDepart(@Param("ids")String[] ids);
    
    List<User> listUserByUserId(@Param("ids")String[] ids);

	User getUserByUserName(String userName);
	
}