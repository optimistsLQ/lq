package com.foxconn.mapper;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.ProxyEntity;

public interface ProxyEntityMapper {
	
    Integer deleteByPrimaryKey(String pid);
    
    Integer deleteByUserId(String userId);

    Integer insert(ProxyEntity record);

    Integer insertSelective(ProxyEntity record);

    ProxyEntity selectByUserId(String userId);
    
    List<ProxyEntity> selectByUserIds(@Param("userIds") List<String> userIds);
    
    ProxyEntity selectByProxyId(String proxyId);
    
    ProxyEntity selectByProxyIdByEndTimeBefore(String proxyId);
    
    ProxyEntity selectByUserIdTime(@Param("proxyId")String proxyId, @Param("currTime")Date currTime);

    List<ProxyEntity> findAll();
    List<ProxyEntity> findAllBySelfId(String id);
    
    Integer updateByPrimaryKeySelective(ProxyEntity record);

    Integer updateByPrimaryKey(ProxyEntity record);
}