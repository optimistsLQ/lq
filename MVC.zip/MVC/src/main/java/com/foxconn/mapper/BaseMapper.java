package com.foxconn.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.ParamTransfer;

public interface BaseMapper {

	List<Map<String,Object>> listData(@Param("obj")ParamTransfer param);
	Integer selectAllCount(ParamTransfer param);
	Integer selectAllCountAddCondition(@Param("obj")ParamTransfer param);
	Integer selectHaveConditionCount(@Param("obj")ParamTransfer param);
	Integer deleteItem(@Param("tableName")String tableName,@Param("ids")String[] ids,@Param("deleteField")String deleteField);
	Integer updateItem(@Param("uid")String uid,@Param("tableName")String tableName,@Param("map")Map<String,Object> map);
	Integer insertItem(@Param("tableName")String tableName,@Param("params")List<?> params,@Param("columnName")List<String> columnName,@Param("fieldList")List<String> fieldList);
	Integer selectMonthExists(@Param("tableName")String tableName,@Param("dateTime")String dateTime);
	Integer deleteAll(@Param("tableName")String tableName,@Param("dateTime")String dateTime);
	List<Map<String, Object>> getAllField();
}
