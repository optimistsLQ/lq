package com.foxconn.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.Role;

public interface RoleEntityMapper {
	
    int deleteByPrimaryKey(@Param("roleids") List<String> roleids);

    int insert(Role record);

    int insertSelective(Role record);

    Role selectByPrimaryKey(String roleId);

    int updateByPrimaryKeySelective(Role record);

    int updateByPrimaryKey(Role record);
    
    List<Role> listAllRole();
    
    List<Role> findAllRolePermission();
    
    int insertRoleGetId(@Param("obj")Role obj);
    
    List<Role> findAllRoleUserPermission();
    
    Role findOneRoleUserPermission(String roleId);
}