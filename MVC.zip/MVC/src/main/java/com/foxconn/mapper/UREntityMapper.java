package com.foxconn.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.UREntity;

public interface UREntityMapper {
    int deleteByPrimaryKey(String urId);

    int insert(UREntity record);

    int insertSelective(UREntity record);

    UREntity selectByPrimaryKey(String urId);

    int updateByPrimaryKeySelective(UREntity record);

    int updateByPrimaryKey(UREntity record);
    
    int delByUserId(String userId);
    
    List<UREntity> listByUserId(String userId);
    
    List<UREntity> listAll();
    /**
     * 新增用戶的角色
     * @return
     */
    int insertListByIds(@Param("userId")String userId,@Param("addList")List<String> addList);
    /**
     * 刪除用戶的角色
     * @return
     */
    int delListByIds(@Param("userId")String userId,@Param("delList")List<String> delList);
}