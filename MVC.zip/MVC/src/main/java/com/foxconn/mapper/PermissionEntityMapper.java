package com.foxconn.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.Permission;

public interface PermissionEntityMapper {
	
    int deleteByPrimaryKeys(@Param("perId")String [] perId);

    int insert(Permission record);

    int insertSelective(Permission record);

    Permission selectByPrimaryKey(String perId);

    int updateByPrimaryKeySelective(Permission record);

    int updateByPrimaryKey(Permission record);
    
    List<Permission> listAllPermission();
    
    Permission getPermissionByPerName(String perName);
}