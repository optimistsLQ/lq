package com.foxconn.service;

import java.util.List;

import com.foxconn.entity.Permission;


/**權限業務接口
 * @author C3410596
 *
 */
public interface PermissionService {
	/**添加权限
	 * @param permission
	 */
	int insertPermission(Permission permission);
	/**根据id删除权限
	 * @param preId
	 */
	int delPermission(String [] perId);
	/**分页查询所有权限
	 * @return
	 */
	List<Permission> listAllPermission();
	/**验证权限名是否存在
	 * @param perName
	 * @return
	 */
	Permission getPermissionByPerName(String perName);
	/**根据ID查询权限
	 * @param perId
	 * @return
	 */
	Permission getPermissionByPerId(String perId);
	/**修改权限信息
	 * @param permission
	 * @return
	 */
	int updatePermission(Permission permission);

}
