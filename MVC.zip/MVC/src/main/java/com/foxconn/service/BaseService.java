package com.foxconn.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.foxconn.entity.ParamTransfer;

/**
 * 基础资料
 * @author C3408775
 */
public interface BaseService {
	/**
	 * 查询数据
	 * @param cla 查询的数据类型
	 * @param param 查询的相关参数对象
	 */
	List<?> listData(Class<?> cla,ParamTransfer param);
	/**
	 * 查询数据总数量
	 * @param cla 查询的数据类型
	 * @param param 查询的参数对象
	 */
	int selectAllCount(Class<?> cla,ParamTransfer param);
	/**
	 * 查询数据总数量+帶有條件的總數量
	 * @param cla 查询的数据类型
	 * @param param 查询的参数对象
	 */
	int selectAllCountAddCondition(Class<?> cla,ParamTransfer param);
	/**
	 * 查询带有条件数据数量
	 * @param cla 查询的数据类型
	 * @param param 查询的参数对象
	 */
	int selectHaveConditionCount(Class<?> cla,ParamTransfer param);
	/**
	 * 通过id批量删除
	 * @param cla 需要删除的对象类型
	 * @param ids 需要删除的id数组集
	 */
	String deleteItem(Class<?> cla,String[] ids);
	/**
	 * 通过id批量删除
	 * @param cla 需要删除的对象类型
	 * @param ids 需要删除的id数组集
	 * @param deleteField 刪除的字段
	 */
	String deleteItem(Class<?> cla,String[] ids,String deleteField);
	/**
	 * 编辑单条数据
	 * @param obj 需要写入的对象
	 */
	String updateItem(Object obj);
	/**
	 * 批量写入/单笔写入
	 * @param cla 需要写入的对象类型
	 * @param params 需要写入的数据集合
	 * @note 批量写入的时候 默认每次提交500
	 * @param date 資料所屬日期
	 * @throws Exception 
	 */
	String insertItem(Class<?> cla,List<?> param) throws Exception;
	String insertItem(Class<?> cla,List<?> param,String date) throws Exception;
	/**
	 * 处理文件的上传
	 * @param file
	 * @param date 資料所屬日期
	 */
	String handleUploadFile(Class<?> cla,MultipartFile file,String date) throws Exception;
	/**
	 * 查询数据是否存在
	 * @param cla 查询的表名
	 * @param date 查詢的日期
	 */
	boolean selectMonthExists(Class<?> cla,String date);
	/**
	 * 清空表
	 * @param 删除的表名
	 * @param date 删除的日期
	 **/
	int deleteAll(Class<?> cla,String date);
	
	/**查询数据库所有表的所有number字段
	 * @return
	 */
	Map<String, List<String>> getAllField();
}
