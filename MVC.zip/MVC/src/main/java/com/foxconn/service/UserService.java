package com.foxconn.service;

import java.util.List;

import com.foxconn.entity.User;

/**
 * 用户业务层接口
 */
public interface UserService {
    
    /**
     * 通過用戶id獲取User對象
     * @param userId 
     * @return User 對象
     **/
	User getUserById(String userId);
    
    /**
     * 將用戶數據插入到數據庫中
     * @param user 用戶數據對象
     * @return boolean 是否插入成功
     **/
    boolean insertUser(User user);
    
    /**查询所有用户
     * @return 返回所有用户集合
     */
    List<User> listAllUser(String type);

	/**根据用户名查询用户
	 * @param userName
	 * @return
	 */
	User getUserByCardNum(String cardNum);

	/**根据ID删除用户
	 * @param userId
	 */
	boolean delUser(List<String> userId);

	/**根据用户ID修改用户
	 * @param user
	 */
	boolean updateUser(User user);
	
	/**根據部門ID查詢用戶
	 * @param departId
	 * @return
	 */
	List<User> findUserByDepart(String[] ids);
	
	/**
	 * 根據用戶Id查詢用戶
	 * @param ids
	 * @return
	 */
	List<User> findUserByUserId(String[] ids);
	
	/**
	 * 根據用戶名查詢用戶
	 **/
	User getUserByUserName(String userName);
}
