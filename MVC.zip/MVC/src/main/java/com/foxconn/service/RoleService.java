package com.foxconn.service;

import java.util.List;

import com.foxconn.entity.Role;

/**
 * 角色業務接口
 */
public interface RoleService {
	/**添加角色
	 * @param role
	 */
	String  insertRole(Role role);
	/**根據角色id刪除角色
	 * @param roleId
	 */
	int delRoles(List<String> roleids);

	/**查詢所有角色
	 * @return
	 */
	List<Role> listRoleAll();
	/**
	 * 添加角色获得其ID
	 * @param roleName
	 * @return
	 */
	int insertRoleGetId(Role roleEntity,String[] menus);
	/**查询所有角色和其对应的权限
	 * @return
	 */
	List<Role> findAllRolePermission();
	/**查询所有的角色和其对应的用户和其对应的权限
	 * @return
	 */
	List<Role> findAllRoleUserPermission();
	/**根据ID查询对应角色和权限
	 * @param roleId
	 * @return
	 */
	Role findOneRoleUserPermission(String roleId);
	/**修改角色信息
	 * @param role
	 * @return
	 */
	int updateRoel(Role role);
}
