package com.foxconn.service;

import java.util.Date;
import java.util.List;

import com.foxconn.entity.ProxyEntity;

public interface ProxyService {

	int deleteByPrimaryKey(String pid);
	int deleteByUserId(String userId);
	int insertSelective(ProxyEntity record);
	ProxyEntity selectByUserId(String userId);
	List<ProxyEntity> selectByUserIds(List<String> userIds);
	ProxyEntity selectByProxyId(String proxyId);
	ProxyEntity selectByProxyIdByEndTimeBefore(String proxyId);
	List<ProxyEntity> findAll();
	List<ProxyEntity> findAllBySelfId(String id);
	ProxyEntity checkProxyExists(String proxyId,Date endTime);
}
