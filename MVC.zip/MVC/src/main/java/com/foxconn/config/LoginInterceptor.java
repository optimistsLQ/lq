package com.foxconn.config;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.foxconn.entity.User;

@Component
public class LoginInterceptor implements HandlerInterceptor {

	private static final Log logger = LogFactory.getLog(LoginInterceptor.class);
	
	@Override
	public boolean preHandle(HttpServletRequest req, HttpServletResponse resp, Object handler)
			throws Exception {
		String servletPath = req.getServletPath();
		if(servletPath.equals("/")) { 
			return true;
		}
		logger.info("訪問地址:"+servletPath);
		logger.info("訪問主機:"+req.getRemoteAddr());
		Object user = req.getSession().getAttribute("user");
		if (null != user) {
			User u = (User)user;
			logger.info("訪問者:"+u.getUserName());
			return true;
		} else {			
			logger.info("登錄超時,導致跳轉頁面");
			//判断是ajax请求,还是页面请求
			if(req.getHeader("X-Requested-With")!=null) {
				resp.setContentType("application/json");
				resp.getWriter().print("{\"timeout\":\"../login.do\"}");
			} else {
				resp.setContentType("text/html;charset=utf-8");
				resp.getWriter().print("<div style='font-family:Microsoft Yahei'>登錄超時!<a href='javascript:window.open(\"../login.do\",\"_top\");'>重新登錄</a></div>");
			}
			return false;
		}
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		
	}

}
