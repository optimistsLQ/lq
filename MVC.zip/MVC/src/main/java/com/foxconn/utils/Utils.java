package com.foxconn.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpSession;

import org.apache.commons.collections.CollectionUtils;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.CellValue;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.util.ResourceUtils;
import org.springframework.web.multipart.MultipartFile;

import com.foxconn.entity.Permission;
import com.foxconn.entity.ResponseStatus;
import com.foxconn.entity.Role;
import com.foxconn.entity.User;
import com.github.nobodxbodon.zhconverter.简繁转换类;

public class Utils {

	//private static final Log logger = LogFactory.getLog(Utils.class);
	//正则表达式的预编译功能
	private static final Pattern compile = Pattern.compile("[A-Z]");
	
	/**
	 * 驼峰转下划线
	 * @param str
	 * @return
	 */
	public static String humpToLine(String str){
		Matcher matcher = compile.matcher(str);
		StringBuffer sb = new StringBuffer();
		while (matcher.find()) {
			matcher.appendReplacement(sb, "_"+matcher.group(0));
		}
		matcher.appendTail(sb);
		return sb.toString().toUpperCase();
	}
	
	/**
	 * 下划线命名转为驼峰命名
	 * @param underlineByName 下面线命名
	 **/
	public static String underlineToHump(String underlineByName) {
		StringBuilder result=new StringBuilder();
		String tempArray[]=underlineByName.split("_");
		for(String elements:tempArray) {
			if(result.length() == 0) {
				result.append(elements.toLowerCase());
			} else {
				result.append(elements.substring(0, 1).toUpperCase());
				result.append(elements.substring(1).toLowerCase());
			}
		}
		return result.toString();
	}
	/**
	 * 将集合拆分为多个集合
	 * @param list source List
	 * @param splitSize 拆分大小
	 * @return
	 */
	public static List<List<?>> splitCollection(List<?> list,int splitSize){
		List<List<?>> newList = new ArrayList<>();
		int sizeAll = list.size();
		int splitNum = sizeAll%splitSize;
		int number = sizeAll/splitSize;
		if(splitNum>0){
			number+=1;
		}
		for(int i = 0 ;i<number; i++){
			int listNum = i+1;//集合个数
			int startSize = i*splitSize;//0 500 1000
			int endSize = listNum*splitSize;//500 1000 1500
			
			if(listNum == number){
				newList.add(list.subList(startSize, list.size()));
			}else{
				newList.add(list.subList(startSize, endSize));
			}
		}
		return newList;
	}
	
	public static List<Object> readExcel(MultipartFile file,Class<?> cla,boolean isUpperCase) throws Exception{
		boolean checkSuffix = checkSuffix(file);
		Integer totalShees = 0;
		Integer totalRows = 0;
		
		Set<String> exists = new HashSet<String>();
		List<Object> list = new ArrayList<Object>();
		if(checkSuffix){
			InputStream is = null;
			XSSFWorkbook workbook = null;
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			try {
				is = file.getInputStream();
				workbook = new XSSFWorkbook(is);
				FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
				totalShees = workbook.getNumberOfSheets();
				for(int k=0;k<totalShees;k++)//遍歷多張表
				{
					XSSFSheet sheet = workbook.getSheetAt(k);
					Row row = null;
					totalRows = sheet.getPhysicalNumberOfRows();
					if(sheet.getRow(0)==null){
						continue;
					}
					int headLen = sheet.getRow(0).getPhysicalNumberOfCells();//得到表頭每行的總格數
					for (int i = 1; i < totalRows; i++) {//得到每一行
						String value = "";//保存每行的值
						row = sheet.getRow(i);
						for (int j = 0; j < headLen; j++) {
							Cell cell = row.getCell(j);//得到每行的每一格
							if(cell==null){//單元格不存在
								value+="-$";
								continue;
							}
							switch (cell.getCellTypeEnum()) {
							case STRING:
							{//字符串
								cell.setCellType(CellType.STRING);
								String stringValue;
								if (isUpperCase) 
								{
									stringValue = cell.getStringCellValue().toUpperCase().trim();
								}
								else
								{
									stringValue = cell.getStringCellValue().trim();
								}
								value += stringValue+"$";
								break;
							}
							case BOOLEAN:
							{
								boolean valueBol = cell.getBooleanCellValue();
								value += valueBol+"$";
								break;
							}
							case FORMULA:
							{//公式
								CellValue evaluate = evaluator.evaluate(cell);
								switch (evaluate.getCellTypeEnum()) {
									case STRING:
									{
										if (isUpperCase) 
										{
											value+=evaluate.getStringValue().toUpperCase().trim()+"$";
										}
										else
										{
											value+=evaluate.getStringValue().trim()+"$";
										}
										break;
									}
									case NUMERIC:
									{
										if(HSSFDateUtil.isCellDateFormatted(cell)){
											Date date = HSSFDateUtil.getJavaDate(evaluate.getNumberValue());
											value += sdf.format(date)+"$";
										//判断是否科学计数法
										}else if((evaluate.getNumberValue()+"").contains("E")){
											//取消科学计数法
								            NumberFormat nf = NumberFormat.getInstance();
								            //设置保留多少位小数
								            nf.setMaximumFractionDigits(2);
								            // 取消科学计数法
								            nf.setGroupingUsed(false);
											//取消科学计数法
											value += nf.format(evaluate.getNumberValue())+"$";
										} else {
											//保留两位小数
											NumberFormat nf = NumberFormat.getInstance();
											nf.setMaximumFractionDigits(2);
											value += nf.format(evaluate.getNumberValue())+"$";
										}
										break;
									}
									default:
										value += "未知公式$";
										break;
								}
								break;
							}
							case NUMERIC://數字
							{
								double cellNumberValue = cell.getNumericCellValue();
								//判斷是否可以格式化
								if(HSSFDateUtil.isCellDateFormatted(cell)){
									Date dateValue = HSSFDateUtil.getJavaDate(cellNumberValue);
									value += sdf.format(dateValue)+"$";
								//判断是否科学计数法
								} else if((cellNumberValue+"").contains("E")) {
									// 取消科学计数法
						            NumberFormat nf = NumberFormat.getInstance();
						            // 设置保留多少位小数
						            nf.setMaximumFractionDigits(2);
						            // 取消科学计数法
						            nf.setGroupingUsed(false);
									value += nf.format(cellNumberValue)+"$";
								} else {
									// 保留两位小数
									NumberFormat nf = NumberFormat.getInstance();
									// 设置保留多少位小数
									nf.setMaximumFractionDigits(2);
									// 取消科学计数法
									nf.setGroupingUsed(false);
									value += nf.format(cellNumberValue)+"$";
								}
								break;
							}
							case BLANK:
							{//空值
								value +="-$";
								break;
							}
							case ERROR:
							{//錯誤
								value +="#N/A$";
								break;
							}
							default:
								value += "未知類型$";
								break;
							}
						}
						String[] values = value.split("\\$");
						Object obj = cla.newInstance();
						int index = 0;
						for (Field fie:cla.getDeclaredFields()) {
							String fieldName = fie.getName().toLowerCase();
							if ("uid".equals(fieldName) || fieldName.startsWith("serial") || "writetime".equals(fieldName) || "createtime".equals(fieldName)) {
								continue;
							}
							for (Method method : cla.getDeclaredMethods()) {
								if(method.getName().startsWith("set") && method.getName().substring(3).toUpperCase().equals(fie.getName().toUpperCase())){
									String methodType = method.getParameterTypes()[0].getSimpleName();
									if(index>=values.length) continue;
									//字符串類型
									if(methodType.toLowerCase().equals("string")){
										method.invoke(obj, values[index]);
									//數字類型
									} else if(methodType.toLowerCase().equals("integer")){
										if(values[index].equals("-")){values[index]="0";}
										method.invoke(obj, (int)Double.parseDouble(values[index]));
									//小數類型
									}else if(methodType.toLowerCase().equals("double")){
										if(values[index].equals("-")){values[index]="0";}
										method.invoke(obj, Double.parseDouble(values[index]));
									//日期類型
									}else if(methodType.toLowerCase().equals("date")){
										Date date = null;
										try{
											String dateStr = values[index].replaceAll("/", "-");
											//正常日期
											if(dateStr.contains("-")){
												date = sdf.parse(dateStr);
											//非正常日期,純數字
											} else if(dateStr.matches("[0-9]+\\.?[0-9]*")){
												date = HSSFDateUtil.getJavaDate(Double.parseDouble(dateStr));
												//非正常日期,以1999年開始的日期,說明是MMdd格式
											    if(sdf.format(date).startsWith("19")){
											    	//补充年份和零
											    	if(dateStr.length()==3){
											    		date = new SimpleDateFormat("yyyyMMdd").parse(sdf.format(new Date()).split("-")[0]+"0"+dateStr);
											    	}
											    	//补充年份和零
											    	else if(dateStr.length()==2){
											    		String newDateSet = "";
											    		for(char c:dateStr.toCharArray()){
											    			newDateSet += ("0"+c);
											    		}
											    		date = new SimpleDateFormat("yyyyMMdd").parse(sdf.format(new Date()).split("-")[0]+newDateSet);
											    	//符合MMDD格式,补充年份
											    	} else {
											    		date = new SimpleDateFormat("yyyyMMdd").parse(sdf.format(new Date()).split("-")[0]+dateStr);
											    	}
												//非正常日期,yyyyMMdd格式的日期
												} else if(Long.parseLong(sdf.format(date).split("-")[0])
														> Long.parseLong(sdf.format(new Date()).split("-")[0])){
													date = new SimpleDateFormat("yyyyMMdd").parse(dateStr);
												}
											} else {
												date = new Date(0);
											}
										} catch(Exception e) {
											date = new Date(0);
										}
										method.invoke(obj, date);
									}
									index++;
									break;
								}
							}
						}
						if(!exists.contains(obj.toString())){
							exists.add(obj.toString());
							list.add(obj);
						}
					}
				}
			} catch (IllegalStateException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
				throw new Exception();
			}finally{
				try {
					workbook.close();
					is.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return list;
	}
	
	/**
	 * 檢查文件後綴
	 * @param suffix
	 * @return
	 */
	private static boolean checkSuffix(MultipartFile file){
		String filename = file.getOriginalFilename();
		String suffix = filename.substring(filename.lastIndexOf(".")+1).toLowerCase();
		if(TYPE_XLSX.equalsIgnoreCase(suffix) && filename!="" && file.getSize()>0){
			return true;
		}else{
			return false;
		}
	}
	/**
	 * 排除static|velocity的修飾符字段
	 * 並且需要是private修飾字段
	 * @return boolean true 表示通過檢查
	 */
	public static boolean excludeField(int mod){
		if (Modifier.isPrivate(mod) && !Modifier.isStatic(mod) && !Modifier.isVolatile(mod)) {
			return true;
		}
		return false;
	}
	
	/**
	 * 生成表單號
	 **/
	public static String formNumber() {
		return UUID.randomUUID().toString().replaceAll("-", "").toUpperCase();
	}
	
	
	/**
	 * List的深度拷貝
	 * @param src 需要拷貝的集合
	 * @return 返回拷貝對象的結果
	 **/
	public static <T> List<T> ListDeepCopy(List<T> src) {
		if(src==null) return null;
		ByteArrayOutputStream byteOut = null;
		ObjectOutputStream out = null;
		ByteArrayInputStream byteIn = null;
		ObjectInputStream in = null;
		try {
			byteOut = new ByteArrayOutputStream(); 
			out = new ObjectOutputStream(byteOut); 
			out.writeObject(src); 
			byteIn = new ByteArrayInputStream(byteOut.toByteArray()); 
			in = new ObjectInputStream(byteIn); 
			@SuppressWarnings("unchecked") 
			List<T> dest = (List<T>) in.readObject();
			return dest; 
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(byteOut!=null) byteOut.close();
				if(out!=null) out.close();
				if(byteIn!=null) byteIn.close();
				if(in!=null) in.close();
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}
	
	/**
	 * 對象的深度拷貝
	 * @param src 需要拷貝的集合
	 * @return 返回拷貝對象的結果
	 **/
	public static Object ObjectDeepCopy(Object src)
	{
		try {
			ByteArrayOutputStream byteOut = new ByteArrayOutputStream(); 
			ObjectOutputStream out = new ObjectOutputStream(byteOut); 
			out.writeObject(src); 
			ByteArrayInputStream byteIn = new ByteArrayInputStream(byteOut.toByteArray()); 
			ObjectInputStream in = new ObjectInputStream(byteIn); 
			return in.readObject(); 
		} catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static final String TYPE_XLSX = "xlsx";
	public static final String DIR_UP_LOAD = "file";
	
	/**獲取項目路徑，并在該項目路徑下添加static/filedir/子文件夾，用於存放上傳文件
	 * @return 項目路徑+static/filedir/
	 */
	public static String getDataSharingUrl() {
		String projectUrl = null;
		try {
			File path = new File(ResourceUtils.getURL("classpath:").getPath());
			if (!path.exists()) {
				path = new File("");
			}
			File upload = new File(path.getAbsolutePath(), "static/filedir/");
			if (!upload.exists()) {
				upload.mkdirs();
			}
			projectUrl = upload.getAbsolutePath() + File.separator;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return projectUrl;
	}
	
	/**
	 * 隨機生成一個四位數的驗證碼
	 **/
	public static String createVerificationCode() {
		StringBuffer verificationCode = new StringBuffer();
		Random random = new Random(System.currentTimeMillis());
		for (int i = 0; i<4; i++) {
			verificationCode.append(random.nextInt(10));
		}
		return verificationCode.toString();
	}
	
    /** 
     * 使用DecimalFormat,保留小数点后两位 
     */  
    public static String twoDecimalPlaces(double value) {  
        NumberFormat nf = NumberFormat.getNumberInstance();  
        nf.setMaximumFractionDigits(2);
        nf.setMinimumFractionDigits(2);
        nf.setRoundingMode(RoundingMode.FLOOR);//两位小数以后的全部舍去
        nf.setGroupingUsed(false);//是否用千分位
        return nf.format(value);
    }
    
    /** 
     * 使用DecimalFormat,保留小数点后两位,四舍五入
     */
    public static Double twoDecimalPlacesHalfUp(double value) {  
        NumberFormat nf = NumberFormat.getNumberInstance();  
        nf.setMaximumFractionDigits(2);
        nf.setMinimumFractionDigits(2);
        nf.setRoundingMode(RoundingMode.HALF_UP);//四舍五入
        nf.setGroupingUsed(false);//是否用千分位
        return Double.parseDouble(nf.format(value));
    }
    
	/**
	 * 简体转繁体
	 **/
	public static String SimplifiedConverter(String str)
	{
		return 简繁转换类.转换(str, 简繁转换类.目标.繁体).trim();
	}
	
	/**
	 * 將集合對象中的字符串由簡體轉換為繁體
	 **/
	public static void SimplifiedConverter(List<?> list) {
		try {
			//如果為空,直接結束
			if(list.isEmpty()) {
				return;
			}
			//找出get方法的方法名,並且返回值是string
			List<String> getMethodNameList = new ArrayList<String>();
			//找出set方法的方法名
			Set<String> setMethodNameSet = new HashSet<String>();
			for(Method m:list.get(0).getClass().getMethods()) {
				if(m.getName().startsWith("get") 
						&& m.getReturnType().getSimpleName().equals("String")
						&& m.getParameterCount() == 0) {
					getMethodNameList.add(m.getName());
				} else if(m.getName().startsWith("set") 
						&& m.getParameterCount() == 1
						&& m.getParameters()[0].getType().getSimpleName().equals("String")) {
					setMethodNameSet.add(m.getName());
				}
			}
			//簡轉繁
			for(Object obj:list) {
				Class<?> _cla = obj.getClass();
				for(String methodName:getMethodNameList) {
					Method getMethod = _cla.getMethod(methodName);
					Object returnValue = getMethod.invoke(obj);
					if(returnValue != null) {
						String converterStr = Utils.SimplifiedConverter((String)returnValue);
						//調用set方法
						String setMethodName = getMethod.getName().replace("get", "set");
						//判斷set方法是否存在
						if(setMethodNameSet.contains(setMethodName)) {
							Method setMethod = _cla.getMethod(setMethodName,String.class);
							setMethod.invoke(obj, converterStr);
						}
					}
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 格式化表格,让表格的td个数不应该过长,处理废弃的td,主要针对非分摊性费用的上传
	 **/
	public static String tableFormat(String table) {
		Document document = Jsoup.parseBodyFragment(table);
		Elements trs = document.select("tr");
		//查找td的最大个数
		int trMaxTdCount = 0;
		for(int i = 0;i<trs.size();i++) {
			Elements tds = trs.get(i).select("td");
			//處理th
			if(tds.size() == 0) {
				tds = trs.get(i).select("th");
			}
			int tdCount = 0;//每行的td数量
			int tdEmptyCount = 0;// 没有值的td個數
			boolean isStartCount = false;//是否开始统计td数量
			for(int j = tds.size()-1;j >= 0;j--) {
				Element tdElement = tds.get(j);
				String text = tdElement.text().trim();
				if(!isStartCount && text.length()>0 && !text.matches("[\\s\\p{Zs}]+")) {
					isStartCount = true;
				}
				//统计td的个数
				if(isStartCount) {
					String colspan = tdElement.attr("colspan");
					if(colspan.length() > 0) {
						tdCount += Integer.parseInt(colspan);
					} else {
						tdCount++;
					}
				}
				if (text.length() == 0) {
					tdEmptyCount++;
				}
			}
			if(tdCount > trMaxTdCount) {
				trMaxTdCount = tdCount;
			}
			// 删除横向多余的td
			if (tdEmptyCount == tds.size()) {
				for (int j = 0;j < tds.size(); j++) {
					tds.get(j).remove();
				}
			}
		}
		//删除列开始位置多余的td
		f:for(int j = 0;j<trMaxTdCount;j++) {
			//判斷TR否存在數據
			for(int i = 0;i<trs.size();i++) {
				Elements tds = trs.get(i).select("td");
				//處理th
				if(tds.size() == 0) {
					tds = trs.get(i).select("th");
				}
				if(j < tds.size()) {
					Element tdElement = tds.get(j);
					String text = tdElement.text().trim();
					if(text.length() > 0 && !text.matches("[\\s\\p{Zs}]+")) {
						continue f;
					}
				}
			}
			//如果没有continue,说明整列都没有数据,就删除整列td
			for(int i = 0;i<trs.size();i++) {
				Elements tds = trs.get(i).select("td");
				//處理th
				if(tds.size() == 0) {
					tds = trs.get(i).select("th");
				}
				if(j < tds.size()) {
					tds.get(j).remove();
				}
			}
		}
		//根据td的最大个数,删除多余td
		for(int i = 0;i<trs.size();i++) {
			Elements tds = trs.get(i).select("td");
			//處理th
			if(tds.size() == 0) {
				tds = trs.get(i).select("th");
			}
			int tdCount = 0;
			//统计不为空的td个数
			int isNotEmptyTdCount = 0;
			//统计所有td个数
			for(int j = 0;j<tds.size();j++) {
				Element tdElement = tds.get(j);
				String text = tdElement.text().trim();
				String colspan = tdElement.attr("colspan");
				String rowspan = tdElement.attr("rowspan");
				//統計tr中td的個數
				if(colspan.length() > 0) {
					tdCount += Integer.parseInt(colspan);
				} else {
					tdCount ++;
				}
				//判斷是否為多餘的td
				if(tdCount > trMaxTdCount && rowspan.length()==0 
						&& (text.length()==0 || text.matches("[\\s\\p{Zs}]+"))) {
					tdElement.remove();
					continue;
				}
				//調整td內容的顯示位置
				if(text.length() > 0 && !text.matches("[\\s\\p{Zs}]+")) {
					//沒有跨單元格的,如果是文字靠左顯示,如果是数字就靠右显示
					if(colspan.length()==0 && rowspan.length()==0) {
						if(isContainNumber(text)) {
							tdElement.attr("style", "text-align:right!important;padding-right:5px!important;");
						} else {
							tdElement.attr("style", "text-align:left!important;padding-left:5px!important;");
						}
					//如果縱向跨行,文字居中,數字靠右
					} else if(rowspan.length() > 0) {
						if(isContainNumber(text)) {
							tdElement.attr("style", "text-align:right!important;");
						} else {
							tdElement.attr("style", "text-align:center!important;");
						}
					//剩下的根據內容就行靠左顯示,如果是数字就靠右显示
					} else {
						if(isContainNumber(text)) {
							tdElement.attr("style", "text-align:right!important;padding-right:5px!important;");
						} else {
							for(String symbol:new String[]{"：",":","；",";","。",".","，",",","！","!"}) {
								if(text.contains(symbol)) {
									tdElement.attr("style", "text-align:left!important;padding-left:5px!important;");
									break;
								}
							}
						}
					}
					//统计不为空TD的数量
					if(colspan.length()==0) {
						isNotEmptyTdCount++;
					} else {
						isNotEmptyTdCount += Integer.parseInt(colspan);
					}
				}
			}
			//说明整行都没有内容,直接移除整个TR
			if(isNotEmptyTdCount == 0 && tdCount>=trMaxTdCount) {
				trs.get(i).remove();
				continue;
			}
		}
		//返回最终结果
		return document.body().html();
	}
	
	/**
	 * 判斷是否包含數字
	 **/
	private static boolean isContainNumber(String text) {
		if (text.equals("-")) return true;
		String formatText = text.replaceAll(",", "");
		Pattern p = Pattern.compile("-?\\d+(\\.\\d+)?");
		Matcher m = p.matcher(formatText);
		boolean isNumber = m.find();
		p = Pattern.compile("[\\u4e00-\\u9fa5]");
		m = p.matcher(formatText);
		boolean isChinese = m.find();
		p = Pattern.compile("[a-zA-Z]");
		m = p.matcher(formatText);
		boolean isLetter = m.find();
		return (isNumber && !isChinese && !isLetter);
	}
	
	/**
	 * 判断是否拥有URL的权限
	 **/
	public static boolean containsEndUrl(HttpSession session,String endUrl) {
		User userEntity = (User) session.getAttribute("user");
		for (Role r:userEntity.getRoleList()) {
			for (Permission p:r.getPermissionList()) {
				if (p.getPerUrl().endsWith(endUrl)) {
					return true;
				}
			}
		}
		return false;
	}
	
	/**
	 * 將list變更為 xxx,xxx,xxx的字符串形式
	 **/
	public static String listConvertString(List<String> list) {
		return list.toString().replace("[", "").replace("]", "").replaceAll("\\s+", "");
	}
	
	/**
	 * 假分頁
	 **/
	public static ResponseStatus<List<?>> paging(List<?> inList, int currPage, int pageSize) {
		ResponseStatus<List<?>> rs = new ResponseStatus<>();
		// 获取当前页码的起始索引
		int startIndex = (currPage - 1) * pageSize;
		List<Object> list = new ArrayList<>();
		if (CollectionUtils.isNotEmpty(inList)) {
		for (int i = startIndex;i < (startIndex + pageSize);i ++) {
				if (inList.size() > i) {					
					list.add(inList.get(i));
				}
			}
			rs.setMessage("有数据");
		} else {
			rs.setMessage("未查到数据，集合为空");
		}
		rs.setData(list);
		rs.setAllPageCode((inList.size() + pageSize - 1)/pageSize);
		return rs;
	}
}
