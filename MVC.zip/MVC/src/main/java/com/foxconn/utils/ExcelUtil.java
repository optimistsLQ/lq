package com.foxconn.utils;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

import com.lowagie.text.Document;
import com.lowagie.text.pdf.PdfCopy;
import com.lowagie.text.pdf.PdfImportedPage;
import com.lowagie.text.pdf.PdfReader;

public class ExcelUtil {

	/**
	 * HSSFWorkbook:是操作Excel2003以前（包括2003）的版本,扩展名是.xls
	 * XSSFWorkbook:是操作Excel2007的版本，扩展名是.xlsx
	 * 当数据量超出65536条后,这时应该用SXSSFworkbook.
	 * @param fileName
	 * @param list 内容为map结构
	 * @throws IOException 
	 */
	@SuppressWarnings("unchecked")
	public static void handleExcelDown(String fileName,String title,List<?> list,HttpServletResponse resp) {
		Workbook workbook = new SXSSFWorkbook();
		Sheet sheet = workbook.createSheet();
		// 第0行,生成表头
		Row headRow = sheet.createRow(0);
		int colum = 0;
		for (String titleStr : title.split(",")) {
			Cell cell = headRow.createCell(colum++, CellType.STRING);
			cell.setCellValue(titleStr);
		}
		// 生成表格
		for (int i = 0; i < list.size(); i++) {
			Row row = sheet.createRow(i+1);
			Map<String,Object> map = (Map<String,Object>)list.get(i);
			Set<Entry<String,Object>> entrySet = map.entrySet();
			Iterator<Entry<String, Object>> it = entrySet.iterator();
			colum = 0;
			while (it.hasNext()) {
				Entry<String, Object> entry = it.next();
				Object value = entry.getValue();
				if(value==null) {
					Cell cell = row.createCell(colum++, CellType.STRING);
					cell.setCellValue("");
				} else if (value instanceof BigDecimal || value.toString().matches("^-?\\d+(\\.\\d+)?$")) {
					Cell cell = row.createCell(colum++, CellType.NUMERIC);
					cell.setCellValue(value==null?0:Double.parseDouble(value.toString()));
				} else {
					Cell cell = row.createCell(colum++, CellType.STRING);
					cell.setCellValue(value==null?"":value.toString());
				}
			}
		}
		resp.setContentType("application/vnd.ms-excel;charset=utf-8");
		resp.setHeader("Content-Disposition", "attachment;filename="+fileName+".xlsx");
		try {
			workbook.write(resp.getOutputStream());
			resp.getOutputStream().flush();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				workbook.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	/**
	 * 处理00012这种费用代码下载只有12的问题
	 * @param fileName
	 * @param title
	 * @param list
	 * @param resp
	 */
	@SuppressWarnings("unchecked")
	public static void handleExcelDownText(String fileName,String title,List<?> list,HttpServletResponse resp) {
		Workbook workbook = new SXSSFWorkbook();
		Sheet sheet = workbook.createSheet();
		// 第0行,生成表头
		Row headRow = sheet.createRow(0);
		int colum = 0;
		for (String titleStr : title.split(",")) {
			Cell cell = headRow.createCell(colum++, CellType.STRING);
			cell.setCellValue(titleStr);
		}
		// 生成表格
		for (int i = 0; i < list.size(); i++) {
			Row row = sheet.createRow(i+1);
			Map<String,Object> map = (Map<String,Object>)list.get(i);
			Set<Entry<String,Object>> entrySet = map.entrySet();
			Iterator<Entry<String, Object>> it = entrySet.iterator();
			colum = 0;
			while (it.hasNext()) {
				Entry<String, Object> entry = it.next();
				Object value = entry.getValue();
				if (value instanceof BigDecimal) {
					Cell cell = row.createCell(colum++, CellType.NUMERIC);
					cell.setCellValue(value==null?0:Double.parseDouble(value.toString()));
				} else {
					Cell cell = row.createCell(colum++, CellType.STRING);
					cell.setCellValue(value==null?"":value.toString());
				}
			}
		}
		resp.setContentType("application/vnd.ms-excel;charset=utf-8");
		resp.setHeader("Content-Disposition", "attachment;filename="+fileName+".xlsx");
		try {
			workbook.write(resp.getOutputStream());
			resp.getOutputStream().flush();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				workbook.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
    //合併pdf
    public static boolean mergePdfFiles(String[] files, String newfile) {  
        boolean retValue = false;  
        Document document = null;  
        try {  
            document = new Document(new PdfReader(files[0]).getPageSize(1));  
            PdfCopy copy = new PdfCopy(document, new FileOutputStream(newfile));  
            document.open();  
            for (int i = 0; i < files.length; i++) {  
                PdfReader reader = new PdfReader(files[i]);  
                int n = reader.getNumberOfPages();  
                for (int j = 1; j <= n; j++) {
                    document.newPage();  
                    PdfImportedPage page = copy.getImportedPage(reader, j);  
                    copy.addPage(page);  
                }  
            }  
            retValue = true;  
        } catch (Exception e) {  
            e.printStackTrace();  
        } finally {  
            document.close();  
        }  
        return retValue;  
    }
    /**
     * HTML转PDF
     **/
    public static void htmlToPDF(File htmlFile, File pdfFile) {
		wkHtmlTo(htmlFile,pdfFile,false);
	}
    public static void htmlToPDF(File htmlFile, File pdfFile,boolean isJavascriptDelay) {
		wkHtmlTo(htmlFile,pdfFile,isJavascriptDelay);
	}
	private static void wkHtmlTo(File htmlFile, File targetFile, boolean isJavascriptDelay) {
		String htmlPath = htmlFile.getAbsolutePath();
		String targetPath = targetFile.getAbsolutePath();
		Process process = null;
		InputStream errorStream = null;
		InputStream successStream = null;
		try {
			//创建WKHTMLTOPDF允许对象
			Runtime runtime = Runtime.getRuntime();
			if(targetPath.toLowerCase().contains(".pdf"))
				process = runtime.exec("cmd /c wkhtmltopdf "+(isJavascriptDelay?"--javascript-delay 1500":"")+" -L 0 -R 0 --page-size A3 \""+htmlPath+"\" \""+targetPath+"\"");
			else
				process = runtime.exec("cmd /c wkhtmltoimage \""+htmlPath+"\" \""+targetPath+"\"");
			errorStream = process.getErrorStream();
			successStream = process.getInputStream();
			Thread errorThread = new Thread(htmlToStreamMessage(errorStream));
			Thread successThread = new Thread(htmlToStreamMessage(successStream));
			errorThread.start();
			successThread.start();
			errorThread.join();
			successThread.join();
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(errorStream!=null) errorStream.close();
				if(successStream!=null) successStream.close();
			} catch(Exception e) {
				e.printStackTrace();
			}
			if(process!=null) process.destroy();
		}
	}
	/**
	 * HTML转PDF 辅助方法,读取WKHTMLTOPDF的信息
	 **/
	private static Runnable htmlToStreamMessage(InputStream is) {
		return () -> {
			BufferedInputStream bis = null;
			InputStreamReader isr = null;
			BufferedReader br = null;
			try {
				bis = new BufferedInputStream(is);
				isr = new InputStreamReader(bis,"BIG5");
				br = new BufferedReader(isr);
				String message = "";
				while ((message = br.readLine()) != null) {
					System.out.println(message);
				}
			} catch(Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if(bis!=null) bis.close();
					if(isr!=null) isr.close();
					if(br!=null) br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		};
	}
}
