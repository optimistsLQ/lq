package com.foxconn.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * 日期獲取工具類
 **/
public class DateUtils {

	/**
	 * 獲取當前的系統時間
	 * 
	 * @param pattern 自定義匹配日期格式
	 * @return String 返回符合匹配格式的日期字串
	 **/
	public static String getCurrentDate(String pattern) {
		SimpleDateFormat dateFormat = new SimpleDateFormat(pattern);
		return dateFormat.format(new Date());
	}

	/**
	 * 2019-9-22 ==> 2019-09-22
	 * @param time
	 * @return
	 */
	public static String handleMonth(String time) {
		String[] split = time.split("-");
		if(split[1].length() == 1){
			split[1] = "0"+split[1];
			if(split[2].length() == 7){
				split[2] = "0"+split[2];
			}
			String temp = "";
			for (int i = 0; i < split.length; i++) {
				if (i <= 1) {
					temp+=split[i]+"-";
				} else {
					temp+=split[i];
				}
			}
			time = temp;
		};
		return time;
	}
	
	/**
     * 获取指定年月的总天数
     */
     public static int getDayNumOfMonth(String year, String month) {     
         Calendar cal = Calendar.getInstance();     
         //设置年份  
         cal.set(Calendar.YEAR, Integer.parseInt(year));
         //设置月份  
         cal.set(Calendar.MONTH, Integer.parseInt(month)-1);
         //获取某月最大天数
         int lastDay = cal.getActualMaximum(Calendar.DATE);
         //设置日历中月份的最大天数  
         cal.set(Calendar.DAY_OF_MONTH, lastDay);
         //返回结果
         return Integer.parseInt(new SimpleDateFormat("dd").format(cal.getTime()));
     }
     
     /**
      * 获取指定年月的星期天数
      **/
     public static int getSundayNumOfMonth(String year, String month) {
         Calendar cal = Calendar.getInstance();     
         //设置年份  
         cal.set(Calendar.YEAR, Integer.parseInt(year));
         //设置月份  
         cal.set(Calendar.MONTH, Integer.parseInt(month)-1);
         //设置为每月一号
         cal.set(Calendar.DAY_OF_MONTH, 1);
         //星期
         SimpleDateFormat weekDateFormat = new SimpleDateFormat("EEEE",Locale.ENGLISH);
         //月份
         SimpleDateFormat monthDateFormat = new SimpleDateFormat("MM");
         Date forDate = null;
         //统计星期天天数
         int sundayCount = 0;
         for(;;) {
        	 forDate = cal.getTime();
        	 if(!monthDateFormat.format(forDate).equals(month)) {
        		 break;
        	 }
        	 if(weekDateFormat.format(forDate).toLowerCase().equals("sunday")) {
        		 sundayCount++;
        	 }
        	 cal.add(Calendar.DAY_OF_MONTH, 1);
         }
         return sundayCount;
     }
     
     /**
      * 日期格式化
      **/
     public static String format(Date date, String pattern) {
    	 if (date == null) {
    		 return null;
    	 }
    	 return new SimpleDateFormat(pattern).format(date);
     }
     
     /**
      * 日期轉換
      **/
     public static Date parse(String str,String pattern) {
    	try {
    		// 時間拆分
    		String [] strArr = str.split("-");
    		// 格式化規則
    		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
    		// 判斷日期格式是否存在天
    		if (strArr.length == 3) {
	    		// 獲取當前月的最後一天
	    		String lastDay = getLastDay(str, 1).get(0);
	    		// 判斷天數是否有誤,防止出現2月31號的情況,如果出現,則以最大天數為準
	    		if (Integer.parseInt(strArr[2]) > Integer.parseInt(lastDay.split("-")[2])) {
	    			return sdf.parse(lastDay);
	    		}
    		}
			return sdf.parse(str);
		} catch (ParseException e) {
			e.printStackTrace();
		}
    	return null;
     }
     
     /**
      * 给定两个日期,返回两个日期的天数,但要除去星期天
      **/
     public static int betweenDayNum(Date firstDate,Date lastDate,boolean isContainSunday) {
    	 Calendar cal = Calendar.getInstance();
    	 cal.setTime(firstDate);
         SimpleDateFormat weekDateFormat = new SimpleDateFormat("EEEE",Locale.ENGLISH);
         Date forDate = null;
         //统计天数
         int dayCount = 0;
    	 for(;;) {
    		 forDate = cal.getTime();
    		 if(!isContainSunday && !weekDateFormat.format(forDate).toLowerCase().equals("sunday")) {
    			 dayCount++;
    		 }
    		 cal.add(Calendar.DAY_OF_MONTH, 1);
    		 if(forDate.getTime()>lastDate.getTime()) {
    			 break;
    		 }
    	 }
    	 return dayCount;
     }
     
 	/**
 	 * 日期的“天”補零
 	 **/
 	public static String dayZeroFill(String day) {
 		day = day.replaceAll("\\s+", "");
 		if (day.length() == 1) {
 			return "0"+day;
 		}
 		return day;
 	}
 	
 	/**
 	 * 返回當前當季的第幾個月
 	 **/
 	public static String currentQuarterHowManyMonths() {
 		int month = Integer.parseInt(getCurrentDate("MM"));
 		if (month == 1 || month == 4 || month == 7 || month == 10) {
 			return "第一個月";
 		} else if (month == 3 || month == 6 || month == 9 || month == 12) {
 			return "第三個月";
 		}
 		return "第二個月";
 	}
 	
 	/**
 	 * 當前是第幾季度
 	 * 1~3 為第一季
 	 * 4~6 為第二季
 	 * 7~9 為第三季
 	 * 10~12 為第四季 
 	 **/
 	public static String currentQuarter() {
 		int m = Integer.parseInt(getCurrentDate("MM"));
 		if (m >= 1 && m <= 3) {
 			return "第一季度";
 		} else if (m >= 4 && m <= 6) {
 	        return "第二季度";
 	    } else if (m >= 7 && m <= 9) {
 	        return "第三季度";
 	    }
 		return "第四季度";
 	}
 	
 	/**
 	 * 根據季度得到具體月份
 	 **/
 	public static String quarterConvertMonth(String quarterChinese,String monthChinese) {
 		if (quarterChinese.equals("第一季度") && monthChinese.equals("第一個月")) {
 			return "01";
 		} else if (quarterChinese.equals("第一季度") && monthChinese.equals("第二個月")) {
 			return "02";
 		} else if (quarterChinese.equals("第一季度") && monthChinese.equals("第三個月")) {
 			return "03";
 		} else if (quarterChinese.equals("第二季度") && monthChinese.equals("第一個月")) {
 			return "04";
 		} else if (quarterChinese.equals("第二季度") && monthChinese.equals("第二個月")) {
 			return "05";
 		} else if (quarterChinese.equals("第二季度") && monthChinese.equals("第三個月")) {
 			return "06";
 		} else if (quarterChinese.equals("第三季度") && monthChinese.equals("第一個月")) {
 			return "07";
 		} else if (quarterChinese.equals("第三季度") && monthChinese.equals("第二個月")) {
 			return "08";
 		} else if (quarterChinese.equals("第三季度") && monthChinese.equals("第三個月")) {
 			return "09";
 		} else if (quarterChinese.equals("第四季度") && monthChinese.equals("第一個月")) {
 			return "10";
 		} else if (quarterChinese.equals("第四季度") && monthChinese.equals("第二個月")) {
 			return "11";
 		} else if (quarterChinese.equals("第四季度") && monthChinese.equals("第三個月")) {
 			return "12";
 		}
 		return null;
 	}
 	
 	/**
 	 * 獲取當前月份的最後兩天
 	 **/
 	public static List<String> getLastDay(int lastDay) {
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        Calendar calendar = Calendar.getInstance();
        List<String> list=new ArrayList<String>();
        for(int i=1;i<=lastDay;i++){
            calendar.add(Calendar.MONTH, 1);
            calendar.set(Calendar.DATE, 1);
            calendar.add(Calendar.DATE, -i);
            Date theDate = calendar.getTime();
            String s = df.format(theDate);
            list.add(s);
        }
        return list;
    }
 	
 	/**
 	 * 獲取月份的最後兩天
 	 **/
 	public static List<String> getLastDay(String date, int lastDay) {
 		String [] arr = date.split("-");
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        Calendar calendar = Calendar.getInstance();
        try {calendar.setTime(df.parse(arr[0] + "-" + arr[1] + "-01"));
		} catch (ParseException e) {e.printStackTrace();}
        List<String> list=new ArrayList<String>();
        for(int i=1;i<=lastDay;i++){
            calendar.add(Calendar.MONTH, 1);
            calendar.set(Calendar.DATE, 1);
            calendar.add(Calendar.DATE, -i);
            Date theDate = calendar.getTime();
            String s = df.format(theDate);
            list.add(s);
        }
        return list;
    }
 	
 	/**
 	 * 月份+1
 	 **/
 	public static String monthAdd(String month) {
 		int m = Integer.parseInt(month);
 		if (m == 12) {
 			return "01";
 		}
 		return dayZeroFill(Integer.toString((++m)));
 	}
 	
 	/**
 	 * 根據年月獲取某個星期的所有號數
 	 * 比如:4月所有的星期一
 	 **/
 	public static List<String> getMonthWeek(String year,String month,String englishWeek) {
 		try {
 			month = dayZeroFill(month);
	 		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
	 		Calendar calendar = Calendar.getInstance();
	 		calendar.setTime(df.parse(year + "-" + month + "-01"));
	 		// 設置當前時間星期
	 		switch (englishWeek) {
		 		case "sunday":
		 			calendar.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
		 		break;
		 		case "monday":
		 			calendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
		 		break;
		 		case "tuesday":
		 			calendar.set(Calendar.DAY_OF_WEEK, Calendar.TUESDAY);
		 		break;
		 		case "wednesday":
		 			calendar.set(Calendar.DAY_OF_WEEK, Calendar.WEDNESDAY);
		 		break;
		 		case "thursday":
		 			calendar.set(Calendar.DAY_OF_WEEK, Calendar.THURSDAY);
		 		break;
		 		case "friday":
		 			calendar.set(Calendar.DAY_OF_WEEK, Calendar.FRIDAY);
		 		break;
		 		case "saturday":
		 			calendar.set(Calendar.DAY_OF_WEEK, Calendar.SATURDAY);
		 		break;
	 		}
	 		// 得到時間戳
	 		long timeStamp = calendar.getTime().getTime();
	 		List<String> resultList = new ArrayList<String>();
	 		for (int i = 0;i < 6;i++) {
	 			Date newDate = new Date(timeStamp);
	 			String dateStr = df.format(newDate);
	 			if (dateStr.startsWith(year + "-" + month)) {
	 				resultList.add(dateStr);
	 			}
	 			// 時間戳每次加7天,一天是86400000毫秒
	 			timeStamp += (86400000 * 7);
	 		}
	 		return resultList;
 		} catch (Exception e) {
 			e.printStackTrace();
 		}
 		return null;
 	}
 	
 	/**
 	 * 根據時間獲取該時間所在周範圍
 	 * 周的定義為: 周天到週六
 	 **/
 	public static List<String> getWeekRange(String year, String month, String day) {
 		try {
 			// 補零
	 		month = dayZeroFill(month);
	 		day = dayZeroFill(day);
	 		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
	 		Calendar calendar = Calendar.getInstance();
	 		// 設置所在時間
	 		calendar.setTime(df.parse(year + "-" + month + "-" + day));
	 		// 起始位置設為周天
	 		calendar.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
	 		List<String> list = new ArrayList<String>();
	 		list.add(df.format(calendar.getTime()));
	 		// 遍歷到週六
	 		for (int i=1;i<=6;i++) {
	 			calendar.add(Calendar.DAY_OF_MONTH, 1);
	 			list.add(df.format(calendar.getTime()));
	 		}
	 		return list;
 		} catch (Exception e) {
 			e.printStackTrace();
 		}
 		return null;
 	}
 	
 	/**
 	 * 根據年月日找出某個星期的日期
 	 **/
 	public static String findWeekByYearMonthDay(String year,String month,String day,String englishWeek) {
 		switch (englishWeek) {
	 		case "sunday":
	 			return getWeekRange(year, month, day).get(0);
	 		case "monday":
	 			return getWeekRange(year, month, day).get(1);
	 		case "tuesday":
	 			return getWeekRange(year, month, day).get(2);
	 		case "wednesday":
	 			return getWeekRange(year, month, day).get(3);
	 		case "thursday":
	 			return getWeekRange(year, month, day).get(4);
	 		case "friday":
	 			return getWeekRange(year, month, day).get(5);
	 		case "saturday":
	 			return getWeekRange(year, month, day).get(6);
		}
 		return null;
 	}
 	
	/**
	 * 計算結算類型-月的具體歸屬時間
	 **/
	public static String actualAttributionMonth(String settlementType) {
		String [] currentDateArr = DateUtils.getCurrentDate("yyyy-MM-dd").split("-");
		int year = Integer.parseInt(currentDateArr[0]);
		int month = Integer.parseInt(currentDateArr[1]);
		// 計算年月
		for (char c:settlementType.toCharArray()) {
			if (Character.toString(c).equals("上")) {
				month--;
				if (month <= 0) {
					month = 12;
					year--;
				}
			}
		}
		return year + "-" + DateUtils.dayZeroFill(Integer.toString(month));
	}
	
	/**
	 * 通過結算類型和歸屬日期-推算應送日期
	 **/
	public static String actualMonthShouldDate(String yearStr,String monthStr,String settlementType) {
		int year = Integer.parseInt(yearStr);
		int month = Integer.parseInt(monthStr);
		// 計算年月
		for (char c:settlementType.toCharArray()) {
			if (Character.toString(c).equals("上")) {
				month++;
				if (month > 12) {
					month = 1;
					year++;
				}
			}
		}
		return year + "-" + DateUtils.dayZeroFill(Integer.toString(month));
	}
}
