package com.foxconn;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 程序啟動入口
 **/
@SpringBootApplication
@MapperScan("com.foxconn.mapper")
public class MVCApplicationRun{

    public static void main(String[] args) {
    	SpringApplication.run(MVCApplicationRun.class, args);
    }
}
