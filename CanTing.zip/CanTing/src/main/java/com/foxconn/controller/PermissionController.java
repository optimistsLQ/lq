package com.foxconn.controller;

import java.util.List;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.alibaba.fastjson.JSON;
import com.foxconn.entity.PermissionEntity;
import com.foxconn.entity.Result;
import com.foxconn.entity.ResultCode;
import com.foxconn.service.PermissionService;
import com.github.pagehelper.PageInfo;

@RestController
@RequestMapping("/permission")
@CrossOrigin
public class PermissionController {
	
	@Autowired
	private PermissionService perService;
	
	@RequestMapping("/addPermission.do")
	public Result addPermission(@RequestBody PermissionEntity permission) {
		Result result = null;
		int i = perService.insertPermission(permission);
		if (i > 0) {
			result = new Result(ResultCode.SUCCESS);
		}else {
			result = new Result(ResultCode.FAIL);
		}
		return result;
	}

	@RequestMapping("/delPermission.do")
	public Result delPermission(String perIds) {
		Result result = null;
		List<String> perIdList = JSON.parseArray(perIds, String.class);
		int i = perService.delPermission(perIdList);
		if (i > 0) {
			result = new Result(ResultCode.SUCCESS);
		}else {
			result = new Result(ResultCode.FAIL);
		}
		return result;
	}
	
	@RequestMapping("/updatePermission.do")
	public Result updatePermission(@RequestBody PermissionEntity permission) {
		Result result = null;
		int i = perService.updatePermission(permission);
		if (i > 0) {
			result = new Result(ResultCode.SUCCESS);
		}else {
			result = new Result(ResultCode.FAIL);
		}
		return result;
	}
	
	@RequestMapping("/listPermission.do")
	public Result listPermission(String projectCode, Integer start, Integer length) {
		PageInfo<PermissionEntity> info = perService.listAllPermission(start, length);
		Result result = new Result(ResultCode.SUCCESS,info);
		return result;
	}
	
	@RequestMapping("/validate.do")
	public Result validatePermission(String projectCode, String perName) {
		PermissionEntity permissionEntity = perService.getPermissionByPerName(perName);
		System.out.println(permissionEntity);
		Boolean bool = true;
		if (ObjectUtils.isEmpty(permissionEntity)) {
			bool = false;
		}
		return new Result(ResultCode.SUCCESS, bool);
	}
	
	@RequestMapping("/getPerById.do")
	public Result getPerById(String perId) {
		System.out.println(">>>"+perId);
		PermissionEntity permissionEntity = perService.getPermissionByPerId(perId);
		return new Result(ResultCode.SUCCESS, permissionEntity);
	}
}
