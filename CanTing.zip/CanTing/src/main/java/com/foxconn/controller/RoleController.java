package com.foxconn.controller;

import java.util.List;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.foxconn.entity.RPEntity;
import com.foxconn.entity.Result;
import com.foxconn.entity.ResultCode;
import com.foxconn.entity.RoleEntity;
import com.foxconn.service.RolePermissionService;
import com.foxconn.service.RoleService;

@RestController
@RequestMapping("/role")
@CrossOrigin
public class RoleController {

	@Autowired
	private RoleService roleService;
	@Autowired
	private RolePermissionService RPservice;
	
	@RequestMapping("/addRole.do")
	public Result addrole(String role, String perIds) {
		Result result = null;
		RoleEntity roleEntity = JSON.parseObject(role, RoleEntity.class);
		
		List<String> perIdList = JSONArray.parseArray(perIds, String.class);
		int i = roleService.insertRole(roleEntity);
		String roleId = roleService.getRoleId(roleEntity);
		System.out.println("roleId>"+roleId);
		if (i > 0 && perIdList.size() != 0) {
			for (String perId : perIdList) {
				RPservice.insertRolePermission(new RPEntity(null, roleId, perId, null));
			}
			result = new Result(ResultCode.SUCCESS);
		}else {
			result = new Result(ResultCode.FAIL);
		}
		return result;
	}
	@RequestMapping("/delRole.do")
	public Result delRole(String roleIds) {
		Result result = null;
		List<String> roleIdList = JSON.parseArray(roleIds, String.class);
			int i = roleService.delRoles(roleIdList);
		if (i > 0) {
			result = new Result(ResultCode.SUCCESS);
		}else {
			result = new Result(ResultCode.FAIL);
		}
		return result;
	}
	
	@RequestMapping("/updateRole.do")
	public Result updateRole(String role, String perIds) {
		Result result = null;
		RoleEntity roleEntity = JSON.parseObject(role, RoleEntity.class);
		int i = roleService.updateRoel(roleEntity);
		if (i > 0) {
			RPservice.changeRolePermission(roleEntity.getRoleId(), JSONArray.parseArray(perIds, String.class));
			result = new Result(ResultCode.SUCCESS);
		}else {
			result = new Result(ResultCode.FAIL);
		}
		return result;
	}
	
	@RequestMapping("/listRole.do")
	public Result listRole(String projectCode,Integer start,Integer length) {
		if (null == start) {
			start = 1;
		}
		if (null == length) {
			length = Integer.MAX_VALUE;
		}
		List<RoleEntity> info = roleService.listRoleAll(start, length);
//		int i = roleService.count(projectCode);
		Result result = new Result(ResultCode.SUCCESS,info);
		return result;
	}
	
	@RequestMapping("/getRoleById.do")
	public Result getRoleById(String roleId) {
		Result result = null;
		RoleEntity role = roleService.getRoleById(roleId);
		
		if (ObjectUtils.isNotEmpty(role)) {
			result = new Result(ResultCode.SUCCESS,role);
		}else {
			result = new Result(ResultCode.FAIL);
		}
		return result;
	}
}
