package com.foxconn.controller;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.foxconn.entity.CheckPeople;
import com.foxconn.entity.CheckTotal;
import com.foxconn.entity.Result;
import com.foxconn.entity.ResultCode;
import com.foxconn.entity.base.AuditPeople;
import com.foxconn.service.CheckPeopleService;
import com.foxconn.service.CheckProblemService;
import com.foxconn.service.CheckTotalService;

@RestController
@RequestMapping("/check")
@CrossOrigin
public class CheckTotalController {

	@Autowired
	private CheckTotalService checkTotalService;
	@Autowired
	private CheckProblemService checkProblemService;
	@Autowired
	private CheckPeopleService checkPeopleService;
	
	@RequestMapping("/addCheckTotal.do")
	@Transactional
	public Result addCheckTotal(@RequestBody CheckTotal checkTotal, String auditPeopleArr) {
		Result result = null;
		String checkTotalId = checkTotalService.addCheckTotal(checkTotal);
		if (StringUtils.isNotEmpty(checkTotalId)) {
			result = new Result(ResultCode.SUCCESS);
			List<AuditPeople> auditPeopleList = JSON.parseArray(auditPeopleArr, AuditPeople.class);
			for (AuditPeople auditPeople : auditPeopleList) {
				CheckPeople checkPeople = new CheckPeople(null, checkTotalId, auditPeople.getUname(), auditPeople.getJobCard(), auditPeople.getPeopleType(), null);
				checkPeopleService.addCheckPeople(checkPeople);
			}
		}
		return result;
	}
	
	@RequestMapping("/delCheckTotal.do")
	public Result delCheckTotal(String checkTotalId) {
		Result result = null;
		int i = checkTotalService.delCheckTotalById(checkTotalId);
		if (i > 0) {
			checkPeopleService.delCheckPeopleByCheckTotalId(checkTotalId);
			checkProblemService.delCheckProblemByCheckTotalId(checkTotalId);
			result = new Result(ResultCode.SUCCESS);
		}
		return result;
	}
	
	@RequestMapping("/updataeCheckTotal.do")
	public Result updataeCheckTotal(@RequestBody CheckTotal checkTotal) {
		Result result = null;
		int i = checkTotalService.updateCheckTotal(checkTotal);
		if (i > 0) {
			result = new Result(ResultCode.SUCCESS);
		}else {
			result = new Result(ResultCode.FAIL);
		}
		return result;
	}
}
