package com.foxconn.controller;
import java.util.List;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.shiro.crypto.hash.Md5Hash;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.alibaba.fastjson.JSON;
import com.foxconn.entity.Result;
import com.foxconn.entity.ResultCode;
import com.foxconn.entity.UserEntity;
import com.foxconn.entity.pageDTO;
import com.foxconn.service.UserRoleService;
import com.foxconn.service.UserService;

@CrossOrigin
@RestController
@RequestMapping("/user")
public class UserController {
	@Autowired
	private UserService userService;
	@Autowired
	private UserRoleService URservice;
	
	@RequestMapping("/addUser.do")
	public Result addUser(@RequestBody UserEntity user) {
		Result result = null;
		 String md5HashPwd = new Md5Hash(user.getPwd(),user.getUserNumber(),3).toString();
		 user.setPwd(md5HashPwd);
		int i = userService.insertUser(user);
		if (i > 0) {
			result = new Result(ResultCode.SUCCESS,null);
		}else {
			result = new Result(ResultCode.FAIL,null);
		}
		return result;
	}
	
	@RequestMapping("/delUser.do")
	public Result delUser(String ids) {
		Result result = null;
		List<String> idList = JSON.parseArray(ids, String.class);
		int i = userService.delUser(idList);
		if (i > 0) {
			result = new Result(ResultCode.SUCCESS);
		}else {
			result = new Result(ResultCode.FAIL);
		}
		return result;
	}
	
	@RequestMapping("/updateUser.do")
	public Result updateUser(@RequestBody UserEntity user, @RequestParam String adminRoleID) {
		if ("".equals(user.getPwd())) {
			user.setPwd(null);
		}else {
			String md5HashPwd = new Md5Hash(user.getPwd(),user.getUserNumber(),3).toString();
			user.setPwd(md5HashPwd);
		}
		Result result = null;
		int i = userService.updateUser(user);
		if (i > 0) {
			String[] roleIds = adminRoleID.split(",");
			URservice.changeUserRole(user.getUserId(), roleIds);
			result = new Result(ResultCode.SUCCESS);
		}else {
			result = new Result(ResultCode.FAIL);
		}
		return result; 
	}
	
	@RequestMapping("/listUserById.do/{userId}")
	public Result listUserById(@PathVariable("userId")String userId) {
		Result result = null;
		UserEntity user = userService.getUserById(userId);
		
		if (ObjectUtils.isEmpty(user)) {
			result = new Result(ResultCode.FAIL);
		}else {
			result = new Result(ResultCode.SUCCESS,user);
		}
		return result;
	}
	
	@RequestMapping("/listUserByUserNumberAndProjectCode.do")
	public Result listUserByUserNumberAndProjectCode(String userNumber) {
		UserEntity user = userService.getUserByuerNumber(userNumber);
		return new Result(ResultCode.SUCCESS, user);
	}
	
	@RequestMapping("/listAllUser.do")
	public Result listAllUserByItem(String type, String currPage, 
			String length, String projectCode) {
		if ("".equals(type) || type.length() == 0) {
			type = null;
		}
		pageDTO pageDTO = new pageDTO();
		
		List<UserEntity> data = userService.listAllUser(type, Integer.parseInt(currPage), Integer.parseInt(length));
		Integer countNum = userService.count(type);
		pageDTO.setData(data);
		pageDTO.setTotal(countNum);
		pageDTO.setTotalPage((countNum+Integer.parseInt(length)-1)/Integer.parseInt(length));
		pageDTO.setCurrPage(Integer.parseInt(currPage));
		Result result = new Result(ResultCode.SUCCESS,pageDTO);
		return result;
	}
	
	/**根據工號差用戶，查到有返回FALSE，沒有返回TRUE。如果沒有projectCode參數，則不用查，直接返回FALSE
	 * @param userNumber
	 * @param projectCode
	 * @return
	 */
	@RequestMapping("/getUserByUserNumber.do")
	public String getUserByUserNumber(String userNumber) {
		UserEntity user = userService.getUserByUserNumber(userNumber);
		if (ObjectUtils.isEmpty(user)) {
			return "true";
		}else {
			return "false";
		}
	}
	
	
	/**啟用停用狀態修改
	 * @param userId
	 * @param status
	 * @return
	 */
	@RequestMapping("/updateUserStatus.do")
	public String updateUserStatus(String userId, Integer status) {
		UserEntity userEntity = new UserEntity();
		userEntity.setUserId(userId);
		userEntity.setUserStatus(status);
		int i = userService.updateUser(userEntity);
		if (i > 0) {
			return "true";
		}else {
			return "false";
		}
	}
	
}
