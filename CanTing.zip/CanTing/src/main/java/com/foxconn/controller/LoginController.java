package com.foxconn.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.crypto.hash.Md5Hash;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.foxconn.entity.Result;
import com.foxconn.entity.ResultCode;
import com.foxconn.entity.UserEntity;
import com.foxconn.service.UserService;
import com.foxconn.util.JWTUtils;
import com.foxconn.util.RedisUtil;

import io.jsonwebtoken.Claims;

@CrossOrigin
@RestController
@RequestMapping("/login")
public class LoginController {

	@Autowired
	private UserService userService;
	@Autowired
	private JWTUtils jwtUtils;
	@Autowired
	private RedisUtil redisUtil;
	@RequestMapping(value="/login.do",method = {RequestMethod.POST})
	public Result login(String userNumber, String pwd) {
		System.out.println(userNumber+"--"+pwd);
		try {
			String md5HashPwd = new Md5Hash(pwd,userNumber,3).toString();
//			System.out.println(md5HashPwd);
			UsernamePasswordToken upToken = new UsernamePasswordToken(userNumber, md5HashPwd);
			Subject subject = SecurityUtils.getSubject();
			subject.login(upToken);
			UserEntity user = (UserEntity)subject.getPrincipal();
			String token = jwtUtils.createToken(user.getUserNumber(), user.getUserId(), null);
			
			return new Result(ResultCode.AUTHENTICATION_SUCCESS, token);
		} catch (Exception e) {
			// TODO: handle exception
			return new Result(ResultCode.UNAUTHENTICATED, null);
		}
		
	}
	
/**
 * 退出
 * @param code
 * @return
 */
	@RequestMapping("/loginOUt.do")
	public Result loginOut(HttpServletRequest req) {
//		Subject subject = SecurityUtils.getSubject();
		String token = req.getHeader("T-Token");
		Claims claims = jwtUtils.parseJwt(token);
		String userId = claims.getId();
		redisUtil.del(userId);
		return new Result(ResultCode.LOGIN_OUT);
	}
	
//	/autherror?code
	@RequestMapping("/autherror.do")
	public Result autherror(int code) {
		System.out.println(code);
		Result result = null;
		switch (code) {
		case 1://無權限
			result = new Result(ResultCode.UNAUTHORISE);
			break;

		case 2://未登錄
			result = new Result(ResultCode.TOKEN_NONE);
			break;
		default:
			break;
		}
		System.out.println(result.getMessage());
		return result;
	}
	

    /**
     * Unauthorized api result.
     *
     * @param message the message
     * @return the api result
     */
	@RequestMapping(path = "/unauthorized/{message}")
    public Result unauthorized(@PathVariable String message) {
        return new Result(ResultCode.FAIL);
    }
//	
}
