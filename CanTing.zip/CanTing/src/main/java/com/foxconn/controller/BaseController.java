package com.foxconn.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSON;
import com.foxconn.entity.Result;
import com.foxconn.entity.ResultCode;
import com.foxconn.entity.base.AuditPeople;
import com.foxconn.entity.base.ManagementStand;
import com.foxconn.entity.base.RestaurantDetail;
import com.foxconn.service.BaseDataService;
import com.foxconn.service.BaseService;
import com.foxconn.util.FileUtils;
import com.github.pagehelper.PageInfo;
@CrossOrigin
@RequestMapping("/base")
@RestController
public class BaseController {

	@Autowired
	private BaseDataService baseService;
	//-------------v上传基础资料v----------------
	@RequestMapping("/uploadAuditPeople.do")
	public Result uploadAuditPeople(@RequestParam("file_data") MultipartFile file, @RequestParam("isCover") String isCover) {
		Result result = null;
		try {
			 List<AuditPeople> list = FileUtils.readFile(file, AuditPeople.class);
			 Integer i = baseService.addData(list, AuditPeople.class);
			 if (i > 0) {
					result = new Result(ResultCode.SUCCESS);
				}else {
					result = new Result(ResultCode.FAIL);
				}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	@RequestMapping("/uploadManagementStand.do")
	public Result uploadManagementStand(@RequestParam("file_data") MultipartFile file, @RequestParam("isCover") String isCover) {
		Result result = null;
		try {
			List<ManagementStand> list = FileUtils.readFile(file, ManagementStand.class);
			Integer i = baseService.addData(list, ManagementStand.class);
			if (i > 0) {
				result = new Result(ResultCode.SUCCESS);
			}else {
				result = new Result(ResultCode.FAIL);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	@RequestMapping("/uploadRestaurantDetail.do")
	public Result uploadRestaurantDetail(@RequestParam("file_data") MultipartFile file, @RequestParam("isCover") String isCover) {
		Result result = null;
		try {
			List<RestaurantDetail> list = FileUtils.readFile(file, RestaurantDetail.class);
			Integer i = baseService.addData(list, RestaurantDetail.class);
			if (i > 0) {
				result = new Result(ResultCode.SUCCESS);
			}else {
				result = new Result(ResultCode.FAIL);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	//-------------^上传基础资料^----------------
//	*******************************************
	//-------------删除基础资料----------------
	@RequestMapping("/delAuditPeopleByNTH.do")
	public Result delAuditPeopleByNTH(String listId) {
		Result result = null;
		List<String> ids = JSON.parseArray(listId, String.class);
		Integer i = baseService.delByIds(ids, AuditPeople.class);
		if (i > 0) {
			result = new Result(ResultCode.SUCCESS);
		}else {
			result = new Result(ResultCode.FAIL);
		}
		return result;
	}
	
	@RequestMapping("/delManagementStandByNTH.do")
	public Result delManagementStandByNTH(String listId) {
		Result result = null;
		List<String> ids = JSON.parseArray(listId, String.class);
		Integer i = baseService.delByIds(ids, ManagementStand.class);
		if (i > 0) {
			result = new Result(ResultCode.SUCCESS);
		}else {
			result = new Result(ResultCode.FAIL);
		}
		return result;
	}
	
	@RequestMapping("/delRestaurantDetailByNTH.do")
	public Result delRestaurantDetailByNTH(String listId) {
		Result result = null;
		List<String> ids = JSON.parseArray(listId, String.class);
		Integer i = baseService.delByIds(ids, RestaurantDetail.class);
		if (i > 0) {
			result = new Result(ResultCode.SUCCESS);
		}else {
			result = new Result(ResultCode.FAIL);
		}
		return result;
	}
	//-------------^删除基础资料^----------------
//	*********************************************?
	//-------------修改基础资料----------------
	@RequestMapping("/updateAuditPeople.do")
	public Result updateAuditPeople(@RequestBody AuditPeople entity) {
		Result result = null;
		Integer i = baseService.updateBaseData(entity, AuditPeople.class);
		if (i > 0) {
			result = new Result(ResultCode.SUCCESS);
		}else {
			result = new Result(ResultCode.FAIL);
		}
		return result;
	}
	@RequestMapping("/updateManagementStand.do")
	public Result updateManagementStand(@RequestBody ManagementStand entity) {
		Result result = null;
		Integer i = baseService.updateBaseData(entity, ManagementStand.class);
		if (i > 0) {
			result = new Result(ResultCode.SUCCESS);
		}else {
			result = new Result(ResultCode.FAIL);
		}
		return result;
	}
	@RequestMapping("/updateRestaurantDetail.do")
	public Result updateRestaurantDetail(@RequestBody RestaurantDetail entity) {
		Result result = null;
		Integer i = baseService.updateBaseData(entity, RestaurantDetail.class);
		if (i > 0) {
			result = new Result(ResultCode.SUCCESS);
		}else {
			result = new Result(ResultCode.FAIL);
		}
		return result;
	}
	//-------------^修改基础资料^----------------
//	*********************************************
	//-------------查询基础资料----------------
	@RequestMapping("/listAuditPeople.do")
	public Result listAuditPeople(String item, Integer start, Integer length) {
		PageInfo<?> info = baseService.findBaseData(item, start, length, AuditPeople.class);
		PageInfo<AuditPeople> data = (PageInfo<AuditPeople>) info;
		return new Result(ResultCode.SUCCESS,data);
	}
	@RequestMapping("/listManagementStand.do")
	public Result listManagementStand(String item, Integer start, Integer length) {
		PageInfo<?> info = baseService.findBaseData(item, start, length, ManagementStand.class);
		PageInfo<ManagementStand> data = (PageInfo<ManagementStand>) info;
		return new Result(ResultCode.SUCCESS,data);
	}
	@RequestMapping("/listRestaurantDetail.do")
	public Result listRestaurantDetail(String item, Integer start, Integer length) {
		PageInfo<?> info = baseService.findBaseData(item, start, length, RestaurantDetail.class);
		PageInfo<RestaurantDetail> data = (PageInfo<RestaurantDetail>) info;
		return new Result(ResultCode.SUCCESS,data);
	}
	//-------------根据ID查询基础资料----------------
	@RequestMapping("/getAuditPeopleByNTH.do")
	public Result getAuditPeopleByNTH(String nth) {
		Object entity = baseService.getBaseData(nth, AuditPeople.class);
		AuditPeople data = (AuditPeople) entity;
		return new Result(ResultCode.SUCCESS,data);
	}
	@RequestMapping("/getManagementStandByNTH.do")
	public Result getManagementStandByNTH(String nth) {
		Object entity = baseService.getBaseData(nth, ManagementStand.class);
		ManagementStand data = (ManagementStand) entity;
		return new Result(ResultCode.SUCCESS,data);
	}
	@RequestMapping("/getRestaurantDetailByNTH.do")
	public Result getRestaurantDetailByNTH(String nth) {
		Object entity = baseService.getBaseData(nth, RestaurantDetail.class);
		RestaurantDetail data = (RestaurantDetail) entity;
		return new Result(ResultCode.SUCCESS,data);
	}
	//-------------^查询基础资料^----------------
//	@RequestMapping("/findall.do")
//	public String findall() {
//		List<AuditPeople> list = baseService.findall();
//		return JSON.toJSONString(list);
//	}
	//-------------页面基础资料填充查询---------------
	@RequestMapping("/listAuditPeopleByLeader.do")
	public Result listAuditPeopleByLeader() {
		Map<String, String> queryMap = new HashMap<String, String>();
		queryMap.put("peopleType","組長");
		List<?> data = baseService.listDataByCondition(queryMap, AuditPeople.class);
		return new Result(ResultCode.SUCCESS,data);
	}
	@RequestMapping("/listAuditPeopleByMembers.do")
	public Result listAuditPeopleByMembers() {
		Map<String, String> queryMap = new HashMap<String, String>();
		queryMap.put("peopleType","組員");
		List<?> data = baseService.listDataByCondition(queryMap, AuditPeople.class);
		return new Result(ResultCode.SUCCESS,data);
	}
	//-------------页面基础资料填充查询---------------
}
