package com.foxconn.controller;

import java.util.List;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.foxconn.entity.DepartEntity;
import com.foxconn.entity.Result;
import com.foxconn.entity.ResultCode;
import com.foxconn.service.DepartService;
import com.github.pagehelper.PageInfo;

@RestController
@RequestMapping("/depart")
@CrossOrigin
public class DepartController {

	@Autowired
	private DepartService departService;
	
	/**查詢所有部門
	 * @param map
	 * @return
	 */
	@RequestMapping("/listDepart.do")
	public Result listDepart(Integer start, Integer length) {
//		System.out.println(userNumber+"--"+projectCode);
		PageInfo<DepartEntity> departList = null;
		departList = departService.listAllDepart(start, length);
		Result result = new Result(ResultCode.SUCCESS,departList);
		return result;
	}
	
	/**根據部門ID查詢單個部門信息
	 * @param map
	 * @param path 來源 update  表示修改
	 * @param departId 部門ID
	 * @return
	 */
	@RequestMapping("/getDepartById.do")
	public Result getDepartById(String departId) {
		DepartEntity depart = departService.getDepartById(departId);
		Result result = null;
		if (ObjectUtils.isNotEmpty(depart)) {
			result = new Result(ResultCode.SUCCESS,depart);
		}else {
			result = new Result(ResultCode.FAIL);
		}
		return result;
	}
	
	/**修改部門信息
	 * @param depart
	 * @param map
	 * @return 返回i 
	 */
	@RequestMapping("/updateDepart.do")
	@ResponseBody
	public Result updateDepart(@RequestBody DepartEntity depart) {
//		System.out.println("update>"+depart);
		Result result = null;
		int i = departService.updateDepart(depart);
		if (i > 0) {
			result = new Result(ResultCode.SUCCESS);
		}else {
			result = new Result(ResultCode.FAIL);
		}
		return result;
	}
	
	/**新增部門信息
	 * @param depart
	 * @param map
	 * @return 返回i 
	 */
	@RequestMapping("/addDepart.do")
	@ResponseBody
	public Result addDepart(DepartEntity depart) {
//		System.out.println(depart);
		Result result = null;
		int i = departService.insertDepart(depart);
		if (i > 0) {
			result = new Result(ResultCode.SUCCESS);
		}else {
			result = new Result(ResultCode.FAIL);
		}
		return result;
	}
	
	@RequestMapping("/delDepart.do")
	@ResponseBody
	public Result delDepart(String departIds) {
//		System.out.println("del>>"+departIds);
		Result result = null;
		int i = 0;
		List<String> departids = JSON.parseArray(departIds, String.class);
		for (String departId : departids) {
			i += departService.delDepartById(departId);
		}
		if (i > 0) {
			result = new Result(ResultCode.SUCCESS);
		}else {
			result = new Result(ResultCode.FAIL);
		}
		return result;
	}
}
