package com.foxconn.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.RoleEntity;
import com.foxconn.entity.UREntity;
import com.foxconn.util.BaseMapper;

public interface UREntityMapper extends BaseMapper<UREntity>{

	List<RoleEntity> findRoleByUserid(@Param("userId") String userId);

}