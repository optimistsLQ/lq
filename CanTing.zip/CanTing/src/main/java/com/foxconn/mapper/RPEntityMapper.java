package com.foxconn.mapper;

import com.foxconn.entity.RPEntity;
import com.foxconn.util.BaseMapper;

public interface RPEntityMapper extends BaseMapper<RPEntity>{
    
}