package com.foxconn.mapper;

import com.foxconn.entity.CheckProblem;
import com.foxconn.util.BaseMapper;

public interface CheckProblemMapper extends BaseMapper<CheckProblem>{
}