package com.foxconn.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.RoleEntity;
import com.foxconn.util.BaseMapper;

public interface RoleEntityMapper extends BaseMapper<RoleEntity>{

	RoleEntity getRoleById(@Param("roleId") String roleId);

	List<RoleEntity> listRoleAll(@Param("start")Integer start,@Param("length")Integer length);

	int count();

	String getRoleId(@Param("roleName")String roleName, @Param("description")String description);
    
}