package com.foxconn.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.CheckTotal;
import com.foxconn.util.BaseMapper;

public interface CheckTotalMapper extends BaseMapper<CheckTotal>{

	List<CheckTotal> findByItem(@Param("startTime")String startTime, 
								@Param("endTime")String endTime, @Param("mealSeller")String mealSeller, 
								@Param("restaurantLocation")String restaurantLocation,@Param("overend")String overend);

	String insertGetId(@Param("checkTotal") CheckTotal checkTotal);
   
}