package com.foxconn.mapper.base;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.base.AuditPeople;
import com.foxconn.util.BaseMapper;

public interface AuditPeopleMapper extends BaseMapper<AuditPeople>{

	int delByIds(@Param("ids") List<String> ids);

	Integer insertList(@Param("coverList") List<AuditPeople> coverList);

    List<AuditPeople> findall();

	List<AuditPeople> selectByItem(@Param("item") String item);
}