package com.foxconn.mapper;

import com.foxconn.entity.DepartEntity;
import com.foxconn.util.BaseMapper;

public interface DepartEntityMapper extends BaseMapper<DepartEntity>{
   
}