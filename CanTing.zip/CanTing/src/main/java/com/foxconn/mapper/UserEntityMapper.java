package com.foxconn.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import com.foxconn.entity.UserEntity;
import com.foxconn.util.BaseMapper;

public interface UserEntityMapper extends BaseMapper<UserEntity>{

	List<UserEntity> listAllUser(@Param("item")String item, @Param("start")Integer start, @Param("length") Integer length);
	Integer count(@Param("item")String item);
	UserEntity selectByUserId(@Param("userId")String userId);
//	List<RoleList> getRoleListByUserId(@Param("userId") String userId);
	UserEntity getUserByuerNumber(@Param("userNumber")String userNumber);
}