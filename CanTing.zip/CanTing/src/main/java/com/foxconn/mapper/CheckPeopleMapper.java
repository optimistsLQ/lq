package com.foxconn.mapper;

import com.foxconn.entity.CheckPeople;
import com.foxconn.util.BaseMapper;

public interface CheckPeopleMapper extends BaseMapper<CheckPeople>{
}