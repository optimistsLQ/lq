package com.foxconn.mapper.base;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.base.ManagementStand;
import com.foxconn.util.BaseMapper;

public interface ManagementStandMapper extends BaseMapper<ManagementStand>{

	int delByIds(@Param("ids") List<String> ids);

	Integer insertList(@Param("coverList") List<ManagementStand> coverList);

	List<ManagementStand> selectByItem(@Param("item") String item);
	
}