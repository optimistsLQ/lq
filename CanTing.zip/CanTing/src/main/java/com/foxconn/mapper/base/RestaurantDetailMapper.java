package com.foxconn.mapper.base;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.base.RestaurantDetail;
import com.foxconn.util.BaseMapper;

public interface RestaurantDetailMapper extends BaseMapper<RestaurantDetail>{

	int delByIds(@Param("ids") List<String> ids);

	Integer insertList(@Param("coverList") List<RestaurantDetail> coverList);

	List<RestaurantDetail> selectByItem(@Param("item") String item);
   
}