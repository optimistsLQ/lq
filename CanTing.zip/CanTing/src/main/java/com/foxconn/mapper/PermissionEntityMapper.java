package com.foxconn.mapper;

import com.foxconn.entity.PermissionEntity;
import com.foxconn.util.BaseMapper;

public interface PermissionEntityMapper extends BaseMapper<PermissionEntity>{
    
}