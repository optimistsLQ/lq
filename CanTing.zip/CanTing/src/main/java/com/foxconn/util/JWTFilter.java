package com.foxconn.util;


import java.io.IOException;
import java.net.URLEncoder;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.shiro.authz.UnauthorizedException;
import org.apache.shiro.web.filter.authc.BasicHttpAuthenticationFilter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.alibaba.fastjson.JSONObject;
import com.foxconn.entity.UserEntity;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;



public class JWTFilter extends BasicHttpAuthenticationFilter{

	 private Logger logger = Logger.getLogger(this.getClass());
	 /**所有的请求都会先经过Filter，所以我们继承官方的BasicHttpAuthenticationFilter，并且重写鉴权的方法。代码的执行流程preHandle->isAccessAllowed->isLoginAttempt->executeLogin
	     * 如果带有 token，则对 token 进行检查，否则直接通过
	     */
	 @Value("${jwt.config.ttl}")
		private long ttl;
	    @Override
	    protected boolean isAccessAllowed(ServletRequest request, ServletResponse response, Object mappedValue) throws UnauthorizedException {
	    	HttpServletRequest req = (HttpServletRequest) request;
	    	HttpServletResponse resp = (HttpServletResponse) response;
	    	JWTUtils jwtUtils = WebApplicationContextUtils.getRequiredWebApplicationContext(request.getServletContext()).getBean(com.foxconn.util.JWTUtils.class);
	    	RedisUtil redisUtil = WebApplicationContextUtils.getRequiredWebApplicationContext(request.getServletContext()).getBean(com.foxconn.util.RedisUtil.class);
	    	//判断请求的请求头是否带上 "token"
	    	String token = req.getHeader("T-Token");
	    	
	    	if (StringUtils.isEmpty(token)) {
	    		JSONObject json = new JSONObject();
	    		json.put("timeout","403");
	    		json.put("msg","未登錄！");
	    		jwtUtils.responseWrite(resp, json);
//	    		return false;
	    		return true;
	    		
	    	}else {
	    		Claims claims = null;
	    		try {
	    			claims = jwtUtils.parseJwt(token);
				} catch (ExpiredJwtException e) {
					e.printStackTrace();
				
					JSONObject json = new JSONObject();
    	    		json.put("state","405");
    	    		json.put("msg","已過期！");
    	    		jwtUtils.responseWrite(resp, json);
    	    		return false;
				}
	    		if (null != claims) {
	    			String userId = claims.getId();
	    			UserEntity user = (UserEntity) redisUtil.get(userId);
	    			if (null == user) {
	    				JSONObject json = new JSONObject();
	    	    		json.put("state","405");
	    	    		json.put("msg","已過期！");
	    	    		jwtUtils.responseWrite(resp, json);
	    	    		return false;
	    			}
	    			redisUtil.set(user.getUserId(), user, ttl);
	    			logger.info("訪問用戶>："+user.getUserNumber()+" "+user.getNickname());
	    			return true;
	    		}else {//claims為空，token錯誤
	    			JSONObject json = new JSONObject();
    	    		json.put("state","406");
    	    		json.put("msg","token解析錯誤！");
    	    		jwtUtils.responseWrite(resp, json);
	    			return false;
	    		}
	    	}
	       
	    }
	   

	    /**
	     * 对跨域提供支持
	     */
	    @Override
	    protected boolean preHandle(ServletRequest request, ServletResponse response) throws Exception {
	        HttpServletRequest httpServletRequest = (HttpServletRequest) request;
	        HttpServletResponse httpServletResponse = (HttpServletResponse) response;
	        httpServletResponse.setHeader("Access-control-Allow-Origin", httpServletRequest.getHeader("Origin"));
	        httpServletResponse.setHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS,PUT,DELETE");
	        httpServletResponse.setHeader("Access-Control-Allow-Headers", httpServletRequest.getHeader("Access-Control-Request-Headers"));
	       
	        
	        logger.info("JwtFilter請求路徑>："+httpServletRequest.getRequestURI());
	        // 跨域时会首先发送一个option请求，这里我们给option请求直接返回正常状态
	        if (httpServletRequest.getMethod().equals(RequestMethod.OPTIONS.name())) {
	            httpServletResponse.setStatus(HttpStatus.OK.value());
	            return false;
	        }
	        return super.preHandle(request, response);
	    }

	    /**
	     * 将非法请求跳转到 /unauthorized/**
	     */
	    private void responseError(ServletResponse response, String message) {
	        try {
	            HttpServletResponse httpServletResponse = (HttpServletResponse) response;
	            //设置编码，否则中文字符在重定向时会变为空字符串
	            message = URLEncoder.encode(message, "UTF-8");
	            httpServletResponse.sendRedirect("/unauthorized/" + message);
	        } catch (IOException e) {
//	            logger.error(e.getMessage());
	            System.out.println(e.getMessage());
	        }
	    }
}
