package com.foxconn.util;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.CellValue;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.util.ResourceUtils;
import org.springframework.web.multipart.MultipartFile;

import com.github.nobodxbodon.zhconverter.简繁转换类;
import com.github.nobodxbodon.zhconverter.简繁转换类.目标;

public class FileUtils {

	/**读取Excel
	 * @param <T>
	 * @param file
	 * @param cla
	 * @return
	 * @throws Exception
	 */
	public static <T> List<T> readFile(MultipartFile file, Class<T> cla) throws Exception {
		String suffix = getFileSuffix(file);//获取文件后缀
		List<T> resultList = new ArrayList<T>();
		if (StringUtils.isNotEmpty(suffix) && suffix.equalsIgnoreCase("xlsx")) {
			List<Map<String,Object>> list = readExcel(file);
			for (Map<String, Object> map : list) {
				T bean = FileUtils.mapToBean(cla, map);
				resultList.add(bean);
			}
		}else {
			throw new Exception("上传文件后缀必须是xlsx");
		}
		return resultList;
	}
	
	/**获取文件后缀
	 * @param file
	 * @return
	 */
	public static String getFileSuffix(MultipartFile file) {
		String filename = file.getOriginalFilename();
		String suffix = filename.substring(filename.lastIndexOf(".") + 1).toLowerCase();
		return suffix;
	}
	

	/**读取Excel 被上面的方法调用
	 * @param file
	 * @return
	 */
	public static List<Map<String, Object>> readExcel(MultipartFile file){
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		List<Map<String, Object>> list = new ArrayList<Map<String,Object>>();
		XSSFWorkbook workbook = null;
		InputStream inputStream = null;
		try {
			inputStream = file.getInputStream();
			workbook = new XSSFWorkbook(inputStream);
			
			XSSFSheet sheet = workbook.getSheetAt(0);
			FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
			
			int maxRowNum = sheet.getPhysicalNumberOfRows();
			int maxColNum = sheet.getRow(0).getPhysicalNumberOfCells();
			XSSFRow row0 = sheet.getRow(0);//获取Excel第一行（属性）
			for(int r = 1;r<maxRowNum;r++) {
				Map<String, Object> objMap = new LinkedHashMap<String, Object>();
				for(int c = 0;c<maxColNum;c++) {
					XSSFRow row = sheet.getRow(r);//得到每行
					XSSFCell cell = row.getCell(c);//得到每个单元格
					String title = row0.getCell(c).getStringCellValue();
					//userName(姓名)
					String key = title.substring(0, title.indexOf("("));
					if (null == cell) {
						objMap.put(key, null);
					}else {
						CellType cellTypeEnum = cell.getCellTypeEnum();
						switch (cellTypeEnum) {
						case STRING:
							objMap.put(key, simplifiedTo(cell.getStringCellValue().trim()));
							break;
						case NUMERIC:
							if(HSSFDateUtil.isCellDateFormatted(cell)){//判断数字是否为日期
								Date date = HSSFDateUtil.getJavaDate(cell.getNumericCellValue());
								objMap.put(key, format.format(date));
							}else {
								objMap.put(key, cell.getNumericCellValue());
							}
							
							break;
						case FORMULA:
							CellValue evaluate = evaluator.evaluate(cell);
							CellType cellTypeEnum2 = evaluate.getCellTypeEnum();
							switch (cellTypeEnum2) {
							case STRING:
								objMap.put(key, simplifiedTo(cell.getStringCellValue().trim()));
								break;
							case NUMERIC:
								if(HSSFDateUtil.isCellDateFormatted(cell)){//判断数字是否为日期
									Date date = HSSFDateUtil.getJavaDate(cell.getNumericCellValue());
									objMap.put(key, format.format(date));
								}else {
									objMap.put(key, cell.getNumericCellValue());
								}
								break;
							default:
								objMap.put(key, "*");
								break;
							}
							
							break;
							
						default:
							objMap.put(key, "*");
							break;
						}
					}
				}
			list.add(objMap);
//			System.out.println(">>>"+objMap);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				workbook.close();
				if (null != inputStream) {
					inputStream.close();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
	}
	
	/**map转成Javabean
	 * @param <T>
	 * @param cla
	 * @param map
	 * @return
	 * @throws IntrospectionException
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 */
	public static <T> T mapToBean(Class<T> cla, Map<String, Object> map) throws IntrospectionException,
	InstantiationException,
	IllegalAccessException {
		// 获取类属性
		BeanInfo beanInfo = Introspector.getBeanInfo(cla);
		// 创建 JavaBean 对象
		T javaBean = cla.newInstance();
		// 给 JavaBean 对象的属性赋值
		PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();
		for (PropertyDescriptor property : propertyDescriptors) {
			String propertyName = property.getName();
			if (map.containsKey(propertyName)) {
				Object value = map.get(propertyName);
				try {
					if(property.getPropertyType().getSimpleName().equals("String") && value instanceof Double) {
						property.getWriteMethod().invoke(javaBean, Double.toString((Double)value));
					} else {
						property.getWriteMethod().invoke(javaBean, value);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return javaBean;
	}
	
	/**上传文件
	 * @param file
	 * @return
	 * @throws Exception 
	 */
	public static String uploadFile(MultipartFile file) throws Exception {
		File path = new File(ResourceUtils.getURL("classpath:").getPath());
		if (!path.exists()) {
			path = new File("");
		}
		File dirPath = new File(path.getAbsolutePath(),"static"+File.separator+"filedir"+File.separator);
		if (!dirPath.exists()) {//如果static/filedir文件夹不存在，就创建
			dirPath.mkdirs();
		}
		String realpath = dirPath.getAbsolutePath()+File.separator+getUUID()+"~~~"+file.getOriginalFilename();
		File realfile = new File(realpath);
		file.transferTo(realfile);
	return realpath;
	}
	
	public static void downFile(HttpServletRequest req, HttpServletResponse resp, String url) {
		File file = new File(url);
		FileInputStream inputStream = null;
		OutputStream outStream = null;
		String fileName = file.getName().split("~~~")[1];
		try {
			if (req.getHeader("User-Agent").toLowerCase().indexOf("firefox") > 0) {
				fileName = new String(fileName.getBytes("UTF-8"),"ISO8859-1");
			} else if (req.getHeader("User-Agent").toUpperCase().indexOf("MSIE") > 0  || req.getHeader("User-Agent").toUpperCase().indexOf("EDGE") > 0) {
				fileName = URLEncoder.encode(fileName, "UTF-8");
			} else if (req.getHeader("User-Agent").toUpperCase().indexOf("CHROME") > 0) {
				fileName = new String(fileName.getBytes("UTF-8"), "ISO8859-1");
			}
			inputStream = new FileInputStream(file);//读进内存
			resp.setCharacterEncoding("utf-8");
			resp.setContentType("application/msword");
			resp.setHeader("Content-Disposition", "attachment;Filename="+fileName);
			outStream = resp.getOutputStream();//从内存写出去
			byte [] bytes = new byte [2048];
			int len = 0;
			while((len = inputStream.read(bytes)) > 0) {
				outStream.write(bytes, 0, len);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			try {
			        if (null != outStream) {
					outStream.close();
			        }
					if (null != inputStream) {
						inputStream.close();
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	/**
	 * 生成uuid
	 **/
	public static String getUUID() {
		return UUID.randomUUID().toString().replaceAll("-", "").toUpperCase();
	}
	
	public static String simplifiedTo(String str) {
		return 简繁转换类.转换(str, 目标.繁体);
	}
}
