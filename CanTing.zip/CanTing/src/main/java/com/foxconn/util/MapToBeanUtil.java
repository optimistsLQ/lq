package com.foxconn.util;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.util.Map;

public class MapToBeanUtil {

	public static <T> T mapToBean(Class<T> cla, Map<String, Object> map) throws IntrospectionException,
	InstantiationException,
	IllegalAccessException {
		System.out.println(map);
		// 获取类属性
		BeanInfo beanInfo = Introspector.getBeanInfo(cla);
		// 创建 JavaBean 对象
		T javaBean = cla.newInstance();
		// 给 JavaBean 对象的属性赋值
		PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();
		for (PropertyDescriptor property : propertyDescriptors) {
			String propertyName = property.getName();
			System.out.println("key>"+propertyName);
			if (map.containsKey(propertyName)) {
				Object value = map.get(propertyName);
				try {
					property.getWriteMethod().invoke(javaBean, value);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return javaBean;
	}
//	public static void main(String[] args) {
//		HashMap<String, Object> hashMap = new HashMap<String, Object>();
//		hashMap.put("userNumber","zhongdong");
//		hashMap.put("pwd","123");
//		hashMap.put("createtime",new Date(0));
//		hashMap.put("userStatus",123);
//		try {
//			UserEntity u = MapToBeanUtil.mapToBean(UserEntity.class, hashMap);
//			System.out.println(u);
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//	}
}
