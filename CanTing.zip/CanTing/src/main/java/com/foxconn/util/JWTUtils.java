package com.foxconn.util;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONObject;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.impl.TextCodec;
import lombok.Getter;
import lombok.Setter;

@Component(value = "jwtUtil")
public class JWTUtils {

//	@Value("${jwt.config.ttl}")
//	private long ttl;
	@Value("${jwt.config.key}")
	private  String key;
	
	public String createToken(String username, String userId, Map<String, Object> map) {
//		System.out.println(key+"---"+ttl);
		//設置失效時間
//		long exp = System.currentTimeMillis() + ttl;
		//創建jwtBuilder
		JwtBuilder builder = Jwts.builder().setId(userId).setSubject(username).setIssuedAt(new Date())
		.signWith(SignatureAlgorithm.HS256, TextCodec.BASE64.encode(key));
		if (null != map) {
			for(Map.Entry<String, Object> entry:map.entrySet()) {
				builder.claim(entry.getKey(), entry.getValue());
			}
		}
		//根據map設置claims
		//創建token
		String token = builder.compact();
		return token;
	
	}
	
	/** 校验 token 是否正确
	 * @param token
	 * @param userName
	 * @return
	 */
	public Claims parseJwt (String token) {
		
		Claims claims = Jwts.parser().setSigningKey(TextCodec.BASE64.encode(key)).parseClaimsJws(token).getBody();
		return claims;
	}
	
	/**
	 * response 輸出JSON
	 **/
	public boolean responseWrite(HttpServletResponse response,Object jsonObj) {
		try {
			response.setStatus(200);
			response.setContentType("application/json;charset=utf-8");
			response.getOutputStream().write(JSONObject.toJSONString(jsonObj).getBytes("UTF-8"));
			return true;
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}
   
}
