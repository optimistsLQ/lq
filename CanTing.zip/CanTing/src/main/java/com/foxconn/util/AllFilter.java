package com.foxconn.util;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.apache.shiro.web.filter.authc.AnonymousFilter;
import org.springframework.web.bind.annotation.RequestMethod;

public class AllFilter extends AnonymousFilter{

	private Logger logger = Logger.getLogger(this.getClass());
	
    @Override
    protected boolean onPreHandle(ServletRequest request, ServletResponse response, Object mappedValue) {
    	HttpServletRequest httpServletRequest = (HttpServletRequest) request;
    	if (!(httpServletRequest.getMethod().equals(RequestMethod.OPTIONS.name()))) {
    		logger.info("AllFilter請求路徑>："+httpServletRequest.getRequestURI()+httpServletRequest.getMethod());
        }
        // Always return true since we allow access to anyone
        return true;
    }
}
