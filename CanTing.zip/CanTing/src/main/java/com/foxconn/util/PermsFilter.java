package com.foxconn.util;

import java.io.IOException;

import javax.annotation.Resource;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.shiro.web.filter.authz.PermissionsAuthorizationFilter;

import com.foxconn.entity.Result;
import com.foxconn.entity.ResultCode;

public class PermsFilter extends PermissionsAuthorizationFilter{
	
	@Resource
	private JWTUtils jwtUtils;

	@Override
	protected boolean onAccessDenied(ServletRequest request, ServletResponse response) throws IOException {
//		// TODO Auto-generated method stub
//            // If subject is known but not authorized, redirect to the unauthorized URL if there is one
//            // If no unauthorized URL is specified, just return an unauthorized HTTP status code
		HttpServletRequest httpServletRequest = (HttpServletRequest) request;
        HttpServletResponse httpServletResponse = (HttpServletResponse) response;
        httpServletResponse.setHeader("Access-control-Allow-Origin", httpServletRequest.getHeader("Origin"));
        httpServletResponse.setHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS,PUT,DELETE");
        httpServletResponse.setHeader("Access-Control-Allow-Headers", httpServletRequest.getHeader("Access-Control-Request-Headers"));
	       
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        if(httpRequest.getMethod().toUpperCase().equals("OPTIONS")) {
        	return true;
        }
		jwtUtils.responseWrite((HttpServletResponse)response, new Result(ResultCode.UNAUTHORISE));
        return false;
	}

	
}
