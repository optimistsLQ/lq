package com.foxconn.util;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import tk.mybatis.mapper.common.Mapper;

@Component
public interface BaseMapper<T> extends Mapper<T> {
	
//	/**
//	 * 監考老師接待來訪看見愛上了對方
//	 **/
//	@Results(id="userMap", value={
//			@Result(column="id", property="id", id=true),
//		    @Result(column="user_name", property="userName"),
//		    @Result(column="user_password ", property="userPassword"),
//		    @Result(column="user_email", property="userEmail"),
//		    @Result(column="user_info", property="userInfo"),
//		    @Result(column="head_img", property="headImg", jdbcType=JdbcType.BLOB),
//		    @Result(column="create_time", property="createTime", jdbcType=JdbcType.TIMESTAMP)
//	})
//	
//	/**
//	 * 查詢更加了解了解了顧客家裡卡士大夫
//	 **/
//	@Select({"select id,user_name,user_password,user_email,user_info,head_img,create_time from sys_user where id = #{id}"})
//	@ResultMap("userMap")
//	void abc();
//	
//	@ResultMap("userMap")
//	void abcd();
}