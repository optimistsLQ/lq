package com.foxconn.entity;


import java.sql.Date;
import java.util.List;

import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "t_user")
public class UserEntity {
	@Id
    private String userId;

    private String userNumber;

    private String nickname;

    private String pwd;

    private String phone;

    private String email;

    private Integer userStatus;

    private String departId;

    private String proxyPeople;

    private String starttime;

    private String endtime;

    private Date createtime;

    private String lastLogintime;

    @Transient
    private List<RoleEntity> roleList;
    @Transient
    private DepartEntity depart;
}