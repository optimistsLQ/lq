package com.foxconn.entity;

import java.util.List;

import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "T_depart")
public class DepartEntity {
	@Id
    private String departId;

    private String departName;

    private String departCode;

    private String remarks;

    @Transient
    private List<UserEntity> userList; 

}