package com.foxconn.entity;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "T_CHECKPROBLEM")
public class CheckProblem {
	@Id
    private String checkProblemId;

    private String checkMtotalId;

    private String typeBigName;

    private String thirdCode;

    private String typeSmallName;

    private String standContent;

    private String beforeImg;

    private String afterImg;

    private String problemDetail;

    private BigDecimal beforeScore;

    private BigDecimal afterScore;

    private Object beforeMoney;

    private Object afterMoney;

    private Date writetime;

    private String grade;

    private String revise;

    private String examine;

    private String updateCause;

    private String column33;

}