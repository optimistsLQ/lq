package com.foxconn.entity;

import lombok.Data;

@Data
public class pageDTO {

	private Object data;
	private Integer totalPage;
	private Integer currPage;
	private Integer total;
}
