package com.foxconn.entity;

import java.util.Date;

import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "t_permission")
public class PermissionEntity {
	@Id
    private String perId;

    private String perName;

    private String perUrl;

    private String perDescription;

    private Date createtime;

}