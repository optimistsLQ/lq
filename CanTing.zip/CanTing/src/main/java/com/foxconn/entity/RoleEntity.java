package com.foxconn.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "t_role")
public class RoleEntity {
	@Id
    private String roleId;

    private String roleName;

    private Date createtime;

    private String description;

    private List<UserEntity> userList;
    private List<PermissionEntity> permissionList;
}