package com.foxconn.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Result {

	private boolean success;
	private String message;
	private Integer code;
	private Object data;
	public Result(ResultCode resultCode, Object data) {
		this.success = resultCode.getSuccess();
		this.message = resultCode.getMsg();
		this.code = resultCode.getCode();
		this.data = data;
	}
	
	public Result(ResultCode resultCode) {
		this.success = resultCode.getSuccess();
		this.message = resultCode.getMsg();
		this.code = resultCode.getCode();
	}
}
