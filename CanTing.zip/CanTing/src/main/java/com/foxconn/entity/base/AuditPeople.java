package com.foxconn.entity.base;

import java.util.Date;

import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "T_AUDIT_PEOPLE")
public class AuditPeople {
	@Id
    private String nth;

    private String jobCard;

    private String uname;

    private String comfort;

    private String stationNature;
    
    private String peopleType;

    private Date writeTime;

}