package com.foxconn.entity;


public enum ResultCode {

	SUCCESS(true,1000,"操作成功"),
	FAIL(false,1001,"操作失敗"),
	UNAUTHENTICATED(false,1002,"身份认证失敗"),
	AUTHENTICATION_SUCCESS(true,1003,"身份认证成功"),
	UNAUTHORISE(false,1005,"權限不足"),
	SERVER_ERROR(false,9999,"抱歉！系統繁忙，請稍後再試！"),
	TOKEN_NONE(false,9997,"你還未登錄，請先登錄！"),
	LOGIN_OUT(true,0000,"退出成功！"),
	TOKEN_OVERDUE(false,9998,"Token過期，請重新登錄！");
	
	private Boolean success;
	private int code;
	private String msg;
	private ResultCode(Boolean success, int code, String msg) {
		this.success = success;
		this.code = code;
		this.msg = msg;
	}
	public Boolean getSuccess() {
		return success;
	}
	public void setSuccess(Boolean success) {
		this.success = success;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	
}
