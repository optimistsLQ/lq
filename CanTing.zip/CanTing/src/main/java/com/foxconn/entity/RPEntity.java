package com.foxconn.entity;

import java.util.Date;

import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "t_role_permission")
public class RPEntity {
	@Id
    private String rpId;

    private String roleId;

    private String perId;

    private Date createtime;

}