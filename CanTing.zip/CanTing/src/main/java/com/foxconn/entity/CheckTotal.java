package com.foxconn.entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "T_CHECKTOTAL")
public class CheckTotal {
	@Id
    private String checktotalId;

    private String mealSeller;

    private String restaurantLocation;

    private String leader;

    private String checktime;

    private String mealSure;

    private String rearServiceSure;

    private String hastrouble;

    private String overend;

    private String proof;

    private String jiheStatus;

    private String restaurantId;

    private String checkNaturn;

    private String checkPoint;

}