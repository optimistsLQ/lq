package com.foxconn.entity;

import java.util.Date;

import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "t_user_role")
public class UREntity {
	@Id
    private String urId;

    private String userId;

    private String roleId;

    private Date createtime;

   
}