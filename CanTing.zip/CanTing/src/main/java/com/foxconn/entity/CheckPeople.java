package com.foxconn.entity;

import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "T_CHECKPEOPLE")
public class CheckPeople {
	@Id
    private String checkpeopleId;

    private String checkTotalId;

    private String checkManname;

    private String checkManCard;

    private String manType;

    private String remark1;
   
}