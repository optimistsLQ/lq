package com.foxconn.entity.base;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "T_MANAGEMENSTANDARD")
public class ManagementStand {
	@Id
    private String nth;

    private String oneCode;

    private String typeBigName;

    private String twoCode;

    private String typeSmallName;

    private String threeCode;

    private String content;

    private String gradation;

    private Double kouScore;

    private String warning;

    private String firstHandle;

    private String secondHandle;

    private String thirdHandle;

    private Date writeTime;

}