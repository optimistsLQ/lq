package com.foxconn.entity.base;

import java.util.Date;

import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "T_RESTAURANT_DETAIL")
public class RestaurantDetail {
	@Id
    private String nth;

    private String restaurantLocations;

    private String restaurantName;

    private String restaurantStatus;

    private String restaurantType;

    private String kitchenType;

    private String contractStart;

    private String contractEnd;

    private String restaurantLegal;

    private String restaurantLegalName;
//可就餐人数
    private Double volume;

    private String remarks;

    private Date writeTime;
   
}