package com.foxconn.shiro;


import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.filter.mgt.DefaultFilterChainManager;
import org.apache.shiro.web.filter.mgt.PathMatchingFilterChainResolver;
import org.apache.shiro.web.servlet.AbstractShiroFilter;
import org.slf4j.LoggerFactory;
import com.foxconn.service.impl.PermissionServiceImpl;

public class MyShiroFilterFactory extends ShiroFilterFactoryBean{

	private static ShiroFilterFactoryBean shiroFilterFactoryBean = null;  

	 private static Logger logger = (Logger) LoggerFactory  
	            .getLogger(MyShiroFilterFactory.class);  
	 /** 
     * 初始化时加载filterChainDefinitions 
     */  
    public MyShiroFilterFactory() {  
        super();  
        // 从数据库中读入URL权限列表  
        setFilterChainDefinitions(new PermissionServiceImpl().getAllPer());  
        shiroFilterFactoryBean=this;  
    }  
  
    /** 
     * 重新加载数据库权限 
     *  
     * @author 20005 
     * @createDate 2014-7-28 下午05:28:04 
     */  
    public static void reloadChainDefinitions() {  
        AbstractShiroFilter shiroFilter = null;  
        try {  
            shiroFilter = (AbstractShiroFilter) shiroFilterFactoryBean  
                    .getObject();  
        } catch (Exception e) {  
        	logger.info("getShiroFilter from shiroFilterFactoryBean error!", e);  
        }  
  
        PathMatchingFilterChainResolver filterChainResolver = (PathMatchingFilterChainResolver) shiroFilter  
                .getFilterChainResolver();  
        DefaultFilterChainManager manager = (DefaultFilterChainManager) filterChainResolver  
                .getFilterChainManager();  
  
        // 清空老的权限控制  
        manager.getFilterChains().clear();  
  
        shiroFilterFactoryBean.getFilterChainDefinitionMap().clear();  
        shiroFilterFactoryBean  
                .setFilterChainDefinitions(new PermissionServiceImpl().getAllPer());  
        // 重新构建生成  
        Map<String, String> chains = shiroFilterFactoryBean  
                .getFilterChainDefinitionMap();  
        for (Map.Entry<String, String> entry : chains.entrySet()) {  
            String url = entry.getKey();  
            String chainDefinition = entry.getValue().trim().replace(" ", "");  
            manager.createChain(url, chainDefinition);  
        }  
    } 
}
