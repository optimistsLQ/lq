package com.foxconn.shiro;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.servlet.Filter;
import org.apache.shiro.mgt.DefaultSessionStorageEvaluator;
import org.apache.shiro.mgt.DefaultSubjectDAO;
import org.apache.shiro.mgt.SecurityManager;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.foxconn.entity.PermissionEntity;
import com.foxconn.service.PermissionService;
import com.foxconn.util.AllFilter;
import com.foxconn.util.JWTFilter;
import com.foxconn.util.PermsFilter;
import com.github.pagehelper.PageInfo;

@Configuration
public class ShiroConfig {
	@Autowired
	private PermissionService perService;

//	1.創建realm
	@Bean
	public CustomRealm getRealm() {
		return new CustomRealm();
	}
	
//	2.創建安全管理器
	
	@Bean
	public SecurityManager getsecurityManager(CustomRealm realm) {
		DefaultWebSecurityManager securityManager = new DefaultWebSecurityManager();
		securityManager.setRealm(realm);
		
		// 关闭shiro自带的session
		DefaultSubjectDAO subjectDAO = new DefaultSubjectDAO();
        DefaultSessionStorageEvaluator defaultSessionStorageEvaluator = new DefaultSessionStorageEvaluator();
        defaultSessionStorageEvaluator.setSessionStorageEnabled(false);
        subjectDAO.setSessionStorageEvaluator(defaultSessionStorageEvaluator);
        securityManager.setSubjectDAO(subjectDAO);
		return securityManager;
	}
//	3.配置shiro過濾器工廠
	
	@Bean
	public ShiroFilterFactoryBean getShiroFilter(SecurityManager securityManager) {
		ShiroFilterFactoryBean filterFactory = new ShiroFilterFactoryBean();
		filterFactory.setSecurityManager(securityManager);
//		filterFactory.setLoginUrl("/login/autherror.do?code=1");
//		filterFactory.setUnauthorizedUrl("/login/autherror.do?code=2");
		
		Map<String, Filter> filterMap = new LinkedHashMap<String, Filter>();
		filterMap.put("jwt", new JWTFilter());
		filterMap.put("anon", getAllFilter());
		filterMap.put("perms", getPermsFilter());
		filterFactory.setFilters(filterMap);
		
		
		Map<String, String> filterRuleMap = new HashMap<>();
		PageInfo<PermissionEntity> perInfo = perService.listAllPermission(null, null);
		for (PermissionEntity per : perInfo.getList()) {
			filterRuleMap.put(per.getPerUrl(),per.getPerDescription());
		}
//		System.out.println("shirofilterRuleMap>>"+filterRuleMap);
		filterRuleMap.put("/login/login.do","anon");
		filterRuleMap.put("/depart/listDepart.do","anon");
		filterRuleMap.put("/user/getUserByUserNumber.do","anon");
		filterRuleMap.put("/user/addUser.do","anon");
//		filterRuleMap.put("/depart/listDepart.do","authc");
//		map.put("/jobLog/toRoster.do", "perms[设置黑白名单]");// 该资源必须先授权才能访问
//		filterRuleMap.put("/**","jwt");
		filterFactory.setFilterChainDefinitionMap(filterRuleMap);
		return filterFactory;
	}
	
	
//	4.開啟shiro對註解的支持
//	@Bean
//	public AuthorizationAttributeSourceAdvisor authorizationAttributeSourceAdvisor(SecurityManager securityManager) {
//		AuthorizationAttributeSourceAdvisor advisor = new AuthorizationAttributeSourceAdvisor();
//		advisor.setSecurityManager(securityManager);
//		return advisor;
//	}
	
	@Bean
    public AllFilter getAllFilter(){
        return new AllFilter();
    }
	
	@Bean
	public PermsFilter getPermsFilter(){
		return new PermsFilter();
	}
	
}
