package com.foxconn.shiro;


import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.foxconn.entity.PermissionEntity;
import com.foxconn.entity.RoleEntity;
import com.foxconn.entity.UserEntity;
import com.foxconn.service.UserService;
import com.foxconn.util.JWTUtils;
import com.foxconn.util.RedisUtil;

import io.jsonwebtoken.Claims;

public class CustomRealm extends AuthorizingRealm{

	@Value("${jwt.config.ttl}")
	private long ttl;
	@Autowired
	JWTUtils jwtUtils;
	@Autowired
	private UserService userService;

	@Autowired
	private RedisUtil redisUtil;
	 /**
     * 只有当需要检测用户权限的时候才会调用此方法，例如checkRole,checkPermission之类的
     */
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
        System.out.println("————权限认证————"+principals.toString());
        Claims claims = jwtUtils.parseJwt(principals.toString());
        String username = claims.getSubject();
       
        SimpleAuthorizationInfo authorizationInfo = new SimpleAuthorizationInfo();
        // 此处最好使用缓存提升速度
        UserEntity userInfo = userService.getUserByUserNumber(username);
       
        if (userInfo == null || userInfo.getRoleList().isEmpty()) {
            return authorizationInfo;
        }
        for (RoleEntity role : userInfo.getRoleList()) {
            authorizationInfo.addRole(role.getRoleName());
            if (role == null || role.getPermissionList().isEmpty()) {
                continue;
            }
            for (PermissionEntity p : role.getPermissionList()) {
                authorizationInfo.addStringPermission(p.getPerName());
            }
        }
        return authorizationInfo;
    }


	@Override
	protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
		// 認證
		UsernamePasswordToken uptoken = (UsernamePasswordToken)token;
		String userName = uptoken.getUsername();
		String pwd = new String(uptoken.getPassword());
		UserEntity user = userService.getUserByUserNumber(userName);
		if (null != user && pwd.equals(user.getPwd())) {
			redisUtil.set(user.getUserId(), user, ttl);
			return new SimpleAuthenticationInfo(user, user.getPwd(), this.getName());
		}
		return null;
	}

//    /**
//     * 必须重写此方法，不然会报错
//     */
//    @Override
//    public boolean supports(AuthenticationToken token) {
//        return token instanceof JWTToken;
//    }


}
