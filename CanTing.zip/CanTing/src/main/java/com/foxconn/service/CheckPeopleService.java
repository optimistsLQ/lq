package com.foxconn.service;

import java.util.List;

import com.foxconn.entity.CheckPeople;

public interface CheckPeopleService {

	public int addCheckPeople(CheckPeople checkPeople);
	public int delCheckPeopleByCheckTotalId(String checkTotalId);
	public List<CheckPeople> findByCheckTotalId(String checkTotalId);
}
