package com.foxconn.service;

import java.util.List;

import com.foxconn.entity.RoleEntity;
import com.foxconn.entity.UREntity;


/**用户关联角色业务接口
 * @author C3410596
 *
 */
public interface UserRoleService {
	/**给用户添加权限
	 * @param urEentity
	 */
	int insertUserRole(UREntity urEentity);
	/**根据id删除用户权限
	 * @param urId 用户id
	 */
	int delUserRoleById(String urId);
	/**根据用户id删除用户所有权限
	 * @param userId 
	 */
	int delUserRoleByUserId(String userId);
	
	/**根据用户ID查询对应的角色
	 * @param userId
	 * @return
	 */
	List<RoleEntity> findRoleByUserid(String userId);
	/**
	 * 修改用戶的角色
	 * @param userId
	 * @param roleIds
	 * @return
	 */
	int changeUserRole(String userId,String [] roleIds);
	
}
