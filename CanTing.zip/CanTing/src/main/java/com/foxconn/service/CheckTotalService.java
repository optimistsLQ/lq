package com.foxconn.service;

import com.foxconn.entity.CheckTotal;
import com.github.pagehelper.PageInfo;

public interface CheckTotalService {

	public String addCheckTotal(CheckTotal checkTotal);
	public int delCheckTotalById(String checkTotalId);
	public int updateCheckTotal(CheckTotal checkTotal);
	public CheckTotal findById(String checkTotalId);
	/**
	 * @param startTime 开始时间
	 * @param endTime  结束时间
	 * @param mealSeller  餐包商
	 * @param restaurantLocation  餐厅位置
	 * @param overend  表单状态（已完成）
	 * @return
	 */
	public PageInfo<CheckTotal> findByItem(Integer start, Integer length, String startTime, String endTime, 
			String mealSeller, String restaurantLocation, String overend);
}
