package com.foxconn.service.impl;

import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.foxconn.entity.PermissionEntity;
import com.foxconn.mapper.PermissionEntityMapper;
import com.foxconn.service.PermissionService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;

@Service
public class PermissionServiceImpl implements PermissionService{

	@Autowired
	private PermissionEntityMapper perMapper;
	@Override
	public int insertPermission(PermissionEntity permission) {
		// TODO Auto-generated method stub
		return perMapper.insertSelective(permission);
	}

	@Override
	public int delPermission(List<String> perId) {
		// TODO Auto-generated method stub
		int i = 0;
		for (String id : perId) {
			i += perMapper.deleteByPrimaryKey(id);
		}
		return i;
	}

	@Override
	public PageInfo<PermissionEntity> listAllPermission(Integer start, Integer length) {
		// TODO Auto-generated method stub
		Example example = new Example(PermissionEntity.class);
		if(ObjectUtils.isNotEmpty(start) && ObjectUtils.isNotEmpty(length)) {
			PageHelper.startPage(start, length);
		}
		List<PermissionEntity> list = perMapper.selectByExample(example);
		PageInfo<PermissionEntity> pageInfo = new PageInfo<PermissionEntity>(list);
		return pageInfo;
	}

	@Override
	public PermissionEntity getPermissionByPerName(String perName) {
		// TODO Auto-generated method stub
		Example example = new Example(PermissionEntity.class);
		Criteria criteria = example.createCriteria();
		criteria.andEqualTo("perName", perName);
		PermissionEntity entity = perMapper.selectOneByExample(example);
		return entity;
	}

	@Override
	public PermissionEntity getPermissionByUrl(String url) {
		// TODO Auto-generated method stub
		Example example = new Example(PermissionEntity.class);
		Criteria criteria = example.createCriteria();
		criteria.andEqualTo("perUrl", url);
		PermissionEntity entity = perMapper.selectOneByExample(example);
		return entity;
	}

	@Override
	public PermissionEntity getPermissionByPerId(String perId) {
		// TODO Auto-generated method stub
		return perMapper.selectByPrimaryKey(perId);
	}

	@Override
	public int updatePermission(PermissionEntity permission) {
		// TODO Auto-generated method stub
		return perMapper.updateByPrimaryKeySelective(permission);
	}

	public String getAllPer() {
		// TODO Auto-generated method stub
		List<PermissionEntity> list = perMapper.selectAll();
		HashMap<String, String> perMap = new HashMap<String, String>();
		for (PermissionEntity per : list) {
			perMap.put(per.getPerUrl(), per.getPerDescription());
		}
		return JSON.toJSONString(perMap);
	}

}
