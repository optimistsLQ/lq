package com.foxconn.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.entity.RPEntity;
import com.foxconn.mapper.RPEntityMapper;
import com.foxconn.service.RolePermissionService;

import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;

@Service
public class RPServiceImpl implements RolePermissionService{

	@Autowired
	private RPEntityMapper RPMapper;
	@Override
	public int insertRolePermission(RPEntity rpEntity) {
		// TODO Auto-generated method stub
		return RPMapper.insertSelective(rpEntity);
	}

	@Override
	public List<RPEntity> listByRoleId(String roleId) {
		// TODO Auto-generated method stub
		Example example = new Example(RPEntity.class);
		Criteria criteria = example.createCriteria();
		criteria.andEqualTo("roleId", roleId);
		return RPMapper.selectByExample(example);
	}

	@Override
	public int delRolePermissionByRoleIds(String roleId) {
		// TODO Auto-generated method stub
		Example example = new Example(RPEntity.class);
		Criteria criteria = example.createCriteria();
		criteria.andEqualTo("roleId", roleId);
		return RPMapper.deleteByExample(example);
	}

	@Override
	public int changeRolePermission(String roleId, List<String> perids) {
		// TODO Auto-generated method stub
		this.delRolePermissionByRoleIds(roleId);
		int i = 0;
		for (String perId : perids) {
			i += this.insertRolePermission(new RPEntity(null, roleId, perId, null));
		}
		return i;
	}

}
