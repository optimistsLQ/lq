package com.foxconn.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.entity.CheckPeople;
import com.foxconn.mapper.CheckPeopleMapper;
import com.foxconn.service.CheckPeopleService;

import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;
@Service
public class CheckPeopleImpl implements CheckPeopleService{

	@Autowired
	private CheckPeopleMapper checkPeopleMapper;
	@Override
	public int addCheckPeople(CheckPeople checkPeople) {
		// TODO Auto-generated method stub
		return checkPeopleMapper.insertSelective(checkPeople);
	}

	@Override
	public int delCheckPeopleByCheckTotalId(String checkTotalId) {
		// TODO Auto-generated method stub
		Example example = new Example(CheckPeople.class);
		Criteria criteria = example.createCriteria();
		criteria.andEqualTo("checkTotalId", checkTotalId);
		
		return checkPeopleMapper.deleteByExample(example);
	}

	@Override
	public List<CheckPeople> findByCheckTotalId(String checkTotalId) {
		// TODO Auto-generated method stub
		Example example = new Example(CheckPeople.class);
		Criteria criteria = example.createCriteria();
		criteria.andEqualTo("checkTotalId", checkTotalId);
		List<CheckPeople> list = checkPeopleMapper.selectByExample(example);
		return list;
	}

}
