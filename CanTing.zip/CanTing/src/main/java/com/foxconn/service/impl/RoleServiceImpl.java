package com.foxconn.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.foxconn.entity.RoleEntity;
import com.foxconn.mapper.RoleEntityMapper;
import com.foxconn.service.RolePermissionService;
import com.foxconn.service.RoleService;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;

@Service
public class RoleServiceImpl implements RoleService{

	@Autowired
	private RoleEntityMapper roleMapper;
	@Autowired
	private RolePermissionService RPservice;
	@Override
	public int insertRole(RoleEntity role) {
		// TODO Auto-generated method stub
		return roleMapper.insertSelective(role);
	}

	@Override
	public int delRoles(List<String> roleids) {
		// TODO Auto-generated method stub
		int i = 0;
		for (String id : roleids) {
			i += roleMapper.deleteByPrimaryKey(id);
		}
		if (i > 0) {
			for (String roleId : roleids) {
				RPservice.delRolePermissionByRoleIds(roleId);
			}
		}
		return i;
	}

	/**
	 *
	 */
	@Override
	public List<RoleEntity> listRoleAll(Integer start,Integer length) {
		// TODO Auto-generated method stub
		
		List<RoleEntity> list = roleMapper.listRoleAll(start, length);
		
		return list;
	}

	@Override
	public RoleEntity findOneRole(String roleId) {
		// TODO Auto-generated method stub
		return roleMapper.selectByPrimaryKey(roleId);
	}

	@Override
	public int updateRoel(RoleEntity role) {
		// TODO Auto-generated method stub
		return roleMapper.updateByPrimaryKeySelective(role);
	}

	@Override
	public RoleEntity findByRoleName(String roleName) {
		// TODO Auto-generated method stub
		Example example = new Example(RoleEntity.class);
		Criteria criteria = example.createCriteria();
		criteria.andEqualTo("roleName", roleName);
		return roleMapper.selectOneByExample(example);
	}

	@Override
	public RoleEntity getRoleById(String roleId) {
		// TODO Auto-generated method stub
		return roleMapper.getRoleById(roleId);
	}

	@Override
	public int count() {
		// TODO Auto-generated method stub
		return roleMapper.count();
	}

	@Override
	public String getRoleId(RoleEntity roleEntity) {
		// TODO Auto-generated method stub
		return roleMapper.getRoleId(roleEntity.getRoleName(),roleEntity.getDescription());
	}

}
