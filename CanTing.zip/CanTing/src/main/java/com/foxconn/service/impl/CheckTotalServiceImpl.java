package com.foxconn.service.impl;

import java.util.List;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.formula.functions.T;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.entity.CheckTotal;
import com.foxconn.mapper.CheckTotalMapper;
import com.foxconn.service.CheckTotalService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
@Service
public class CheckTotalServiceImpl implements CheckTotalService{

	@Autowired
	private CheckTotalMapper checkTotalMapper;
	@Override
	public String addCheckTotal(CheckTotal checkTotal) {
		// TODO Auto-generated method stub
		return checkTotalMapper.insertGetId(checkTotal);
	}

	@Override
	public int delCheckTotalById(String checkTotalId) {
		// TODO Auto-generated method stub
		return checkTotalMapper.deleteByPrimaryKey(checkTotalId);
	}

	@Override
	public int updateCheckTotal(CheckTotal checkTotal) {
		// TODO Auto-generated method stub
		return checkTotalMapper.updateByPrimaryKeySelective(checkTotal);
	}

	@Override
	public CheckTotal findById(String checkTotalId) {
		// TODO Auto-generated method stub
		return checkTotalMapper.selectByPrimaryKey(checkTotalId);
	}

	@Override
	public PageInfo<CheckTotal> findByItem(Integer start, Integer length, String startTime, String endTime, String mealSeller,
			String restaurantLocation, String overend) {
		// TODO Auto-generated method stub
		if (ObjectUtils.isNotEmpty(start) && ObjectUtils.isNotEmpty(length)) {
			PageHelper.startPage(start, length);
		}
		List<CheckTotal> list = checkTotalMapper.findByItem(startTime, endTime, mealSeller, restaurantLocation, overend);
		PageInfo<CheckTotal> pageInfo = new PageInfo<CheckTotal>(list);
		return pageInfo;
	}

}
