package com.foxconn.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.entity.CheckProblem;
import com.foxconn.mapper.CheckProblemMapper;
import com.foxconn.service.CheckProblemService;

import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;

@Service
public class CheckProblemServiceImpl implements CheckProblemService{

	@Autowired
	private CheckProblemMapper checkProblemMapper;
	@Override
	public int addCheckProblem(CheckProblem checkProblem) {
		// TODO Auto-generated method stub
		return checkProblemMapper.insertSelective(checkProblem);
	}

	@Override
	public int delCheckProblemById(String id) {
		// TODO Auto-generated method stub
		return checkProblemMapper.deleteByPrimaryKey(id);
	}

	@Override
	public int delCheckProblemByCheckTotalId(String checkTotalId) {
		// TODO Auto-generated method stub
		Example example = new Example(CheckProblem.class);
		Criteria criteria = example.createCriteria();
		criteria.andEqualTo("checkMtotalId", checkTotalId);
		return checkProblemMapper.deleteByExample(example);
	}

	@Override
	public int updateCheckProblem(CheckProblem checkProblem) {
		// TODO Auto-generated method stub
		return checkProblemMapper.updateByPrimaryKeySelective(checkProblem);
	}

	@Override
	public CheckProblem findById(String id) {
		// TODO Auto-generated method stub
		return checkProblemMapper.selectByPrimaryKey(id);
	}

	@Override
	public List<CheckProblem> fingByCheckTotalId(String checkTotalId) {
		// TODO Auto-generated method stub
		Example example = new Example(CheckProblem.class);
		Criteria criteria = example.createCriteria();
		criteria.andEqualTo("checkMtotalId", checkTotalId);
		return checkProblemMapper.selectByExample(example);
	}

}
