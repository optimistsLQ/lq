package com.foxconn.service;

import com.foxconn.entity.DepartEntity;
import com.github.pagehelper.PageInfo;

public interface DepartService {

	public int insertDepart(DepartEntity depart);
	public int delDepartById(String departId);
	public int updateDepart(DepartEntity depart);
	public PageInfo<DepartEntity> listAllDepart(Integer start, Integer length);
	public DepartEntity getDepartById(String departId);
}
