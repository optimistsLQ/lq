package com.foxconn.service;

import java.util.List;

import com.foxconn.entity.RoleEntity;

public interface RoleService {

	/**添加角色
	 * @param role
	 */
	int  insertRole(RoleEntity role);
	/**根據角色id刪除角色
	 * @param roleId
	 */
	int delRoles(List<String> roleids);

	/**查詢所有角色
	 * @return
	 */
	 List<RoleEntity> listRoleAll(Integer start,Integer length);
	
	
	/**根据ID查询对应角色和权限
	 * @param roleId
	 * @return
	 */
	RoleEntity findOneRole(String roleId);
	RoleEntity findByRoleName(String roleName);
	/**修改角色信息
	 * @param role
	 * @return
	 */
	int updateRoel(RoleEntity role);
	RoleEntity getRoleById(String roleId);
	int count();
	String getRoleId(RoleEntity roleEntity);
}
