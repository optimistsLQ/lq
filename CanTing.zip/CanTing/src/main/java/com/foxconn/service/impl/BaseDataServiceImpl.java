package com.foxconn.service.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.entity.base.AuditPeople;
import com.foxconn.entity.base.ManagementStand;
import com.foxconn.entity.base.RestaurantDetail;
import com.foxconn.mapper.base.AuditPeopleMapper;
import com.foxconn.mapper.base.ManagementStandMapper;
import com.foxconn.mapper.base.RestaurantDetailMapper;
import com.foxconn.service.BaseDataService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;

@Service
public class BaseDataServiceImpl implements BaseDataService{

	@Autowired
	private AuditPeopleMapper auditPeopleMapper;
	@Autowired
	private ManagementStandMapper managementStandMapper;
	@Autowired
	private RestaurantDetailMapper restaurantDetailMapper;
	
	@Override
	public <T> Integer addData(List<T> list, Class<T> cla) {
		String className = cla.getSimpleName();
		int i = handleBaseData("insert", list, className);
		return i;
	}
	@Override
	public int delByIds(List<String> ids, Class<?> cla) {
		// TODO Auto-generated method stub
		String className = cla.getSimpleName();
		int i = handleBaseData("delete", ids, className);
		return i;
	}

	@Override
	public int updateBaseData(Object obj, Class<?> cla) {
		String className = cla.getSimpleName();
		int i = handleBaseData("update", obj, className);
		return 0;
	}


	public <T> Integer handleBaseData(String handleType, Object list, String className) {
		Integer i = 0;
		switch (handleType) {
		case "insert":
			if (className.equals("AuditPeople")) {
				List<AuditPeople> coverList = (List<AuditPeople>) list;
				i = auditPeopleMapper.insertList(coverList);
			}else if (className.equals("ManagementStand")) {
				List<ManagementStand> coverList = (List<ManagementStand>) list;
				i = managementStandMapper.insertList(coverList);
			}else if (className.equals("RestaurantDetail")) {
				List<RestaurantDetail> coverList = (List<RestaurantDetail>) list;
				i = restaurantDetailMapper.insertList(coverList);
			}
			break;
		case "delete":
			List<String> idList = (List<String>) list;
			if (className.equals("AuditPeople")) {
				i = auditPeopleMapper.delByIds(idList);
			}else if (className.equals("ManagementStand")) {
				i = managementStandMapper.delByIds(idList);
			}else if (className.equals("RestaurantDetail")) {
				i = restaurantDetailMapper.delByIds(idList);
			}
			break;
		case "update":
			if (className.equals("AuditPeople")) {
				AuditPeople entity = (AuditPeople) list;
				i = auditPeopleMapper.updateByPrimaryKeySelective(entity);
			}else if (className.equals("ManagementStand")) {
				ManagementStand entity = (ManagementStand) list;
				i = managementStandMapper.updateByPrimaryKeySelective(entity);
			}else if (className.equals("RestaurantDetail")) {
				RestaurantDetail entity = (RestaurantDetail) list;
				i = restaurantDetailMapper.updateByPrimaryKeySelective(entity);
			}
			break;

		default:
			
			break;
		}
		return i;
	}
	@Override
	public PageInfo<?> findBaseData(String item, Integer start, Integer length, Class<?> cla) {
		// TODO Auto-generated method stub
		if (ObjectUtils.isNotEmpty(start) && ObjectUtils.isNotEmpty(length)) {
			PageHelper.startPage(start, length);
		}
		String className = cla.getSimpleName();
		PageInfo<?> pageInfo = null;
		if (className.equals("AuditPeople")) {
			List<AuditPeople> list = auditPeopleMapper.selectByItem(item);
			pageInfo = new PageInfo<AuditPeople>(list);
		}else if (className.equals("ManagementStand")) {
			List<ManagementStand> list = managementStandMapper.selectByItem(item);
			pageInfo = new PageInfo<ManagementStand>(list);
		}else if (className.equals("RestaurantDetail")) {
			List<RestaurantDetail> list = restaurantDetailMapper.selectByItem(item);
			pageInfo = new PageInfo<RestaurantDetail>(list);
		}
		return pageInfo;
	}
	@Override
	public Object getBaseData(String nth, Class<?> cla) {
		// TODO Auto-generated method stub
		Object obj = null;
		String className = cla.getSimpleName();
		if (className.equals("AuditPeople")) {
			obj = auditPeopleMapper.selectByPrimaryKey(nth);
		}else if (className.equals("ManagementStand")) {
			obj = managementStandMapper.selectByPrimaryKey(nth);
		}else if (className.equals("RestaurantDetail")) {
			obj = restaurantDetailMapper.selectByPrimaryKey(nth);
		}
		return obj;
	}
	@Override
	public List<?> listDataByCondition(Map<String, String> queryMap, Class<?> cla) {
		// TODO Auto-generated method stub
		List<?> list = null;
		String className = cla.getSimpleName();
		Example example = new Example(cla);
		Criteria criteria = example.createCriteria();
		for (String key : queryMap.keySet()) {
			criteria.andEqualTo(key, queryMap.get(key));
		}
		if (className.equals("AuditPeople")) {
			list = auditPeopleMapper.selectByExample(example);
		}else if (className.equals("ManagementStand")) {
			list = managementStandMapper.selectByExample(example);
		}else if (className.equals("RestaurantDetail")) {
			list = restaurantDetailMapper.selectByExample(example);
		}
		return list;
	}
	

}
