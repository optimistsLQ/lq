package com.foxconn.service;

import java.util.List;

import com.foxconn.entity.CheckProblem;

public interface CheckProblemService {

	public int addCheckProblem(CheckProblem checkProblem);
	public int delCheckProblemById(String id);
	public int delCheckProblemByCheckTotalId(String checkTotalId);
	public int updateCheckProblem(CheckProblem checkProblem);
	public CheckProblem findById(String id);
	public List<CheckProblem> fingByCheckTotalId(String checkTotalId);
}
