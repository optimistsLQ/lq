package com.foxconn.service.impl;

import java.util.List;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.foxconn.entity.DepartEntity;
import com.foxconn.mapper.DepartEntityMapper;
import com.foxconn.service.DepartService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import tk.mybatis.mapper.entity.Example;

@Service
public class DepartServiceImpl implements DepartService{

	@Autowired
	private DepartEntityMapper departMapper;
	@Override
	public int insertDepart(DepartEntity depart) {
		// TODO Auto-generated method stub
		return departMapper.insertSelective(depart);
	}

	@Override
	public int delDepartById(String departId) {
		// TODO Auto-generated method stub
		return departMapper.deleteByPrimaryKey(departId);
	}

	@Override
	public int updateDepart(DepartEntity depart) {
		// TODO Auto-generated method stub
		return departMapper.updateByPrimaryKeySelective(depart);
	}

	@Override
	public PageInfo<DepartEntity> listAllDepart(Integer start, Integer length) {
		// TODO Auto-generated method stub
		Example example = new Example(DepartEntity.class);
		if(ObjectUtils.isNotEmpty(start) && ObjectUtils.isNotEmpty(length)) {
			PageHelper.startPage(start, length);
		}
		List<DepartEntity> list = departMapper.selectByExample(example);
		PageInfo<DepartEntity> pageInfo = new PageInfo<DepartEntity>(list);
		return pageInfo;
	}

	@Override
	public DepartEntity getDepartById(String departId) {
		// TODO Auto-generated method stub
		return departMapper.selectByPrimaryKey(departId);
	}

}
