package com.foxconn.service;

import java.util.List;
import java.util.Map;

public interface BaseService {

	public int addBaseData(Map<String, Object> dataMap, Class<?> cla);
	public int delByIds(List<String> ids, Class<?> cla);
	public int updateBaseData(Object obj, Class<?> cla);
	public List<?> findBaseData(String item, Integer start, Integer length, Class<?> cla);
	
}
