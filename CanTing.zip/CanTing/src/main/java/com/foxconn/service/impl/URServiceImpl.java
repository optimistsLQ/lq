package com.foxconn.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.foxconn.entity.RoleEntity;
import com.foxconn.entity.UREntity;
import com.foxconn.mapper.UREntityMapper;
import com.foxconn.service.UserRoleService;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;

@Service
public class URServiceImpl implements UserRoleService{

	@Autowired
	private UREntityMapper URMapper;
	@Override
	public int insertUserRole(UREntity urEentity) {
		// TODO Auto-generated method stub
		return URMapper.insertSelective(urEentity);
	}

	@Override
	public int delUserRoleById(String urId) {
		// TODO Auto-generated method stub
		return URMapper.deleteByPrimaryKey(urId);
	}

	@Override
	public int delUserRoleByUserId(String userId) {
		// TODO Auto-generated method stub
		Example example = new Example(UREntity.class);
		Criteria criteria = example.createCriteria();
		criteria.andEqualTo("userId", userId);
		return URMapper.deleteByExample(example);
	}

	@Override
	public int changeUserRole(String userId, String[] roleIds) {
		// TODO Auto-generated method stub
		this.delUserRoleByUserId(userId);
		int i = 0;
		for (String roleId : roleIds) {
			i += this.insertUserRole(new UREntity(null, userId, roleId, null));
		}
		
		return i;
	}

	@Override
	public List<RoleEntity> findRoleByUserid(String userId) {
		// TODO Auto-generated method stub
		return URMapper.findRoleByUserid(userId);
	}

}
