package com.foxconn.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.foxconn.entity.RoleEntity;
import com.foxconn.entity.UserEntity;
import com.foxconn.mapper.UserEntityMapper;
import com.foxconn.service.UserRoleService;
import com.foxconn.service.UserService;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserEntityMapper userMapper;

	@Autowired
	private UserRoleService URService;
	@Override
	public UserEntity getUserById(String userId) {
		// TODO Auto-generated method stub
		UserEntity user = userMapper.selectByUserId(userId);
		return user;
	}

	@Override
	public int insertUser(UserEntity user) {
		// TODO Auto-generated method stub
		int i = userMapper.insertSelective(user);
		return i;
		
	}

	@Override
	public List<UserEntity> listAllUser(String item, Integer start, Integer length) {
		List<UserEntity> userList = userMapper.listAllUser(item, start, length);
		for (UserEntity user: userList) {
			String userId = user.getUserId();
			List<RoleEntity> roleList = URService.findRoleByUserid(userId);
			user.setRoleList(roleList);
		}
		
		return userList;
	}

	@Override
	public UserEntity getUserByUserNumber(String userNumber) {
		// TODO Auto-generated method stub
		Example example = new Example(UserEntity.class);
		Criteria criteria = example.createCriteria();
		criteria.andEqualTo("userNumber", userNumber);
		UserEntity user = userMapper.selectOneByExample(example);
		return user;
	}

	@Override
	public int delUser(List<String> userId) {
		// TODO Auto-generated method stub
		int i = 0;
		for (String id : userId) {
			i += userMapper.deleteByPrimaryKey(id);
		}
		if (i > 0) {
			for (String uid : userId) {
				URService.delUserRoleByUserId(uid);
			}
		}
		return i;
	}

	@Override
	public int updateUser(UserEntity user) {
		// TODO Auto-generated method stub
		int i = userMapper.updateByPrimaryKeySelective(user);
		return i;
	}

	@Override
	public UserEntity getUserByNickname(String nickname) {
		// TODO Auto-generated method stub
		Example example = new Example(UserEntity.class);
		Criteria criteria = example.createCriteria();
		criteria.andEqualTo("nickname", nickname);
		UserEntity user = userMapper.selectOneByExample(example);
		return user;
	}

	@Override
	public Integer count(String item) {
		// TODO Auto-generated method stub
		return userMapper.count(item);
	}

	@Override
	public UserEntity getUserByuerNumber(String userNumber) {
		// TODO Auto-generated method stub
		UserEntity user = userMapper.getUserByuerNumber(userNumber);
		return user;
	}
	
}
