package com.foxconn.service;

import java.util.List;

import com.foxconn.entity.RPEntity;

/**给角色操作权限的业务接口
 * @author C3410596
 *
 */
public interface RolePermissionService {
	/**给角色增加权限
	 * @param rpEntity
	 * @return
	 */
	int insertRolePermission(RPEntity rpEntity);
	
	
	/**查询某个角色的所有权限
	 * @param roleId
	 * @return
	 */
	List<RPEntity> listByRoleId(String roleId);
	/**删除某个角色的所有权限
	 * @param roleId
	 * @return
	 */
	int delRolePermissionByRoleIds(String roleId);

	int changeRolePermission(String roleId, List<String> perids);

}
