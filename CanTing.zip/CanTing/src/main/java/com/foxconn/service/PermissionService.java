package com.foxconn.service;

import java.util.List;

import com.foxconn.entity.PermissionEntity;
import com.github.pagehelper.PageInfo;


/**權限業務接口
 * @author C3410596
 *
 */
public interface PermissionService {
	/**添加权限
	 * @param permission
	 */
	int insertPermission(PermissionEntity permission);
	/**根据id删除权限
	 * @param preId
	 */
	int delPermission(List<String> perId);
	/**分页查询所有权限
	 * @return
	 */
	PageInfo<PermissionEntity> listAllPermission(Integer start, Integer length);
	/**验证权限名是否存在
	 * @param perName
	 * @return
	 */
	PermissionEntity getPermissionByPerName(String perName);
	PermissionEntity getPermissionByUrl(String url);
	/**根据ID查询权限
	 * @param perId
	 * @return
	 */
	PermissionEntity getPermissionByPerId(String perId);
	/**修改权限信息
	 * @param permission
	 * @return
	 */
	int updatePermission(PermissionEntity permission);
	
}
