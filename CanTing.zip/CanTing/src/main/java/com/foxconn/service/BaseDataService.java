package com.foxconn.service;

import java.util.List;
import java.util.Map;

import com.github.pagehelper.PageInfo;

public interface BaseDataService {

	public <T> Integer addData(List<T> list, Class<T> cla);
	public int delByIds(List<String> ids, Class<?> cla);
	public int updateBaseData(Object obj, Class<?> cla);
	public PageInfo<?> findBaseData(String item, Integer start, Integer length, Class<?> cla);
	public Object getBaseData(String nth, Class<?> cla);
	public List<?> listDataByCondition(Map<String, String> queryMap, Class<?> cla);
}
