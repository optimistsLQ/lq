package com.foxconn.service.impl;

import java.util.List;
import java.util.Map;

import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.entity.base.AuditPeople;
import com.foxconn.entity.base.ManagementStand;
import com.foxconn.entity.base.RestaurantDetail;
import com.foxconn.mapper.base.AuditPeopleMapper;
import com.foxconn.mapper.base.ManagementStandMapper;
import com.foxconn.mapper.base.RestaurantDetailMapper;
import com.foxconn.service.BaseService;
import com.foxconn.util.BaseMapper;
import com.foxconn.util.MapToBeanUtil;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;

@Service
public class BaseServiceImpl implements BaseService{

	@Autowired
	private AuditPeopleMapper auditPeopleMapper;
	@Autowired
	private ManagementStandMapper managementStandMapper;
	@Autowired
	private RestaurantDetailMapper restaurantDetailMapper;
//	@Autowired
//	private BaseMapper<?> baseMapper;
	@Override
	public int addBaseData(Map<String, Object> dataMap, Class<?> cla) {
		// TODO Auto-generated method stub
		String className = cla.getSimpleName();
		int i = 0;
		try {
			Object mapToBean = MapToBeanUtil.mapToBean(cla, dataMap);
				switch (className) {
				case "AuditPeople":
					AuditPeople auditPeople = (AuditPeople) mapToBean;
						auditPeopleMapper.insertSelective(auditPeople);
					break;
				case "ManagementStand":
					ManagementStand managementStand = (ManagementStand) mapToBean;
					managementStandMapper.insertSelective(managementStand);
					break;
				case "RestaurantDetail":
					RestaurantDetail restaurantDetail = (RestaurantDetail) mapToBean;
					restaurantDetailMapper.insertSelective(restaurantDetail);
					break;
		
				default:
					throw new ClassNotFoundException(cla+">基礎資料缺失該類相關信息");
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		
		return i;
	}

	@Override
	public int delByIds(List<String> ids, Class<?> cla) {
		// TODO Auto-generated method stub
		int i = 0;
//		Annotation[] tableNames = cla.getAnnotations();
//		for (Annotation s : tableNames) {
//			System.out.println(s.toString());
//		}
		Table annotation = cla.getAnnotation(Table.class);//获取类上的table注解name属性的值，即表明
		    String tableName = annotation.name();
		    System.out.println(tableName);
		    
//		    baseMapper.delDataByIds(ids,tableName);
		    
//			Example example = new Example(cla);
//			Criteria criteria = example.createCriteria();
//			example.setTableName(tableName);
//			criteria.andEqualTo("nth", value);
//			
//			i = auditPeopleMapper.deleteByExample(example);
		return 0;
	}

	@Override
	public int updateBaseData(Object obj, Class<?> cla) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<?> findBaseData(String item, Integer start, Integer length, Class<?> cla) {
		// TODO Auto-generated method stub
		return null;
	}

}
