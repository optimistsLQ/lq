package com.foxconn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import tk.mybatis.spring.annotation.MapperScan;

/**
 * 程序啟動入口
 **/
@SpringBootApplication
@MapperScan(basePackages = "com.foxconn.mapper")
public class CanTingRun{

    public static void main(String[] args) {
   	SpringApplication.run(CanTingRun.class, args);
    	
    }

	
    
}
