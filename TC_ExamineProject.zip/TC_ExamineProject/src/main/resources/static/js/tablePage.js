/**
 * 点击 TC&LH匹配 按钮
 * */
function TC_LHCompear(){
	clickVersion = $("#TCclickDate").text();
	if (!clickVersion){
		alert("请先选择TC报表爬取日期");
		return;
	}
	showLoading("数据爬取对比中。。。。");
	$.post("/TC/getCompearLH_TC.do",{clickVersion:clickVersion},function(data){
		alert(data);
		hideLoading();
	});
}
/**
 * Excel下载按钮
 * 根据writetime  excel下载TC&LH匹配明细
 * */
function excelDownLoad(writetime){
	window.location = "/TC/getLH_TCResultExcel.do?writetime=" + writetime;
}

/**
 * 开启遮罩层
 * @param loadText 提示语
 * @returns
 */
function showLoading(loadText) {
    $("#msgText").html(loadText);
    $('#greyModal').show();
    $('#loadingModal').show();
    $('body').css("overflow","hidden");
}
/**
 * 关闭遮罩层
 * @returns
 */
function hideLoading() {
  $('#greyModal').hide();
  $('#loadingModal').hide();
  $('body').css("overflow","auto");
}