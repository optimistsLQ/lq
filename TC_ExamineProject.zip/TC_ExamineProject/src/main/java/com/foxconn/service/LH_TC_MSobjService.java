package com.foxconn.service;

import java.util.List;

import com.foxconn.entity.LH_TC_MSobj;

public interface LH_TC_MSobjService {

	public int addLH_TC_MSList(List<LH_TC_MSobj> list);

	public List<String> findByGrnList(List<String> grnList);

	public List<LH_TC_MSobj> listNoMsData();

	public int updateMs(List<LH_TC_MSobj> list);

	public List<LH_TC_MSobj> listLH_TC_MSdata(String endTime);
}
