package com.foxconn.service;

import com.foxconn.entity.exChangeEntity;
import com.foxconn.mapper.exChangeEntityMapper;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

@Service
public class ExChangeServiceImpl
  implements ExChangeService
{
  @Autowired
  private exChangeEntityMapper mapper;
  
  public int addExChange(exChangeEntity ex)
  {
    return this.mapper.insertSelective(ex);
  }
  
  public int delExChangeById(String id)
  {
    return this.mapper.deleteByPrimaryKey(id);
  }
  
  public int updateExChange(exChangeEntity ex)
  {
    return this.mapper.updateByPrimaryKeySelective(ex);
  }
  
  public List<exChangeEntity> listAll()
  {
    Example example = new Example(exChangeEntity.class);
    example.setOrderByClause("exchange_date");
    return this.mapper.selectByExample(example);
  }
  
  public Map<String, Double> listAllToMap()
  {
    List<exChangeEntity> list = this.mapper.selectAll();
    HashMap<String, Double> map = new HashMap();
    for (exChangeEntity ex : list) {
      map.put(ex.getExchangeDate(), ex.getExchangeNum());
    }
    return map;
  }
}
