package com.foxconn.service;

import com.foxconn.entity.exChangeEntity;
import java.util.List;
import java.util.Map;

public abstract interface ExChangeService
{
  public abstract int addExChange(exChangeEntity paramexChangeEntity);
  
  public abstract int delExChangeById(String paramString);
  
  public abstract int updateExChange(exChangeEntity paramexChangeEntity);
  
  public abstract List<exChangeEntity> listAll();
  
  public abstract Map<String, Double> listAllToMap();
}
