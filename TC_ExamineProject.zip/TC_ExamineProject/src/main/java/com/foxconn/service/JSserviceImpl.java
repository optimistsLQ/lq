package com.foxconn.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.entity.JSDetail;
import com.foxconn.mapper.JSDetailMapper;
import com.google.common.collect.Lists;

@Service
public class JSserviceImpl implements JSservice{

	@Autowired
	private JSDetailMapper mapper;
	@Override
	public List<JSDetail> listMS_LHdata(String startTime, String endTime) {
		// TODO Auto-generated method stub
		return mapper.listMS_LHdata(startTime,endTime);
	}
	@Override
	public int updateHasCheck(List<String> stockInCodeList) {
		// TODO Auto-generated method stub
		int i = 0;
		if (stockInCodeList.size() > 300) {
			for(List<String> list : Lists.partition(stockInCodeList, 300)) {
				i += mapper.updateHasCheck(list);
			}
		} else {
			i = mapper.updateHasCheck(stockInCodeList);
		}
		return i;
	}

}
