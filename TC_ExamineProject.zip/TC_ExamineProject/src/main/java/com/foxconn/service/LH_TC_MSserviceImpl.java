package com.foxconn.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.entity.JSDetail;
import com.foxconn.entity.LH_TC_MSobj;
import com.foxconn.mapper.LH_TC_MSobjMapper;
import com.foxconn.utils.ExcelUtil;
import com.google.common.collect.Lists;

@Service
public class LH_TC_MSserviceImpl implements LH_TC_MSobjService{

	@Autowired
	private LH_TC_MSobjMapper mapper;

	@Override
	public int addLH_TC_MSList(List<LH_TC_MSobj> LH_TC_MSlist) {
		// TODO Auto-generated method stub
		List<String> fieldList = Arrays.asList(new String[] { "bu", "tradeType", "formHead", "changshangCode", "changshangName", "hhVendorCode", "stockinCode", "stockinTime", 
	    		"pruchaseCode", "materiel", "unit", "unsettledNum", "currency", "poPrice", "stockinMoney", "actualPrice", "apPrice", "action", "effectiveDate", 
	    		"effectiveWay", "hhPaycondition", "hfjPaycondition", "poPaycondition","free", "writetime", "purchaseDate", "tcEffectiveWay", "tcEffectiveDate", 
	    		"tcExpireDate", "tcApPrice", "tcAcPrice", "tcApplePrice", "tcAction", "tcPaymentTerm", "tcUpDri", "remark","msAcPrice",
	    		"msApPrice","msEffectivedate","msExchangeRate","tcOk" });
	    
	    int i = 0;
	    if (LH_TC_MSlist.size() > 50) {
	      List<List<LH_TC_MSobj>> splitList = ExcelUtil.splitList(LH_TC_MSlist, 50);
	      for (List<LH_TC_MSobj> list : splitList) {
	        i += this.mapper.addLH_TC_MSlist(list, fieldList);
	      }
	    } else {
	      i = this.mapper.addLH_TC_MSlist(LH_TC_MSlist, fieldList);
	    }
	    return i;
	}

	@Override
	public List<String> findByGrnList(List<String> grnList) {
		// TODO Auto-generated method stub
		List<String> list = new ArrayList<String>();
		if (grnList.size() > 300) {
			for(List<String> splitList:Lists.partition(grnList, 300)) {
				list.addAll(mapper.findByGrnList(splitList));	
			}
		} else {
			list = mapper.findByGrnList(grnList);
		}
		return list;
	}

	@Override
	public List<LH_TC_MSobj> listNoMsData() {
		// TODO Auto-generated method stub
		return mapper.listNoMsData();
	}

	@Override
	public int updateMs(List<LH_TC_MSobj> LHList) {
		// TODO Auto-generated method stub
		int i =0;
		if (LHList.size() > 200) {
			List<List<LH_TC_MSobj>> splitList = ExcelUtil.splitList(LHList, 200);
			for (List<LH_TC_MSobj> list : splitList)
				i += this.mapper.updateMs(list);
		} else {
			i = this.mapper.updateMs(LHList);
		}
		return i;
	}

	@Override
	public List<LH_TC_MSobj> listLH_TC_MSdata(String endTime) {
		// TODO Auto-generated method stub
		return mapper.listLH_TC_MSdata(endTime);
	}
	
}
