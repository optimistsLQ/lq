package com.foxconn.service;

import com.foxconn.entity.LH_TCDetails;
import com.foxconn.entity.TcDetail;
import com.foxconn.entity.exChangeEntity;
import com.foxconn.mapper.JSDetailMapper;
import com.foxconn.mapper.LH_TCDetailsMapper;
import com.foxconn.mapper.TcDetailMapper;
import com.foxconn.service.TcService;
import com.foxconn.utils.ExcelUtil;
import com.foxconn.utils.TiptopData;
import com.foxconn.utils.Toolkit;
import com.foxconn.utils.Utils;
import com.google.common.collect.Lists;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import tk.mybatis.mapper.entity.Example;

@Service
public class TCServiceImpl implements TcService {
	private static final Logger logger = LoggerFactory.getLogger(TCServiceImpl.class);

	@Autowired
	private TcDetailMapper tcDetailMapper;

	
	public int addTCList(List<TcDetail> tcReportDataList) {
		// 2.再插入tcReportDataList里的所有数据
		List<String> fieldList = Arrays.asList(new String[] { "buCode", "upDri", "hhPn", "machineModel", "newVendorCode", "currency",
				"effectiveDate", "expireDate", "effectiveWay", "allocation", "applePrice", "actualPrice", "apPrice", "action",
				"hhPayment", "fthPayment", "tcVersion", "clickVersion", "md5Msg" });
		int i = 0;
		if (tcReportDataList.size() > 100) {
			List<List<TcDetail>> splitList = ExcelUtil.splitList(tcReportDataList, 100);
			for (List<TcDetail> list : splitList)
				i += this.tcDetailMapper.addTCList(list, fieldList);
		} else {
			i = this.tcDetailMapper.addTCList(tcReportDataList, fieldList);
		}
		return i;
	}

	public int delTC() {
		return 0;
	}

	public List<TcDetail> listTCByClickVersion(String clickVersion) {
		return this.tcDetailMapper.listTCByClickVersion(clickVersion);
	}



	public List<String> getDateListByDateTime(String dateTime) {
		List<String> dateList = this.tcDetailMapper.getDateListByDateTime(dateTime + " 00:00:00",
				dateTime + " 24:00:00");
		return dateList;
	}

	/**
	 *分页查询tc资料
	 *并整理成map《BuCode+HhPn+NewVendorCode+Currency ： list<TcDetail>》
	 */
	public Map<String, List<TcDetail>> getTCSourceTop2W(int start, int length) {
		Map<String, List<TcDetail>> map = new HashMap<>();
		List<TcDetail> TClist = this.tcDetailMapper.listDataTop2W(start, length);
		if (ObjectUtils.isEmpty(TClist))
			return null;
		for (TcDetail tcDetail : TClist) {
			String key = tcDetail.getBuCode() + tcDetail.getHhPn() + tcDetail.getNewVendorCode()
					+ tcDetail.getCurrency();
			List<TcDetail> oldList = map.get(key);
			if (null == oldList) {
				oldList = new ArrayList<>();
				map.put(key, oldList);
			}
			oldList.add(tcDetail);
		}
		return map;
	}

	public Map<String, List<TcDetail>> TClistToMap(List<TcDetail> TClist) {
		Map<String, List<TcDetail>> map = new HashMap<>();
		if (ObjectUtils.isEmpty(TClist))
			return null;
		for (TcDetail tcDetail : TClist) {
			String key = tcDetail.getBuCode() + tcDetail.getHhPn() + tcDetail.getNewVendorCode()
					+ tcDetail.getCurrency();
			List<TcDetail> oldList = map.get(key);
			if (null == oldList) {
				oldList = new ArrayList<>();
				map.put(key, oldList);
			}
			oldList.add(tcDetail);
		}
		return map;
	}

	@Override
	
	public int delTcByMd5(List<String> MD5List) {
		int i = 0;
		for (List<String> splitList:Lists.partition(MD5List, 200)) {
			i += tcDetailMapper.delTcByMd5(splitList);
		}
		return i;
	}

	
	
	public static void main(String[] args) {
		exChangeEntity e1 = new exChangeEntity();
		e1.setExchangeDate("aaa");
		exChangeEntity e2 = new exChangeEntity();
		e2.setExchangeDate("bbb");
		ArrayList<exChangeEntity> list = new ArrayList<exChangeEntity>();
		list.add(e1);
		list.add(e2);
		for (exChangeEntity data : list) {
			data.setExchangeNum(1d);
		}
		System.out.println(list);
	}
}
