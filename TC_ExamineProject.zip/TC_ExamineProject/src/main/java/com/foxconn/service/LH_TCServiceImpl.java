package com.foxconn.service;

import com.foxconn.entity.LH_TCDetails;
import com.foxconn.mapper.LH_TCDetailsMapper;
import com.foxconn.utils.ExcelUtil;
import com.google.common.collect.Lists;

import java.util.Arrays;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;

@Service
public class LH_TCServiceImpl implements LH_TCService {
	@Autowired
	private LH_TCDetailsMapper mapper;

	public int addLH_TClist(List<LH_TCDetails> LH_TClist) {
		List<String> fieldList = Arrays.asList(new String[] { "bu", "tradeType", "formHead", "changshangCode",
				"changshangName", "hhVendorCode", "stockinCode", "stockinTime", "pruchaseCode", "materiel", "unit",
				"unsettledNum", "currency", "poPrice", "stockinMoney", "actualPrice", "acPrice2", "apPrice", "apPrice2",
				"action", "effectiveDate", "effectiveWay", "hhPaycondition", "hfjPaycondition", "poPaycondition","apDri",
				"free", "writetime", "purchaseDate", "tcEffectiveWay", "tcEffectiveDate", "tcExpireDate", "tcApPrice",
				"tcAcPrice", "tcApplePrice", "tcAction", "tcPaymentTerm", "tcUpDri", "tcOk", "msAcPrice", "msApPrice",
				"msEffectivedate", "msExchangeRate", "billCode", "billDate", "billPrice", "billMoney", "payDate",
				"urgent", "jbCode","jbtime", "poMinusBill", "billMinusAp", "apMinusAc", "apMinusApple" });

		int i = 0;
		if (LH_TClist.size() > 50) {
			List<List<LH_TCDetails>> splitList = ExcelUtil.splitList(LH_TClist, 50);
			for (List<LH_TCDetails> list : splitList) {
				i += this.mapper.addLH_TClist(list, fieldList);
			}
		} else {
			i = this.mapper.addLH_TClist(LH_TClist, fieldList);
		}
		return i;
	}

	public int delLH_TCByCondition(String condition, String param) {
		Example example = new Example(LH_TCDetails.class);
		Example.Criteria criteria = example.createCriteria();
		criteria.andEqualTo(param, condition);
		return this.mapper.deleteByExample(example);
	}

	public List<String> getLH_TCWriteTime(String startDate, String endDate) {
		return this.mapper.getLH_TCWriteTime(startDate, endDate);
	}

	public List<LH_TCDetails> getLH_TCResultByWritetime(String writetime) {
		Example example = new Example(LH_TCDetails.class);
		Example.Criteria criteria = example.createCriteria();
		criteria.andEqualTo("writetime", writetime);
		return this.mapper.selectByExample(example);
	}

	@Override
	public List<LH_TCDetails> listNeedCheckData() {
		// TODO Auto-generated method stub
		return this.mapper.listNeedCheckData();
	}

	@Override
	public int updateLH_TClist(List<LH_TCDetails> dataList) {
		// TODO Auto-generated method stub
		int i = 0;
		if (dataList.size() > 300) {
			for (List<LH_TCDetails> list : Lists.partition(dataList, 300)) {
				i += this.mapper.updateLH_TClist(list);
			}
			;
		}
		return i;
	}

	@Override
	public List<LH_TCDetails> getLHFromJStable() {
		// TODO Auto-generated method stub
		return mapper.getLHFromJStable();
	}

	@Override
	public List<LH_TCDetails> listDataByJbtime(String startTime, String endTime) {
		// TODO Auto-generated method stub
		return mapper.listDataByJbtime(startTime, endTime);
	}

	@Override
	public List<LH_TCDetails> listFreeHasNoCheckData() {
		// TODO Auto-generated method stub
		return mapper.listFreeHasNoCheckData();
	}
}
