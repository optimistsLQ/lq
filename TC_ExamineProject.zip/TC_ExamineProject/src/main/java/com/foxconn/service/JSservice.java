package com.foxconn.service;

import java.util.List;

import com.foxconn.entity.JSDetail;

public interface JSservice {

	public List<JSDetail> listMS_LHdata(String startTime, String endTime);

	public int updateHasCheck(List<String> stockInCodeList);

}
