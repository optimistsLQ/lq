package com.foxconn.service;

import com.foxconn.entity.LH_TCDetails;
import java.util.List;

public abstract interface LH_TCService
{
  public abstract int addLH_TClist(List<LH_TCDetails> paramList);
  
  public abstract int delLH_TCByCondition(String paramString1, String paramString2);
  
  public abstract List<String> getLH_TCWriteTime(String paramString1, String paramString2);
  
  public abstract List<LH_TCDetails> getLH_TCResultByWritetime(String paramString);

/**结果表里查询所有未进行二次匹配的数据
 * @return
 */
public abstract List<LH_TCDetails> listNeedCheckData();

public abstract int updateLH_TClist(List<LH_TCDetails> dataList);

public abstract List<LH_TCDetails> getLHFromJStable();

public abstract List<LH_TCDetails> listDataByJbtime(String startTime, String endTime);

public abstract List<LH_TCDetails> listFreeHasNoCheckData();
}
