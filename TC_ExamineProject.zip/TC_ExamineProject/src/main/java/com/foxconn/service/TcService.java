package com.foxconn.service;

import com.foxconn.entity.LH_TCDetails;
import com.foxconn.entity.TcDetail;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

public abstract interface TcService
{
  /**先根据md5list删除之前的重复数据，再插入paramList里的所有数据
 * @param MD5List 《String》 需要先删除的以前的重复数据
 * @param paramList 需要插入的新数据
 * @return 返回插入条数和删除的条数
 */
public abstract int addTCList(List<TcDetail> paramList);
  
  public abstract int delTC();
  
  public abstract List<TcDetail> listTCByClickVersion(String paramString);
  
//  public abstract String CompearLHandTC(List<LH_TCDetails> lhList, Map<String, List<TcDetail>> paramMap,boolean bool);
//  public abstract Map<String,Object> CompearLHandTC_second(List<LH_TCDetails> lH_TClist,Map<String, List<TcDetail>> tCMap);
  
  public abstract List<String> getDateListByDateTime(String paramString);
  
  /**分页查询TC报表资料2万条
 * @return
 */
  public abstract Map<String, List<TcDetail>> getTCSourceTop2W(int start, int length);
  
  public abstract Map<String, List<TcDetail>> TClistToMap(List<TcDetail> paramList);
  
  int delTcByMd5(List<String> MD5List);

}
