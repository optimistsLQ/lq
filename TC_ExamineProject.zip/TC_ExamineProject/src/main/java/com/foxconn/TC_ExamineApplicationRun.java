package com.foxconn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import tk.mybatis.spring.annotation.MapperScan;

@SpringBootApplication
@MapperScan({ "com.foxconn.mapper" })
public class TC_ExamineApplicationRun {
	public static void main(String[] args) {
		SpringApplication.run(TC_ExamineApplicationRun.class, args);
	}
}
