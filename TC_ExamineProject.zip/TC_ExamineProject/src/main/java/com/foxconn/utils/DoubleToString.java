package com.foxconn.utils;

import java.text.DecimalFormat;
import java.text.NumberFormat;

public class DoubleToString {

	private DecimalFormat df = new DecimalFormat( "0.0000000" );
	public  String doubleToStr(Double doub) {
		return df.format(doub);
		
	}
	public static void main(String[] args) {
		DoubleToString s = new DoubleToString();
//		for(int i = 0;i < 100; i++) {
//			System.out.println(s.doubleToStr(23.586457456464d));
//		}
		
		Double a = 0.0007165d;
		 
		System.out.println(s.doubleToStr(a));
	}
}
