package com.foxconn.utils;

import com.github.nobodxbodon.zhconverter.简繁转换类;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.CellValue;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFFormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Utils {
	public static boolean isNumeric(String str) {
		Pattern pattern = Pattern.compile("^-?\\d+(\\.\\d+)?$");
		Matcher isNum = pattern.matcher(str);
		if (!isNum.matches())
			return false;
		return true;
	}

	public static String underlineToHump(String underlineByName) {
		StringBuilder result = new StringBuilder();
		String[] tempArray = underlineByName.split("_");
		for (String elements : tempArray) {
			if (result.length() == 0) {
				result.append(elements.toLowerCase());
			} else {
				result.append(elements.substring(0, 1).toUpperCase());
				result.append(elements.substring(1).toLowerCase());
			}
		}
		return result.toString();
	}

	public static String humpToLine(String str) {
		Matcher matcher = Pattern.compile("[A-Z]").matcher(str);
		StringBuffer sb = new StringBuffer();
		while (matcher.find())
			matcher.appendReplacement(sb, "_" + matcher.group(0));
		matcher.appendTail(sb);
		return sb.toString().toUpperCase();
	}

	public static <T> List<T> readExcel(InputStream in, Class<T> cla) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try (XSSFWorkbook workbook = new XSSFWorkbook(in)) {
			XSSFSheet sheet0 = workbook.getSheetAt(0);
			XSSFFormulaEvaluator xSSFFormulaEvaluator = workbook.getCreationHelper().createFormulaEvaluator();
			int maxRowNum = sheet0.getPhysicalNumberOfRows();
			int maxColNum = sheet0.getRow(0).getPhysicalNumberOfCells();
			Map<String, List<Object>> map = new HashMap<>();
			for (int c = 0; c < maxColNum; c++) {
				ArrayList<Object> colList = new ArrayList();
				for (int r = 1; r < maxRowNum; r++) {
					XSSFRow rows = sheet0.getRow(r);
					XSSFCell cell = rows.getCell(c);
					if (null == cell) {
						colList.add("");
					} else {
						double value;
						CellValue evaluate;
						CellType cellTypeEnum, cellType = cell.getCellTypeEnum();
						switch (cellType.ordinal()) {
						case 1:
							colList.add(cell.getStringCellValue().trim());
							break;
						case 2:
							value = cell.getNumericCellValue();
							if (HSSFDateUtil.isCellDateFormatted((Cell) cell)) {
								Date dateValue = HSSFDateUtil.getJavaDate(value);
								colList.add(sdf.format(dateValue));
								break;
							}
							if (Double.toString(value).contains("E")) {
								NumberFormat nf = NumberFormat.getInstance();
								nf.setMaximumFractionDigits(2);
								nf.setGroupingUsed(false);
								colList.add(nf.format(value));
								break;
							}
							colList.add(Double.toString(cell.getNumericCellValue()));
							break;
						case 3:
							evaluate = xSSFFormulaEvaluator.evaluate((Cell) cell);
							cellTypeEnum = evaluate.getCellTypeEnum();
							switch (cellTypeEnum.ordinal()) {
							case 1:
								colList.add(cell.getStringCellValue());
								break;
							case 2:
								value = cell.getNumericCellValue();
								if (HSSFDateUtil.isCellDateFormatted((Cell) cell)) {
									Date dateValue = HSSFDateUtil.getJavaDate(value);
									colList.add(sdf.format(dateValue));
									break;
								}
								if (Double.toString(value).contains("E")) {
									NumberFormat nf = NumberFormat.getInstance();
									nf.setMaximumFractionDigits(2);
									nf.setGroupingUsed(false);
									colList.add(nf.format(value));
									break;
								}
								colList.add(Double.toString(cell.getNumericCellValue()));
								break;
							}
							colList.add("");
							break;
						default:
							colList.add("");
							break;
						}
					}
				}
				String key = (String) colList.get(0);
				colList.remove(0);
				map.put(key, colList);
			}
			return converJavaListBean(map, cla);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (null != in)
					in.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	private static <T> List<T> converJavaListBean(Map<String, List<Object>> map, Class<T> cla) throws Exception {
		List<T> result = new ArrayList<>();
		String firstKey = null;
		Map<String, String> methodNameMap = new HashMap<>();
		Map<String, String> methodParameterType = new HashMap<>();
		for (Method m : cla.getDeclaredMethods()) {
			String methodName = m.getName();
			if (methodName.startsWith("set")) {
				methodName = methodName.substring(3);
				methodName = methodName.substring(0, 1).toLowerCase() + methodName.substring(1);
				if (map.containsKey(methodName)) {
					methodNameMap.put(methodName, m.getName());
					methodParameterType.put(methodName, m.getParameterTypes()[0].getName());
					if (firstKey == null)
						firstKey = methodName;
				}
			}
		}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		for (int i = 0; i < ((List) map.get(firstKey)).size(); i++) {
			Object newObj = cla.newInstance();
			Integer ii = new Integer(i);
			map.forEach((field, list) -> {
				try {
					Method setMethod = newObj.getClass().getMethod((String) methodNameMap.get(field),
							new Class[] { Class.forName((String) methodParameterType.get(field)) });
					if (setMethod.getParameterCount() == 1)
						switch (setMethod.getParameterTypes()[0].getSimpleName()) {
						case "String":
							setMethod.invoke(newObj, new Object[] { list.get(ii.intValue()).toString() });
							break;
						case "Integer":
							setMethod.invoke(newObj, new Object[] {
									Integer.valueOf((int) Double.parseDouble(list.get(ii.intValue()).toString())) });
							break;
						case "Double":
							setMethod.invoke(newObj, new Object[] {
									Double.valueOf(Double.parseDouble(list.get(ii.intValue()).toString())) });
							break;
						case "Date":
							setMethod.invoke(newObj, new Object[] { sdf.parse(list.get(ii.intValue()).toString()) });
							break;
						}
				} catch (Exception e) {
					e.printStackTrace();
				}
			});
			result.add((T) newObj);
		}
		return result;
	}

	public static <T> T mapToJavabean(Map<String, Object> objMap, Class<T> cla) {
		Object obj = null;
		try {
			obj = cla.newInstance();
			Method[] methods = cla.getDeclaredMethods();
			for (Method m : methods) {
				if (m.getName().startsWith("set")) {
					String _name = m.getName().substring(3);
					String objMapKey = humpToLine(_name).substring(1);
					Object value = objMap.get(objMapKey);
					if (value instanceof BigDecimal) {
						if (m.getParameters()[0].getType().getSimpleName().equals("Integer")) {
							m.invoke(obj, new Object[] { Integer.valueOf(((BigDecimal) value).intValue()) });
						} else {
							m.invoke(obj, new Object[] { Double.valueOf(((BigDecimal) value).doubleValue()) });
						}
					} else if (value instanceof String) {
						m.invoke(obj, new Object[] { value });
					} else {
						m.invoke(obj, new Object[] { value });
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return (T) obj;
	}

	public static String simplifiedConverter(String str) {
		return 简繁转换类.转换(str.trim().replaceAll("'", ""), 简繁转换类.目标.繁体);
	}

	public static String systemDate(String format) {
		SimpleDateFormat dateFormat = new SimpleDateFormat(format);
		return dateFormat.format(new Date());
	}

	public static Date dateStrParse(String dateStr, String format) {
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat(format);
			return dateFormat.parse(dateStr);
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
	}

	public static String dateFormatStr(Object date, String format) {
		SimpleDateFormat dateFormat = new SimpleDateFormat(format);
		return dateFormat.format(date);
	}

	public static <T> List<T> ListDeepCopy(List<T> src) {
		if (src == null)
			return null;
		ByteArrayOutputStream byteOut = null;
		ObjectOutputStream out = null;
		ByteArrayInputStream byteIn = null;
		ObjectInputStream in = null;
		try {
			byteOut = new ByteArrayOutputStream();
			out = new ObjectOutputStream(byteOut);
			out.writeObject(src);
			byteIn = new ByteArrayInputStream(byteOut.toByteArray());
			in = new ObjectInputStream(byteIn);
			List<T> dest = (List<T>) in.readObject();
			return dest;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (byteOut != null)
					byteOut.close();
				if (out != null)
					out.close();
				if (byteIn != null)
					byteIn.close();
				if (in != null)
					in.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public static Map<String, String> readTXT() {
		Map<String, String> map = new HashMap<>();
		Properties pro = new Properties();
		try (FileInputStream in = new FileInputStream("DataSource.properties")) {
			pro.load(in);
			Enumeration<?> enum1 = pro.propertyNames();
			while (enum1.hasMoreElements()) {
				String strKey = (String) enum1.nextElement();
				String strValue = pro.getProperty(strKey);
				map.put(strKey, strValue);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return map;
	}

	public static <T> T deepCopy(T src) {
		try (ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
				ObjectOutputStream out = new ObjectOutputStream(byteOut)) {
			out.writeObject(src);
			try (ByteArrayInputStream byteIs = new ByteArrayInputStream(byteOut.toByteArray());
					ObjectInputStream in = new ObjectInputStream(byteIs);) {
				return (T) in.readObject();
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	/**判断两个字符串类型的数字之差的绝对值是否小于0.0001
	 * @param a
	 * @param b
	 * @return 差值的绝对值小于0.0001返回true，否则返回false
	 */
	public static boolean equalData(String a, String b) {
		Double val = Double.valueOf(a) - Double.valueOf(b);
		if (Math.abs(val) <= 0.0001) {
			return true;
		} else {
			return false;
		}
	}
	
	public static String getUUID() {
		return UUID.randomUUID().toString().trim().replaceAll("-", "");
	}
}
