package com.foxconn.utils;

import com.foxconn.utils.TiptopClient;
import com.foxconn.utils.Toolkit;
import com.foxconn.utils.Utils;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;

@Configuration
public class TiptopData {
	private static final Logger logger = LoggerFactory.getLogger(com.foxconn.utils.TiptopData.class);

	/**获取采购日期
	 * @return map《采购单号，采购时间》
	 */
	public Map<String, String> getPurchaseDateFromTiptop() {
	SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
	Calendar calendar = Calendar.getInstance();
	calendar.setTime(new Date());
	calendar.add(Calendar.YEAR, -1);
	Date last_Year = calendar.getTime();
	String lastYear = sdf.format(last_Year);
    List<String> fileNameList = new ArrayList<>();
    Map<String, String> txtMap = Utils.readTXT();
    logger.info("---tiptop开始爬取采购日期---");
    String tiptop_loginName = txtMap.get("tiptop_loginName");
    String tiptop_passWord = txtMap.get("tiptop_passWord");
    String tiptop_ip = txtMap.get("tiptop_IP");
    TiptopClient tiptopClient = new TiptopClient();
    boolean bool = tiptopClient.connection(tiptop_ip, 23);
    if (!bool) {
      logger.info("tiptop");
      return null;
    } 
    String loginResult = tiptopClient.login(tiptop_loginName, tiptop_passWord, "HFCCD0WMLB");
    System.out.println("Tiptop+ loginResult");
    if (loginResult.equals("ok")) {
      tiptopClient.setDownFilePrefix("MLB");
      String MLBfileName = tiptopClient.sendCommand("3\n6\n7\n\n\n\n>="+lastYear+"\n\n\n\n\n\n", true);
      System.out.println("MLBfileName :" + MLBfileName);
      fileNameList.add(MLBfileName);
      tiptopClient.sendCommand("[ESC][DELETE][CTRL+P]");
      tiptopClient.sendCommand("HFCCD0WNPI\n");
      tiptopClient.setDownFilePrefix("NPI");
      String NPIfileName = tiptopClient.sendCommand("\n\n\n\n>="+lastYear+"\n\n\n\n\n\n", true);
      System.out.println("NPIfileName :" + NPIfileName);
      fileNameList.add(NPIfileName);
      tiptopClient.sendCommand("[ESC][DELETE][CTRL+P]");
      tiptopClient.sendCommand("HFCCD0WAT \n");
      tiptopClient.setDownFilePrefix("WAT");
      String WATfileName = tiptopClient.sendCommand("\n\n\n\n>="+lastYear+"\n\n\n\n\n\n", true);
      System.out.println("WATfileName :" + WATfileName);
      fileNameList.add(WATfileName);
      txtMap = resolveFile(fileNameList);
    } else {
    	logger.info("tiptop爬取採購日期"+loginResult);
    }
    tiptopClient.disconnect();
    return txtMap;
  }

	public Map<String, String> resolveFile(List<String> fileNameList) {
		Map<String, String> map = new HashMap<>();
		for (String fileName : fileNameList) {
			FileReader fileReader = null;
			BufferedReader br = null;
			File txtFile = new File(fileName);
			try {
				fileReader = new FileReader(txtFile);
				br = new BufferedReader(fileReader);
				String line = null;
				while ((line = br.readLine()) != null) {
					String str = Toolkit.findStr(line, "[A-Za-z0-9]+\\-{1}[A-Za-z0-9]+\\-{1}\\s*\\d+\\s+\\d+");
					if (str != null) {
						String purchaseCode = Toolkit.findStr(str, "[A-Za-z0-9]+\\-{1}[A-Za-z0-9]+");
						String purchaseDate = Toolkit.findStr(str, "\\d{8,10}");
						purchaseDate = purchaseDate.substring(0, 4) + "-" + purchaseDate.substring(4, 6) + "-"
								+ purchaseDate.substring(6);
						map.put(purchaseCode, purchaseDate);
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
				break;
			} finally {
				try {
					if (fileReader != null)
						fileReader.close();
					if (br != null)
						br.close();
					if (txtFile.exists())
						txtFile.delete();
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
		}
		return map;
	}

	public static void main(String[] args) {
//		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
//		String today = sdf.format(new Date());
//		System.out.println(today);
		com.foxconn.utils.TiptopData T = new com.foxconn.utils.TiptopData();
		Map<String, String> map = T.getPurchaseDateFromTiptop();
		map.forEach((k,v) ->{
			System.out.println(k+" - "+v);
		});
	}
}
