package com.foxconn.utils;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;

public class AdapterAnalysisEventListener<T> extends AnalysisEventListener<T> {
	public void invoke(T data, AnalysisContext context) {
	}

	public void doAfterAllAnalysed(AnalysisContext context) {
	}
}
