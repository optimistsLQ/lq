package com.foxconn.utils;
/**
 * DES加密解密算法
 */


import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.JSONReader;
import com.foxconn.entity.GrnEntity;
import com.google.common.collect.Lists;
public class api_lahuo {

	/**
	 * DES加密算法
	 * @param encryptString 要加密的字符串
	 * @param sKey 加密碼Key
	 * @return 正確返回加密后的結果，錯誤返回原字符串
	 * @throws Exception
	 */
    public static String ToDESEncrypt(String encryptString, String sKey){
		// 加密碼Key必須8位 不夠補齊，長了截取
		if (sKey.length() < 8) {
			int length = sKey.length();
			for (int i = 0; i < 8 - length; i++) {
				sKey += i;
			}
		} else {
			sKey = sKey.substring(0, 8);
		}

		try {
			byte[] data = encryptString.getBytes("UTF-8");
			byte[] key = sKey.getBytes("UTF-8");

			// 從原始密鈅數據創建DESKeySpec對象
			DESKeySpec dks = new DESKeySpec(key);

			// 創建一個密鈅工廠，然後用它把DESKeySpec轉換成SecretKey對象
			SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
			SecretKey securekey = keyFactory.generateSecret(dks);

			// Cipher對象實際完成加密操作
			Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");

			// 用密鈅初始化Cipher對象
			cipher.init(Cipher.ENCRYPT_MODE, securekey,
					new IvParameterSpec(key));

			byte[] bt = cipher.doFinal(data);

			return byteToHexString(bt);
		} 
		catch (Exception e) {
			return encryptString;
		}
    }
    
    /**
     * DES解密算法
     * @param decryptString 要解密的字符串
     * @param sKey 加密Key
     * @return 正確返回解密后的結果，錯發返回原字符串
     */
    public static String ToDESDecrypt(String decryptString, String sKey){
		if (decryptString == null)
			return null;

		try {
			// 加密碼Key必須8位 不夠補齊，長了截取
			if (sKey.length() < 8) {
				int length = sKey.length();
				for (int i = 0; i < 8 - length; i++) {
					sKey += i;
				}
			} else {
				sKey = sKey.substring(0, 8);
			}

			byte[] data = hexStringToByte(decryptString);
			byte[] key = sKey.getBytes("UTF-8");

			// 從原始密鈅數據創建DESKeySpec對象
			DESKeySpec dks = new DESKeySpec(key);

			// 創建一個密鈅工廠，然後用它把DESKeySpec轉換成SecretKey對象
			SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
			SecretKey securekey = keyFactory.generateSecret(dks);

			// Cipher對象實際完成解密操作
			Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");

			// 用密鈅初始化Cipher對象
			cipher.init(Cipher.DECRYPT_MODE, securekey,
					new IvParameterSpec(key));

			byte[] bt = cipher.doFinal(data);

			return new String(bt, "UTF-8");
		} catch (Exception e) {
			return decryptString;
		}
    }
    
    //Byte數據轉16進制字符串
    private static String byteToHexString(byte[] bytes) {
        StringBuffer sb = new StringBuffer(bytes.length);
        String sTemp;
        for (int i = 0; i < bytes.length; i++) {
            sTemp = Integer.toHexString(0xFF & bytes[i]);
            if (sTemp.length() < 2)
                sb.append(0);
            sb.append(sTemp.toUpperCase());
        }
        return sb.toString();
    }
    
    //16進制字符串轉byte數組
    private static byte[] hexStringToByte(String hex) {
    		int len = (hex.length() / 2);
    		byte[] result = new byte[len];
    		char[] achar = hex.toCharArray();
    		for (int i = 0; i < len; i++) {
    			int pos = i * 2;
    	    		result[i] = (byte) (toByte(achar[pos]) << 4 | toByte(achar[pos + 1]));
    		}
    		return result;
    }
    	  
    private static int toByte(char c) {
    		byte b = (byte) "0123456789ABCDEF".indexOf(c);
    		return b;
    }
    
	/**
	 * 將16進制的字符串還原成byte[]
	 **/
	private static byte[] toByte(String str) {
		char[] c = str.toUpperCase().toCharArray();
		byte[] b = new byte[c.length / 2];
		for (int i = 0; i < b.length; i++) {
			int pos = i * 2;
			b[i] = ((byte) ("0123456789ABCDEF".indexOf(c[pos]) << 4 | "0123456789ABCDEF".indexOf(c[(pos + 1)])));
		}
		return b;
	}
	
	/**
	 * 將byte[]轉換為16進制字符串
	 **/
	private static String to16(byte[] b, int len) {
		StringBuffer buffer = new StringBuffer();
		for (int i = 0; i < len; i++) {
			if ((b[i] & 0xFF) < 16) {
				buffer.append("0");
			}
			buffer.append(Long.toString(b[i] & 0xFF, 16));
		}
		return buffer.toString();
	}
	
	public List<GrnEntity> getERPData(List<String> dris){
		List<GrnEntity> resultList = new ArrayList<GrnEntity>();
    	SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy/MM/dd");
    	// 获取token  1,封装获取token的参数并进行加密
    	 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
    	 Map<String, String> map = new LinkedHashMap<String, String>();
    	 //“{ ‘userId’:’xx’, ‘password’:’xx’, ‘applyTime’ :’xx’}”
    	 map.put("userId", "CDWATGRN");
    	 map.put("password", "erp123.");
    	 map.put("applyTime", sdf.format(new Date()));
    	 String jsonString = JSONObject.toJSONString(map);
//    	 System.out.println(jsonString);
        // 得到加密信息
    	 String toDESEncrypt = api_lahuo.ToDESEncrypt(jsonString, "1qaz@WSX");
    	 HttpResponse response2 = null;
    	 try {
	    	 HttpClient httpClient = HttpClients.createDefault();
	    	 HttpPost post = new HttpPost("http://10.134.82.99:8133/api/Token/GetToken");
	    	 //10.134.82.99:8133/tiptop/NoClaim/getNcGRData
	    	 post.setHeader("Content-Type", "application/json");
	    	 
	    	 JSONObject param = new JSONObject();
	    	 param.put("userInfo", toDESEncrypt);
	    	 StringEntity requestentity = new StringEntity(param.toString(),"utf-8");
	    	 post.setEntity(requestentity);
	    	 // 请求token
	    	 HttpResponse response = httpClient.execute(post);
	    	 String str = EntityUtils.toString(response.getEntity());
	    	 // 解密得到token
	    	 String token = api_lahuo.ToDESDecrypt(str.replaceAll("\"", ""), "erp123.");
	         // 爬去數據
	    	 HttpGet get = new HttpGet("http://10.134.82.99:8133/tiptop/NoClaim/getNcGRData");
	    	 get.setHeader("Authorization","Bearer " + token);
	    	 get.setHeader("Content-Type", "application/json");
	    	 // 得到返回的数据
			 response2 = httpClient.execute(get);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} 
    	 
    	 File tempFile = new File(UUID.randomUUID().toString() + ".txt");
    	 // 将数据去掉斜杠并存入TXT临时文件
    	 try (FileOutputStream fos = new FileOutputStream(tempFile);
    		  InputStream is = response2.getEntity().getContent();){
    		 
    		 byte [] b = new byte[1024];
    		 int len = 0;
    		 while ((len = is.read(b)) != -1) {
    			 // \ 5c  "[ 225b ]" 5d22 [ 5b ] 5d
    			 String to16 = to16(b, len);
    			 to16 = to16.replaceAll("5c", "");
    			 to16 = to16.replaceAll("225b", "5b");
    			 to16 = to16.replaceAll("5d22", "5d");
    			 fos.write(toByte(to16));
    			 fos.flush();
    		 }
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
    	 // 解析TXT文件获取数据，并转换成对象放入resultList
    	 JSONReader jsonReader = null;
    	 try {
	    	 jsonReader = new JSONReader(new FileReader(tempFile));
	    	 jsonReader.startArray();
	    	 while (jsonReader.hasNext()) {
	    		 HashMap<String, Object> obj = jsonReader.readObject(HashMap.class);
	    		 Map<String, Object> newObj = new HashMap<>();
	    		 obj.forEach((k,v) -> {
	    			 
	    			// 处理所有免费样品
	    			 if ("HN".equals(k)) {
//	    				 System.out.println("----");
	    				 if (v.toString().contains("樣品採") || v.toString().contains("con") || v.toString().contains("Con")
	    						 || v.toString().contains("Free") || v.toString().contains("免") || v.toString().contains("換")
	    						 || v.toString().contains("free") || v.toString().contains("吸收製 ")) {
	    					 newObj.put("free", "Y");		
	    				 } else {
	    					 newObj.put("free", "N");
	    				 }
	    			 }
	    			// 处理日期格式
	    			 if ("SD".equals(k) || "ED".equals(k)) {
	    				 if (ObjectUtils.isNotEmpty(v)) {
	    					 String dateStr = v.toString().split("\\s+")[0];
	    					 try {
	    						 v = sdf2.format(sdf2.parse(dateStr));
	    					 } catch (ParseException e) {
	    						 // TODO Auto-generated catch block
//	    						 System.out.println("*********");
	    						 e.printStackTrace();
	    					 }
	    				 }
	    			 }
	    			 
	    			 
	    			 // 处理dri为空
//	    			 if ("DRI".equals(k)) {
//	    				 if (ObjectUtils.isNotEmpty(v)) {
////	    					 System.out.println("dri不为空");
//	    					 if (!dris.contains(v)) {
//	    						 return;
//	    					 }
//	    				 }
//	    			 }
	    			 newObj.put(k.toString().toLowerCase(), v);
	    		 });
//	    			 GrnEntity grnEntity = GrnEntity.class.newInstance();
//					 BeanUtils.populate(grnEntity, newObj);
		    		 String objstr = JSONObject.toJSONString(newObj);
		    		 GrnEntity grnEntity = JSONObject.parseObject(objstr, GrnEntity.class);
		    		 if (dris.contains(grnEntity.getDri())) {
		    			 grnEntity.setUserCard("admin");
		    			 resultList.add(grnEntity);
		    			 
		    		 }
	    	 }
    	 } catch (Exception e) {
    		 // TODO Auto-generated catch block
    		 e.printStackTrace();
    	 } finally {
    		 if (jsonReader != null) {
    			 jsonReader.endArray();
    			 jsonReader.close();
    		 }
    		 tempFile.delete();
    	 }
    	 for (GrnEntity grnEntity : resultList) {
			System.out.println(grnEntity);
		}
    	 System.out.println("获取拉货明细数量："+resultList.size());
    	 return resultList;
	}
	public static void main(String[] args) {
		api_lahuo lahuo = new api_lahuo();
		lahuo.getERPData(Arrays.asList("屈堯","謝唐靈"));
	}
}

