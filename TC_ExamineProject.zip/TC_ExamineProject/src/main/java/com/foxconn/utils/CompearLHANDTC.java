package com.foxconn.utils;

import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.foxconn.entity.LH_TCDetails;
import com.foxconn.entity.LH_TC_MSobj;
import com.foxconn.entity.TcDetail;
import com.foxconn.mapper.JSDetailMapper;
import com.foxconn.service.LH_TCService;
import com.foxconn.service.LH_TC_MSobjService;
import com.foxconn.service.TCServiceImpl;
import com.foxconn.service.TcService;
import com.google.common.collect.Lists;

@Component
public class CompearLHANDTC {
	private static final Logger logger = LoggerFactory.getLogger(TCServiceImpl.class);

	@Autowired
	private TcService tcService;

	@Autowired
	private TiptopData tiptop;

	@Autowired
	private LH_TCService LH_TCServiceimpl;
	@Autowired
	private JSDetailMapper JSDetailMappers;
	@Autowired
	private LH_TC_MSobjService LH_TC_MSservice;

	@Transactional
	public Map<String, Object> CompearLHandTC(List<LH_TC_MSobj> lhList, Map<String, List<TcDetail>> TCMap, boolean bool) {
		logger.info("TC_LH第一次开始对比，拉货list："+lhList.size() +" tc_size:"+TCMap.size());
		DecimalFormat df = new DecimalFormat( "0.0000000" );
		Map<String, Object> resultMap = new HashMap<>();
		Date now = new Date();
		String nowTime = Utils.dateFormatStr(now, "yyyyMMddHHmmss");
//		StringBuffer minStockInDate = new StringBuffer();
		Map<String, String> purchaseDateMap = null;
		if (bool == true) {
			// 去tiptop爬取采购时间《采购单号，采购时间》
			purchaseDateMap = tiptop.getPurchaseDateFromTiptop();
			if (ObjectUtils.isEmpty(purchaseDateMap)) {
				resultMap.put("msg", "NG,对比失败~tiptop爬取采购日期失败");
				return resultMap;
			}
			
		}
		int aa = 0;
//		List<LH_TCDetails> resultList = new ArrayList<>();
//		long minStockInTime = 0l;
			
				for (LH_TC_MSobj LH_TC : lhList) {
					 LH_TC.setWritetime(nowTime);// 设置写入时间
				    String stockinTime = LH_TC.getStockinTime();
//				    Date stockinDate = Utils.dateStrParse(stockinTime, "yyyy-MM-dd");
				    // 寻找最早的入库日期---
//				    long temp = now.getTime() - stockinDate.getTime();
//				    if (minStockInTime < temp) {
//				      minStockInTime = temp;
//				      minStockInDate.delete(0, minStockInDate.length());
//				      minStockInDate.append(stockinTime);
//				    }
				 // 寻找最早的入库日期---
				    // 根据采购单号获取采购日期
				    String purchaseDate = LH_TC.getPurchaseDate();
				    if (bool) {
				    	
				    	purchaseDate = purchaseDateMap.get(LH_TC.getPruchaseCode());
				    	LH_TC.setPurchaseDate(purchaseDate);
				    }
				    
				    boolean HhVendorCodeHasVal;
				    String changshang;
				    if (LH_TC.getHhVendorCode() != null)
				    {
				      changshang = LH_TC.getHhVendorCode();
				      HhVendorCodeHasVal = true;
				    } else {
				      changshang = LH_TC.getChangshangCode();
				      HhVendorCodeHasVal = false;
				    }
				    String LHkey = LH_TC.getBu() + LH_TC.getMateriel() + changshang + LH_TC.getCurrency();
				    //----------------
//				    if (LHkey.equals("FATP604-33088-LF-2D-FVHK0010441USD")) {
//				    	System.out.println("ceshi");
//				    }
				    //----------------
				    List<TcDetail> TcList = TCMap.get(LHkey);
				    if ((TcList != null) && (TcList.size() != 0)) {// 拉货和TC匹配上
					      List<TcDetail> TcOKList = new ArrayList<>();// 存放比对OK且符合条件的TcDetail
					      
					      String effectiveWay = TcList.get(0).getEffectiveWay().replaceAll("\\s*", "").toUpperCase();
					      for (TcDetail tcDetail : TcList) {
						        String effectiveDate = tcDetail.getEffectiveDate();
						        String expireDate = tcDetail.getExpireDate();
						        if ("BYGRN".contains(effectiveWay)) {// 通过入库日期比较
						          boolean b = findInRangeData(stockinTime, effectiveDate, expireDate);
						          if (b == true) {
						            TcOKList.add(tcDetail);
						            tcDetail.setFiled1("TC-BYGRN,入库日期匹配OK");
						          } else {
						        	  tcDetail.setFiled1("TC-BYGRN,入库日期不在范围内");
						          }
						        } else if ("BYPO".contains(effectiveWay)) {// 通过采购日期比较
						        	if (purchaseDate != null) {
							            boolean b = findInRangeData(purchaseDate, effectiveDate, expireDate);
							            if (b == true) {
							              TcOKList.add(tcDetail);
							              tcDetail.setFiled1("TC-BYPO,采购日期匹配OK");
							            } else {
							            	tcDetail.setFiled1("TC-BYPO,采购日期不在范围内");
							            }
							          } else {
							            logger.info("BYPO,没有拿到对应的采购时间");
							            tcDetail.setFiled1("BYPO,LH无采购日期，不能匹配");
							          }
						        } else {
						        	// 不是BYGRN或BYPO，没匹配
						        	tcDetail.setFiled1("LH_TC-不是BYGRN或BYPO，没匹配");
						        }
					      }
					      
					      if (TcOKList.size() == 0) {// 没有匹配上的数据，结束本次循环
					    	  LH_TC.setRemark("LH_TC匹配失败");
					    	  continue;
					      }
					      TcDetail tc;
					      
					      if (TcOKList.size() == 1) {
					        tc = TcOKList.get(0);
					      } else {
					        tc = findNearestDate(stockinTime, TcOKList);
					      }
					      if (ObjectUtils.isNotEmpty(tc)) {
					    	  aa++;
					      }
					      LH_TC.setTcEffectiveWay(tc.getEffectiveWay());
					      LH_TC.setTcEffectiveDate(tc.getEffectiveDate());
					      LH_TC.setTcExpireDate(tc.getExpireDate());
					      LH_TC.setTcApPrice(df.format(tc.getApPrice()));
					      LH_TC.setTcAcPrice(df.format(tc.getActualPrice()));
					      LH_TC.setTcApplePrice(df.format(tc.getApplePrice()));
					      LH_TC.setTcAction(tc.getAction());
					      LH_TC.setRemark(tc.getFiled1());
					      if (HhVendorCodeHasVal) {
					        LH_TC.setTcPaymentTerm(tc.getHhPayment());
					      } else {
					        LH_TC.setTcPaymentTerm(tc.getFthPayment());
					      }
					      LH_TC.setTcUpDri(tc.getUpDri());
					      LH_TC.setTcOk("TCOK");
				      } else {
				    	  // 拉货和TC没匹配上
				    	  LH_TC.setRemark("LH_TC-拉货和TC没匹配上");
				      }
					  
				   
//				    resultList.add(LH_TC);
				}
				logger.info("对比完了;aa="+aa);

				
				// 在此剔除没有匹配成功的LH，返回并再次与上板TC匹配
				List<String> OKListgrn = new ArrayList<String>();
				List<LH_TC_MSobj> OKList = new ArrayList<LH_TC_MSobj>();
				List<LH_TC_MSobj> NGList = new ArrayList<LH_TC_MSobj>();
				for (LH_TC_MSobj lh_TCDetails : lhList) {
				    // 过滤掉免费，free，从，等字样---
					
					if ("free".equals(lh_TCDetails.getFree())) {
						OKList.add(lh_TCDetails);
						OKListgrn.add(lh_TCDetails.getStockinCode());
						continue;
					}
					// 过滤掉免费，free，从，等字样---
					
					if (ObjectUtils.isNotEmpty(lh_TCDetails.getTcEffectiveWay())) {
						OKList.add(lh_TCDetails);
						OKListgrn.add(lh_TCDetails.getStockinCode());
					} else {
						NGList.add(lh_TCDetails);
					}
				}
				
				
				logger.info("OKList:"+OKList.size()+" - "+OKListgrn.size());
				// 保存对比成功的数据，并将对比成功的数据从jstable删除
				if (ObjectUtils.isNotEmpty(OKList)) {
					int i = LH_TC_MSservice.addLH_TC_MSList(OKList);
					if (OKListgrn.size() > 100) {
						for(List<String> list : Lists.partition(OKListgrn, 100)) {
							JSDetailMappers.updateJStableByGrnList(list);
						}
					} else {
						JSDetailMappers.updateJStableByGrnList(OKListgrn);
					}
				}
//				resultMap.put("msg", "对比成功~" + minStockInDate.toString());
//				resultMap.put("OKList", OKList);
				resultMap.put("NGList", NGList);
				resultMap.put("msg", String.valueOf(OKList.size()));
				return resultMap;
		} 
	

	/**判断目标日期是否在生效日期和失效日期之间
	 * @param targetTime 目标日期
	 * @param startTime 生效日期
	 * @param endTime 失效日期2021/06/07
	 * @return
	 */
	public boolean findInRangeData(String targetTime, String startTime, String endTime) {
		targetTime = targetTime.replaceAll("/", "-");
		startTime = startTime.replaceAll("/", "-");
		endTime = endTime.replaceAll("/", "-");
		
		boolean b;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate targetDate = LocalDate.parse(targetTime, formatter);
		LocalDate startDate = LocalDate.parse(startTime, formatter);
		LocalDate endDate = LocalDate.parse(endTime, formatter);
		if (targetDate.isAfter(startDate) && targetDate.isBefore(endDate)) {
			b = true;
		} else if (targetDate.isEqual(startDate) || targetDate.isEqual(endDate)) {
			b = true;
		} else {
			b = false;
		}
		return b;
	}

	public static TcDetail findNearestDate(String targetTime, List<TcDetail> TcList) {
		boolean b = true;
		TcDetail tempTcDetail = null;
		if (TcList.size() > 1) {
			Date now = new Date();
			String effectiveDate = null;
			long l = 0L;
			for (TcDetail tcDetail : TcList) {
				String date = tcDetail.getEffectiveDate();
				String tcVersion = tcDetail.getTcVersion();
				Date uploadTime = Toolkit.dateParse(tcVersion, "yyyy-MM-dd HH:mm:ss");
				long abs = now.getTime() - uploadTime.getTime();
				if (effectiveDate == null) {
					effectiveDate = date;
					l = abs;
				}
				if (effectiveDate != date)
					b = false;
				if (abs <= l) {
					l = abs;
					tempTcDetail = tcDetail;
				}
			}
		}
		if (b == true)
			return tempTcDetail;
		Date stockInTime = Toolkit.dateParse(targetTime, "yyyy-MM-dd");
		Integer temp = null;
		for (TcDetail t : TcList) {
			Date date = Toolkit.dateParse(t.getEffectiveDate(), "yyyy-MM-dd");
			int result = Math.abs(
					(int) (stockInTime.getTime() / 1000L / 60L / 60L / 24L - date.getTime() / 1000L / 60L / 60L / 24L));
			if (temp == null)
				temp = Integer.valueOf(result);
			if (result <= temp.intValue()) {
				temp = Integer.valueOf(result);
				tempTcDetail = t;
			}
		}
		return tempTcDetail;
	}
	
	

	public Map<String,Object> CompearLHandTC_second(List<LH_TCDetails> lH_TClist, Map<String, List<TcDetail>> tCMap) {
		int a = 0;
		logger.info("TC_LH第二次开始对比，拉货list："+lH_TClist.size() +" tc_size:"+tCMap.size());
		Map<String, Object> resultMap = new HashMap<>();
		Map<String, String> purchaseDateMap = tiptop.getPurchaseDateFromTiptop();// 根據採購單號爬取採購日期
		if (ObjectUtils.isEmpty(purchaseDateMap)) {
			resultMap.put("msg", "NG,对比失败~tiptop爬取采购日期失败");
			return resultMap;
		}
		
		long minStockInTime = 0l;
		Date now = new Date();
		String nowTime = Utils.dateFormatStr(now, "yyyyMMddHHmmss");
		StringBuffer minStockInDate = new StringBuffer();
		
			ArrayList<LH_TCDetails> resultList = new ArrayList<LH_TCDetails>();
		for (LH_TCDetails LH_TC : lH_TClist) {
			LH_TC.setWritetime(nowTime);
		    String stockinTime = LH_TC.getStockinTime();
		    String purchaseDate = purchaseDateMap.get(LH_TC.getPruchaseCode());
	    	LH_TC.setPurchaseDate(purchaseDate);
	    	 Date stockinDate = Utils.dateStrParse(stockinTime, "yyyy-MM-dd");
			    // 寻找最早的入库日期---
			    long temp = now.getTime() - stockinDate.getTime();
			    if (minStockInTime < temp) {
			      minStockInTime = temp;
			      minStockInDate.delete(0, minStockInDate.length());
			      minStockInDate.append(stockinTime);
			    }
			 // 寻找最早的入库日期---
	    	
		    boolean HhVendorCodeHasVal;
		    String changshang;
		    if (LH_TC.getHhVendorCode() != null)
		    {
		      changshang = LH_TC.getHhVendorCode();
		      HhVendorCodeHasVal = true;
		    } else {
		      changshang = LH_TC.getChangshangCode();
		      HhVendorCodeHasVal = false;
		    }
		    String LHkey = LH_TC.getBu() + LH_TC.getMateriel() + changshang + LH_TC.getCurrency();
		    Double tc_acPrice2 = null, tc_apPrice2 = null;
		    List<TcDetail> TcList = tCMap.get(LHkey);
		    if ((TcList != null) && (TcList.size() != 0)) {// 拉货和TC匹配上
			      List<TcDetail> TcOKList = new ArrayList<>();// 存放比对OK且符合条件的TcDetail
			      
			      String effectiveWay = TcList.get(0).getEffectiveWay().replaceAll("\\s*", "").toUpperCase();
			      for (TcDetail tcDetail : TcList) {
				        String effectiveDate = tcDetail.getEffectiveDate();
				        String expireDate = tcDetail.getExpireDate();
				        if ("BYGRN".contains(effectiveWay)) {// 通过入库日期比较
				          boolean b = findInRangeData(stockinTime, effectiveDate, expireDate);
				          if (b == true) {
				            TcOKList.add(tcDetail);
				            tcDetail.setFiled1("TC-BYGRN,入库日期匹配OK");
				          } else {
				        	  tcDetail.setFiled1("TC-BYGRN,入库日期不在范围内");
				          }
				        } else if ("BYPO".contains(effectiveWay)) {// 通过采购日期比较
				        	if (purchaseDate != null) {
					            boolean b = findInRangeData(purchaseDate, effectiveDate, expireDate);
					            if (b == true) {
					              TcOKList.add(tcDetail);
					              tcDetail.setFiled1("TC-BYPO,采购日期匹配OK");
					            } else {
					            	tcDetail.setFiled1("TC-BYPO,采购日期不在范围内");
					            }
					          } else {
					            logger.info("BYPO,没有拿到对应的采购时间");
					            tcDetail.setFiled1("BYPO,LH无采购日期，不能匹配");
					          }
				        } else {
				        	// 二次匹配时有發票日期，所以这里剩下的数据且生效方式不为空的数据根据發票日期进行匹配
				        	if (StringUtils.isNotEmpty(effectiveWay)) {
				        		String billDate = LH_TC.getBillDate();
				        		if (StringUtils.isNotEmpty(billDate)) {
				        			boolean b = findInRangeData(billDate, effectiveDate, expireDate);
				        			if (b == true) {
							              TcOKList.add(tcDetail);
							              tcDetail.setFiled1("effectiveWay其他生效方式，发票日期匹配成功");
							            } else {
							            	tcDetail.setFiled1("ByINVIOCE，发票日期不在范围内");
							            }
				        		} else {
				        			tcDetail.setFiled1("发票日期为空，不能匹配");
				        		}
				        	} else {
				        		tcDetail.setFiled1("effectiveWay生效方式为空，不能匹配");
				        	}
				        }
			      }
			      
			      if (TcOKList.size() == 0) {// 没有匹配上的数据，结束本次循环
//					    	  LH_TC.setRemark("LH_TC匹配失败");
			    	  LH_TC.setApPrice2(LH_TC.getApPrice());
			    	  LH_TC.setAcPrice2(LH_TC.getActualPrice());
			    	  resultList.add(LH_TC);
			    	  a++;
			    	  continue;
			      }
			      TcDetail tc;
			      
			      if (TcOKList.size() == 1) {
			        tc = TcOKList.get(0);
			      } else {
			        tc = findNearestDate(stockinTime, TcOKList);
			      }
			      LH_TC.setTcOk("tcok2");
			      tc_apPrice2 = tc.getApPrice();
			      if (null != LH_TC.getTcApPrice()) {// 此處第一次匹配上
			    	  Double tcApPrice1 = Double.valueOf(LH_TC.getTcApPrice());
			    	  if (tc_apPrice2 > tcApPrice1) {
			    		  LH_TC.setApPrice2("<span style='color:red'>"+String.valueOf(tc_apPrice2)+"</span>");
			    	  } else {
			    		  LH_TC.setApPrice2(String.valueOf(tc_apPrice2));
			    	  }
			    	  
			      } else {// 此處第一次沒有匹配上，但第二次匹配上了，則將第一次空格填滿
			    	  LH_TC.setTcEffectiveWay(tc.getEffectiveWay());
				      LH_TC.setTcEffectiveDate(tc.getEffectiveDate());
				      LH_TC.setTcExpireDate(tc.getExpireDate());
				      LH_TC.setTcApPrice(tc.getApPrice().toString());
				      LH_TC.setTcAcPrice(tc.getActualPrice().toString());
				      LH_TC.setTcApplePrice(tc.getApplePrice().toString());
				      LH_TC.setTcAction(tc.getAction());
				      if (HhVendorCodeHasVal) {
				        LH_TC.setTcPaymentTerm(tc.getHhPayment());
				      } else {
				        LH_TC.setTcPaymentTerm(tc.getFthPayment());
				      }
				      LH_TC.setTcUpDri(tc.getUpDri());
				      
				      LH_TC.setAcPrice2(tc.getActualPrice().toString());
				      LH_TC.setApPrice2(tc.getApPrice().toString());
			      }
//					      --------------------
			      Double tcAcPrice1 = Double.valueOf(LH_TC.getTcAcPrice());
			      tc_acPrice2 = tc.getActualPrice();
			      if (tc_acPrice2 > tcAcPrice1) {
			    	  LH_TC.setAcPrice2("<span style='color:red'>"+String.valueOf(tc_acPrice2)+"</span>");
			      } else {
			    	  LH_TC.setAcPrice2(String.valueOf(tc_acPrice2));
			      }
			      
		      } 
		    
//		    if (null != LH_TC.getBillCode()) {
//		    	logger.info("update"+LH_TC);
//		    }
			  
		    //....這裡匹配邏輯三......
		    if (StringUtils.isNotEmpty(LH_TC.getBillCode()) && StringUtils.isNotEmpty(LH_TC.getPoPrice())) {
//		    	-----------1-------------
		    	Double poPrice = Double.valueOf(LH_TC.getPoPrice());
		    	Double billPrice = Double.valueOf(LH_TC.getBillPrice());
		    	if (LH_TC.getUnit().equalsIgnoreCase("kps")) {
		    		billPrice = billPrice * 1000;
		    	}
		    	Double check1 = (poPrice - billPrice) * Double.valueOf(LH_TC.getUnsettledNum());
		    	if (check1 >= 0) {
		    		LH_TC.setPoMinusBill(String.format("%.4f", check1));
		    	} else {
		    		LH_TC.setPoMinusBill("false");
		    	}
//		    	------------2-------------
		    	if (ObjectUtils.isNotEmpty(tc_apPrice2)) {
		    		if ((billPrice - tc_apPrice2) == 0) {
		    			LH_TC.setBillMinusAp("true");
		    		} else {
		    			LH_TC.setBillMinusAp("false");
		    		}
		    	} 
//	    	    ------------3-------------
		    	if (ObjectUtils.isNotEmpty(tc_apPrice2) && ObjectUtils.isNotEmpty(tc_acPrice2)) {
		    		Double check3 = (tc_apPrice2 - tc_acPrice2) * Double.valueOf(LH_TC.getUnsettledNum());
		    		if (LH_TC.getUnit().equalsIgnoreCase("kps")) {
		    			check3 = check3 * 1000;
		    		}
		    		LH_TC.setApMinusAc(String.format("%.4f", check3));
		    	}
//    	        ------------4-------------
		    	if (ObjectUtils.isNotEmpty(tc_apPrice2) && ObjectUtils.isNotEmpty(LH_TC.getTcApplePrice())) {
		    		Double check4 = tc_apPrice2 - Double.valueOf(LH_TC.getTcApplePrice());
		    		if (check4 <= 0) {
		    			LH_TC.setApMinusApple("true");
		    		} else {
		    			LH_TC.setApMinusApple("false");
		    		}
		    	}
		    	
		    }
		    resultList.add(LH_TC);
		}
		logger.info("a:"+a);
		resultMap.put("LH_TCdata", resultList);
		resultMap.put("msg", "OK");
		resultMap.put("minStockInDate", minStockInDate.toString());
		return resultMap;
				// 在此剔除没有匹配成功的LH，返回并再次与上板TC匹配
//				List<LH_TCDetails> NGList = new ArrayList<LH_TCDetails>();
//				List<LH_TCDetails> OKList = new ArrayList<LH_TCDetails>();
//				for (LH_TCDetails lh_TCDetails : lhList) {
//				    // 过滤掉免费，free，从，等字样---
//					String dantou = lh_TCDetails.getFormHead();
//					
//					if (dantou.contains("Con") || dantou.contains("Free") || dantou.contains("免") || dantou.contains("換")) {
//						OKList.add(lh_TCDetails);
//						continue;
//					}
//					// 过滤掉免费，free，从，等字样---
//					
//					if (ObjectUtils.isEmpty(lh_TCDetails.getTcEffectiveWay())) {
//						NGList.add(lh_TCDetails);
//					} else {
//						OKList.add(lh_TCDetails);
//					}
//				}
//				logger.info("OKList:"+OKList.size());
//				logger.info("NGList:"+NGList.size());
//				resultMap.put("msg", "对比成功~");
//				resultMap.put("OKList", OKList);
//				resultMap.put("NGList", NGList);
//				return resultMap;
	}
}
