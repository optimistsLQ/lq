package com.foxconn.utils;

import com.foxconn.utils.Toolkit;
import java.util.Map;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.util.EntityUtils;

public class TCReportClient {
	public static void getTCReprotDataFromERP(HttpClient erpHttpClient, String baseURL) {
    Map<String, String> featureCode = null;
    try {
      featureCode = Toolkit.FeatureCode(erpHttpClient, baseURL + "/Pages/TCSystem/TC_ListUP.aspx?MENU_ID=MMR006");
      HttpPost post = new HttpPost(baseURL + "/Reserved.ReportViewerWebControl.axd?OpType=SessionKeepAlive&ControlID=" + (String)featureCode.get("ControlID"));
      post.setHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko");
      post.setHeader("X-Requested-With", "XMLHttpRequest");
      HttpResponse Response = erpHttpClient.execute((HttpUriRequest)post);
      String html = EntityUtils.toString(Response.getEntity());
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
}
