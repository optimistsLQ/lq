package com.foxconn.utils;

import com.alibaba.druid.util.StringUtils;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;

public abstract class Toolkit {
	public static Date dateParse(String dateStr, String regex) {
		try {
			return (new SimpleDateFormat(regex)).parse(dateStr);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public static void sleep(long millis) {
		try {
			Thread.sleep(millis);
		} catch (InterruptedException e) {
			e = null;
		}
	}

	public static Map<String, String> FeatureCode(HttpClient httpClient, String url) throws Exception {
		HttpGet httpGet = new HttpGet(url);
		Map<String, String> value = new HashMap<>();
		HttpEntity entity = httpClient.execute((HttpUriRequest) httpGet).getEntity();
		InputStream is = entity.getContent();
		InputStreamReader isr = new InputStreamReader(is);
		BufferedReader br = new BufferedReader(isr);
		StringBuffer htmlAll = new StringBuffer();
		for (String html = ""; (html = br.readLine()) != null;) {
			if (html.indexOf("\"__VIEWSTATE\"") != -1)
				value.put("__VIEWSTATE", getPageValue(html));
			if (html.indexOf("\"__EVENTVALIDATION\"") != -1)
				value.put("__EVENTVALIDATION", getPageValue(html));
			if (html.indexOf("\"__VIEWSTATEGENERATOR\"") != -1)
				value.put("__VIEWSTATEGENERATOR", getPageValue(html));
			if (html.contains("ControlID")) {
				String controlID = StringUtils.subString(html, "ControlID=", "\",\"");
				value.put("ControlID", controlID);
			}
			htmlAll.append(html + "\r\n");
		}
		value.put("htmlAll", htmlAll.toString());
		br.close();
		isr.close();
		is.close();
		return value;
	}

	public static Map<String, String> FeatureCode(HttpResponse response) throws Exception {
		Map<String, String> value = new HashMap<>();
		HttpEntity entity = response.getEntity();
		InputStream is = entity.getContent();
		InputStreamReader isr = new InputStreamReader(is);
		BufferedReader br = new BufferedReader(isr);
		StringBuffer htmlAll = new StringBuffer();
		for (String html = ""; (html = br.readLine()) != null;) {
			if (html.indexOf("\"__VIEWSTATE\"") != -1)
				value.put("__VIEWSTATE", getPageValue(html));
			if (html.indexOf("\"__EVENTVALIDATION\"") != -1)
				value.put("__EVENTVALIDATION", getPageValue(html));
			if (html.indexOf("\"__VIEWSTATEGENERATOR\"") != -1)
				value.put("__VIEWSTATEGENERATOR", getPageValue(html));
			if (html.contains("ControlID")) {
				String controlID = StringUtils.subString(html, "ControlID=", "\",\"");
				value.put("ControlID", controlID);
			}
			htmlAll.append(html + "\r\n");
		}
		value.put("htmlAll", htmlAll.toString());
		br.close();
		isr.close();
		is.close();
		return value;
	}

	private static String getPageValue(String html) {
		String temp = html.substring(html.toLowerCase().indexOf("value="));
		temp = temp.substring(temp.indexOf("\"") + 1, temp.lastIndexOf("\""));
		return temp;
	}

	public static String findStr(String text, String regex) {
		Pattern p = Pattern.compile(regex, 2);
		Matcher m = p.matcher(text);
		if (m.find())
			return m.group();
		return null;
	}
}
