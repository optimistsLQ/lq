package com.foxconn.utils;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.foxconn.entity.JSDetail;
import com.foxconn.entity.LH_TCDetails;
import com.foxconn.entity.LH_TC_MSobj;
import com.foxconn.entity.MGgrnDetail;
import com.foxconn.mapper.JSDetailMapper;
import com.foxconn.service.ExChangeService;
import com.foxconn.service.LH_TC_MSobjService;

@Component
public class CompearLHANDMS {

	@Autowired
	private ERPClient ERPClient;
	@Autowired
	private ExChangeService exChangeService;
	@Autowired
	private LH_TC_MSobjService LH_TC_MSservice;
	@Transactional
	public String lhCompearMs() {
		// 1获取没有ms信息的拉货明细
		List<LH_TC_MSobj> LHList = LH_TC_MSservice.listNoMsData();
		if (ObjectUtils.isEmpty(LHList)) {
			return "无拉货明细需要对比Ms";
		}
		// 寻找最小的入库日期
		Date now = new Date();
		long minStockInTime = 0l;
		String minDate = null;
		for (LH_TC_MSobj jsDetail : LHList) {
			String stockinTime = jsDetail.getStockinTime();
			Date stockinDate = Utils.dateStrParse(stockinTime, "yyyy-MM-dd");
			long temp = now.getTime() - stockinDate.getTime();
		    if (minStockInTime < temp) {
		      minStockInTime = temp;
		      minDate = stockinTime;
		    }
			
		}
		
		
		// 2. 爬取Ms信息
		// 查询所有月份对应的汇率
		Map<String, Double> exChangeMap = exChangeService.listAllToMap();
		Map<String, MGgrnDetail> Ms_grn = null;
		String loginMsg = ERPClient.login();
		if (loginMsg.contains("登录成功")) {
			System.out.println("----登录成功,开始爬取MS_GRN-----");
			Map<String, Object> ms_GRNMap = ERPClient.getMS_GRN(minDate, exChangeMap);
//			《GrnNo， MGgrnDetail对象》
			Ms_grn = (Map<String, MGgrnDetail>) ms_GRNMap.get("data");
			System.out.println("----MS_GRN解析成功-----" + Ms_grn.size());
//			boolean b = false;
//			for (Map.Entry<String, MGgrnDetail> obj : MGgrn.entrySet()) {
//				b = true;
//				System.out.println((String) obj.getKey() + "  --ms_GRNMap--   " + obj.getValue());
//				if (b)
//					break;
//			}
		}
		if (ObjectUtils.isEmpty(Ms_grn)) {
			return "ms获取失败";
		}
		// 3.开始对比ms
		for (LH_TC_MSobj js : LHList) {
			String apPrice = js.getTcApPrice();
			String acPrice = js.getTcAcPrice();
			// 将Kps 转换成ps
			if (js.getUnit().toLowerCase().indexOf("k") != -1) {
				if (ObjectUtils.isNotEmpty(apPrice))
					apPrice = String.valueOf(Double.valueOf(apPrice) * 1000.0D);
				if (ObjectUtils.isNotEmpty(acPrice))
					acPrice = String.valueOf(Double.valueOf(acPrice) * 1000.0D);
			}
			String LH_grn = js.getStockinCode();
			MGgrnDetail mGgrnDetail = Ms_grn.get(LH_grn);
			if (ObjectUtils.isNotEmpty(mGgrnDetail)) {
//				js.setRemark(js.getRemark()+"-MSgrn匹配OK");
				js.setMsExchangeRate(mGgrnDetail.getExChangeRate());
				if (apPrice != null && Utils.equalData(apPrice, mGgrnDetail.getExChange_ap())) {
					js.setMsApPrice("true");
				} else {
					js.setMsApPrice(String.valueOf(mGgrnDetail.getExChange_ap()));
				}
				if (acPrice != null && Utils.equalData(acPrice, mGgrnDetail.getExChange_ac())) {
					js.setMsAcPrice("true");
				} else {
					js.setMsAcPrice(String.valueOf(mGgrnDetail.getExChange_ac()));
				}
				if (js.getTcEffectiveDate() != null && js.getTcEffectiveDate()
						.equals(mGgrnDetail.getEffectiveDate().replaceAll("/", "-"))) {
					js.setMsEffectivedate("true");
				} else {
					js.setMsEffectivedate(mGgrnDetail.getEffectiveDate());
				}
			} 
		}
		int i =LH_TC_MSservice.updateMs(LHList);
		return "MS对比完成";
	}
	
	
	
	/**二次比对MS信息
	 * @param dataList
	 * @param mGgrn
	 */
	public Map<String,Object> compLH_MS_second(List<LH_TCDetails> dataList, Map<String, MGgrnDetail> Ms_grn) {
		// TODO Auto-generated method stub
		List<LH_TCDetails> resultList = new ArrayList<LH_TCDetails>();
		List<String> hasTCList = new ArrayList<String>();
		for (LH_TCDetails js : dataList) {
			// 这里筛选出进行了实时匹配TC的数据，方便对jstable数据的状态修改
			if ("tcok2".equals(js.getTcOk())) {
				hasTCList.add(js.getStockinCode());
			}
			// 这里筛选出进行了实时匹配TC的数据，方便对jstable数据的状态修改
			
			String apPrice = js.getTcApPrice();
			String acPrice = js.getTcAcPrice();
			// 将Kps 转换成ps
			if (js.getUnit().toLowerCase().indexOf("k") != -1) {
				if (ObjectUtils.isNotEmpty(apPrice))
					apPrice = String.valueOf(Double.valueOf(apPrice) * 1000.0D);
				if (ObjectUtils.isNotEmpty(acPrice))
					acPrice = String.valueOf(Double.valueOf(acPrice) * 1000.0D);
			}
			String LH_grn = js.getStockinCode();
			MGgrnDetail mGgrnDetail = Ms_grn.get(LH_grn);
			if (ObjectUtils.isNotEmpty(mGgrnDetail)) {
//				js.setRemark(js.getRemark()+"-MSgrn匹配OK");
				js.setMsExchangeRate(mGgrnDetail.getExChangeRate());
				if (apPrice != null && Utils.equalData(apPrice, mGgrnDetail.getExChange_ap())) {
					js.setMsApPrice("true");
				} else {
					js.setMsApPrice(String.valueOf(mGgrnDetail.getExChange_ap()));
				}
				if (acPrice != null && Utils.equalData(acPrice, mGgrnDetail.getExChange_ac())) {
					js.setMsAcPrice("true");
				} else {
					js.setMsAcPrice(String.valueOf(mGgrnDetail.getExChange_ac()));
				}
				if (js.getTcEffectiveDate() != null && js.getTcEffectiveDate()
						.equals(mGgrnDetail.getEffectiveDate().replaceAll("/", "-"))) {
					js.setMsEffectivedate("true");
				} else {
					js.setMsEffectivedate(mGgrnDetail.getEffectiveDate());
				}
			} 
			resultList.add(js);
		}
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("dataList", resultList);
		resultMap.put("stockInCodeList", hasTCList);
		return resultMap;
	}
}
