package com.foxconn.utils;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;


public class ExcelUtil {
    private static final Logger logger = LoggerFactory.getLogger(ExcelUtil.class);
    
    /**multipartFile转File
     * @param multipartFile
     * @return
     */
    public static File transferToFile(MultipartFile multipartFile) {
//      选择用缓冲区来实现这个转换即使用java 创建的临时文件 使用 MultipartFile.transferto()方法 。
       File file = null;
       try {   
          String originalFilename = multipartFile.getOriginalFilename();
          String[] filename = originalFilename.split("\\.");
          file=File.createTempFile(filename[0], filename[1]);
          multipartFile.transferTo(file);
           file.deleteOnExit();        
      } catch (Exception e) {
          e.printStackTrace();
      }
      return file;
  }
    
    /**
     * 按指定大小，分隔集合，将集合按规定个数分为n个部分
     *
     * @param list
     * @return
     */
    public static <T> List<List<T>> splitList(List<T> list,int length) {
        //数据库批量操作1000条数据会报错在in的情况下，
        int len = length;
        //判断非空
        if (list == null || list.isEmpty() || len < 1) {
            return Collections.emptyList();
        }
        //声明返回对象存值
        List<List<T>> result = new ArrayList<>();
        int size = list.size();
        //计算循环次数
        int count = (size + len - 1) / len;
        for (int i = 0; i < count; i++) {
            List<T> subList = list.subList(i * len, ((i + 1) * len > size ? size : len * (i + 1)));
            result.add(subList);
        }
        return result;
    }
    
}