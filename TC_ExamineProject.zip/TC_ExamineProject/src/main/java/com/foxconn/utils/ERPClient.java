package com.foxconn.utils;

import com.alibaba.druid.util.StringUtils;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import com.alibaba.excel.read.builder.ExcelReaderSheetBuilder;
import com.alibaba.excel.read.listener.ReadListener;
import com.foxconn.entity.LH_TCDetails;
import com.foxconn.entity.LH_TC_MSobj;
import com.foxconn.entity.MGgrnDetail;
import com.foxconn.entity.TcDetail;
import com.foxconn.utils.Toolkit;
import com.foxconn.utils.Utils;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.Credentials;
import org.apache.http.auth.NTCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.conn.HttpClientConnectionManager;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ERPClient {
	private String baseURL;

	private String loginURL;

	private String loginName;

	private String passWord;

	private String PCname;

	private HttpClient erpHttpClient;

	private static final Logger logger = LoggerFactory.getLogger(ERPClient.class);

	public String readProperties() {
    Properties pro = new Properties();
    try (FileInputStream in = new FileInputStream(new File("DataSource.properties"))) {
      pro.load(in);
      this.loginURL = pro.getProperty("erp_loginURL");
      this.baseURL = pro.getProperty("erp_baseURL");
      this.loginName = pro.getProperty("erp_loginName");
      this.passWord = pro.getProperty("erp_passWord");
      this.PCname = pro.getProperty("erp_PCname");
    } catch (Exception e) {
      e.printStackTrace();
      return "讀取配置文件失敗";
    } 
    if (this.loginURL == null || this.baseURL == null || this.loginName == null || this.passWord == null) {
    	return "請先配置系統資料";
    }
    return null;
  }

	/**
	 * ERP执行域登录
	 */
	public String login() {
		HashMap<String, String> map = new HashMap<String, String>();
		String readProperties = readProperties();
		if (readProperties != null) {
			return readProperties;
		}
			System.out.println(loginName + " - " + passWord);
			PoolingHttpClientConnectionManager connManager = new PoolingHttpClientConnectionManager();
			connManager.setMaxTotal(100);
			connManager.setDefaultMaxPerRoute(1000);
			CredentialsProvider credsProvider = new BasicCredentialsProvider();
			credsProvider.setCredentials(AuthScope.ANY, new NTCredentials(loginName, passWord, PCname, "IDSBG"));
			RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(3000).setRedirectsEnabled(false)
					.build();
			erpHttpClient = HttpClients.custom().setConnectionManager(connManager)
					.setDefaultRequestConfig(requestConfig).setDefaultCredentialsProvider(credsProvider).build();
		String str = "";
		try {
			// 去登陸首頁拿取__VIEWSTATEGENERATOR和__VIEWSTATE的值
			Map<String, String> featureCode = Toolkit.FeatureCode(erpHttpClient, loginURL);
//			System.out.println("featureCode>>>"+featureCode);
			// 構建post參數放入paramList
			ArrayList<NameValuePair> paramList = new ArrayList<NameValuePair>();
			paramList.add(new BasicNameValuePair("__VIEWSTATEGENERATOR", featureCode.get("__VIEWSTATEGENERATOR")));
			paramList.add(new BasicNameValuePair("__VIEWSTATE", featureCode.get("__VIEWSTATE")));
			paramList.add(new BasicNameValuePair("__EVENTVALIDATION", featureCode.get("__EVENTVALIDATION")));
			paramList.add(new BasicNameValuePair("__EVENTTARGET", "ADLogin"));
			paramList.add(new BasicNameValuePair("__EVENTARGUMENT", ""));
			paramList.add(new BasicNameValuePair("txtUserID", "請輸入用戶名"));
			paramList.add(new BasicNameValuePair("txtPassword", "請輸入密碼"));
			paramList.add(new BasicNameValuePair("txtPassword_t", ""));
			paramList.add(new BasicNameValuePair("txt_code", "驗證碼"));
			HttpPost post = new HttpPost(loginURL);
			post.setEntity(new UrlEncodedFormEntity(paramList, "utf-8"));
			HttpResponse response = erpHttpClient.execute(post);
//			System.out.println("狀態嗎："+response.getStatusLine().getStatusCode());
			HttpEntity entity = response.getEntity();
			try (InputStream is = entity.getContent();
					InputStreamReader isr = new InputStreamReader(is);
					BufferedReader br = new BufferedReader(isr);) {
//				System.out.println(response.getHeaders("location")[0]);
				if (response.getStatusLine().getStatusCode() == 302) {
					// 成功爬取
					System.out.println("ERP登錄成功");
					str = "登录成功";
				} else {
					// 爬取失敗
					String lineHtml = "";
					while ((lineHtml = br.readLine()) != null) {
						if (lineHtml.contains("請輸入正確的驗證碼")) {
							// 驗證碼輸入錯誤
							str = "驗證碼错误";
							break;
						}
						if (lineHtml.contains("用戶名或密碼錯誤，請重新輸入")) {
							// 密碼輸入錯誤
							str = "用戶名或密碼錯誤";
							break;
						}
						if (lineHtml.contains("The page cannot be found")) {
							// 密碼輸入錯誤
							str = "srm登錄網址錯誤";
							break;
						}
						if (lineHtml.contains("401")) {
							// 密碼輸入錯誤
							str = "ERP系统密码错误";
							break;
						}
					}
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return str;
	}

	/**
	 * 爬取拉货明细，
	 * 
	 * @return 返回map，里面包含resultList（爬取的所有数据），GRN_stockinCode
	 */
	public Map<String, Object> getERPData_new() {
		List<LH_TC_MSobj> resultList = new ArrayList<LH_TC_MSobj>();// 这里面装的是爬取的数据
		List<String> GRN_stockinCode = new ArrayList<String>();
		String[] arr = { "WATCD@ON_TCP893", "WATMLBCD@ON_TCP893", "WATNPICD@ON_TCP883" };
		String[] BUarr = { "FATP", "MLB", "NPI" };
		Map<String, String> featureCode = null;
		for (int i = 0; i < arr.length; i++) {
			try {
				// 第一次请求,获取状态码及ID
				featureCode = this.getFeatureCode(this.erpHttpClient,
						this.baseURL + "/Pages/TCSystem/TC_WATCHGRNReportCM.aspx?MENU_ID=MMR071");
				// 第二次请求
				{
					HttpPost post = new HttpPost(
							this.baseURL + "/Reserved.ReportViewerWebControl.axd?OpType=SessionKeepAlive&ControlID="
									+ featureCode.get("ControlID"));
					post.setHeader("User-Agent",
							"Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko");
					post.setHeader("X-Requested-With", "XMLHttpRequest");
					HttpResponse Response = erpHttpClient.execute(post);
					String html = EntityUtils.toString(Response.getEntity());
//					System.out.println("第二次请求:" + html);
				}
				// 第三次请求
				{
					HttpPost post = new HttpPost(
							this.baseURL + "/Pages/TCSystem/TC_WATCHGRNReportCM.aspx?MENU_ID=MMR071");
					post.setHeader("User-Agent",
							"Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko");
					post.setHeader("X-Requested-With", "XMLHttpRequest");
					ArrayList<NameValuePair> paramListSearch = new ArrayList<NameValuePair>();
					paramListSearch
							.add(new BasicNameValuePair("ScriptManager1", "ScriptManager1|ReportViewer1$ctl09$ctl00"));
					paramListSearch.add(new BasicNameValuePair("ScriptManager1_HiddenField", ""));
					paramListSearch.add(new BasicNameValuePair("__EVENTTARGET", ""));
					paramListSearch.add(new BasicNameValuePair("__EVENTARGUMENT", ""));
					paramListSearch.add(new BasicNameValuePair("__VIEWSTATE", featureCode.get("__VIEWSTATE")));
					paramListSearch.add(
							new BasicNameValuePair("__VIEWSTATEGENERATOR", featureCode.get("__VIEWSTATEGENERATOR")));
					paramListSearch
							.add(new BasicNameValuePair("__EVENTVALIDATION", featureCode.get("__EVENTVALIDATION")));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$ctl03$ctl00", ""));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$ctl03$ctl01", ""));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$isReportViewerInVs", ""));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$ctl15", ""));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$ctl16", "standards"));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$AsyncWait$HiddenCancelField", "False"));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$ctl09$ctl03$ddValue", arr[i]));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$ToggleParam$store", ""));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$ToggleParam$collapse", "false"));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$ctl13$ClientClickedId", ""));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$ctl12$store", ""));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$ctl12$collapse", "false"));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$ctl14$VisibilityState$ctl00", "None"));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$ctl14$ScrollPosition", ""));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$ctl14$ReportControl$ctl02", ""));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$ctl14$ReportControl$ctl03", ""));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$ctl14$ReportControl$ctl04", "100"));
					paramListSearch.add(new BasicNameValuePair("__ASYNCPOST", "true"));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$ctl09$ctl00", "View Report"));
					post.setEntity(new UrlEncodedFormEntity(paramListSearch, "utf-8"));
					HttpResponse Response = erpHttpClient.execute(post);
					if (Response.getStatusLine().getStatusCode() == 200) {
						try (InputStream in = Response.getEntity().getContent();
								InputStreamReader ir = new InputStreamReader(in);
								BufferedReader br = new BufferedReader(ir);) {
							String str = "";
							StringBuffer htmlAll = new StringBuffer();
							while ((str = br.readLine()) != null) {
								htmlAll.append(str + "\r\n");
							}
							featureCode.put("__VIEWSTATE", findStr("__VIEWSTATE\\|.+?\\|", htmlAll));
							featureCode.put("__VIEWSTATEGENERATOR", findStr("__VIEWSTATEGENERATOR\\|.+?\\|", htmlAll));
							featureCode.put("__EVENTVALIDATION", findStr("__EVENTVALIDATION\\|.+?\\|", htmlAll));
							featureCode.put("ReportSession",
									findStr("ReportSession=[a-zA-Z0-9]+", htmlAll).split("=")[1]);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
					System.out.println("第三次请求:");
				}
				// 第四次请求
				{
					HttpPost post = new HttpPost(
							this.baseURL + "/Reserved.ReportViewerWebControl.axd?OpType=SessionKeepAlive&ControlID="
									+ featureCode.get("ControlID"));
					post.setHeader("User-Agent",
							"Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko");
					post.setHeader("X-Requested-With", "XMLHttpRequest");
					HttpResponse Response = erpHttpClient.execute(post);
					String html = EntityUtils.toString(Response.getEntity());
					System.out.println("第四次请求:");
				}
				// 第五次请求
				{
					HttpPost post = new HttpPost(
							this.baseURL + "/Pages/TCSystem/TC_WATCHGRNReportCM.aspx?MENU_ID=MMR071");
					post.setHeader("User-Agent",
							"Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko");
					post.setHeader("X-Requested-With", "XMLHttpRequest");
					ArrayList<NameValuePair> paramListSearch = new ArrayList<NameValuePair>();
					paramListSearch.add(new BasicNameValuePair("ScriptManager1",
							"ScriptManager1|ReportViewer1$ctl14$Reserved_AsyncLoadTarget"));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$ctl15", "ltr"));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$ctl16", "standards"));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$AsyncWait$HiddenCancelField", "False"));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$ctl09$ctl03$ddValue", arr[i]));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$ToggleParam$collapse", "false"));
					paramListSearch.add(new BasicNameValuePair("null", "100"));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$ctl12$collapse", "false"));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$ctl14$VisibilityState$ctl00", "None"));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$ctl14$ReportControl$ctl04", "100"));
					paramListSearch.add(
							new BasicNameValuePair("__EVENTTARGET", "ReportViewer1$ctl14$Reserved_AsyncLoadTarget"));
					paramListSearch.add(new BasicNameValuePair("__EVENTARGUMENT", ""));
					paramListSearch.add(new BasicNameValuePair("__VIEWSTATE", featureCode.get("__VIEWSTATE")));
					paramListSearch.add(
							new BasicNameValuePair("__VIEWSTATEGENERATOR", featureCode.get("__VIEWSTATEGENERATOR")));
					paramListSearch
							.add(new BasicNameValuePair("__EVENTVALIDATION", featureCode.get("__EVENTVALIDATION")));
					paramListSearch.add(new BasicNameValuePair("__ASYNCPOST", "true"));
					paramListSearch.add(new BasicNameValuePair("ScriptManager1_HiddenField", ""));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$ctl03$ctl00", ""));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$ctl03$ctl01", ""));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$isReportViewerInVs", ""));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$ToggleParam$store", ""));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$ctl10$ctl00$CurrentPage", ""));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$ctl10$ctl03$ctl00", ""));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$ctl13$ClientClickedId", ""));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$ctl12$store", ""));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$ctl14$ScrollPosition", ""));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$ctl14$ReportControl$ctl02", ""));
					paramListSearch.add(new BasicNameValuePair("ReportViewer1$ctl14$ReportControl$ctl03", ""));
					post.setEntity(new UrlEncodedFormEntity(paramListSearch, "utf-8"));
					HttpResponse Response = erpHttpClient.execute(post);
					System.out.println("第5次请求:");
				}

				// 第6次请求（下载按钮）
				{
					HttpGet get = new HttpGet(this.baseURL + "/Reserved.ReportViewerWebControl.axd?ReportSession="
							+ featureCode.get("ReportSession")
							+ "&Culture=1028&CultureOverrides=True&UICulture=1028&UICultureOverrides=True&ReportStack=1&ControlID="
							+ featureCode.get("ControlID")
							+ "&OpType=Export&FileName=MMR070_WATCH+GRN%e5%a0%b1%e8%a1%a8CM&ContentDisposition=OnlyHtmlInline&Format=EXCELOPENXML");
					HttpResponse response = erpHttpClient.execute(get);
					if (response.getStatusLine().getStatusCode() == 200) {
						AtomicInteger ii = new AtomicInteger(i);
						AtomicInteger count = new AtomicInteger(0);
						InputStream in = response.getEntity().getContent();
//						--------------------将流输入文件
//						FileOutputStream out = new FileOutputStream(new File(BUarr[ii.intValue()]+"aaa.xlsx"));
//						byte [] b = new byte[1024];
//						int len = 0;
//						while ((len = in.read(b)) != -1) {
//							out.write(b, 0, len);
//						}
//						out.close();
//						in.close();
//						---------------------将流输入文件
						EasyExcel.read(in, LH_TC_MSobj.class, new AnalysisEventListener<LH_TC_MSobj>() {

							@Override
							public void invoke(LH_TC_MSobj data, AnalysisContext context) {
								// TODO Auto-generated method stub
								if (StringUtils.isEmpty(data.getStockinCode())) {
									return;
								}
								// 转换单位KPS to ps ----------
//								if (data.getUnit() != null && data.getUnit().toLowerCase().contains("k")) {
//									data.setUnsettledNum(String.valueOf(Double.valueOf(data.getUnsettledNum()) * 1000));
//									data.setUnit("ps");
//								}
								// 转换单位KPS to ps ----------
								String dantou = data.getFormHead();
								if (dantou.contains("樣品採") || dantou.contains("con") || dantou.contains("Con")
									|| dantou.contains("Free") || dantou.contains("免") || dantou.contains("換")
									|| dantou.contains("free") || dantou.contains("吸收製 ")) {
									data.setFree("free");
								}
								count.getAndAdd(1);
								data.setBu(BUarr[ii.intValue()]);
//								logger.info("-------***----"+data);
								resultList.add(data);
								GRN_stockinCode.add(data.getStockinCode());
								
							}

							@Override
							public void doAfterAllAnalysed(AnalysisContext context) {
								// TODO Auto-generated method stub
							}
						}).sheet(0).headRowNumber(7).doRead();
						
						System.out.println("爬取拉货明细" + BUarr[ii.intValue()] + "  ~~  " + count.intValue() + "条");
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		System.out.println("爬取拉货明细总计" + resultList.size() + "条");
		Map<String, Object> resultMpa = new HashMap<String, Object>();
		resultMpa.put("data", resultList);
		resultMpa.put("GRNList", GRN_stockinCode);
		return resultMpa;
	}
	

	/**爬取TC报表
	 * @return
	 */
	public Map<String, Object> getTCReportData() {
		List<TcDetail> dataList = null;
		LocalDate date = LocalDate.now();
		DateTimeFormatter formatter6 = DateTimeFormatter.ofPattern("yyyy/M/d");
		String timeStr6 = date.format(formatter6);
		DateTimeFormatter formatter8 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String timeStr8 = date.format(formatter8);
		StringBuffer M_code = new StringBuffer("");
		String factoryCode = "CDWATNPI,CDWATSMT,CDWATFATP";
		HttpResponse response = null;
		try {
			HttpGet fristClieck_1 = new HttpGet(this.baseURL + "/Pages/TCSystem/TC_ListUP.aspx?MENU_ID=MMR006");
			HashMap<String, String> headerMap = new HashMap<>();
			headerMap.put("Accept", "text/html, application/xhtml+xml, */*");
			headerMap.put("Accept-Encoding", "gzip, deflate");
			headerMap.put("Accept-Language", "zh-TW");
			headerMap.put("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko");
			response = getGetResponse(headerMap, fristClieck_1, this.erpHttpClient);
			Map<String, String> featureCode = Toolkit.FeatureCode(response);
			Document doument = Jsoup.parse(featureCode.get("htmlAll"));
			Elements iframes = doument.getElementsByAttributeValue("title", "M'Code place holder");
			Elements trElement = iframes.get(0).nextElementSibling().child(0).getElementsByTag("tr");
			for (Element tr : trElement)
				M_code.append(tr.getElementsByTag("label").html()).append(",");
			String Mcode = M_code.substring(13, M_code.length() - 1);
			String selectVal = getSelectVal(featureCode.get("htmlAll"));
			getCalendarHtml("/Reserved.ReportViewerWebControl.axd?OpType=Calendar&LCID=1028&selectDate=");
			String ControlID = featureCode.get("ControlID");
			getOKHtml("/Reserved.ReportViewerWebControl.axd?OpType=SessionKeepAlive&ControlID=", ControlID);
			Map<String, String> paramMap = new HashMap<>();
			paramMap.put("ScriptManager1", "ScriptManager1|ReportViewer1$ctl09$ctl03");
			paramMap.put("__EVENTTARGET", "ReportViewer1$ctl09$ctl03");
			paramMap.put("__VIEWSTATE", featureCode.get("__VIEWSTATE"));
			paramMap.put("__VIEWSTATEGENERATOR", featureCode.get("__VIEWSTATEGENERATOR"));
			paramMap.put("__EVENTVALIDATION", featureCode.get("__EVENTVALIDATION"));
			paramMap.put("ReportViewer1$ctl16", "standards");
			paramMap.put("ReportViewer1$AsyncWait$HiddenCancelField", "FALSE");
			paramMap.put("ReportViewer1$ctl09$ctl03$txtValue", Mcode);
			paramMap.put("ReportViewer1$ctl09$ctl07$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl09$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl11$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl13$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl15$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl17$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl19$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl25$ddValue", selectVal);
			paramMap.put("ReportViewer1$ctl09$ctl03$divDropDown$ctl01$HiddenIndices",
					"0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44");
			paramMap.put("ReportViewer1$ToggleParam$collapse", "FALSE");
			paramMap.put("ReportViewer1$ctl12$collapse", "FALSE");
			paramMap.put("ReportViewer1$ctl14$VisibilityState$ctl00", "None");
			paramMap.put("ReportViewer1$ctl14$ReportControl$ctl04", "100");
			HttpPost this_post = new HttpPost(this.baseURL + "/Pages/TCSystem/TC_ListUP.aspx?MENU_ID=MMR006");
			featureCode = getClickFirstRequestDataHtml(paramMap, this_post);
			String html = featureCode.get("htmlAll");
			selectVal = getSelectVal(html);
			getCalendarHtml("/Reserved.ReportViewerWebControl.axd?OpType=Calendar&LCID=1028&selectDate=");
			getOKHtml("/Reserved.ReportViewerWebControl.axd?OpType=SessionKeepAlive&ControlID=", ControlID);
			paramMap.put("ScriptManager1", "ScriptManager1|ReportViewer1$ctl09$ctl05");
			paramMap.put("ReportViewer1$ctl16", "standards");
			paramMap.put("ReportViewer1$AsyncWait$HiddenCancelField", "False");
			paramMap.put("ReportViewer1$ctl09$ctl03$txtValue", Mcode);
			paramMap.put("ReportViewer1$ctl09$ctl05$txtValue", factoryCode);
			paramMap.put("ReportViewer1$ctl09$ctl07$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl09$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl11$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl13$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl15$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl17$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl19$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl25$ddValue", selectVal);
			paramMap.put("ReportViewer1$ctl09$ctl03$divDropDown$ctl01$HiddenIndices",
					"0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44");
			paramMap.put("ReportViewer1$ctl09$ctl05$divDropDown$ctl01$HiddenIndices", "4,5,6");
			paramMap.put("ReportViewer1$ToggleParam$collapse", "false");
			paramMap.put("ReportViewer1$ctl12$collapse", "false");
			paramMap.put("ReportViewer1$ctl14$VisibilityState$ctl00", "None");
			paramMap.put("ReportViewer1$ctl14$ReportControl$ctl04", "100");
			paramMap.put("__EVENTTARGET", "ReportViewer1$ctl09$ctl05");
			paramMap.put("__VIEWSTATE", featureCode.get("__VIEWSTATE"));
			paramMap.put("__VIEWSTATEGENERATOR", featureCode.get("__VIEWSTATEGENERATOR"));
			paramMap.put("__EVENTVALIDATION", featureCode.get("__EVENTVALIDATION"));
			paramMap.put("__ASYNCPOST", "true");
			this_post = new HttpPost(this.baseURL + "/Pages/TCSystem/TC_ListUP.aspx?MENU_ID=MMR006");
			featureCode = getClickFirstRequestDataHtml(paramMap, this_post);
			html = featureCode.get("htmlAll");
			selectVal = getSelectVal(html);
			getCalendarHtml("/Reserved.ReportViewerWebControl.axd?OpType=Calendar&LCID=1028&selectDate=");
			getOKHtml("/Reserved.ReportViewerWebControl.axd?OpType=SessionKeepAlive&ControlID=", ControlID);
			paramMap.put("ScriptManager1", "ScriptManager1|ReportViewer1$ctl09$ctl21");
			paramMap.put("ReportViewer1$ctl16", "standards");
			paramMap.put("ReportViewer1$AsyncWait$HiddenCancelField", "False");
			paramMap.put("ReportViewer1$ctl09$ctl03$txtValue", Mcode);
			paramMap.put("ReportViewer1$ctl09$ctl05$txtValue", factoryCode);
			paramMap.put("ReportViewer1$ctl09$ctl07$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl09$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl11$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl13$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl15$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl17$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl19$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl21$txtValue", timeStr6);
			paramMap.put("ReportViewer1$ctl09$ctl25$ddValue", selectVal);
			paramMap.put("ReportViewer1$ctl09$ctl03$divDropDown$ctl01$HiddenIndices",
					"0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44");
			paramMap.put("ReportViewer1$ctl09$ctl05$divDropDown$ctl01$HiddenIndices", "4,5,6");
			paramMap.put("ReportViewer1$ToggleParam$collapse", "false");
			paramMap.put("ReportViewer1$ctl12$collapse", "false");
			paramMap.put("ReportViewer1$ctl14$VisibilityState$ctl00", "None");
			paramMap.put("ReportViewer1$ctl14$ReportControl$ctl04", "100");
			paramMap.put("__EVENTTARGET", "ReportViewer1$ctl09$ctl21");
			paramMap.put("__VIEWSTATE", featureCode.get("__VIEWSTATE"));
			paramMap.put("__VIEWSTATEGENERATOR", featureCode.get("__VIEWSTATEGENERATOR"));
			paramMap.put("__EVENTVALIDATION", featureCode.get("__EVENTVALIDATION"));
			paramMap.put("__ASYNCPOST", "true");
			this_post = new HttpPost(this.baseURL + "/Pages/TCSystem/TC_ListUP.aspx?MENU_ID=MMR006");
			featureCode = getClickFirstRequestDataHtml(paramMap, this_post);
			getCalendarHtml("/Reserved.ReportViewerWebControl.axd?OpType=Calendar&LCID=1028&selectDate=" + timeStr6);
			getCalendarHtml("/Reserved.ReportViewerWebControl.axd?OpType=Calendar&LCID=1028&selectDate=" + timeStr8);
			getOKHtml("/Reserved.ReportViewerWebControl.axd?OpType=SessionKeepAlive&ControlID=", ControlID);
			paramMap.put("ScriptManager1", "ScriptManager1|ReportViewer1$ctl09$ctl25$ddValue");
			paramMap.put("ReportViewer1$ctl16", "standards");
			paramMap.put("ReportViewer1$AsyncWait$HiddenCancelField", "False");
			paramMap.put("ReportViewer1$ctl09$ctl03$txtValue", Mcode);
			paramMap.put("ReportViewer1$ctl09$ctl05$txtValue", factoryCode);
			paramMap.put("ReportViewer1$ctl09$ctl07$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl09$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl11$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl13$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl15$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl17$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl19$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl21$txtValue", timeStr8);
			paramMap.put("ReportViewer1$ctl09$ctl23$ddValue", "3");
			paramMap.put("ReportViewer1$ctl09$ctl25$ddValue", "ALL");
			paramMap.put("ReportViewer1$ctl09$ctl03$divDropDown$ctl01$HiddenIndices",
					"0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44");
			paramMap.put("ReportViewer1$ctl09$ctl05$divDropDown$ctl01$HiddenIndices", "4,5,6");
			paramMap.put("ReportViewer1$ToggleParam$collapse", "false");
			paramMap.put("ReportViewer1$ctl12$collapse", "false");
			paramMap.put("ReportViewer1$ctl14$VisibilityState$ctl00", "None");
			paramMap.put("ReportViewer1$ctl14$ReportControl$ctl04", "100");
			paramMap.put("__EVENTTARGET", "ReportViewer1$ctl09$ctl25$ddValue");
			paramMap.put("__VIEWSTATE", featureCode.get("__VIEWSTATE"));
			paramMap.put("__VIEWSTATEGENERATOR", featureCode.get("__VIEWSTATEGENERATOR"));
			paramMap.put("__EVENTVALIDATION", featureCode.get("__EVENTVALIDATION"));
			paramMap.put("__ASYNCPOST", "true");
			this_post = new HttpPost(this.baseURL + "/Pages/TCSystem/TC_ListUP.aspx?MENU_ID=MMR006");
			featureCode = getClickFirstRequestDataHtml(paramMap, this_post);
			featureCode.get("htmlAll");
			getCalendarHtml("/Reserved.ReportViewerWebControl.axd?OpType=Calendar&LCID=1028&selectDate=" + timeStr8);
			getOKHtml("/Reserved.ReportViewerWebControl.axd?OpType=SessionKeepAlive&ControlID=", ControlID);
			paramMap.put("ScriptManager1", "ScriptManager1|ReportViewer1$ctl09$ctl00");
			paramMap.put("ReportViewer1$ctl16", "standards");
			paramMap.put("ReportViewer1$AsyncWait$HiddenCancelField", "False");
			paramMap.put("ReportViewer1$ctl09$ctl03$txtValue", Mcode);
			paramMap.put("ReportViewer1$ctl09$ctl05$txtValue", factoryCode);
			paramMap.put("ReportViewer1$ctl09$ctl07$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl09$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl11$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl13$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl15$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl17$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl19$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl21$txtValue", timeStr8);
			paramMap.put("ReportViewer1$ctl09$ctl23$ddValue", "3");
			paramMap.put("ReportViewer1$ctl09$ctl25$ddValue", "ALL");
			paramMap.put("ReportViewer1$ctl09$ctl27$ddValue", "ALL");
			paramMap.put("ReportViewer1$ctl09$ctl03$divDropDown$ctl01$HiddenIndices",
					"0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44");
			paramMap.put("ReportViewer1$ctl09$ctl05$divDropDown$ctl01$HiddenIndices", "4,5,6");
			paramMap.put("ReportViewer1$ToggleParam$collapse", "false");
			paramMap.put("ReportViewer1$ctl12$collapse", "false");
			paramMap.put("ReportViewer1$ctl14$VisibilityState$ctl00", "None");
			paramMap.put("ReportViewer1$ctl14$ReportControl$ctl04", "100");
			paramMap.put("__VIEWSTATE", featureCode.get("__VIEWSTATE"));
			paramMap.put("__VIEWSTATEGENERATOR", featureCode.get("__VIEWSTATEGENERATOR"));
			paramMap.put("__EVENTVALIDATION", featureCode.get("__EVENTVALIDATION"));
			paramMap.put("__ASYNCPOST", "true");
			paramMap.put("ReportViewer1$ctl09$ctl00", "View Report");
			this_post = new HttpPost(this.baseURL + "/Pages/TCSystem/TC_ListUP.aspx?MENU_ID=MMR006");
			featureCode = getClickFirstRequestDataHtml(paramMap, this_post);
			html = featureCode.get("htmlAll");
			String ReportSession = findStr("ReportSession=[a-zA-Z0-9]+", new StringBuffer(html)).split("=")[1];
			getCalendarHtml("/Reserved.ReportViewerWebControl.axd?OpType=Calendar&LCID=1028&selectDate=" + timeStr8);
			getOKHtml("/Reserved.ReportViewerWebControl.axd?OpType=SessionKeepAlive&ControlID=", ControlID);
			paramMap.put("ScriptManager1", "ScriptManager1|ReportViewer1$ctl14$Reserved_AsyncLoadTarget");
			paramMap.put("ReportViewer1$ctl15", "ltr");
			paramMap.put("ReportViewer1$ctl16", "standards");
			paramMap.put("ReportViewer1$AsyncWait$HiddenCancelField", "False");
			paramMap.put("ReportViewer1$ctl09$ctl03$txtValue", Mcode);
			paramMap.put("ReportViewer1$ctl09$ctl05$txtValue", factoryCode);
			paramMap.put("ReportViewer1$ctl09$ctl07$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl09$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl11$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl13$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl15$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl17$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl19$txtValue", "%");
			paramMap.put("ReportViewer1$ctl09$ctl21$txtValue", timeStr8);
			paramMap.put("ReportViewer1$ctl09$ctl23$ddValue", "3");
			paramMap.put("ReportViewer1$ctl09$ctl25$ddValue", "ALL");
			paramMap.put("ReportViewer1$ctl09$ctl27$ddValue", "ALL");
			paramMap.put("ReportViewer1$ctl09$ctl03$divDropDown$ctl01$HiddenIndices",
					"0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44");
			paramMap.put("ReportViewer1$ctl09$ctl05$divDropDown$ctl01$HiddenIndices", "4,5,6");
			paramMap.put("ReportViewer1$ToggleParam$collapse", "false");
			paramMap.put("null", "100");
			paramMap.put("ReportViewer1$ctl12$collapse", "false");
			paramMap.put("ReportViewer1$ctl14$VisibilityState$ctl00", "None");
			paramMap.put("ReportViewer1$ctl14$ReportControl$ctl04", "100");
			paramMap.put("__EVENTTARGET", "ReportViewer1$ctl14$Reserved_AsyncLoadTarget");
			paramMap.put("__VIEWSTATE", featureCode.get("__VIEWSTATE"));
			paramMap.put("__VIEWSTATEGENERATOR", featureCode.get("__VIEWSTATEGENERATOR"));
			paramMap.put("__EVENTVALIDATION", featureCode.get("__EVENTVALIDATION"));
			paramMap.put("__ASYNCPOST", "true");
			this_post = new HttpPost(this.baseURL + "/Pages/TCSystem/TC_ListUP.aspx?MENU_ID=MMR006");
			featureCode = getClickFirstRequestDataHtml(paramMap, this_post);
			featureCode.get("htmlAll");
			HttpGet excelGet = new HttpGet(this.baseURL + "/Reserved.ReportViewerWebControl.axd?ReportSession="
					+ ReportSession
					+ "&Culture=1028&CultureOverrides=True&UICulture=1028&UICultureOverrides=True&ReportStack=1&ControlID="
					+ ControlID
					+ "&OpType=Export&FileName=TC222&ContentDisposition=OnlyHtmlInline&Format=EXCELOPENXML");
			response = this.erpHttpClient.execute((HttpUriRequest) excelGet);
			InputStream in = response.getEntity().getContent();
			return resolveInputStream_new(in);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	
	/**解析上面爬取的TC报表的输入流
	 * @param in
	 * @return 返回List<TcDetail>结果
	 */
	public Map<String, Object> resolveInputStream_new(InputStream in) {
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String version = now.format(df);
		List<TcDetail> dataList = new ArrayList<>();
		List<String> md5List = new ArrayList<>();
//		AtomicInteger a = new AtomicInteger(0);
		EasyExcel.read(in, TcDetail.class, new AnalysisEventListener<TcDetail>() {

			@Override
			public void invoke(TcDetail data, AnalysisContext context) {
				// TODO Auto-generated method stub CDWATNPI,CDWATSMT,CDWATFATP
				String buCode = data.getBuCode().toUpperCase();
				if ("CDWATNPI".equals(buCode)) {
					buCode = "NPI";
				} else if ("CDWATFATP".equals(buCode)) {
					buCode = "FATP";
				} else if ("CDWATSMT".equals(buCode)) {
					buCode = "MLB";
				}
				data.setBuCode(buCode);
				data.setClickVersion(version);
				String md5 = data.toMD5();
				data.setMd5Msg(md5);
				dataList.add(data);
				md5List.add(md5);
			}

			@Override
			public void doAfterAllAnalysed(AnalysisContext context) {
				// TODO Auto-generated method stub
				
			}
		}).sheet(0).headRowNumber(3).doRead();
		Map<String, Object> resutlMap = new HashMap<String, Object>();
		resutlMap.put("dataList", dataList);
		resutlMap.put("md5List", md5List);
		return resutlMap;
	}
	
	

	public HttpResponse getPostResponse(Map<String, String> headerMap, Map<String, String> paramMap, HttpPost post,
			HttpClient httpClient) throws Exception {
		if (ObjectUtils.isNotEmpty(headerMap)) {
			headerMap.forEach((key, val) -> post.setHeader(key, val));
			headerMap.clear();
		}
		ArrayList<NameValuePair> paramListSearch = new ArrayList<>();
		if (ObjectUtils.isNotEmpty(paramMap)) {
			paramMap.forEach((key, val) -> paramListSearch.add(new BasicNameValuePair(key, val)));
			paramMap.clear();
		}
		post.setEntity((HttpEntity) new UrlEncodedFormEntity(paramListSearch, "utf-8"));
		HttpResponse response = httpClient.execute((HttpUriRequest) post);
		return response;
	}

	public HttpResponse getGetResponse(Map<String, String> headerMap, HttpGet get, HttpClient httpClient)
			throws Exception {
		if (ObjectUtils.isNotEmpty(headerMap)) {
			headerMap.forEach((key, val) -> get.setHeader(key, val));
			headerMap.clear();
		}
		HttpResponse response = httpClient.execute((HttpUriRequest) get);
		return response;
	}

	public Map<String, String> getFeatureCode(HttpClient httpClient, String url) throws Exception {
		Map<String, String> featureCode = Toolkit.FeatureCode(httpClient, url);
		return featureCode;
	}

	public Map<String, String> getFeatureCode(HttpResponse response) {
		Map<String, String> featureCode = new HashMap<>();
		try (InputStream in = response.getEntity().getContent();
				InputStreamReader ir = new InputStreamReader(in);
				BufferedReader br = new BufferedReader(ir)) {
			String str = "";
			StringBuffer htmlAll = new StringBuffer();
			while ((str = br.readLine()) != null)
				htmlAll.append(str + "\r\n");
			featureCode.put("__VIEWSTATE", findStr("__VIEWSTATE\\|.+?\\|", htmlAll));
			featureCode.put("__VIEWSTATEGENERATOR", findStr("__VIEWSTATEGENERATOR\\|.+?\\|", htmlAll));
			featureCode.put("__EVENTVALIDATION", findStr("__EVENTVALIDATION\\|.+?\\|", htmlAll));
			featureCode.put("htmlAll", htmlAll.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return featureCode;
	}

	public static String findStr(String regex, StringBuffer sourceStr) {
		Pattern p = Pattern.compile(regex, 2);
		Matcher m = p.matcher(sourceStr);
		if (m.find()) {
			String temp = m.group();
			if (temp.contains("|"))
				return temp.substring(temp.indexOf("|") + 1, temp.lastIndexOf("|"));
			return temp;
		}
		return null;
	}

	public String getSelectVal(String html) {
		Document doument = Jsoup.parse(html);
		Elements selectValElement = doument.getElementsByAttributeValue("data-parameterName", "TEAM");
		String selectVal = selectValElement.get(0).child(0).getElementsByAttributeValue("selected", "selected").val();
		return selectVal;
	}

	public Map<String, String> getClickFirstRequestDataHtml(Map<String, String> paramMap, HttpPost this_post)
			throws Exception {
		Map<String, String> headerMap = new HashMap<>();
		headerMap.put("X-Requested-With", "XMLHttpRequest");
		headerMap.put("Accept", "*/*");
		headerMap.put("Accept-Encoding", "gzip, deflate");
		headerMap.put("Accept-Language", "zh-TW");
		headerMap.put("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko");
		headerMap.put("Referer", "http://10.146.64.230:8081/Pages/TCSystem/TC_ListUP.aspx?MENU_ID=MMR006");
		headerMap.put("X-MicrosoftAjax", "Delta=true");
		HttpResponse response = getPostResponse(headerMap, paramMap, this_post, this.erpHttpClient);
		Map<String, String> featureCode = getFeatureCode(response);
		return featureCode;
	}

	public Map<String, String> getMS_GRNpostRequest(Map<String, String> paramMap, HttpPost this_post) throws Exception {
		Map<String, String> headerMap = new HashMap<>();
		headerMap.put("X-Requested-With", "XMLHttpRequest");
		headerMap.put("Accept", "*/*");
		headerMap.put("Accept-Encoding", "gzip, deflate");
		headerMap.put("Accept-Language", "zh-TW");
		headerMap.put("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko");
		headerMap.put("Referer", "http://10.146.64.230:8081/Pages/MSReport/MSGRListReport.aspx?MENU_ID=CMR070");
		headerMap.put("X-MicrosoftAjax", "Delta=true");
		HttpResponse response = getPostResponse(headerMap, paramMap, this_post, this.erpHttpClient);
		Map<String, String> featureCode = getFeatureCode(response);
		return featureCode;
	}

	public String getCalendarHtml(String url, Map<String, String> headMap) throws Exception {
		HttpGet this_get = new HttpGet(this.baseURL + url);
		if (ObjectUtils.isNotEmpty(headMap)) {
			headMap.forEach((k, v) -> this_get.setHeader(k, v));
			headMap.clear();
		}
		HttpResponse response = getGetResponse(null, this_get, this.erpHttpClient);
		return EntityUtils.toString(response.getEntity());
	}

	public String getCalendarHtml(String url) throws Exception {
		HttpGet this_get = new HttpGet(this.baseURL + url);
		HttpResponse response = getGetResponse(null, this_get, this.erpHttpClient);
		return EntityUtils.toString(response.getEntity());
	}

	public String getOKHtml(String url, String ControlID) throws Exception {
		return getOKHtml(url, ControlID, null);
	}

	public String getOKHtml(String url, String ControlID, Map<String, String> headerMap) throws Exception {
		HttpPost this_post = new HttpPost(this.baseURL + url + ControlID);
		HashMap<String, String> paramMap = new HashMap<>();
		paramMap.put("OpType", "SessionKeepAlive");
		paramMap.put("ControlID", ControlID);
		HttpResponse response = getPostResponse(headerMap, paramMap, this_post, this.erpHttpClient);
		return EntityUtils.toString(response.getEntity());
	}

	/**爬取MS_GRN清单
	 * @param minStockInDate 拉货明细里最早的入库日期
	 * @param exchangeMap 每月对应的汇率
	 * @return 《GrnNo， MGgrnDetail对象》
	 */
	public Map<String, Object> getMS_GRN(String minStockInDate, Map<String, Double> exchangeMap) {
    Map<String, Object> result = new HashMap<>();
    Map<String, MGgrnDetail> MGgrnMap = new HashMap<>();
    String minStockInDate_ = minStockInDate.replaceAll("/", "-");
    if (ObjectUtils.isEmpty(exchangeMap)) {
      result.put("msg", "汇率获取失败");
      return result;
    } 
    List<String> factoryCodeList = Arrays.asList(new String[] { "HFCCD0WAT", "HFCCD0WMLB", "HFCCD0WNPI" });
    String today_ = Utils.dateFormatStr(new Date(), "yyyy-MM-dd");
    String today = Utils.dateFormatStr(new Date(), "yyyy/MM/dd");
    HttpResponse response = null;
    HttpGet get = new HttpGet(this.baseURL + "/Pages/MSReport/MSGRListReport.aspx?MENU_ID=CMR070");
    try {
      HashMap<String, String> headerMap = new HashMap<>();
      headerMap.put("Accept", "text/html, application/xhtml+xml, */*");
      headerMap.put("Accept-Encoding", "gzip, deflate");
      headerMap.put("Accept-Language", "zh-TW");
      headerMap.put("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko");
      headerMap.put("Referer", "http://10.146.64.230:8081/Menu.aspx");
      response = getGetResponse(headerMap, get, this.erpHttpClient);
      Map<String, String> featureCode = Toolkit.FeatureCode(response);
      headerMap.put("Referer", "http://10.146.64.230:8081/Pages/MSReport/MSGRListReport.aspx?MENU_ID=CMR070");
      getCalendarHtml("/Reserved.ReportViewerWebControl.axd?OpType=Calendar&LCID=1028&selectDate=", headerMap);
      headerMap.put("Referer", "http://10.146.64.230:8081/Pages/MSReport/MSGRListReport.aspx?MENU_ID=CMR070");
      getCalendarHtml("/Reserved.ReportViewerWebControl.axd?OpType=Calendar&LCID=1028&selectDate=", headerMap);
      String ControlID = featureCode.get("ControlID");
      headerMap.put("Accept", "*/*");
      headerMap.put("Accept-Encoding", "gzip, deflate");
      headerMap.put("Accept-Language", "zh-TW");
      headerMap.put("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko");
      headerMap.put("X-Requested-With", "XMLHttpRequest");
      headerMap.put("Referer", "http://10.146.64.230:8081/Pages/MSReport/MSGRListReport.aspx?MENU_ID=CMR070");
      getOKHtml("/Reserved.ReportViewerWebControl.axd?OpType=SessionKeepAlive&ControlID=", ControlID, headerMap);
      for (String factoryCode : factoryCodeList) {
        headerMap.put("Referer", "http://10.146.64.230:8081/Reserved.ReportViewerWebControl.axd?OpType=Calendar&LCID=1028&selectDate=");
        getCalendarHtml("/Reserved.ReportViewerWebControl.axd?OpType=Calendar&LCID=1028&selectDate=" + URLEncoder.encode(minStockInDate, "UTF-8"), headerMap);
        headerMap.put("Referer", "http://10.146.64.230:8081/Reserved.ReportViewerWebControl.axd?OpType=Calendar&LCID=1028&selectDate=");
        getCalendarHtml("/Reserved.ReportViewerWebControl.axd?OpType=Calendar&LCID=1028&selectDate=" + URLEncoder.encode(today, "UTF-8"), headerMap);
        HttpPost post = new HttpPost(this.baseURL + "/Pages/MSReport/MSGRListReport.aspx?MENU_ID=CMR070");
        Map<String, String> paramMap = new HashMap<>();
        paramMap.put("ScriptManager1", "ScriptManager1|ReportViewer1$ctl09$ctl00");
        paramMap.put("__VIEWSTATE", featureCode.get("__VIEWSTATE"));
        paramMap.put("__VIEWSTATEGENERATOR", featureCode.get("__VIEWSTATEGENERATOR"));
        paramMap.put("__EVENTVALIDATION", featureCode.get("__EVENTVALIDATION"));
        paramMap.put("ReportViewer1$ctl16", "standards");
        paramMap.put("ReportViewer1$AsyncWait$HiddenCancelField", "False");
        paramMap.put("ReportViewer1$ctl09$ctl03$ddValue", factoryCode);
        paramMap.put("ReportViewer1$ctl09$ctl05$txtValue", minStockInDate);
        paramMap.put("ReportViewer1$ctl09$ctl07$txtValue", today);
        paramMap.put("ReportViewer1$ctl09$ctl09$txtValue", "Y,N,NULL");
        paramMap.put("ReportViewer1$ctl09$ctl09$divDropDown$ctl01$HiddenIndices", "0,1,2");
        paramMap.put("ReportViewer1$ToggleParam$collapse", "false");
        paramMap.put("ReportViewer1$ctl12$collapse", "false");
        paramMap.put("ReportViewer1$ctl14$VisibilityState$ctl00", "None");
        paramMap.put("ReportViewer1$ctl14$ReportControl$ctl04", "100");
        paramMap.put("__ASYNCPOST", "true");
        paramMap.put("ReportViewer1$ctl09$ctl00", "View Report");
        featureCode = getMS_GRNpostRequest(paramMap, post);
        String html = featureCode.get("htmlAll");
        String ReportSession = findStr("ReportSession=[a-zA-Z0-9]+", new StringBuffer(html)).split("=")[1];
        headerMap.put("Referer", "http://10.146.64.230:8081/Pages/MSReport/MSGRListReport.aspx?MENU_ID=CMR070");
        getCalendarHtml("/Reserved.ReportViewerWebControl.axd?OpType=Calendar&LCID=1028&selectDate=" + minStockInDate_, headerMap);
        headerMap.put("Referer", "http://10.146.64.230:8081/Pages/MSReport/MSGRListReport.aspx?MENU_ID=CMR070");
        getCalendarHtml("/Reserved.ReportViewerWebControl.axd?OpType=Calendar&LCID=1028&selectDate=" + today_, headerMap);
        headerMap.put("Accept", "*/*");
        headerMap.put("Accept-Encoding", "gzip, deflate");
        headerMap.put("Accept-Language", "zh-TW");
        headerMap.put("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko");
        headerMap.put("X-Requested-With", "XMLHttpRequest");
        headerMap.put("Referer", "http://10.146.64.230:8081/Pages/MSReport/MSGRListReport.aspx?MENU_ID=CMR070");
        getOKHtml("/Reserved.ReportViewerWebControl.axd?OpType=SessionKeepAlive&ControlID=", ControlID);
        post = new HttpPost(this.baseURL + "/Pages/MSReport/MSGRListReport.aspx?MENU_ID=CMR070");
        paramMap = new HashMap<>();
        paramMap.put("ScriptManager1", "ScriptManager1|ReportViewer1$ctl14$Reserved_AsyncLoadTarget");
        paramMap.put("ReportViewer1$ctl15", "ltr");
        paramMap.put("ReportViewer1$ctl16", "standards");
        paramMap.put("ReportViewer1$AsyncWait$HiddenCancelField", "False");
        paramMap.put("ReportViewer1$ctl09$ctl03$ddValue", factoryCode);
        paramMap.put("ReportViewer1$ctl09$ctl05$txtValue", minStockInDate_);
        paramMap.put("ReportViewer1$ctl09$ctl07$txtValue", today_);
        paramMap.put("ReportViewer1$ctl09$ctl09$txtValue", "Y,N,NULL");
        paramMap.put("ReportViewer1$ctl09$ctl09$divDropDown$ctl01$HiddenIndices", "0,1,2");
        paramMap.put("ReportViewer1$ToggleParam$collapse", "false");
        paramMap.put("null", "100");
        paramMap.put("ReportViewer1$ctl12$collapse", "false");
        paramMap.put("ReportViewer1$ctl14$VisibilityState$ctl00", "None");
        paramMap.put("ReportViewer1$ctl14$ReportControl$ctl04", "100");
        paramMap.put("__EVENTTARGET", "ReportViewer1$ctl14$Reserved_AsyncLoadTarget");
        paramMap.put("__VIEWSTATE", featureCode.get("__VIEWSTATE"));
        paramMap.put("__VIEWSTATEGENERATOR", featureCode.get("__VIEWSTATEGENERATOR"));
        paramMap.put("__EVENTVALIDATION", featureCode.get("__EVENTVALIDATION"));
        paramMap.put("__ASYNCPOST", "true");
        featureCode = getMS_GRNpostRequest(paramMap, post);
        String excelURL = "/Reserved.ReportViewerWebControl.axd?ReportSession=" + ReportSession + "&Culture=1028&CultureOverrides=True&UICulture=1028&UICultureOverrides=True&ReportStack=1&ControlID=" + ControlID + "&OpType=Export&FileName=ms_grn&ContentDisposition=OnlyHtmlInline&Format=EXCELOPENXML";
        HttpGet excelGet = new HttpGet(this.baseURL + excelURL);
        response = this.erpHttpClient.execute((HttpUriRequest)excelGet);
        InputStream in = response.getEntity().getContent();
        Map<String, MGgrnDetail> resolveMS_GRN = resolveMS_GRN(in, exchangeMap);
        MGgrnMap.putAll(resolveMS_GRN);
      } 
      result.put("data", MGgrnMap);
      result.put("msg", "msGRN清单获取成功");
    } catch (Exception e) {
      e.printStackTrace();
    } 
    return result;
  }

	/**解析MS_GRN输入流
	 * @param in
	 * @param exchangeMap
	 * @return 《GrnNo， MGgrnDetail对象》
	 */
	public Map<String, MGgrnDetail> resolveMS_GRN(InputStream in, Map<String, Double> exchangeMap) {
    Map<String, MGgrnDetail> MGgrnMap = new HashMap<>();
//    ArrayList<MGgrnDetail> list = new ArrayList<>();
    
    EasyExcel.read(in, MGgrnDetail.class, new AnalysisEventListener<MGgrnDetail>() {

    	DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy/MM/dd");
//        String dateStr = today.format(fmt);
    	
		@Override
		public void invoke(MGgrnDetail data, AnalysisContext context) {
			// TODO Auto-generated method stub
//			list.add(data);
			// 先过滤掉ap,ac价格为null的数据
			if (null == data.getAcPrice() && null == data.getApPrice()) {
				return;
			}
			
			 if ("RMB".equals(data.getCurrency().toUpperCase())) {
			      Double exchange = (Double) exchangeMap.get(data.getStockInDate().substring(0, 7).replaceAll("/", "-"));
			      if (ObjectUtils.isNotEmpty(exchange)) {
			        data.setExChangeRate(String.valueOf(exchange));
			        data.setExChange_ac(ERPClient.sixDecimal(data.getAcPrice() == null ? 0.0D : (data.getAcPrice() * exchange)));
			        data.setExChange_ap(ERPClient.sixDecimal(data.getApPrice() == null ? 0.0D : (data.getApPrice() * exchange)));
//			        logger.info("MSGRn>>"+data);
			      } else {
			    	  logger.info(data.getStockInDate().substring(0, 7).replaceAll("/", "-") + "  本月汇率为空，沿用上月汇率");
			    	  String stockInDate = data.getStockInDate();
			    	  LocalDate stockInTime = LocalDate.parse(stockInDate, fmt);
			    	  LocalDate preMonth = stockInTime.minusMonths(1);
			    	  String preMonthstr = preMonth.format(fmt);
			    	  preMonthstr = preMonthstr.substring(0, 7).replaceAll("/", "-");
			    	  exchange = exchangeMap.get(preMonthstr);
			    	  data.setExChangeRate(String.valueOf(exchange));
			    	  data.setExChange_ac(ERPClient.sixDecimal(data.getAcPrice() == null ? 0.0D : (data.getAcPrice() * exchange)));
				      data.setExChange_ap(ERPClient.sixDecimal(data.getApPrice() == null ? 0.0D : (data.getApPrice() * exchange)));
			      }
			    } else if ("USD".equals(data.getCurrency().toUpperCase())) {
			      data.setExChangeRate("1");
			      data.setExChange_ac(String.valueOf(data.getAcPrice()));
			      data.setExChange_ap(String.valueOf(data.getApPrice()));
			    }
//			    list.add(data);
			    MGgrnMap.put(data.getGrnNo(), data);
		}

		@Override
		public void doAfterAllAnalysed(AnalysisContext context) {
			// TODO Auto-generated method stub
			
		}
	}).sheet(0).headRowNumber(3).doRead();
    
//    File file = new File(Utils.getUUID() + "MS_GRN.xlsx");
//    
//    EasyExcel.write(file, MGgrnDetail.class).sheet(0).doWrite(list);
    return MGgrnMap;
  }
	
	
	
	public static String sixDecimal(double val) {
		String valStr = String.valueOf(val);
		if (valStr.indexOf(".") == -1) {
			return String.valueOf(val);
		}
		String decimal = valStr.split("\\.")[1];
		if (decimal.length() > 6) {
			return String.format("%.6f", Double.valueOf(val));
		}
		return String.valueOf(val);
	}

	public static void main(String[] args) throws Exception {
//		String s = "2021/05/02";
//		System.out.println(s.substring(0, 7).replaceAll("/", "-"));
//		
//		TcDetail tcDetail = new TcDetail();
//		tcDetail.setAction("aaa");
//		String string = tcDetail.getAction();
//		string = "bbb";
//		tcDetail.setAction(string);
//		System.out.println(tcDetail);
		LocalDate now = LocalDate.now();
		LocalDate preMonth = now.minusMonths(1);
		System.out.println(now+" - "+preMonth);
	}
}
