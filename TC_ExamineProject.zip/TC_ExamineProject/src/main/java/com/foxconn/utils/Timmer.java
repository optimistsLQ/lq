package com.foxconn.utils;

import com.foxconn.controller.TCController;
import java.io.File;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.util.ResourceUtils;

@Configuration
@EnableScheduling
public class Timmer {
	@Autowired
	private TCController TCcontroller;
	
	/**
	 * 每天定时获取TC报表,并和LH匹配
	 */
//	@Scheduled(cron = "00 30 06 * * ?")
	@Scheduled(cron = "00 52 19 * * ?")
	public void getTCcompearLH() {
		//1 爬取TC报表并去重存入数据库
		String msg = this.TCcontroller.getTCReportData();
		System.out.println("获取TC: " + msg);
		//2.对比拉货TC
		TCcontroller.compearLH_TC();
		//3.对比拉货MS
		TCcontroller.compearMS_grn();
	}
	
//	/**
//	 * 每天定时获取MSGRN清单并和LH进行对比
//	 */
//	@Scheduled(cron = "00 00 09 * * ?")
//	public void getMScompearLH() {
//		TCcontroller.compearMS_grn();
//	}
	

	@Scheduled(cron = "0 55 23 * * ?")
	public void delFile() {
		try {
			File path = new File(ResourceUtils.getURL("classpath:").getPath());
			path = path.getParentFile().getParentFile();
			if (!path.exists())
				path = new File((new File("")).getAbsolutePath() + "\\");
			File[] listFiles = path.listFiles();
			for (File file : listFiles) {
				if (file.getName().endsWith(".xlsx"))
					file.delete();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
