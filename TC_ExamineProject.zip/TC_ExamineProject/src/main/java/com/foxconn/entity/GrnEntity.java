package com.foxconn.entity;

import javax.persistence.Table;
@Table(name = "T_LAHUODETAIL")
public class GrnEntity {

	private String grnId;
	
	private String bu;
//	贸易类型
	private String tot;
//	单头名称
	private String hn;
//	厂商编号
	private String mn;
//	厂商简称
	private String aom;
//	HH VendorCode
	private String hhsc;
//	入库单号
	private String sin;
//	入库日期
	private String sd;
//	采购单号
	private String pono;
//	料号
	private String pano;
//	库存单位
	private String un;
//	未请款数量
	private String qnr;
//	币别
	private String cr;
//	PO价格
	private String poa;
//	入库金额
	private String sa;
//	AC价格
	private String aa;
//	AP价格
	private String apa;
//	Action
	private String ac;
//	生效日期
	private String ed;
//	生效方式
	private String em;
//	付款条件（HH）
	private String hhtop;
//	付款条件（PO）
	private String potop;
//	dri
	private String dri;
//	是否为免费样品
	private String free;
//	操作者
	private String userCard;
	public String getGrnId() {
		return grnId;
	}
	public void setGrnId(String grnId) {
		this.grnId = grnId;
	}
	public String getBu() {
		return bu;
	}
	public void setBu(String bu) {
		this.bu = bu;
	}
	public String getTot() {
		return tot;
	}
	public void setTot(String tot) {
		this.tot = tot;
	}
	public String getHn() {
		return hn;
	}
	public void setHn(String hn) {
		this.hn = hn;
	}
	public String getMn() {
		return mn;
	}
	public void setMn(String mn) {
		this.mn = mn;
	}
	public String getAom() {
		return aom;
	}
	public void setAom(String aom) {
		this.aom = aom;
	}
	public String getHhsc() {
		return hhsc;
	}
	public void setHhsc(String hhsc) {
		this.hhsc = hhsc;
	}
	public String getSin() {
		return sin;
	}
	public void setSin(String sin) {
		this.sin = sin;
	}
	public String getSd() {
		return sd;
	}
	public void setSd(String sd) {
		this.sd = sd;
	}
	public String getPono() {
		return pono;
	}
	public void setPono(String pono) {
		this.pono = pono;
	}
	public String getPano() {
		return pano;
	}
	public void setPano(String pano) {
		this.pano = pano;
	}
	public String getUn() {
		return un;
	}
	public void setUn(String un) {
		this.un = un;
	}
	public String getQnr() {
		return qnr;
	}
	public void setQnr(String qnr) {
		this.qnr = qnr;
	}
	public String getCr() {
		return cr;
	}
	public void setCr(String cr) {
		this.cr = cr;
	}
	public String getPoa() {
		return poa;
	}
	public void setPoa(String poa) {
		this.poa = poa;
	}
	public String getSa() {
		return sa;
	}
	public void setSa(String sa) {
		this.sa = sa;
	}
	public String getAa() {
		return aa;
	}
	public void setAa(String aa) {
		this.aa = aa;
	}
	public String getApa() {
		return apa;
	}
	public void setApa(String apa) {
		this.apa = apa;
	}
	public String getAc() {
		return ac;
	}
	public void setAc(String ac) {
		this.ac = ac;
	}
	public String getEd() {
		return ed;
	}
	public void setEd(String ed) {
		this.ed = ed;
	}
	public String getEm() {
		return em;
	}
	public void setEm(String em) {
		this.em = em;
	}
	public String getHhtop() {
		return hhtop;
	}
	public void setHhtop(String hhtop) {
		this.hhtop = hhtop;
	}
	public String getPotop() {
		return potop;
	}
	public void setPotop(String potop) {
		this.potop = potop;
	}

	public String getDri() {
		return dri;
	}
	public void setDri(String dri) {
		this.dri = dri;
	}
	public String getFree() {
		return free;
	}
	public void setFree(String free) {
		this.free = free;
	}

	public String getUserCard() {
		return userCard;
	}
	public void setUserCard(String userCard) {
		this.userCard = userCard;
	}
	@Override
	public String toString() {
		return "GrnEntity [grnId=" + grnId + ", bu=" + bu + ", tot=" + tot + ", hn=" + hn + ", mn=" + mn + ", aom="
				+ aom + ", hhsc=" + hhsc + ", sin=" + sin + ", sd=" + sd + ", pono=" + pono + ", pano=" + pano + ", un="
				+ un + ", qnr=" + qnr + ", cr=" + cr + ", poa=" + poa + ", sa=" + sa + ", aa=" + aa + ", apa=" + apa
				+ ", ac=" + ac + ", ed=" + ed + ", em=" + em + ", hhtop=" + hhtop + ", potop=" + potop + ", dri=" + dri
				+ ", free=" + free + ", userCard=" + userCard + "]";
	}
	
}
