package com.foxconn.entity;
 
import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;

import java.io.Serializable;

import javax.persistence.Id;

import org.springframework.format.annotation.NumberFormat;
 
public class TcDetailDTO implements Serializable, Cloneable {
	private static final long serialVersionUID = -5507251721354953831L;
	
	@Id
	@ExcelIgnore
	private String tcId;
	@ExcelProperty(value = { "BU Code" },index = 0)
	private String buCode;
	@ExcelProperty(value = { "核價人員" },index = 1)
	private String upDri;
	@ExcelProperty(value = { "鴻海料號" })
	private String hhPn;
	@ExcelProperty(value = { "机种" })
	private String machineModel;
	@ExcelProperty(value = { "新廠商代碼" })
	private String newVendorCode;
	@ExcelProperty(value = { "幣別" })
	private String currency;
	@ExcelProperty(value = { "生效日期" })
	private String effectiveDate;
	@ExcelProperty(value = { "失效日期" })
	private String expireDate;
	@ExcelProperty(value = { "生效方式" })
	private String effectiveWay;
	@ExcelProperty(value = { "配额" })
	private String allocation;
	@NumberFormat(pattern = "#.######")
	@ExcelProperty(value = { "蘋果指定單價" })
	private Double applePrice;
	@NumberFormat(pattern = "#.######")
	@ExcelProperty(value = { "實付價" })
	private Double actualPrice;
	@NumberFormat(pattern = "#.######")
	@ExcelProperty(value = { "應付價" })
	private Double apPrice;
	@ExcelProperty(value = { "收回方式" })
	private String action;
	@ExcelProperty(value = { "付款條件（應收代付）" })
	private String hhPayment;
	@ExcelProperty(value = { "付款條件（直接交易）" })
	private String fthPayment;
	@ExcelProperty(value = { "本版本上傳時間" })
	@DateTimeFormat(value = "yyyy-MM-dd HH:mm:ss")
	private String tcVersion;
	
	private String clickVersion;

	public String getBuCode() {
		return buCode;
	}

	public void setBuCode(String buCode) {
		this.buCode = buCode;
	}

	public String getUpDri() {
		return upDri;
	}

	public void setUpDri(String upDri) {
		this.upDri = upDri;
	}

	public String getHhPn() {
		return hhPn;
	}

	public void setHhPn(String hhPn) {
		this.hhPn = hhPn;
	}

	public String getMachineModel() {
		return machineModel;
	}

	public void setMachineModel(String machineModel) {
		this.machineModel = machineModel;
	}

	public String getNewVendorCode() {
		return newVendorCode;
	}

	public void setNewVendorCode(String newVendorCode) {
		this.newVendorCode = newVendorCode;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getExpireDate() {
		return expireDate;
	}

	public void setExpireDate(String expireDate) {
		this.expireDate = expireDate;
	}

	public String getEffectiveWay() {
		return effectiveWay;
	}

	public void setEffectiveWay(String effectiveWay) {
		this.effectiveWay = effectiveWay;
	}

	public String getAllocation() {
		return allocation;
	}

	public void setAllocation(String allocation) {
		this.allocation = allocation;
	}

	public Double getApplePrice() {
		return applePrice;
	}

	public void setApplePrice(Double applePrice) {
		this.applePrice = applePrice;
	}

	public Double getActualPrice() {
		return actualPrice;
	}

	public void setActualPrice(Double actualPrice) {
		this.actualPrice = actualPrice;
	}

	public Double getApPrice() {
		return apPrice;
	}

	public void setApPrice(Double apPrice) {
		this.apPrice = apPrice;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}




	public String getHhPayment() {
		return hhPayment;
	}




	public void setHhPayment(String hhPayment) {
		this.hhPayment = hhPayment;
	}




	public String getFthPayment() {
		return fthPayment;
	}




	public void setFthPayment(String fthPayment) {
		this.fthPayment = fthPayment;
	}




	public String getTcVersion() {
		return tcVersion;
	}




	public void setTcVersion(String tcVersion) {
		this.tcVersion = tcVersion;
	}




	public String getClickVersion() {
		return clickVersion;
	}




	public void setClickVersion(String clickVersion) {
		this.clickVersion = clickVersion;
	}




	public static void main(String[] args) {
//		List<String> list = new ArrayList<String>();
//		list.add("a");
//		list.add("b");
//		list.add("c");
////		String join = String.join(",", list);
//		
//		String join = list.stream().collect(Collectors.joining(","));
//		System.out.println(join);
		// 封装两个临时对象
//		ImmutablePair<String, Integer> a = ImmutablePair.of("a", 1);
//		System.out.println(a.getKey()+" "+a.getValue());
//		// 封装三个临时对象
//		ImmutableTriple<String, Integer, Date> b = ImmutableTriple.of("b", 2, new Date());
//		System.out.println(b.getLeft()+" "+b.getMiddle()+" "+b.getRight());
	}
}