package com.foxconn.entity;

import javax.persistence.Id;
import javax.persistence.Table;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;

@Table(name = "T_LH_TC_MS")
public class LH_TC_MSobj {
	private static final long serialVersionUID = 6504917183878631772L;
	@Id
	@ExcelIgnore
	private String lhId;
//	@ExcelProperty(value = { "BU" }, index = 0)
	private String bu;
	@ExcelProperty(value = { "貿易類型" }, index = 0)
	private String tradeType;
	@ExcelProperty(value = { "單頭名稱" }, index = 1)
	private String formHead;
	@ExcelProperty(value = { "廠商編號" }, index = 2)
	private String changshangCode;
	@ExcelProperty(value = { "廠商簡稱" }, index = 3)
	private String changshangName;
	@ExcelProperty(value = { "HH VendorCode" }, index = 4)
	private String hhVendorCode;
	@ExcelProperty(value = { "入庫單號" }, index = 5)
	private String stockinCode;
	@ExcelProperty(value = { "入庫時間" }, index = 6)
	private String stockinTime;
	@ExcelProperty(value = { "採購單號" }, index = 7)
	private String pruchaseCode;
	@ExcelProperty(value = { "料號" }, index = 8)
	private String materiel;
	@ExcelProperty(value = { "庫存單位" }, index = 9)
	private String unit;
	@ExcelProperty(value = { "未請款數量" }, index = 10)
	private String unsettledNum;
	@ExcelProperty(value = { "幣別" }, index = 11)
	private String currency;
	@ExcelProperty(value = { "poPrice" }, index = 12)
	private String poPrice;
	@ExcelProperty(value = { "入庫金額" }, index = 13)
	private String stockinMoney;
	@ExcelProperty(value = { "actualPrice" }, index = 14)
	private String actualPrice;
//	@ExcelIgnore
//	private String acPrice2;
	@ExcelProperty(value = { "apPrice" }, index = 15)
	private String apPrice;
//	@ExcelIgnore
//	private String apPrice2;
	@ExcelProperty(value = { "action" }, index = 16)
	private String action;
	@ExcelProperty(value = { "effectiveDate" }, index = 17)
	private String effectiveDate;
	@ExcelProperty(value = { "effectiveWay" }, index = 18)
	private String effectiveWay;
	@ExcelProperty(value = { "付款條件(HH)" }, index = 19)
	private String hhPaycondition;
	@ExcelProperty(value = { "付款條件(HFJ)" }, index = 20)
	private String hfjPaycondition;
	@ExcelProperty(value = { "付款條件(PO)" }, index = 21)
	private String poPaycondition;
	@ExcelIgnore
	private String free;
//	@ExcelProperty(value = { "写入时间" }, index = 24)
	@ExcelIgnore
	private String writetime;
//	@ExcelProperty(value = { "采购时间" }, index = 25)
	@ExcelIgnore
	private String purchaseDate;
//	----------------------------
	@ExcelIgnore
	private String tcEffectiveWay;
	@ExcelIgnore
	private String tcEffectiveDate;
	@ExcelIgnore
	private String tcExpireDate;
	@ExcelIgnore
	private String tcApPrice;
	@ExcelIgnore
	private String tcAcPrice;
	@ExcelIgnore
	private String tcApplePrice;
	@ExcelIgnore
	private String tcAction;
	@ExcelIgnore
	private String tcPaymentTerm;
	@ExcelIgnore
	private String tcUpDri;
	@ExcelIgnore
	private String tcOk;
//	-------------------------
	@ExcelIgnore
	private String msAcPrice;
	@ExcelIgnore
	private String msApPrice;
	@ExcelIgnore
	private String msEffectivedate;
	@ExcelIgnore
	private String msExchangeRate;
	@ExcelIgnore
	private String remark;
	public String getLhId() {
		return lhId;
	}
	public void setLhId(String lhId) {
		this.lhId = lhId;
	}
	public String getBu() {
		return bu;
	}
	public void setBu(String bu) {
		this.bu = bu;
	}
	public String getTradeType() {
		return tradeType;
	}
	public void setTradeType(String tradeType) {
		this.tradeType = tradeType;
	}
	public String getFormHead() {
		return formHead;
	}
	public void setFormHead(String formHead) {
		this.formHead = formHead;
	}
	public String getChangshangCode() {
		return changshangCode;
	}
	public void setChangshangCode(String changshangCode) {
		this.changshangCode = changshangCode;
	}
	public String getChangshangName() {
		return changshangName;
	}
	public void setChangshangName(String changshangName) {
		this.changshangName = changshangName;
	}
	public String getHhVendorCode() {
		return hhVendorCode;
	}
	public void setHhVendorCode(String hhVendorCode) {
		this.hhVendorCode = hhVendorCode;
	}
	public String getStockinCode() {
		return stockinCode;
	}
	public void setStockinCode(String stockinCode) {
		this.stockinCode = stockinCode;
	}
	public String getStockinTime() {
		return stockinTime;
	}
	public void setStockinTime(String stockinTime) {
		this.stockinTime = stockinTime;
	}
	public String getPruchaseCode() {
		return pruchaseCode;
	}
	public void setPruchaseCode(String pruchaseCode) {
		this.pruchaseCode = pruchaseCode;
	}
	public String getMateriel() {
		return materiel;
	}
	public void setMateriel(String materiel) {
		this.materiel = materiel;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public String getUnsettledNum() {
		return unsettledNum;
	}
	public void setUnsettledNum(String unsettledNum) {
		this.unsettledNum = unsettledNum;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getPoPrice() {
		return poPrice;
	}
	public void setPoPrice(String poPrice) {
		this.poPrice = poPrice;
	}
	public String getStockinMoney() {
		return stockinMoney;
	}
	public void setStockinMoney(String stockinMoney) {
		this.stockinMoney = stockinMoney;
	}
	public String getActualPrice() {
		return actualPrice;
	}
	public void setActualPrice(String actualPrice) {
		this.actualPrice = actualPrice;
	}
	public String getApPrice() {
		return apPrice;
	}
	public void setApPrice(String apPrice) {
		this.apPrice = apPrice;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public String getEffectiveWay() {
		return effectiveWay;
	}
	public void setEffectiveWay(String effectiveWay) {
		this.effectiveWay = effectiveWay;
	}
	public String getHhPaycondition() {
		return hhPaycondition;
	}
	public void setHhPaycondition(String hhPaycondition) {
		this.hhPaycondition = hhPaycondition;
	}
	public String getHfjPaycondition() {
		return hfjPaycondition;
	}
	public void setHfjPaycondition(String hfjPaycondition) {
		this.hfjPaycondition = hfjPaycondition;
	}
	public String getPoPaycondition() {
		return poPaycondition;
	}
	public void setPoPaycondition(String poPaycondition) {
		this.poPaycondition = poPaycondition;
	}
	public String getFree() {
		return free;
	}
	public void setFree(String free) {
		this.free = free;
	}
	public String getWritetime() {
		return writetime;
	}
	public void setWritetime(String writetime) {
		this.writetime = writetime;
	}
	public String getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(String purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	public String getTcEffectiveWay() {
		return tcEffectiveWay;
	}
	public void setTcEffectiveWay(String tcEffectiveWay) {
		this.tcEffectiveWay = tcEffectiveWay;
	}
	public String getTcEffectiveDate() {
		return tcEffectiveDate;
	}
	public void setTcEffectiveDate(String tcEffectiveDate) {
		this.tcEffectiveDate = tcEffectiveDate;
	}
	public String getTcExpireDate() {
		return tcExpireDate;
	}
	public void setTcExpireDate(String tcExpireDate) {
		this.tcExpireDate = tcExpireDate;
	}
	public String getTcApPrice() {
		return tcApPrice;
	}
	public void setTcApPrice(String tcApPrice) {
		this.tcApPrice = tcApPrice;
	}
	public String getTcAcPrice() {
		return tcAcPrice;
	}
	public void setTcAcPrice(String tcAcPrice) {
		this.tcAcPrice = tcAcPrice;
	}
	public String getTcApplePrice() {
		return tcApplePrice;
	}
	public void setTcApplePrice(String tcApplePrice) {
		this.tcApplePrice = tcApplePrice;
	}
	public String getTcAction() {
		return tcAction;
	}
	public void setTcAction(String tcAction) {
		this.tcAction = tcAction;
	}
	public String getTcPaymentTerm() {
		return tcPaymentTerm;
	}
	public void setTcPaymentTerm(String tcPaymentTerm) {
		this.tcPaymentTerm = tcPaymentTerm;
	}
	public String getTcUpDri() {
		return tcUpDri;
	}
	public void setTcUpDri(String tcUpDri) {
		this.tcUpDri = tcUpDri;
	}
	public String getTcOk() {
		return tcOk;
	}
	public void setTcOk(String tcOk) {
		this.tcOk = tcOk;
	}
	public String getMsAcPrice() {
		return msAcPrice;
	}
	public void setMsAcPrice(String msAcPrice) {
		this.msAcPrice = msAcPrice;
	}
	public String getMsApPrice() {
		return msApPrice;
	}
	public void setMsApPrice(String msApPrice) {
		this.msApPrice = msApPrice;
	}
	public String getMsEffectivedate() {
		return msEffectivedate;
	}
	public void setMsEffectivedate(String msEffectivedate) {
		this.msEffectivedate = msEffectivedate;
	}
	public String getMsExchangeRate() {
		return msExchangeRate;
	}
	public void setMsExchangeRate(String msExchangeRate) {
		this.msExchangeRate = msExchangeRate;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	@Override
	public String toString() {
		return "LH_TC_MSobj [lhId=" + lhId + ", bu=" + bu + ", tradeType=" + tradeType + ", formHead=" + formHead
				+ ", changshangCode=" + changshangCode + ", changshangName=" + changshangName + ", hhVendorCode="
				+ hhVendorCode + ", stockinCode=" + stockinCode + ", stockinTime=" + stockinTime + ", pruchaseCode="
				+ pruchaseCode + ", materiel=" + materiel + ", unit=" + unit + ", unsettledNum=" + unsettledNum
				+ ", currency=" + currency + ", poPrice=" + poPrice + ", stockinMoney=" + stockinMoney
				+ ", actualPrice=" + actualPrice + ", apPrice=" + apPrice + ", action=" + action + ", effectiveDate="
				+ effectiveDate + ", effectiveWay=" + effectiveWay + ", hhPaycondition=" + hhPaycondition
				+ ", hfjPaycondition=" + hfjPaycondition + ", poPaycondition=" + poPaycondition + ", free=" + free
				+ ", writetime=" + writetime + ", purchaseDate=" + purchaseDate + ", tcEffectiveWay=" + tcEffectiveWay
				+ ", tcEffectiveDate=" + tcEffectiveDate + ", tcExpireDate=" + tcExpireDate + ", tcApPrice=" + tcApPrice
				+ ", tcAcPrice=" + tcAcPrice + ", tcApplePrice=" + tcApplePrice + ", tcAction=" + tcAction
				+ ", tcPaymentTerm=" + tcPaymentTerm + ", tcUpDri=" + tcUpDri + ", tcOk=" + tcOk + ", msAcPrice="
				+ msAcPrice + ", msApPrice=" + msApPrice + ", msEffectivedate=" + msEffectivedate + ", msExchangeRate="
				+ msExchangeRate + ", remark=" + remark + "]";
	}

	
}
