package com.foxconn.entity;

import java.io.Serializable;

import javax.persistence.Id;
import javax.persistence.Table;

@Table(name="t_exchange")
public class exChangeEntity implements Serializable {
private static final long serialVersionUID = -4879399342140965063L;
@Id
private String exchangeId;
private String exchangeDate;
private Double exchangeNum;
 
	public String getExchangeId() {
		return this.exchangeId;
	}

	public void setExchangeId(String exchangeId) {
		this.exchangeId = exchangeId;
	}

	public String getExchangeDate() {
		return this.exchangeDate;
	}

	public void setExchangeDate(String exchangeDate) {
		this.exchangeDate = exchangeDate;
	}

	public Double getExchangeNum() {
		return this.exchangeNum;
	}

	public void setExchangeNum(Double exchangeNum) {
		this.exchangeNum = exchangeNum;
	}

	public String toString() {
		return "exChangeEntity [exchangeId=" + this.exchangeId + ", exchangeDate=" + this.exchangeDate
				+ ", exchangeNum=" + this.exchangeNum + "]";
	}
}

