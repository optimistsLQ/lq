package com.foxconn.entity;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import java.io.Serializable;
import javax.persistence.Id;
import javax.persistence.Table;
 
@Table(name = "T_MS_GRN")
public class MGgrnDetail implements Serializable {
	private static final long serialVersionUID = 3332975632747339597L;
	@Id
	@ExcelIgnore
	private String msId;
	@ExcelProperty(value = { "入库单号" }, index = 1)
	private String grnNo;
	@ExcelProperty(value = { "入库日期" }, index = 2)
	private String stockInDate;
	@ExcelProperty(value = { "币别" }, index = 12)
	private String currency;
	@ExcelProperty(value = { "ac价格" }, index = 15)
	private Double acPrice;
	@ExcelProperty(value = { "ap价格" }, index = 16)
	private Double apPrice;
	@ExcelProperty(value = { "生效日期" }, index = 17)
	private String effectiveDate;
	private String exChangeRate;
	private String exChange_ac;
	private String exChange_ap;
	public String getMsId() {
		return msId;
	}
	public void setMsId(String msId) {
		this.msId = msId;
	}
	public String getGrnNo() {
		return grnNo;
	}
	public void setGrnNo(String grnNo) {
		this.grnNo = grnNo;
	}
	public String getStockInDate() {
		return stockInDate;
	}
	public void setStockInDate(String stockInDate) {
		this.stockInDate = stockInDate;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public Double getAcPrice() {
		return acPrice;
	}
	public void setAcPrice(Double acPrice) {
		this.acPrice = acPrice;
	}
	public Double getApPrice() {
		return apPrice;
	}
	public void setApPrice(Double apPrice) {
		this.apPrice = apPrice;
	}
	public String getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public String getExChangeRate() {
		return exChangeRate;
	}
	public void setExChangeRate(String exChangeRate) {
		this.exChangeRate = exChangeRate;
	}
	public String getExChange_ac() {
		return exChange_ac;
	}
	public void setExChange_ac(String exChange_ac) {
		this.exChange_ac = exChange_ac;
	}
	public String getExChange_ap() {
		return exChange_ap;
	}
	public void setExChange_ap(String exChange_ap) {
		this.exChange_ap = exChange_ap;
	}
	@Override
	public String toString() {
		return "MGgrnDetail [msId=" + msId + ", grnNo=" + grnNo + ", stockInDate=" + stockInDate + ", currency="
				+ currency + ", acPrice=" + acPrice + ", apPrice=" + apPrice + ", effectiveDate=" + effectiveDate
				+ ", exChangeRate=" + exChangeRate + ", exChange_ac=" + exChange_ac + ", exChange_ap=" + exChange_ap
				+ "]";
	}
	
}