package com.foxconn.entity;
 
import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import com.foxconn.controller.TCController;
import com.foxconn.utils.MD5Util;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.ImmutableTriple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.format.annotation.NumberFormat;
 
@Table(name = "T_TC_DETAIL")
public class TcDetail implements Serializable, Cloneable {
	private static final long serialVersionUID = -5507251721354953831L;
	@Id
	@ExcelIgnore
	private String tcId;
	@ExcelProperty(value = { "BU Code" }, index = 3)
	private String buCode;
	@ExcelProperty(value = { "核價人員" }, index = 6)
	private String upDri;
	@ExcelProperty(value = { "鴻海料號" }, index = 7)
	private String hhPn;
	@ExcelProperty(value = { "机种" }, index = 9)
	private String machineModel;
	@ExcelProperty(value = { "新廠商代碼" }, index = 19)
	private String newVendorCode;
	@ExcelProperty(value = { "幣別" }, index = 27)
	private String currency;
	@ExcelProperty(value = { "生效日期" }, index = 30 )
	private String effectiveDate;
	@ExcelProperty(value = { "失效日期" }, index = 31 )
	private String expireDate;
	@ExcelProperty(value = { "生效方式" }, index = 32)
	private String effectiveWay;
	@ExcelProperty(value = { "配额" }, index = 33)
	private String allocation;
	@NumberFormat(pattern = "#.######")
	@ExcelProperty(value = { "蘋果指定單價" }, index = 34)
	private Double applePrice;
	@NumberFormat(pattern = "#.######")
	@ExcelProperty(value = { "實付價" }, index = 38)
	private Double actualPrice;
	@NumberFormat(pattern = "#.######")
	@ExcelProperty(value = { "應付價" }, index = 40)
	private Double apPrice;
	@ExcelProperty(value = { "收回方式" }, index = 42)
	private String action;
	@ExcelProperty(value = { "付款條件（應收代付）" }, index = 50)
	private String hhPayment;
	@ExcelProperty(value = { "付款條件（直接交易）" }, index = 52)
	private String fthPayment;
	@ExcelProperty(value = { "本版本上傳時間" }, index = 66)
	@DateTimeFormat(value = "yyyy-MM-dd HH:mm:ss")
	private String tcVersion;
	
	private String clickVersion;
	// 存放MD5加密信息
	@ExcelIgnore
	private String md5Msg;
	private String filed1;
	private static final Logger logger = LoggerFactory.getLogger(TcDetail.class);
	public String toMD5() {
		String msg = buCode+upDri+hhPn+machineModel+newVendorCode+currency+effectiveDate+expireDate+effectiveWay+applePrice+actualPrice+apPrice+action+hhPayment+fthPayment;
		return MD5Util.getMD5(msg);
	}
	
	public String getTcId() {
		return tcId;
	}
	public void setTcId(String tcId) {
		this.tcId = tcId;
	}
	public String getBuCode() {
		return buCode;
	}
	public void setBuCode(String buCode) {
		this.buCode = buCode;
	}
	public String getUpDri() {
		return upDri;
	}
	public void setUpDri(String upDri) {
		this.upDri = upDri;
	}
	public String getHhPn() {
		return hhPn;
	}
	public void setHhPn(String hhPn) {
		this.hhPn = hhPn;
	}
	public String getNewVendorCode() {
		return newVendorCode;
	}
	public void setNewVendorCode(String newVendorCode) {
		this.newVendorCode = newVendorCode;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public String getExpireDate() {
		return expireDate;
	}
	public void setExpireDate(String expireDate) {
		this.expireDate = expireDate;
	}
	public String getEffectiveWay() {
		return effectiveWay;
	}
	public void setEffectiveWay(String effectiveWay) {
		this.effectiveWay = effectiveWay;
	}
	public Double getApplePrice() {
		return applePrice;
	}
	public void setApplePrice(Double applePrice) {
		this.applePrice = applePrice;
	}
	public Double getActualPrice() {
		return actualPrice;
	}
	public void setActualPrice(Double actualPrice) {
		this.actualPrice = actualPrice;
	}
	public Double getApPrice() {
		return apPrice;
	}
	public void setApPrice(Double apPrice) {
		this.apPrice = apPrice;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getHhPayment() {
		return hhPayment;
	}
	public void setHhPayment(String hhPayment) {
		this.hhPayment = hhPayment;
	}
	public String getFthPayment() {
		return fthPayment;
	}
	public void setFthPayment(String fthPayment) {
		this.fthPayment = fthPayment;
	}
	public String getTcVersion() {
		return tcVersion;
	}
	public void setTcVersion(String tcVersion) {
		this.tcVersion = tcVersion;
	}
	public String getClickVersion() {
		return clickVersion;
	}
	public void setClickVersion(String clickVersion) {
		this.clickVersion = clickVersion;
	}
	
	public String getMd5Msg() {
		return md5Msg;
	}

	public void setMd5Msg(String md5Msg) {
		this.md5Msg = md5Msg;
	}

	public String getFiled1() {
		return filed1;
	}
	public void setFiled1(String filed1) {
		this.filed1 = filed1;
	}
	public String getMachineModel() {
		return machineModel;
	}
	public void setMachineModel(String machineModel) {
		this.machineModel = machineModel;
	}

	public String getAllocation() {
		return allocation;
	}

	public void setAllocation(String allocation) {
		this.allocation = allocation;
	}

	@Override
	public String toString() {
		return "TcDetail [tcId=" + tcId + ", buCode=" + buCode + ", upDri=" + upDri + ", hhPn=" + hhPn
				+ ", machineModel=" + machineModel + ", newVendorCode=" + newVendorCode + ", currency=" + currency
				+ ", effectiveDate=" + effectiveDate + ", expireDate=" + expireDate + ", effectiveWay=" + effectiveWay
				+ ", Allocation=" + allocation + ", applePrice=" + applePrice + ", actualPrice=" + actualPrice
				+ ", apPrice=" + apPrice + ", action=" + action + ", hhPayment=" + hhPayment + ", fthPayment="
				+ fthPayment + ", tcVersion=" + tcVersion + ", clickVersion=" + clickVersion + ", md5Msg=" + md5Msg
				+ ", filed1=" + filed1 + "]";
	}

	public static void main(String[] args) {
//		List<String> list = new ArrayList<String>();
//		list.add("a");
//		list.add("b");
//		list.add("c");
////		String join = String.join(",", list);
//		
//		String join = list.stream().collect(Collectors.joining(","));
//		System.out.println(join);
		// 封装两个临时对象
//		ImmutablePair<String, Integer> a = ImmutablePair.of("a", 1);
//		System.out.println(a.getKey()+" "+a.getValue());
//		// 封装三个临时对象
//		ImmutableTriple<String, Integer, Date> b = ImmutableTriple.of("b", 2, new Date());
//		System.out.println(b.getLeft()+" "+b.getMiddle()+" "+b.getRight());
	}
}