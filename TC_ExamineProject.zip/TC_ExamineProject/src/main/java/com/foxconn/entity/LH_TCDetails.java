package com.foxconn.entity;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import java.io.Serializable;
import javax.persistence.Id;
import javax.persistence.Table;
 
@Table(name = "T_LH_TCRESULT")
public class LH_TCDetails implements Serializable {
	private static final long serialVersionUID = 6504917183878631772L;
	@Id
	@ExcelIgnore
	private String lhId;
	@ExcelProperty(value = { "BU" }, index = 0)
	@HeadStyle(fillForegroundColor = 25)
	private String bu;
	@ExcelProperty(value = { "貿易類型" }, index = 1)
	@HeadStyle(fillForegroundColor = 25)
	private String tradeType;
	@ExcelProperty(value = { "單頭名稱" }, index = 2)
	@HeadStyle(fillForegroundColor = 25)
	private String formHead;
	@ExcelProperty(value = { "廠商編號" }, index = 3)
	@HeadStyle(fillForegroundColor = 25)
	private String changshangCode;
	@ExcelProperty(value = { "廠商簡稱" }, index = 4)
	@HeadStyle(fillForegroundColor = 25)
	private String changshangName;
	@ExcelProperty(value = { "HH VendorCode" }, index = 5)
	@HeadStyle(fillForegroundColor = 25)
	private String hhVendorCode;
	@ExcelProperty(value = { "入庫單號" }, index = 6)
	@HeadStyle(fillForegroundColor = 25)
	private String stockinCode;
	@ExcelProperty(value = { "入庫時間" }, index = 7)
	@HeadStyle(fillForegroundColor = 25)
	private String stockinTime;
	@ExcelProperty(value = { "採購單號" }, index = 8)
	@HeadStyle(fillForegroundColor = 25)
	private String pruchaseCode;
	@ExcelProperty(value = { "料號" }, index = 9)
	@HeadStyle(fillForegroundColor = 25)
	private String materiel;
	@ExcelProperty(value = { "庫存單位" }, index = 10)
	@HeadStyle(fillForegroundColor = 25)
	private String unit;
	@ExcelProperty(value = { "未請款數量" }, index = 11)
	@HeadStyle(fillForegroundColor = 25)
	private String unsettledNum;
	@ExcelProperty(value = { "幣別" }, index = 12)
	@HeadStyle(fillForegroundColor = 25)
	private String currency;
	@ExcelProperty(value = { "poPrice" }, index = 13)
	@HeadStyle(fillForegroundColor = 25)
	private String poPrice;
	@ExcelProperty(value = { "入庫金額" }, index = 14)
	@HeadStyle(fillForegroundColor = 25)
	private String stockinMoney;
	@ExcelProperty(value = { "actualPrice" }, index = 15)
	@HeadStyle(fillForegroundColor = 25)
	private String actualPrice;
	@ExcelProperty(value = { "apPrice" }, index = 16)
	@HeadStyle(fillForegroundColor = 25)
	private String apPrice;
	@ExcelProperty(value = { "action" }, index = 17)
	@HeadStyle(fillForegroundColor = 25)
	private String action;
	@ExcelProperty(value = { "effectiveDate" }, index = 18)
	@HeadStyle(fillForegroundColor = 25)
	private String effectiveDate;
	@ExcelProperty(value = { "effectiveWay" }, index = 19)
	@HeadStyle(fillForegroundColor = 25)
	private String effectiveWay;
	@ExcelProperty(value = { "付款條件(HH)" }, index = 20)
	@HeadStyle(fillForegroundColor = 25)
	private String hhPaycondition;
	@ExcelProperty(value = { "付款條件(HFJ)" }, index = 21)
	@HeadStyle(fillForegroundColor = 25)
	private String hfjPaycondition;
	@ExcelProperty(value = { "付款條件(PO)" }, index = 22)
	@HeadStyle(fillForegroundColor = 25)
	private String poPaycondition;
	@ExcelProperty(value = { "apDri" })
	@HeadStyle(fillForegroundColor = 25)
	private String apDri;
	@ExcelProperty(value = { "写入时间" })
	@HeadStyle(fillForegroundColor = 25)
	private String writetime;
	@ExcelProperty(value = { "采购时间" })
	@HeadStyle(fillForegroundColor = 50)
	private String purchaseDate;
//	------------------------
	@ExcelProperty(value = { "發票號碼" })
	@HeadStyle(fillForegroundColor = 57)
	private String billCode;
	//发票日期
	@ExcelProperty(value = { "發票日期" })
	@HeadStyle(fillForegroundColor = 57)
    private String billDate;
	//发票单价
	@ExcelProperty(value = { "發票單價" })
	@HeadStyle(fillForegroundColor = 57)
    private String billPrice;
	//发票金额
	@ExcelProperty(value = { "發票金額" })
	@HeadStyle(fillForegroundColor = 57)
    private String billMoney;
	//付款日期
	@ExcelProperty(value = { "付款日期" })
	@HeadStyle(fillForegroundColor = 57)
    private String payDate;
	//紧急程度
	@ExcelProperty(value = { "緊急程度" })
	@HeadStyle(fillForegroundColor = 57)
    private String urgent;
	  //结报单号
	@ExcelProperty(value = { "結報單號" })
	@HeadStyle(fillForegroundColor = 57)
    private String jbCode;
	@ExcelProperty(value = { "結報日期" })
	@HeadStyle(fillForegroundColor = 57)
	private String jbtime;
//	    ---------------
	@ExcelProperty(value = { "tcEffectiveWay" })
	@HeadStyle(fillForegroundColor = 52)
	private String tcEffectiveWay;
	@ExcelProperty(value = { "tcEffectiveDate" })
	@HeadStyle(fillForegroundColor = 52)
	private String tcEffectiveDate;
	@ExcelProperty(value = { "tcExpireDate" })
	@HeadStyle(fillForegroundColor = 52)
	private String tcExpireDate;
	@ExcelProperty(value = { "tcApPrice" })
	@HeadStyle(fillForegroundColor = 52)
	private String tcApPrice;
	@ExcelProperty(value = { "tcApPrice2" })
	@HeadStyle(fillForegroundColor = 34)
	private String apPrice2;
	@ExcelProperty(value = { "tcAcPrice" })
	@HeadStyle(fillForegroundColor = 52)
	private String tcAcPrice;
	@ExcelProperty(value = { "tcAcPrice2" })
	@HeadStyle(fillForegroundColor = 34)
	private String acPrice2;
	@ExcelProperty(value = { "tcApplePrice" })
	@HeadStyle(fillForegroundColor = 52)
	private String tcApplePrice;
	@ExcelProperty(value = { "tcAction" })
	@HeadStyle(fillForegroundColor = 52)
	private String tcAction;
	@ExcelProperty(value = { "tcPaymentTerm" })
	@HeadStyle(fillForegroundColor = 52)
	private String tcPaymentTerm;
	@ExcelProperty(value = { "tcUpDri" })
	@HeadStyle(fillForegroundColor = 52)
	private String tcUpDri;
	@HeadStyle(fillForegroundColor = 52)
	private String tcOk;
//	------------------
	@ExcelProperty(value = { "msAcPrice" })
	@HeadStyle(fillForegroundColor = 29)
	private String msAcPrice;
	@ExcelProperty(value = { "msApPrice" })
	@HeadStyle(fillForegroundColor = 29)
	private String msApPrice;
	@ExcelProperty(value = { "ms生效日期" })
	@HeadStyle(fillForegroundColor = 29)
	private String msEffectivedate;
	@ExcelProperty(value = "当月汇率")
	@HeadStyle(fillForegroundColor = 29)
	private String msExchangeRate;
//    --------------------
	@ExcelProperty(value = "系統價高check")
	@HeadStyle(fillForegroundColor = 24)
	private String poMinusBill;
	@ExcelProperty(value = "Invoice price check")
	@HeadStyle(fillForegroundColor = 24)
	private String billMinusAp;
	@ExcelProperty(value = "Discount/amt")
	@HeadStyle(fillForegroundColor = 24)
	private String apMinusAc;
	@ExcelProperty(value = "AppleContractPrice")
	@HeadStyle(fillForegroundColor = 24)
	private String apMinusApple;
	@ExcelProperty(value = "[應付日]check")
	@HeadStyle(fillForegroundColor = 24)
	private String paydayMinusYingpayday;
	@ExcelProperty(value = "審核人員")
	@HeadStyle(fillForegroundColor = 24)
	private String checkMan;
	@ExcelProperty(value = "審核日期")
	@HeadStyle(fillForegroundColor = 24)
	private String checkTime;
	@ExcelProperty(value = "審核通過")
	@HeadStyle(fillForegroundColor = 24)
	private String checkPass;
	
	private String free;
	
	public String getApDri() {
		return apDri;
	}
	public void setApDri(String apDri) {
		this.apDri = apDri;
	}
	public String getLhId() {
		return lhId;
	}
	public void setLhId(String lhId) {
		this.lhId = lhId;
	}
	public String getBu() {
		return bu;
	}
	public void setBu(String bu) {
		this.bu = bu;
	}
	public String getTradeType() {
		return tradeType;
	}
	public void setTradeType(String tradeType) {
		this.tradeType = tradeType;
	}
	public String getFormHead() {
		return formHead;
	}
	public void setFormHead(String formHead) {
		this.formHead = formHead;
	}
	public String getChangshangCode() {
		return changshangCode;
	}
	public void setChangshangCode(String changshangCode) {
		this.changshangCode = changshangCode;
	}
	public String getChangshangName() {
		return changshangName;
	}
	public void setChangshangName(String changshangName) {
		this.changshangName = changshangName;
	}
	public String getHhVendorCode() {
		return hhVendorCode;
	}
	public void setHhVendorCode(String hhVendorCode) {
		this.hhVendorCode = hhVendorCode;
	}
	public String getStockinCode() {
		return stockinCode;
	}
	public void setStockinCode(String stockinCode) {
		this.stockinCode = stockinCode;
	}
	public String getStockinTime() {
		return stockinTime;
	}
	public void setStockinTime(String stockinTime) {
		this.stockinTime = stockinTime;
	}
	public String getPruchaseCode() {
		return pruchaseCode;
	}
	public void setPruchaseCode(String pruchaseCode) {
		this.pruchaseCode = pruchaseCode;
	}
	public String getMateriel() {
		return materiel;
	}
	public void setMateriel(String materiel) {
		this.materiel = materiel;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public String getUnsettledNum() {
		return unsettledNum;
	}
	public void setUnsettledNum(String unsettledNum) {
		this.unsettledNum = unsettledNum;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getPoPrice() {
		return poPrice;
	}
	public void setPoPrice(String poPrice) {
		this.poPrice = poPrice;
	}
	public String getStockinMoney() {
		return stockinMoney;
	}
	public void setStockinMoney(String stockinMoney) {
		this.stockinMoney = stockinMoney;
	}
	public String getActualPrice() {
		return actualPrice;
	}
	public void setActualPrice(String actualPrice) {
		this.actualPrice = actualPrice;
	}
	public String getApPrice() {
		return apPrice;
	}
	public void setApPrice(String apPrice) {
		this.apPrice = apPrice;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public String getEffectiveWay() {
		return effectiveWay;
	}
	public void setEffectiveWay(String effectiveWay) {
		this.effectiveWay = effectiveWay;
	}
	public String getHhPaycondition() {
		return hhPaycondition;
	}
	public void setHhPaycondition(String hhPaycondition) {
		this.hhPaycondition = hhPaycondition;
	}
	public String getHfjPaycondition() {
		return hfjPaycondition;
	}
	public void setHfjPaycondition(String hfjPaycondition) {
		this.hfjPaycondition = hfjPaycondition;
	}
	public String getPoPaycondition() {
		return poPaycondition;
	}
	public void setPoPaycondition(String poPaycondition) {
		this.poPaycondition = poPaycondition;
	}
	public String getWritetime() {
		return writetime;
	}
	public void setWritetime(String writetime) {
		this.writetime = writetime;
	}
	public String getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(String purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	public String getTcEffectiveWay() {
		return tcEffectiveWay;
	}
	public void setTcEffectiveWay(String tcEffectiveWay) {
		this.tcEffectiveWay = tcEffectiveWay;
	}
	public String getTcEffectiveDate() {
		return tcEffectiveDate;
	}
	public void setTcEffectiveDate(String tcEffectiveDate) {
		this.tcEffectiveDate = tcEffectiveDate;
	}
	public String getTcExpireDate() {
		return tcExpireDate;
	}
	public void setTcExpireDate(String tcExpireDate) {
		this.tcExpireDate = tcExpireDate;
	}
	public String getTcApPrice() {
		return tcApPrice;
	}
	public void setTcApPrice(String tcApPrice) {
		this.tcApPrice = tcApPrice;
	}
	public String getTcAcPrice() {
		return tcAcPrice;
	}
	public void setTcAcPrice(String tcAcPrice) {
		this.tcAcPrice = tcAcPrice;
	}
	public String getTcApplePrice() {
		return tcApplePrice;
	}
	public void setTcApplePrice(String tcApplePrice) {
		this.tcApplePrice = tcApplePrice;
	}
	public String getTcAction() {
		return tcAction;
	}
	public void setTcAction(String tcAction) {
		this.tcAction = tcAction;
	}
	public String getTcPaymentTerm() {
		return tcPaymentTerm;
	}
	public void setTcPaymentTerm(String tcPaymentTerm) {
		this.tcPaymentTerm = tcPaymentTerm;
	}
	public String getTcUpDri() {
		return tcUpDri;
	}
	public void setTcUpDri(String tcUpDri) {
		this.tcUpDri = tcUpDri;
	}

	public String getJbtime() {
		return jbtime;
	}
	public void setJbtime(String jbtime) {
		this.jbtime = jbtime;
	}
	//	public String getMsAcPrice() {
//		return msAcPrice;
//	}
//	public void setMsAcPrice(String msAcPrice) {
//		this.msAcPrice = msAcPrice;
//	}
//	public String getMsApPrice() {
//		return msApPrice;
//	}
//	public void setMsApPrice(String msApPrice) {
//		this.msApPrice = msApPrice;
//	}
//	public String getMsEffectivedate() {
//		return msEffectivedate;
//	}
//	public void setMsEffectivedate(String msEffectivedate) {
//		this.msEffectivedate = msEffectivedate;
//	}
//	public String getMsExchangeRate() {
//		return msExchangeRate;
//	}
//	public void setMsExchangeRate(String msExchangeRate) {
//		this.msExchangeRate = msExchangeRate;
//	}
	public String getAcPrice2() {
		return acPrice2;
	}
	public void setAcPrice2(String acPrice2) {
		this.acPrice2 = acPrice2;
	}
	public String getApPrice2() {
		return apPrice2;
	}
	public void setApPrice2(String apPrice2) {
		this.apPrice2 = apPrice2;
	}
	public String getBillCode() {
		return billCode;
	}
	public void setBillCode(String billCode) {
		this.billCode = billCode;
	}
	public String getBillDate() {
		return billDate;
	}
	public void setBillDate(String billDate) {
		this.billDate = billDate;
	}
	public String getBillPrice() {
		return billPrice;
	}
	public void setBillPrice(String billPrice) {
		this.billPrice = billPrice;
	}
	public String getBillMoney() {
		return billMoney;
	}
	public void setBillMoney(String billMoney) {
		this.billMoney = billMoney;
	}
	public String getPayDate() {
		return payDate;
	}
	public void setPayDate(String payDate) {
		this.payDate = payDate;
	}
	public String getUrgent() {
		return urgent;
	}
	public void setUrgent(String urgent) {
		this.urgent = urgent;
	}
	public String getJbCode() {
		return jbCode;
	}
	public void setJbCode(String jbCode) {
		this.jbCode = jbCode;
	}
	public String getPoMinusBill() {
		return poMinusBill;
	}
	public void setPoMinusBill(String poMinusBill) {
		this.poMinusBill = poMinusBill;
	}
	public String getBillMinusAp() {
		return billMinusAp;
	}
	public void setBillMinusAp(String billMinusAp) {
		this.billMinusAp = billMinusAp;
	}
	public String getApMinusAc() {
		return apMinusAc;
	}
	public void setApMinusAc(String apMinusAc) {
		this.apMinusAc = apMinusAc;
	}
	public String getApMinusApple() {
		return apMinusApple;
	}
	public void setApMinusApple(String apMinusApple) {
		this.apMinusApple = apMinusApple;
	}
	public String getPaydayMinusYingpayday() {
		return paydayMinusYingpayday;
	}
	public void setPaydayMinusYingpayday(String paydayMinusYingpayday) {
		this.paydayMinusYingpayday = paydayMinusYingpayday;
	}
	public String getCheckMan() {
		return checkMan;
	}
	public void setCheckMan(String checkMan) {
		this.checkMan = checkMan;
	}
	public String getCheckTime() {
		return checkTime;
	}
	public void setCheckTime(String checkTime) {
		this.checkTime = checkTime;
	}
	public String getCheckPass() {
		return checkPass;
	}
	public void setCheckPass(String checkPass) {
		this.checkPass = checkPass;
	}
	public String getTcOk() {
		return tcOk;
	}
	public void setTcOk(String tcOk) {
		this.tcOk = tcOk;
	}
	public String getMsAcPrice() {
		return msAcPrice;
	}
	public void setMsAcPrice(String msAcPrice) {
		this.msAcPrice = msAcPrice;
	}
	public String getMsApPrice() {
		return msApPrice;
	}
	public void setMsApPrice(String msApPrice) {
		this.msApPrice = msApPrice;
	}
	public String getMsEffectivedate() {
		return msEffectivedate;
	}
	public void setMsEffectivedate(String msEffectivedate) {
		this.msEffectivedate = msEffectivedate;
	}
	public String getMsExchangeRate() {
		return msExchangeRate;
	}
	public void setMsExchangeRate(String msExchangeRate) {
		this.msExchangeRate = msExchangeRate;
	}
	public String getFree() {
		return free;
	}
	public void setFree(String free) {
		this.free = free;
	}

}