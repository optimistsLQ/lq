package com.foxconn.entity;

import java.io.Serializable;

import javax.persistence.Id;
import javax.persistence.Table;

import com.alibaba.excel.annotation.ExcelIgnore;
@Table(name="T_JSTABLE")
public class JSDetail implements Serializable{
	private static final long serialVersionUID = -3002366423131081080L;

	@Id
	@ExcelIgnore
	private String jsId;

	private String bu;
	
    private String tradeType;

    private String formHead;

    private String changshangCode;

    private String changshangName;

    private String hhVendorCode;

    private String stockinCode;

    private String stockinTime;

    private String pruchaseCode;

    private String materiel;

    private String unit;

    private Double unsettledNum;

    private String currency;

    private Double poPrice;

    private Double stockinMoney;

    private Double actualPrice;

    private Double apPrice;

    private String action;

    private String effectiveDate;

    private String effectiveWay;

    private String hhPaycondition;

    private String hfjPaycondition;

    private String poPaycondition;
    
    private String apDri;
//  標識是否免費樣品
    private String free;

//发票号码
    private String billCode;
//发票日期
    private String billDate;
//发票单价
    private String billPrice;
//发票金额
    private String billMoney;
//待扣款（Y/N）
    private String waitcutpay;
//付款日期
    private String payDate;
//紧急程度
    private String urgent;
//结报单号
    private String jbCode;
    // 里面存放匹配方式（代表自动匹配，‘上传匹配’代表手动上传匹配）
    private String matchType;
//	结报人
    private String jbdri;
//    结报时间
    private String jbtime;
    
    private String writetime;
    private String tcOk;// 这个字段表示该条数据是否被审核，如果已被审核会写入已审核
    private String hascheck;
    
    
    
    public String getApDri() {
		return apDri;
	}

	public void setApDri(String apDri) {
		this.apDri = apDri;
	}

	public String getHascheck() {
		return hascheck;
	}

	public void setHascheck(String hascheck) {
		this.hascheck = hascheck;
	}

	public JSDetail() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public String getJsId() {
        return jsId;
    }

    public String getWritetime() {
		return writetime;
	}


	public void setWritetime(String writetime) {
		this.writetime = writetime;
	}


	public void setJsId(String jsId) {
        this.jsId = jsId == null ? null : jsId.trim();
    }

    public String getTradeType() {
        return tradeType;
    }

    public void setTradeType(String tradeType) {
        this.tradeType = tradeType == null ? null : tradeType.trim();
    }

    public String getFormHead() {
        return formHead;
    }

    public void setFormHead(String formHead) {
        this.formHead = formHead == null ? null : formHead.trim();
    }

    public String getFree() {
		return free;
	}

	public void setFree(String free) {
		this.free = free;
	}

	public String getChangshangCode() {
        return changshangCode;
    }

    public void setChangshangCode(String changshangCode) {
        this.changshangCode = changshangCode == null ? null : changshangCode.trim();
    }

    public String getChangshangName() {
        return changshangName;
    }

    public void setChangshangName(String changshangName) {
        this.changshangName = changshangName == null ? null : changshangName.trim();
    }

    public String getHhVendorCode() {
        return hhVendorCode;
    }

    public void setHhVendorCode(String hhVendorCode) {
        this.hhVendorCode = hhVendorCode == null ? null : hhVendorCode.trim();
    }

    public String getStockinCode() {
        return stockinCode;
    }

    public void setStockinCode(String stockinCode) {
        this.stockinCode = stockinCode == null ? null : stockinCode.trim();
    }

    public String getStockinTime() {
        return stockinTime;
    }

    public void setStockinTime(String stockinTime) {
        this.stockinTime = stockinTime == null ? null : stockinTime.trim();
    }

    public String getPruchaseCode() {
        return pruchaseCode;
    }

    public void setPruchaseCode(String pruchaseCode) {
        this.pruchaseCode = pruchaseCode == null ? null : pruchaseCode.trim();
    }

    public String getMateriel() {
        return materiel;
    }

    public void setMateriel(String materiel) {
        this.materiel = materiel == null ? null : materiel.trim();
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit == null ? null : unit.trim();
    }

    public Double getUnsettledNum() {
        return unsettledNum;
    }

    public void setUnsettledNum(Double unsettledNum) {
        this.unsettledNum = unsettledNum;
    }

   

    public String getCurrency() {
		return currency;
	}


	public void setCurrency(String currency) {
		this.currency = currency;
	}


	public Double getPoPrice() {
        return poPrice;
    }

    public void setPoPrice(Double poPrice) {
        this.poPrice = poPrice;
    }

    public Double getStockinMoney() {
        return stockinMoney;
    }

    public void setStockinMoney(Double stockinMoney) {
        this.stockinMoney = stockinMoney;
    }

    public Double getActualPrice() {
        return actualPrice;
    }

    public void setActualPrice(Double actualPrice) {
        this.actualPrice = actualPrice;
    }

    public Double getApPrice() {
        return apPrice;
    }

    public void setApPrice(Double apPrice) {
        this.apPrice = apPrice;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action == null ? null : action.trim();
    }

    public String getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate == null ? null : effectiveDate.trim();
    }

    public String getEffectiveWay() {
        return effectiveWay;
    }

    public void setEffectiveWay(String effectiveWay) {
        this.effectiveWay = effectiveWay == null ? null : effectiveWay.trim();
    }

    public String getHhPaycondition() {
        return hhPaycondition;
    }

    public void setHhPaycondition(String hhPaycondition) {
        this.hhPaycondition = hhPaycondition == null ? null : hhPaycondition.trim();
    }

    public String getHfjPaycondition() {
        return hfjPaycondition;
    }

    public void setHfjPaycondition(String hfjPaycondition) {
        this.hfjPaycondition = hfjPaycondition == null ? null : hfjPaycondition.trim();
    }

    public String getPoPaycondition() {
        return poPaycondition;
    }

    public void setPoPaycondition(String poPaycondition) {
        this.poPaycondition = poPaycondition == null ? null : poPaycondition.trim();
    }

    public String getBillCode() {
        return billCode;
    }

    public void setBillCode(String billCode) {
        this.billCode = billCode == null ? null : billCode.trim();
    }

    public String getBillDate() {
        return billDate;
    }

    public void setBillDate(String billDate) {
        this.billDate = billDate == null ? null : billDate.trim();
    }

    public String getBillPrice() {
        return billPrice;
    }

    public void setBillPrice(String billPrice) {
        this.billPrice = billPrice;
    }

    public String getBillMoney() {
        return billMoney;
    }

    public void setBillMoney(String billMoney) {
        this.billMoney = billMoney;
    }

    public String getWaitcutpay() {
        return waitcutpay;
    }

    public void setWaitcutpay(String waitcutpay) {
        this.waitcutpay = waitcutpay == null ? null : waitcutpay.trim();
    }

    public String getPayDate() {
        return payDate;
    }

    public void setPayDate(String payDate) {
        this.payDate = payDate == null ? null : payDate.trim();
    }

    public String getUrgent() {
        return urgent;
    }

    public void setUrgent(String urgent) {
        this.urgent = urgent == null ? null : urgent.trim();
    }

	public String getJbCode() {
		return jbCode;
	}

	public void setJbCode(String jbCode) {
		this.jbCode = jbCode;
	}


	public String getBu() {
		return bu;
	}


	public void setBu(String bu) {
		this.bu = bu;
	}


	public String getMatchType() {
		return matchType;
	}


	public void setMatchType(String matchType) {
		this.matchType = matchType;
	}


	public String getJbdri() {
		return jbdri;
	}


	public void setJbdri(String jbdri) {
		this.jbdri = jbdri;
	}


	public String getJbtime() {
		return jbtime;
	}


	public void setJbtime(String jbtime) {
		this.jbtime = jbtime;
	}


	public String getTcOk() {
		return tcOk;
	}


	public void setTcOk(String tcOk) {
		this.tcOk = tcOk;
	}

	@Override
	public String toString() {
		return "JSDetail [jsId=" + jsId + ", bu=" + bu + ", tradeType=" + tradeType + ", formHead=" + formHead
				+ ", changshangCode=" + changshangCode + ", changshangName=" + changshangName + ", hhVendorCode="
				+ hhVendorCode + ", stockinCode=" + stockinCode + ", stockinTime=" + stockinTime + ", pruchaseCode="
				+ pruchaseCode + ", materiel=" + materiel + ", unit=" + unit + ", unsettledNum=" + unsettledNum
				+ ", currency=" + currency + ", poPrice=" + poPrice + ", stockinMoney=" + stockinMoney
				+ ", actualPrice=" + actualPrice + ", apPrice=" + apPrice + ", action=" + action + ", effectiveDate="
				+ effectiveDate + ", effectiveWay=" + effectiveWay + ", hhPaycondition=" + hhPaycondition
				+ ", hfjPaycondition=" + hfjPaycondition + ", poPaycondition=" + poPaycondition + ", apDri=" + apDri
				+ ", free=" + free + ", billCode=" + billCode + ", billDate=" + billDate + ", billPrice=" + billPrice
				+ ", billMoney=" + billMoney + ", waitcutpay=" + waitcutpay + ", payDate=" + payDate + ", urgent="
				+ urgent + ", jbCode=" + jbCode + ", matchType=" + matchType + ", jbdri=" + jbdri + ", jbtime=" + jbtime
				+ ", writetime=" + writetime + ", tcOk=" + tcOk + ", hascheck=" + hascheck + "]";
	}

}