package com.foxconn.controller;

import com.alibaba.excel.EasyExcel;
import com.alibaba.fastjson.JSONObject;
import com.foxconn.entity.LH_TCDetails;
import com.foxconn.entity.LH_TC_MSobj;
import com.foxconn.entity.LH_TC_MSobjDTO;
import com.foxconn.entity.TcDetail;
import com.foxconn.entity.TcDetailDTO;
import com.foxconn.service.LH_TCService;
import com.foxconn.service.LH_TC_MSobjService;
import com.foxconn.service.TcService;
import com.foxconn.utils.CompearLHANDMS;
import com.foxconn.utils.CompearLHANDTC;
import com.foxconn.utils.ERPClient;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.lang3.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("TC")
public class TCController {
	private static final Logger logger = LoggerFactory.getLogger(TCController.class);

	@Autowired
	private ERPClient ERPClient;

	@Autowired
	private TcService Tcs;

	@Autowired
	private LH_TCService LH_TCservice;

//	@Autowired
//	private ExChangeService exChangeService;
	@Autowired
	private CompearLHANDTC compearLH_TC;
	@Autowired
	private CompearLHANDMS compearLH_MS;
	@Autowired
	private LH_TC_MSobjService LH_TC_MSservice;
	

	
	
	

	/**爬取TC报表数据并存储数据库T_TC_detail表
	 * @return
	 */
	@RequestMapping({ "/getTCReportData.do" })
	@ResponseBody
	public String getTCReportData() {
		System.out.println("------controller获取TC报表-------");
		String loginMsg = this.ERPClient.login();
		int a = 0;
		int b = 0;
		if ("登录成功".equals(loginMsg)) {
			Map<String, Object> map = ERPClient.getTCReportData();
			List<TcDetail> tcReportDataList = (List<TcDetail>) map.get("dataList");
			List<String> md5List = (List<String>) map.get("md5List");
			// 1.先删除MD5List里的以前的重复数据
			a = Tcs.delTcByMd5(md5List);
			b = this.Tcs.addTCList(tcReportDataList);
		}
		return loginMsg += "Tc del:"+a+" - add:"+b;
	}

	/**
	 * 查找TC报表资料,每次查询2W条最新的数据
	 * @return
	 */
	@RequestMapping({ "/getCompearLH_TC.do" })
	@ResponseBody
	public String compearLH_TC() {
		String str = "";
		Date now = new Date();
		List<LH_TC_MSobj> okAll = new ArrayList<LH_TC_MSobj>();
		// 1 从erp獲取拉貨明細
		List<LH_TC_MSobj> lhList = null;
		List<String> grnList = null;
		String loginMsg = ERPClient.login();
		if ("登录成功".equals(loginMsg)) {
			Map<String, Object> map = ERPClient.getERPData_new();
			lhList = (List<LH_TC_MSobj>) map.get("data");
			grnList = (List<String>) map.get("GRNList");
			
		} else {return loginMsg;}
		if (ObjectUtils.isEmpty(lhList)) {
			str = "没有拉货明细";
			return str;
		}
		//去掉重複的lhList裡的數據
		logger.info("去重前條數："+lhList.size());
		List<String> repeatData = LH_TC_MSservice.findByGrnList(grnList);
		logger.info("重複條數："+repeatData.size());
		Iterator<LH_TC_MSobj> iterator = lhList.iterator();
		w:while (iterator.hasNext()) {
			LH_TC_MSobj LH = iterator.next();
			for (String grn : repeatData) {
				if (LH.getStockinCode().equalsIgnoreCase(grn)) {
					iterator.remove();
					continue w;
				}
			}
		}
		logger.info("去重後條數："+lhList.size());
		// 将TC分批次（分10次，每次20000条）和拉货对比
		int count = 0;
		for (int i = 1; i <= 10 ;i++) {
			Map<String, Object> compearLHandTCMap = compearLHandTC(lhList, i );
			String msg = (String) compearLHandTCMap.get("msg");
			try {
				count += Integer.parseInt(msg);
			} catch (Exception e) {
				// TODO: handle exception
				
			}
			List<LH_TC_MSobj> NGList = (List<LH_TC_MSobj>) compearLHandTCMap.get("NGList");
			if ("NG没有TC报表数据".equals(msg)) {
				logger.info(" 第"+i+"次比对，对比OK"+count+"条，对比NG"+NGList.size()+"条 - "+msg);
				str = msg;
				return str;
			} 
			logger.info("NGList:"+NGList.size()+" 第"+i+"次比对LH_TC");
			if (ObjectUtils.isEmpty(NGList)) {
				break;
			}
			logger.info("NGList"+NGList.get(1));
			lhList = NGList;
		}
		System.out.println("-----"+str);
		return str;
	}
	
	/**对比LH_TC
	 * @param lhList 拉货明细
	 * @param i tc报表页码
	 * @return
	 */
	public Map<String, Object> compearLHandTC(List<LH_TC_MSobj> lhList, int i) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		// 分页查询TC报表资料20000条，并整理成map《》
		Map<String, List<TcDetail>> tcDetailMap = this.Tcs.getTCSourceTop2W(i,20000);
//		System.out.println("tcDetailMap:"+tcDetailMap.size());
		if (ObjectUtils.isEmpty(tcDetailMap)) {
			resultMap.put("NGList", lhList);
			resultMap.put("msg", "NG没有TC报表数据");
			return resultMap;
		}
		boolean bool;
		if (i == 1) {
			bool = true;
		} else {
			bool = false;
		}
		return this.compearLH_TC.CompearLHandTC(lhList, tcDetailMap,bool);
		
		
	}
	
	/**jstable 拉货明细和ms对比
	 * @return
	 */
	@RequestMapping({ "/compearMS_grn.do" })
	@ResponseBody
	public String compearMS_grn() {
		String str = compearLH_MS.lhCompearMs();
		System.out.println(str);
		return str;
	}

	@RequestMapping({ "/toIndex.do" })
	public String toIndexPage() {
		return "table";
	}

	@RequestMapping({ "/getLH_TCWriteTime.do" })
	@ResponseBody
	public String getLH_TCWriteTime(String startDate, String endDate) {
		startDate = startDate.replaceAll("-", "") + "000000";
		endDate = endDate.replaceAll("-", "") + "240000";
		List<String> writeTimeList = this.LH_TCservice.getLH_TCWriteTime(startDate, endDate);
		System.out.println(writeTimeList);
		return JSONObject.toJSONString(writeTimeList);
	}

//	@RequestMapping({ "/getLH_TCResultExcel.do" })
//	public String getLH_TCResultExcel(HttpServletResponse response, String writetime) {
//		List<LH_TCDetails> list = this.LH_TCservice.getLH_TCResultByWritetime(writetime);
//		try {
//			response.setContentType("application/vnd.ms-excel");
//			response.setCharacterEncoding("utf-8");
//			String fileName = URLEncoder.encode("LH_TC对比明细", "UTF-8");
//			response.setHeader("Content-disposition", "attachment;filename=" + fileName + ".xlsx");
//			EasyExcel.write((OutputStream) response.getOutputStream(), LH_TCDetails_DTO.class).sheet("模板").doWrite(list);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return null;
//	}
	
	@RequestMapping({ "/getLH_MSExcel.do" })
	public void getLH_MSExcel(HttpServletResponse response,String reservation) {
		String startTime = reservation.substring(0, 10).replaceAll("-", "");
		String endTime = reservation.substring(13).replaceAll("-", "");
		startTime += "000000";
		endTime += "240000";
//		System.out.println(startTime+"---"+endTime);
		List<LH_TC_MSobj> list = LH_TC_MSservice.listLH_TC_MSdata(endTime);
		System.out.println(list.get(0));
		try {
			response.setContentType("application/vnd.ms-excel");
			response.setCharacterEncoding("utf-8");
			String fileName = URLEncoder.encode("LH_TC_MS对比结果", "UTF-8");
			response.setHeader("Content-disposition", "attachment;filename=" + fileName + ".xlsx");
			EasyExcel.write(response.getOutputStream(), LH_TC_MSobjDTO.class).sheet("模板").doWrite(list);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@RequestMapping({ "readTXT.do" })
	@ResponseBody
	public Map<String, String> readTXT() {
		Map<String, String> map = new HashMap<>();
		Properties pro = new Properties();
		try (FileInputStream in = new FileInputStream("DataSource.properties")) {
			pro.load(in);
			Enumeration<?> enum1 = pro.propertyNames();
			while (enum1.hasMoreElements()) {
				String strKey = (String) enum1.nextElement();
				String strValue = pro.getProperty(strKey);
				map.put(strKey, strValue);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return map;
	}

	@RequestMapping({ "/saveDataSource.do" })
	@ResponseBody
	public String saveDataSource(@RequestBody Map<String, String> obj) {
		String path = "DataSource.properties";
		File file = new File(path);
		Properties pro = new Properties();
		try (FileOutputStream out = new FileOutputStream(file)) {
			for (Map.Entry<String, String> entity : obj.entrySet())
				pro.setProperty(entity.getKey(), entity.getValue());
			pro.store(out, (String) null);
			return "保存成功";
		} catch (Exception e) {
			e.printStackTrace();
			return "保存失敗";
		}
	}
//
//	/**爬取MS_GRN清单
//	 * @param minStockInDate  2020-12-28 拉货明细最早的入库日期
//	 * @return
//	 */
//	@RequestMapping({ "/getMC_GRNData.do" })
//	@ResponseBody
//	public Map<String, Object> getMS_GRNData(String minStockInDate) {
//		// 查询所有月份对应的汇率
//		Map<String, Double> exChangeMap = exChangeService.listAllToMap();
//		Map<String, Object> ms_GRNMap = null;
//		String loginMsg = ERPClient.login();
//		if (loginMsg.contains("登录成功")) {
//			System.out.println("----登录成功,开始爬取MS_GRN-----");
//			ms_GRNMap = ERPClient.getMS_GRN(minStockInDate, exChangeMap);
////			《GrnNo， MGgrnDetail对象》
//			Map<String, MGgrnDetail> MGgrn = (Map<String, MGgrnDetail>) ms_GRNMap.get("data");
//			System.out.println("----MS_GRN解析成功-----" + MGgrn.size());
////			boolean b = false;
////			for (Map.Entry<String, MGgrnDetail> obj : MGgrn.entrySet()) {
////				b = true;
////				System.out.println((String) obj.getKey() + "  --ms_GRNMap--   " + obj.getValue());
////				if (b)
////					break;
////			}
//		}
//		return ms_GRNMap;
//	}
	
	/**根据日期从数据库下载当日的TC数据
	 * @param date
	 * @return
	 */
	@RequestMapping("/downLoadTC.do")
	@ResponseBody
	public String downLoadTC(String date, HttpServletResponse response) {
		List<TcDetail> list = Tcs.listTCByClickVersion(date);
//		System.out.println(list.get(10));
		response.setContentType("application/vnd.ms-excel");
		try {
		response.setCharacterEncoding("utf-8");
		String fileName = URLEncoder.encode("TC明细"+date, "UTF-8");
		response.setHeader("Content-disposition", "attachment;filename=" + fileName + ".xlsx");
		EasyExcel.write(response.getOutputStream(), TcDetailDTO.class).sheet("TC_"+date).doWrite(list);
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	@RequestMapping("/aaa.do")
	@ResponseBody
	public String aaa() {
		List<LH_TCDetails> lhList = LH_TCservice.getLHFromJStable();
		System.out.println(lhList.size());
		return null;
	}
}
