package com.foxconn.controller;

import com.foxconn.entity.exChangeEntity;
import com.foxconn.service.ExChangeService;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping({ "Ex" })
public class ExChangeController {
	@Autowired
	private ExChangeService exChangeService;

	@RequestMapping({ "/addEX.do" })
	@ResponseBody
	public String addEX(exChangeEntity ex) {
		System.out.println(ex);
		int i = this.exChangeService.addExChange(ex);
		return String.valueOf(i);
	}

	@RequestMapping({ "/delEX.do" })
	@ResponseBody
	public String delEX(String exchangeId) {
		int i = this.exChangeService.delExChangeById(exchangeId);
		return String.valueOf(i);
	}

	@RequestMapping({ "/updateEX.do" })
	@ResponseBody
	public String updateEX(exChangeEntity ex) {
		int i = this.exChangeService.updateExChange(ex);
		return String.valueOf(i);
	}

	@RequestMapping({ "/listAllData.do" })
	@ResponseBody
	public List<exChangeEntity> listAllData() {
		return this.exChangeService.listAll();
	}

	@RequestMapping({ "/toExChange.do" })
	public String toExChangeHtml() {
		return "exChange";
	}


}
