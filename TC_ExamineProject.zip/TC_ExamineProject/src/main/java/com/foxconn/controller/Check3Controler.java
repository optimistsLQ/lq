package com.foxconn.controller;

import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.alibaba.excel.EasyExcel;
import com.foxconn.entity.LH_TCDetails;
import com.foxconn.entity.MGgrnDetail;
import com.foxconn.entity.TcDetail;
import com.foxconn.service.ExChangeService;
import com.foxconn.service.JSservice;
import com.foxconn.service.LH_TCService;
import com.foxconn.service.TcService;
import com.foxconn.utils.CompearLHANDMS;
import com.foxconn.utils.CompearLHANDTC;
import com.foxconn.utils.ERPClient;

@Controller
@RequestMapping("check")
public class Check3Controler {
	private static final Logger logger = LoggerFactory.getLogger(TCController.class);
	@Autowired
	private ERPClient ERPClient;
	@Autowired
	private LH_TCService LH_TCservice;
	@Autowired
	private TcService Tcs;
	@Autowired
	private CompearLHANDTC compearLH_TC;
	@Autowired
	private CompearLHANDMS compearLH_MS;
	@Autowired
	private ExChangeService exChangeService;
	@Autowired
	private JSservice jsService;
	/**拉货和TC第二次进行实时比对，结果和第一次比对的结果进行校验（apPrice）
	 * 本次TC报表不存入数据库
	 * @return
	 */
	@RequestMapping("/LH_TCcompar_second.do")
	@ResponseBody
	public String LH_TCcompar_second(HttpServletRequest req) {
		// 2.去jatable表查询已结报，并去LH_TC_MS表获取上次TC匹配价格
		List<LH_TCDetails> jslist = LH_TCservice.listNeedCheckData();
	//  这里将jstable表里的免费样品也全部拿过来放入resultList一并存入数据库
		List<LH_TCDetails> freeData = LH_TCservice.listFreeHasNoCheckData();
		List<LH_TCDetails> resultList = new ArrayList<LH_TCDetails>();
		List<String> stockInCodeList = new ArrayList<String>();
		if (ObjectUtils.isEmpty(jslist) && ObjectUtils.isEmpty(freeData)) {
			return "LH_TC没有可进行二次匹配的数据";
		}
		//当jslist不为空时才执行实时匹配TC，MS和check逻辑
		if (ObjectUtils.isNotEmpty(jslist)) {
			
			// 1.实时抓取TC
			String loginMsg = this.ERPClient.login();
			List<TcDetail> tcReportDataList = null;
			if ("登录成功".equals(loginMsg)) {
				Map<String, Object> map = ERPClient.getTCReportData();
				tcReportDataList = (List<TcDetail>) map.get("dataList");
			} else {return loginMsg;}
			
			if (ObjectUtils.isEmpty(tcReportDataList)) {
				return "TC无数据";
			} 
			//3.将tcReportDataList转成map<key = tcDetail.getBuCode() + tcDetail.getHhPn() + tcDetail.getNewVendorCode()+ tcDetail.getCurrency():val=LH_TCDetails>
			Map<String, List<TcDetail>> tCMap = Tcs.TClistToMap(tcReportDataList);
			
			
			//4. 开始执行比对逻辑
			System.out.println("对比之前："+jslist.size()+" - "+tCMap.size());
			Map<String, Object> result = compearLH_TC.CompearLHandTC_second(jslist, tCMap);
			String msg = (String) result.get("msg");
			if (!"OK".equals(msg)) {
				logger.info(msg);
				return msg;
			}
			List<LH_TCDetails> dataList = (List<LH_TCDetails>) result.get("LH_TCdata");
			String minStockInTime = (String) result.get("minStockInDate");// 最早入库日期
			System.out.println("对比完TC的数量："+dataList.size()+" 最早入库日期："+minStockInTime);
			// 5.获取MS数据
			Map<String, Object> ms_GRNData = this.getMS_GRNData(minStockInTime);
			Map<String, MGgrnDetail> MGgrn = (Map<String, MGgrnDetail>) ms_GRNData.get("data");
			System.out.println("msgrn数量："+MGgrn.size());
			if (ObjectUtils.isEmpty(MGgrn)) {
				logger.info("msgrn获取失败");
				return "msgrn获取失败";
			}
			// 6.写入Ms信息
			Map<String, Object> map = compearLH_MS.compLH_MS_second(dataList, MGgrn);
			resultList.addAll((List<LH_TCDetails>) map.get("dataList"));
			stockInCodeList.addAll((List<String>) map.get("stockInCodeList"));
			
		}
		
		if (ObjectUtils.isNotEmpty(freeData)) {
			//  这里将jstable表里的免费样品也全部拿过来放入resultList一并存入数据库
			for (LH_TCDetails lh_TCDetails : freeData) {
				if (StringUtils.isEmpty(lh_TCDetails.getStockinCode())) {
					System.out.println("空："+lh_TCDetails);
				}
				stockInCodeList.add(lh_TCDetails.getStockinCode());
			}
			resultList.addAll(freeData);
			logger.info("freeData:"+freeData.size());
		}
		// 7.存入数据库
		LH_TCservice.addLH_TClist(resultList);
		// 8.修改jstable表的状态
		if (ObjectUtils.isNotEmpty(stockInCodeList)) {
			jsService.updateHasCheck(stockInCodeList);
		}
//		req.getSession().setAttribute("checkDownLoad", dataList);
		
		return "check_OK";
	}
	
	
	/**下载
	 * @param response
	 * @param req
	 */
	@RequestMapping("/downLoadCheck3.do")
	@ResponseBody
	public void checkDownLoad(HttpServletResponse response,String reservation) {
//		List<LH_TCDetails> listData = (List<LH_TCDetails>) req.getSession().getAttribute("checkDownLoad");
		String startTime = reservation.substring(0, 10).replaceAll("-", "");
		String endTime = reservation.substring(13).replaceAll("-", "");
//		startTime += "000000";
//		endTime += "240000";
		List<LH_TCDetails> listData = LH_TCservice.listDataByJbtime(startTime, endTime);
//		System.out.println("13:"+listData.get(0).getWritetime());
		//下载
		try {
			response.setContentType("application/vnd.ms-excel");
			response.setCharacterEncoding("utf-8");
			String fileName = URLEncoder.encode("check明细", "UTF-8");
			response.setHeader("Content-disposition", "attachment;filename=" + fileName + ".xlsx");
			EasyExcel.write((OutputStream) response.getOutputStream(), LH_TCDetails.class).sheet("check明细").doWrite(listData);
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}
	
	
	/**爬取MS_GRN清单
	 * @param minStockInDate  2020-12-28 拉货明细最早的入库日期
	 * @return
	 */
	@RequestMapping({ "/getMC_GRNData.do" })
	@ResponseBody
	public Map<String, Object> getMS_GRNData(String minStockInDate) {
		// 查询所有月份对应的汇率
		Map<String, Double> exChangeMap = exChangeService.listAllToMap();
		Map<String, Object> ms_GRNMap = null;
		String loginMsg = ERPClient.login();
		if (loginMsg.contains("登录成功")) {
			System.out.println("----登录成功,开始爬取MS_GRN-----");
			ms_GRNMap = ERPClient.getMS_GRN(minStockInDate, exChangeMap);
//			《GrnNo， MGgrnDetail对象》
			Map<String, MGgrnDetail> MGgrn = (Map<String, MGgrnDetail>) ms_GRNMap.get("data");
			System.out.println("----MS_GRN解析成功-----" + MGgrn.size());
//			boolean b = false;
//			for (Map.Entry<String, MGgrnDetail> obj : MGgrn.entrySet()) {
//				b = true;
//				System.out.println((String) obj.getKey() + "  --ms_GRNMap--   " + obj.getValue());
//				if (b)
//					break;
//			}
		}
		return ms_GRNMap;
	}
	
}
