package com.foxconn.mapper;

import com.foxconn.entity.exChangeEntity;
import java.util.Map;
import tk.mybatis.mapper.common.Mapper;

public abstract interface exChangeEntityMapper extends Mapper<exChangeEntity> {
	public abstract Map<String, Double> listAllToMap();
}
