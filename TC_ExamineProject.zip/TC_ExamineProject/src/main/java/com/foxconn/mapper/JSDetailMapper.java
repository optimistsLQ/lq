package com.foxconn.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import com.foxconn.entity.JSDetail;

import tk.mybatis.mapper.common.Mapper;

public interface JSDetailMapper extends Mapper<JSDetail>{
	int addJSList(@Param ("JSList")List<JSDetail> JSList, @Param("field") List<String> field);

	List<JSDetail> findByGRNCode(@Param ("gRNList")List<String> gRNList);

//	List<String> getWritetime();

	List<JSDetail> getHasNoJbCode();

	int updateJSDetailJieBaoCode(@Param ("updateMap")Map<String, String> updateMap);
	
	int updateJSDetailJieBaoCode(@Param ("id") String id, @Param ("JieBaoCode") String JieBaoCode, 
			                      @Param ("finalReportTime") String finalReportTime, @Param ("dri") String dri);

	List<JSDetail> listDataByJbTime(@Param ("startTime")String startTime, @Param ("endTime")String endTime);

	List<JSDetail> listDataByWritetime(@Param ("startTime")String startTime, @Param ("endTime")String endTime);

	List<JSDetail> listNeedRewriteJieBaoCode(@Param ("excludeVal")String excludeVal);

	int updateJStableByGrnList(@Param ("oKListgrn")List<String> oKListgrn);

	List<JSDetail> listJstableNoMs();

	int updateJs(@Param ("list")List<JSDetail> list);

	List<JSDetail> listMS_LHdata(@Param ("startTime")String startTime, @Param ("endTime")String endTime);

	int updateHasCheck(@Param ("stockInCodeList")List<String> stockInCodeList);

}