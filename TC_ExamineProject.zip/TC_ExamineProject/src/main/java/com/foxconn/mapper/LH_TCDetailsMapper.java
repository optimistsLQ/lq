package com.foxconn.mapper;

import com.foxconn.entity.LH_TCDetails;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

public abstract interface LH_TCDetailsMapper extends Mapper<LH_TCDetails> {
	public abstract int addLH_TClist(@Param("list") List<LH_TCDetails> paramList,
			@Param("fieldList") List<String> paramList1);

	public abstract List<String> getLH_TCWriteTime(@Param("startDate") String paramString1,
			@Param("endDate") String paramString2);

	public abstract List<LH_TCDetails> listNeedCheckData();

	public abstract int updateLH_TClist(@Param("lh_tcList") List<LH_TCDetails> lh_tcList);

	public abstract List<LH_TCDetails> getLHFromJStable();

	public abstract int updateTC(@Param("oKList") List<LH_TCDetails> oKList);

	public abstract List<LH_TCDetails> listDataByJbtime(@Param("startTime")String startTime, @Param("endTime")String endTime);

	public abstract List<LH_TCDetails> listFreeHasNoCheckData();
}
