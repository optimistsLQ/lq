package com.foxconn.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.foxconn.entity.LH_TC_MSobj;

import tk.mybatis.mapper.common.Mapper;

public interface LH_TC_MSobjMapper extends Mapper<LH_TC_MSobj>{

	int addLH_TC_MSlist(@Param("list") List<LH_TC_MSobj> list, @Param("fieldList") List<String> fieldList);

	List<String> findByGrnList(@Param("grnList")List<String> grnList);

	List<LH_TC_MSobj> listNoMsData();

	int updateMs(@Param("list")List<LH_TC_MSobj> list);

	List<LH_TC_MSobj> listLH_TC_MSdata(@Param("endTime")String endTime);
}
