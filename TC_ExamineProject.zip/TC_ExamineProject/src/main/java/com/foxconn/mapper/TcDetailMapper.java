package com.foxconn.mapper;

import com.foxconn.entity.TcDetail;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

public interface TcDetailMapper extends Mapper<TcDetail> {
	public int addTCList(@Param("tcList") List<TcDetail> paramList, @Param("field") List<String> paramList1);

	public List<TcDetail> listTCByClickVersion(@Param("clickVersion") String clickVersion);

	public List<String> getDateListByDateTime(@Param("morning") String paramString1,
			@Param("night") String paramString2);

	public Integer delTcByMd5(@Param("mD5List") List<String> mD5List);

	public List<TcDetail> listDataTop2W(@Param("start") int start,@Param("length") int length);
}
